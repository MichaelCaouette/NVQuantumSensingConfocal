# -*- coding: utf-8 -*-
"""
Created on Wed Feb 17 16:18:03 2021


@author: Childresslab
"""
# Get some base modules
from pulses import ChannelPulses, PulsePatternBlock, Sequence
import api_fpga as _fc
from gui_signal_generator import GUISignalGenerator
from gui_pulse_runner import GuiPulseRunner
from count_interpreter import ProcessFPGACounts

# Other cool imports 
import time
import numpy as np
from spinmob import egg
import traceback
_p = traceback.print_last #Very usefull command to use for getting the last-not-printed error


_debug_enabled     = False
def _debug(*a):
    if _debug_enabled: 
        s = []
        for x in a: s.append(str(x))
        print(', '.join(s))

class GUIESR(egg.gui.Window):
    """
    GUI for preparing and reading ESR measurement. 
    It is meant to be run and connected with the pulse runner. 
    
        
    It uses various modules:
        - The signal generator
        - The pulse runner
        - It has its own sequence builder for building the pulse sequence
        - It has its own databox plotter for showing the data
    
    """   
    
    def __init__(self, fpga, name="ESR ! ESR ! ESR !", size=[1000,500]): 
        """
        Initialize

        fpga:
            "FPGA_api" object from api_fpga.py. 
            This is the object shared amoung the GUIs for controlling the fpga. 
            The session of he fpga must already be open.  
            
        """    
        _debug('GUIESR: __init__')
        _debug('If you fall – I’ll be there. – Floor')
        
        # Run the basic stuff for the initialization
        egg.gui.Window.__init__(self, title=name, size=size)

        # Steal the fpga, mouhahaha
        # And connect
        self.fpga = fpga
        # Overid a method that, hopefully, should prevent the freeze out of the
        # gui for long pulse sequence. ESR tends to be long for the FPGA.
        self.fpga.dummy_event_pulse_is_long = self.process_events 
        
        # Build the GUI
        self._initialize_GUI()
        
    def _initialize_GUI(self):
        """
        Fill up the GUI
        """        
        _debug('GUIESR: _initialize_GUI')
        
        # A button for preparing stuff
        self.button_prepare_experiment = egg.gui.Button('Prepare all settings',
                                                        tip='Prepare the measurement before running')
        self.place_object(self.button_prepare_experiment, row=0, column=0)
        self.connect(self.button_prepare_experiment.signal_clicked, 
                     self._button_prepare_experiment_clicked)  

        # Place the pulse runner
        self.gui_pulse_runner = GuiPulseRunner(self.fpga)
        self.place_object(self.gui_pulse_runner, 
                          row=1, column=0, column_span=2)
        # Overid the method for processing properly after the loop.
        self.gui_pulse_runner.dummy_after_one_loop = self.after_one_loop     
        
        # Add the signal generator
        self.sig_gen = GUISignalGenerator(show=False)
        self.gui_sig_gen    = self.sig_gen.window    
        self.place_object(self.gui_sig_gen, 
                          row=1, column = 2)
        
        # tree dictionnarry for the settings
        self.treeDic_settings = egg.gui.TreeDictionary(autosettings_path='setting_ESR_pulse')
        self.place_object(self.treeDic_settings, 
                          row=2, column=0, column_span=2)

        self.treeDic_settings.add_parameter('Power', -20, 
                                            type='float', step=0.01, 
                                            bounds=[-50,30], suffix=' dBm',
                                            tip='Constant power of the RF')
        self.treeDic_settings.add_parameter('f_min', 1, 
                                            type='float', step=0.1, 
                                            bounds=[0,10], suffix=' GHz',
                                            tip='Minimum frequency to sweep')
        self.treeDic_settings.add_parameter('f_max', 1, 
                                            type='float', step=0.1, 
                                            bounds=[0,10], suffix=' GHz',
                                            tip='Maximum frequency to sweep')        
        self.treeDic_settings.add_parameter('N', 200, 
                                            type='int', step=10, 
                                            bounds=[0,None],
                                            tip='Number of points to sweep')         
        
        self.treeDic_settings.add_parameter('dt_off', 5000, 
                                            type='float', step=100, 
                                            bounds=[0,None], suffix=' us',
                                            tip='Duration of the initial off state') 
        self.treeDic_settings.add_parameter('dt_on', 5000, 
                                            type='float', step=100, 
                                            bounds=[0,None], suffix=' us',
                                            tip='Duration of the on state: read, shine the laser, send RF, modulate') 
        self.treeDic_settings.add_parameter('dt_delay_laser', 500, 
                                            type='float', step=10, 
                                            bounds=[0,None], suffix=' us',
                                            tip='Delay to start the laser before the ON state')         

        self.treeDic_settings.add_parameter('want_a_reference', False, 
                                            type='bool',
                                            tip='Weither or not to have a reference counting (without the RF).\nIf yes, the counting duration for the ref will be the same as the ON time.')  
        
        self.treeDic_settings.add_parameter('DIO_laser', 2, 
                                            type='int', step=1, 
                                            bounds=[0,16],
                                            tip='DIO for the laser')         
        self.treeDic_settings.add_parameter('DIO_change_frequency', 7, 
                                            type='int', step=1, 
                                            bounds=[0,16],
                                            tip='DIO for triggering the change in frequency')  
        self.treeDic_settings.add_parameter('DIO_pulse_modulation', 3, 
                                            type='int', step=1, 
                                            bounds=[0,16],
                                            tip='DIO for modulating the pulse')  
        self.treeDic_settings.add_parameter('DIO_sync_scope', 5, 
                                            type='int', step=1, 
                                            bounds=[-1,16],
                                            tip='DIO for synchronizing the oscilloscope. Put -1 for nothing')
        
        # Add a Data Box plotter for the incoming data
        self.databoxplot = egg.gui.DataboxPlot(autosettings_path='plot_ESR')
        self.place_object(self.databoxplot,
                          row=2, column = 2, row_span=2, column_span=2) 
        self.databoxplot.button_multi.set_value(False) # Make all on the same plot
        
        # Some stretches for squeezing the wigdets
        self.set_row_stretch(1)
        self.set_column_stretch(2)
        
        

    def _button_prepare_experiment_clicked(self):
        """
        Prepare the experiment:
            Prepare the pulse sequence class. 
            Prepare the signal generator
            Prepare the axis of the plot
        """
        _debug('GUIESR: _button_prepare_experiment_clicked')   

        # Prepare the pulse sequence 
        self.prepare_pulse_sequence()
        
        
        
        # We want the fpga NOT in each tick mode
        self.gui_pulse_runner.CheckBox_CET_mode.set_checked(value=False)
        
        # The following lines is for giving the sequence with delays
        # Remove the delay if there was previously
        if self.gui_pulse_runner.sequence_has_delay:
            self.gui_pulse_runner.button_set_delays.click()
        # Set the sequence
        self.gui_pulse_runner.set_sequence( self.sequence )
        # Set the delay
        self.gui_pulse_runner.button_set_delays.click()
        
        
        
        # Prepare the setting for the signal generator
        self.fmin = self.treeDic_settings['f_min']
        self.fmax = self.treeDic_settings['f_max']
        self.Nf   = self.treeDic_settings['N']
        self.P    = self.treeDic_settings['Power']
        self.sig_gen.settings['List/f1']    = self.fmin*1e9 #Convert into Hz
        self.sig_gen.settings['List/f2']    = self.fmax*1e9 #Convert into Hz
        self.sig_gen.settings['List/P1']    = self.P
        self.sig_gen.settings['List/P2']    = self.P
        self.sig_gen.settings['List/N'] = self.Nf

        # Make the instrumenbt ready for the pulse sequence
        #THE ORDER OF WHICH METHOD TO CALL FIRST MIGHT MATTER
        self.sig_gen.button_reset.click()  # Reset the parameters 
        
        # This method should set the trigger to be external, pulse modulatiion, 
        # etc. 
        self.sig_gen.api.prepare_list_extmod()

        # Prepare the signal generator for an ESR sequence
#        print('PLEASE UNCOMMENT 478')
        self.sig_gen.combo_mode.set_value(index=1) # Set in List mode
        self.sig_gen.button_generate_list.click()
        self.sig_gen.button_send_list.click()
        
        #Switch on the RF output if it is not ON
        if not(self.sig_gen.button_rf.is_checked()):
            self.sig_gen.button_rf.click()
        
        # Get the real frequency list
        fs = np.array(self.sig_gen.api.get_list_frequencies()) # This is in Hz
        self.x_axis = fs*1e-9 # In GHz
        # And also the power for convienience (And debugin)
        self.ps_real = np.array(self.sig_gen.api.get_list_powers()  )  
       
        
    def prepare_pulse_sequence(self):
        """
        Prepare the pulse sequence. 
        It generates the objet to be converted into a data array. 
        """
        _debug('GUIESR: prepare_pulse_sequence')
        
        # Initiate the sequence on which we gonna construct the sequence
        sequence = Sequence(name='Awesome ESR')
        
        DIO_trigger = self.treeDic_settings['DIO_change_frequency']
        DIO_laser   = self.treeDic_settings['DIO_laser']
        DIO_PM      = self.treeDic_settings['DIO_pulse_modulation']
        DIO_sync    = self.treeDic_settings['DIO_sync_scope']
        dt_in_laser = self.treeDic_settings['dt_delay_laser']
        dt_on  = self.treeDic_settings['dt_on']  
        dt_trigger = 100 # Elapsed time for the trigger
         # (us) Dwell time before starting the sequence. Usefull when having 
         # long delays !
        t0_start = 20
        
        # If we want a reference count, the duration of off will be the same 
        # as the duration of RF ON.
        want_a_reference = self.treeDic_settings['want_a_reference']
        if want_a_reference:
            self.treeDic_settings['dt_off'] = dt_on
        dt_off = self.treeDic_settings['dt_off']
       
        self.nb_block = self.treeDic_settings['N']
        
        
        
        
#        t0_read = dt_off  # Start time to read (us)
#        t1_read = dt_off + dt_on # Stop time to read (us)

        # =====================================================================
        # The sequence will consist of sending the RF and reading AND 
        # Wait for the trigger to have effect for the next block. 
        # If we want a reference count, this waiting time will be equal to the 
        # RF ON duration and will will take the count during this time. 
        # =====================================================================
        
        # Create a channel for the trigger
        channel_trigger_RF = ChannelPulses(channel=DIO_trigger, 
                                           name='Change Frequency')
        # Create the ChannePulse for when to read
        channel_read = ChannelPulses(channel=1, name='Read')      
        # A Channel for the modulation of the pulse
        channel_PM = ChannelPulses(channel=DIO_PM, name='Pulse modulation')          
        # Create the ChannePulse for the laser output
        channel_laser = ChannelPulses(channel=DIO_laser, name='Laser')      
        # Create a channel for the end state (use full for the scope)
        channel_sync = ChannelPulses(channel=DIO_sync, name='Synchronize scope')
        

        # Start by sending Laser, RF and read
        # The laser is ON a little bit earlier, for initiating the population.
        channel_laser.add_pulses([t0_start , t0_start  + dt_in_laser + dt_on])  
        t0 = channel_laser.get_pulses_times()[-1] - dt_on
        channel_PM.add_pulses([t0, t0 + dt_on])
        channel_read.add_pulses([t0, t0 + dt_on])
        t0 = channel_read.get_pulses_times()[-1] # Reference time
        
        # Trigger the change in frequency and wait
        # Add a microsecond, just to make extra sure that there is no overlap
        t0 += 1 
        channel_trigger_RF.add_pulses([t0, t0 + dt_trigger])
        if want_a_reference:
            channel_laser.add_pulses([t0, t0 + dt_off])
            channel_read .add_pulses([t0, t0 + dt_off])
        
        # Finish by sync-ing the scope
        t0 += dt_off
        channel_sync.add_pulses([t0-dt_trigger, t0]) # Same duration as trigger        
        
        
        # Create many block of the same thing. 
        for i in range(self.nb_block):
            # Build the block
            block = PulsePatternBlock(name='Block %d'%i)
            block.add_channelEvents([channel_read, 
                                     channel_trigger_RF, 
                                     channel_laser,
                                     channel_PM,
                                     channel_sync])
            # Add the block to the sequence
            sequence.add_block(block)
        
        self.sequence = sequence       
        

    def databoxplot_update(self):
        """
        Update the plot
        """
        _debug('GUIESR: databoxplot_update')
        
        # CLear the plot
        self.databoxplot.clear() 

        # Add important information in the header
        self.databoxplot.insert_header('repetition', self.rep)
        self.databoxplot.insert_header('iteration' , self.iteration)
        for key in self.treeDic_settings.get_keys():
            # Add each element of the dictionnary three
            self.databoxplot.insert_header(key , self.treeDic_settings[key])
        # Also note the time. It is important you know. 
        self.databoxplot.insert_header('date', time.ctime(time.time()))     
        self.databoxplot.insert_header('absolute_time_sec', time.time())  
        # The x_axis should be prepared in the external GUI 
        #TODO Find a way to not rely on the external GUI. For example, load the 
        #  signal generator in this GUI. 
        self.databoxplot['Frequency_(GHz)'] = self.x_axis
        self.databoxplot['Power_(dBm)']     = self.ps_real
        # Loop over each readout 
        for i, count_per_readout in enumerate(self.counts_total):
            # Add a curve
            self.databoxplot['Total_counts_%d'%i] = count_per_readout
            
        # Show it
        self.databoxplot.plot()     
        
    def after_one_loop(self, counts, iteration, rep):
        """
        What to do after one loop of the fpga. 

        This is called after each loop (single run) of the fpga. 
        
        counts:
            Array of counts that the fpga get. 
        iteration:
            int corresponding to which iteration are we at
            
        rep:
            Number of repetition of the sequence into the fpga instruction
            """
        _debug('GUIESR: after_one_loop')
        
        # Note that for saving 
        self.rep = rep
        self.iteration = iteration
        self.counts_prior_to_process = counts # Save it for debugging
        
        # Get the counts per readout per block
        self.proc = ProcessFPGACounts()
        outputs = self.proc.get_count_per_readout_vs_block(counts, 
                                                           rep, 
                                                           self.nb_block)
        self.block_ind, self.counts = outputs

        # If its the first iteration
        if iteration == 0:
            # Get the count and the correct shape for the array
            self.counts_total = np.array(self.counts)  
        else:
            # Increment the counts
            self.counts_total += np.array(self.counts)  
            
        # Update the plot
        self.databoxplot_update()
        
     
        
if __name__=="__main__":
    # Enable some usefull debugger
    _debug_enabled = True
    
    
#    # Get the fpga paths and ressource number
    import spinmob as sm
    cpu_specific_infos = sm.data.load('cpu_specifics.dat')
    # cpu_specific_infos is defined in the import of the base modules
    bitfile_path = cpu_specific_infos.headers['FPGA_bitfile_path']
    resource_num = cpu_specific_infos.headers['FPGA_resource_number']
#    # Get the fpga API
#    fpga = _fc.FPGA_api(bitfile_path, resource_num) 
#    fpga.open_session()
    
    # If we want a fake FPGA API for testing the code
    import api_fpga as _fc
    fpga = _fc.FPGA_fake_api(bitfile_path, resource_num) # Create the api   
    fpga.open_session()
    print()
    print('!!! FAKE FPGA !!!!!')
    print()
    
    # Get the principal GUI
    self = GUIESR(fpga, size=[1800,800])
    self.show()            
        
        
