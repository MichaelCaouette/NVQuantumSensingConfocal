# -*- coding: utf-8 -*-
"""
Created on Thu Oct  8 11:39:41 2020


@author: Childresslab
"""

# Get some base modules
from gui_signal_generator import GUISignalGenerator
from gui_pulse_runner import GuiPulseRunner
from count_interpreter import ProcessFPGACounts
from pulses import ChannelPulses, PulsePatternBlock, Sequence
import api_fpga as _fc

# Other cool imports
import time
import numpy as np
from spinmob import egg
import traceback
_p = traceback.print_last #Very usefull command to use for getting the last-not-printed error


_debug_enabled     = False
def _debug(*a):
    if _debug_enabled: 
        s = []
        for x in a: s.append(str(x))
        print(', '.join(s))
 

class GUIRabiOscillation(egg.gui.Window):
    """
    GUI for preparing and reading Rabi measurement.
    It is meant to be run and connected with the pulse runner. 
    
    It uses various modules:
        - The signal generator
        - The pulse runner
        - It has its own sequence builder for building the pulse sequence
        - It has its own databox plotter for showing the data
    
    """   
    
    def __init__(self, fpga, name="Please no bad jokes.", size=[1000,500]): 
        """
        Initialize

        fpga:
            "FPGA_api" object from api_fpga.py. 
            This is the object shared amoung the GUIs for controlling the fpga. 
            The session of he fpga must already be open.  
        
        """    
        _debug('GUIRabiOscillation: __init__')
        _debug('If you think you’re too small to make a difference, try sleeping with a mosquito. – Dalai Lama')
        
        # Run the basic stuff for the initialization
        egg.gui.Window.__init__(self, title=name, size=size)

        # Steal the fpga, mouhahaha
        self.fpga = fpga
        # Overid a method that, hopefully, should prevent the freeze out of the
        # gui for long pulse sequence.
        self.fpga.dummy_event_pulse_is_long = self.process_events
        
        # Initialise the GUI
        self._initialize_GUI()
        
    def _initialize_GUI(self):
        """
        Fill up the GUI
        """        
        _debug('GUIRabiOscillation: _initialize_GUI')
        
        # A button for preparing stuff
        self.button_prepare_experiment = egg.gui.Button('Prepare all settings',
                                                        tip='Prepare the measurement before running')
        self.place_object(self.button_prepare_experiment, row=0, column=0)
        self.connect(self.button_prepare_experiment.signal_clicked, 
                     self._button_prepare_experiment_clicked)
        
        # Place the pulse runner
        self.gui_pulse_runner = GuiPulseRunner(self.fpga)
        self.place_object(self.gui_pulse_runner, 
                          row=1, column=0, column_span=2)
        # Overid the method for processing properly after the loop.
        self.gui_pulse_runner.dummy_after_one_loop = self.after_one_loop   
        
        
        # Add the signal generator
        self.sig_gen = GUISignalGenerator(show=False)
        self.gui_sig_gen    = self.sig_gen.window    
        self.place_object(self.gui_sig_gen, 
                          row=1, column = 2)
        
        # tree dictionnarry for the settings
        self.treeDic_settings = egg.gui.TreeDictionary(autosettings_path='setting_RabiOscillation')
        self.place_object(self.treeDic_settings, row=2, column=0, column_span=2)

        self.treeDic_settings.add_parameter('Power', -20, 
                                            type='float', step=0.01, 
                                            bounds=[-50,30], suffix=' dBm',
                                            tip='Constant power of the RF')
        self.treeDic_settings.add_parameter('Frequency', 1, 
                                            type='float', step=0.0001, 
                                            bounds=[0,10], suffix=' GHz',
                                            tip='Frequency of the RF')        
        self.treeDic_settings.add_parameter('N', 50, 
                                            type='int', step=10, 
                                            bounds=[0,None],
                                            tip='Number of points to sweep')         
        
        self.treeDic_settings.add_parameter('dt_readout', 0.4, 
                                            type='float', step=0.1, 
                                            bounds=[0,None], suffix=' us',
                                            tip='Duration of the readout') 
        self.treeDic_settings.add_parameter('t_in', 0, 
                                            type='float', step=0.1, 
                                            bounds=[0,None], suffix=' us',
                                            tip='Initialie time to probe') 
        self.treeDic_settings.add_parameter('t_end', 1, 
                                            type='float', step=0.1, 
                                            bounds=[0,None], suffix=' us',
                                            tip='Last time to probe')         
        self.treeDic_settings.add_parameter('dt_read_after_RF', 1, 
                                            type='float', step=0.1, 
                                            bounds=[0,None], suffix=' us',
                                            tip='How much time to wait before reading after the RF') 
        self.treeDic_settings.add_parameter('delay_read_before_laser', 0.05, 
                                            type='float', step=0.01, 
                                            bounds=[0,None], suffix=' us',
                                            tip='Delay that we read before shining the laser')  
    
        
        self.treeDic_settings.add_parameter('DIO_laser', 2, 
                                            type='int', step=1, 
                                            bounds=[0,16],
                                            tip='DIO for the laser')          
        self.treeDic_settings.add_parameter('DIO_pulse_modulation', 3, 
                                            type='int', step=1, 
                                            bounds=[0,16],
                                            tip='DIO for modulating the pulse')  
        self.treeDic_settings.add_parameter('DIO_sync_scope', 5, 
                                            type='int', step=1, 
                                            bounds=[-1,16],
                                            tip='DIO for synchronizing the oscilloscope. Put -1 for nothing')             
        
        

        
        # Add a Data Box plotter for the incoming data
        self.databoxplot = egg.gui.DataboxPlot(autosettings_path='plot_RabiOscillation')
        self.place_object(self.databoxplot, row=2, column = 2, row_span=2) 
        self.databoxplot.button_multi.set_value(False) # Make all on the same plot
        
        # Some stretches for squeezing the wigdets
        self.set_row_stretch(1)
        self.set_column_stretch(2)
        
        

    def _button_prepare_experiment_clicked(self):
        """
        Prepare the experiment:
            Prepare the pulse sequence class. 
            Prepare the signal generator
            Prepare the axis of the plot
        """
        _debug('GUIRabiOscillation: _button_prepare_experiment_clicked')   

        # Prepare the sequence accoring to the best knowledge that we have so far. 
        self.prepare_pulse_sequence()
        
        # We want the fpga NOT in each tick mode
        self.gui_pulse_runner.CheckBox_CET_mode.set_checked(value=False)
        
        # Set a reasonable amount of repetition for the typical sequence
        self.gui_pulse_runner.NumberBox_repetition.set_value(1000)
        
        # The following lines is for giving the sequence with delays
        # Remove the delay if there was previously
        if self.gui_pulse_runner.sequence_has_delay:
            self.gui_pulse_runner.button_set_delays.click()
        # Set the sequence
        self.gui_pulse_runner.set_sequence( self.sequence )
        # Set the delay
        self.gui_pulse_runner.button_set_delays.click()
        
        # Prepare the setting for the signal generator
        self.tmin = self.treeDic_settings['t_in']
        self.tmax = self.treeDic_settings['t_end']
        self.Nt   = self.treeDic_settings['N']
        self.P    = self.treeDic_settings['Power']
        self.f    = self.treeDic_settings['Frequency']
        
        # Prepare the signal generator for the specific sequence
        #THE ORDER OF WHICH METHOD TO CALL FIRST MIGHT MATTER
        self.sig_gen.button_reset.click()  # Reset the parameters 
        # This method should set the pulse modulation to be external
        self.sig_gen.api.prepare_fixed_extmod()    
        self.sig_gen.combo_mode.set_value(index=0) # Set in Fixed mode
        self.sig_gen.number_dbm      .set_value(self.P)
        self.sig_gen.number_frequency.set_value(self.f*1e9 )#Convert into Hz
        
        #Switch on the RF output if it is not ON
        if not(self.sig_gen.button_rf.is_checked()):
            self.sig_gen.button_rf.click()
       
        
    def prepare_pulse_sequence(self):
        """
        Prepare the pulse sequence. 
        It generates the objet to be converted into a data array. 
        """
        _debug('GUIRabiOscillation: prepare_pulse_sequence')
        
        # Initiate the sequence on which we gonna construct the  sequence
        sequence = Sequence(name='Wonderful Rabi')
        
        DIO_laser   = self.treeDic_settings['DIO_laser']
        DIO_PM      = self.treeDic_settings['DIO_pulse_modulation']
        DIO_sync    = self.treeDic_settings['DIO_sync_scope']
        
        
        T_min_us    = self.treeDic_settings['t_in'] # Minimum time  to probe
        T_max_us    = self.treeDic_settings['t_end'] # Maximum time  to probe
        self.nb_block    = self.treeDic_settings['N'] # Number of point to take
        dt_readout  = self.treeDic_settings['dt_readout'] # Readout time (us)
        delay_read = self.treeDic_settings['delay_read_before_laser'] # Delay (us) that we read before shining the laser
        dt_read_after_RF = self.treeDic_settings['dt_read_after_RF'] # How long to wait before reading after the RF (us)
        
        # Define the aimed time durations of the RF
        # It is aimed, but we know that the real definition of the time is set
        # by the tick of the FPGA.
        self.dt_s_aimed = np.linspace(T_min_us, T_max_us, self.nb_block)
      
        t_ini_laser_init = 1  # Raise time for the initialization laser (us)
        dt_laser_init = 1 # Time duration of the initializaiton laser (us)
        t0_RF = t_ini_laser_init + dt_laser_init + 1 # Initial raise time for the RF (us)   
        
        
#        t0_ref = 0.1 #Initial time for the reference
#        t0_RF = t0_ref + 2*dt_readout # Initial raise time for the RF
        
        # Initiate the sequence on which we gonna construct the Rabi sequence
        sequence = Sequence(name='Rabi sequence')        
        
        # Initiate the channels
        
        # Create a channel for synching the scope
        channel_sync = ChannelPulses(channel=DIO_sync, name='Sync with scope')
        channel_sync.add_pulses([0, 0.5]) # At the beggining
        
        self.dt_reals_s = [] # Will record the real time interval, accounting for the tick in the FPGA
        
        # Define a block for each duration to probe
        for i, dt in enumerate(self.dt_s_aimed):
            
            # Initialize the state into ms=0 with the green laser
            # Channel for the laser output, which follows the readout
            channel_laser = ChannelPulses(channel=DIO_laser, name='Laser') 

            #Add a pulse for the initialization into ms=0
            channel_laser.add_pulses([t_ini_laser_init, t_ini_laser_init+dt_laser_init])            

            # Channel for the modulatiion of the RF
            channel_RF_mod = ChannelPulses(channel=DIO_PM, name='RF modulation')
            # Only put a pulse if the duration is longer than one tick
            if dt >= 1/120:
                # The RF span from time zero to the duration
                channel_RF_mod.add_pulses([t0_RF, t0_RF+dt])
                # Note the real time interval for this pulse
                times_pulses = channel_RF_mod.get_pulses_times() # This gives all the raise and fall
                dt_last = times_pulses[-1] - times_pulses[-2] # Last interval
                self.dt_reals_s.append(dt_last)
            else:
                print('dt = ', dt)
                # Note the zero time interval
                self.dt_reals_s.append(0)
            
            # Channel for the readout
            channel_read = ChannelPulses(channel=1, name='Read') 
            
            # Add a pulse for the readout after the RF
            t0_read = t0_RF+dt+dt_read_after_RF
            # Add a delay at the beggining, before that the laser is shone, just to be cool. 
            channel_read.add_pulses([t0_read-delay_read, t0_read+ dt_readout])
            
            # Add a pulse for shining the NV for both readind ans initialting into ms=0
            t0_shine = t0_read
            channel_laser.add_pulses([t0_shine, t0_shine + dt_laser_init ])              

            # Add a pulse for reading the reference
            t0_read = t0_shine + dt_laser_init-dt_readout
            channel_read.add_pulses([t0_read, t0_read+dt_readout]) 
          
            # Build the block
            block = PulsePatternBlock(name='Block Rabi RF = %.2f us'%dt)
            block.add_channelEvents([channel_sync,
                                     channel_RF_mod,
                                     channel_read ,
                                     channel_laser])
            # Add the block to the sequence
            sequence.add_block(block)
        
        self.sequence = sequence       
        

    def databoxplot_update(self):
        """
        Update the plot
        """
        _debug('GUIRabiOscillation: databoxplot_update')
        
        # CLear the plot
        self.databoxplot.clear() 

        # Add important information in the header
        self.databoxplot.insert_header('repetition', self.rep)
        self.databoxplot.insert_header('iteration' , self.iteration)
        for key in self.treeDic_settings.get_keys():
            # Add each element of the dictionnary three
            self.databoxplot.insert_header(key , self.treeDic_settings[key])
        self.databoxplot.insert_header('date', time.ctime(time.time()))     
        self.databoxplot.insert_header('absolute_time_sec', time.time())              
        # Now add the columns        
        self.databoxplot['Time_(us)'] = self.dt_reals_s
        self.databoxplot['counts'] = self.counts_total[0]
        self.databoxplot['reference'] = self.counts_total[1]
        
        # Show it
        self.databoxplot.plot()   
        
    def after_one_loop(self, counts, iteration, rep):
        """
        What to do after one loop of the fpga. 

        This is called after each loop (single run) of the fpga. 
        
        counts:
            Array of counts that the fpga get. 
        iteration:
            int corresponding to which iteration are we at
            
        rep:
            Number of repetition of the sequence into the fpga instruction
            """
        _debug('GUIRabiOscillation:: after_one_loop')
        
        # Note that for saving 
        self.rep = rep
        self.iteration = iteration
        self.counts_prior_to_process = counts # Save it for debugging
        
        # Get the counts per readout per block
        self.proc = ProcessFPGACounts()
        outputs = self.proc.get_count_per_readout_vs_block(counts, rep, self.nb_block)
        self.block_ind, self.counts = outputs
        # If its the first iteration
        if iteration == 0:
            # Get the count and the correct shape for the array
            self.counts_total = np.array(self.counts)  
        else:
            # Increment the counts
            self.counts_total += np.array(self.counts)  
            
        # Update the plot
        self.databoxplot_update()
        
     
        
if __name__=="__main__":
    # Enable some usefull debugger
    _debug_enabled = True
    import api_signal_generator as api_signal_generator
    api_signal_generator._debug_enabled = True
    
    
    # Get the fpga paths and ressource number
    import spinmob as sm
    cpu_specific_infos = sm.data.load('cpu_specifics.dat')
    # cpu_specific_infos is defined in the import of the base modules
    bitfile_path = cpu_specific_infos.headers['FPGA_bitfile_path']
    resource_num = cpu_specific_infos.headers['FPGA_resource_number']
    # Get the fpga API
    fpga = _fc.FPGA_api(bitfile_path, resource_num) 
    fpga.open_session()
    
#    # If we want a fake FPGA API for testing the code
#    from api_fpga import FPGA_fake_api
#    fpga = FPGA_fake_api('Pata', 'Pouf')
#    print()
#    print('!!! FAKE FPGA !!!!!')
#    print()
#    
    
    # Get the principal GUI
    self = GUIRabiOscillation(fpga, size=[1800,800])
    self.show()            
        
        
        
        
        
        
        
        
        
        
        
        
