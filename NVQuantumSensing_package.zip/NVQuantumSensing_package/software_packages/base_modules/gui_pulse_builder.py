# -*- coding: utf-8 -*-
"""
Created on Thu May 21 15:27:02 2020


@author: Childresslab, Michael
"""



from gui_table_interactive import GUITableInteractive
from pulses import GUIPulsePattern, ChannelPulses, PulsePatternBlock, Sequence


import numpy as np
import spinmob as sm
from spinmob import egg
import traceback
_p = traceback.print_last #Very usefull command to use for getting the last-not-printed error

# Debug stuff.
_debug_enabled     = False

def _debug(*a):
    if _debug_enabled: 
        s = []
        for x in a: s.append(str(x))
        print(', '.join(s))
        

class GuiPulseBuilder(egg.gui.Window):
    """
    A gui for customizing pulse sequences. 
    
    The user determines what each DIO does at each block. 
    
    TODO Upgrade to have:
        - Round the time such that is matches the fpga clocks (8.333333 ns)
        - Add an extra cloumns for naming each pulse. 
    
    """
    def __init__(self,
                 name="Awesome pulse customization", size=[200,600]): 
        """
        Yep, this is the initialization ;) 
        """    
        _debug('GuiPulseBuilder:__init__')
        _debug('It is never too late to be what you might have been. – George Eliot (Mary Ann)')
        
        # Run the basic stuff for the initialization
        egg.gui.Window.__init__(self, title=name, size=size)
        
        # A button for saving the sequence
        self.button_save = egg.gui.Button('Save this\nwonderful sequence')
        self.place_object(self.button_save)
        self.connect(self.button_save.signal_clicked, self._button_save_clicked )
        # A button for loading the sequence
        self.button_load = egg.gui.Button('Load an\nawesome sequence')
        self.place_object(self.button_load)
        self.connect(self.button_load.signal_clicked, self._button_load_clicked )

        # A button for viewing the current sequence
        self.button_view = egg.gui.Button('View this\nmasterpiece')
        self.place_object(self.button_view)
        self.connect(self.button_view.signal_clicked, self._button_view_clicked )        

        
        # A table for creating the pulse
        self.new_autorow()
        self.gui_table = GUITableInteractive(nb_columns= 5)
        self.gui_table.set_first_row(['DIO', 
                                      'Raise (ns)',
                                      'Step/block Raise (ns)', 
                                      'Fall (ns)',
                                      'Step/block Fall (ns)'])
        self.gui_table.table.set_width(510) 
        self.gui_table.table.set_height(200)
        self.place_object(self.gui_table, column_span=3)
        
        # A number box for the number of block in the sequence
        self.gui_table.place_object(egg.gui.Label('# of block'),
                                    row=0, column=4, )                         
 
        self.numberBox_block = egg.gui.NumberBox(value=1, bounds=(1, None),
                                                 int=True) 
        self.gui_table.place_object(self.numberBox_block, 
                                    row=0, column=5,  alignment=1)
        
        # Attempt to pussh all the buttong together
        self.set_column_stretch(2)
        self.set_row_stretch(3)
        

        
    
    def _button_save_clicked(self):
        """
        Save the pulse sequence in the table.
        """
        _debug('GuiPulseBuilder: _button_save_clicked')
        
        # Get the list of rows
        self.list_rows = self.gui_table.get_list_rows()
        list_columns = self.list_rows.T # Transpose for having the columns
        # Update other atrributes
        self.nb_block = int( self.numberBox_block.get_value()) 
        
        # Create the databox and fill it
        self.databox = sm.data.databox()
        # Fill the columns
        self.databox['DIO']                  = list_columns[0]
        self.databox['raise']                = list_columns[1]
        self.databox['step_per_block_raise'] = list_columns[2]
        self.databox['fall']                 = list_columns[3]
        self.databox['step_per_block_fall']  = list_columns[4]
        # Add relevant headers
        self.databox.insert_header('nb_block', self.nb_block)
        
        # Save it with a dialog box
        self.databox.save_file()   
        
        
    def _button_load_clicked(self):
        """
        Load a databox file and fill the table
        """
        _debug('GuiPulseBuilder: _button_load_clicked')
        
        self.d = sm.data.load(text='Please select a pulse sequence.')
        
        # Exctract the headers
        nb_block = self.d.h('nb_block')
        self.numberBox_block.set_value( nb_block)
        
        # Fill up the table
        self.gui_table.button_reset.click()
        self.gui_table.set_table(self.d)
        
        return
   
        
    def _button_view_clicked(self):
        """
        Pop up a window for showing the pulse sequence
        """
        _debug('GuiPulseBuilder: button_view_clicked') 
        
        # Update
        self._build_sequence()
        # Show the block
        GUIPulsePattern(self.sequence)  
        
    def _build_sequence(self):
        """
        Build the pulse sequence from the gui.
        
        It is not a straight foward task. Lol. 
        """
        _debug('GuiPulseBuilder: _build_sequence')
        
        # Update the info from the builder
        self.nb_block  = int( self.numberBox_block.get_value() )
        self.list_rows = self.gui_table.get_list_rows()
        list_columns   = self.list_rows.T # Transpose for having the columns
        list_DIO        = np.array( list_columns[0] ).astype(float)
        list_raise      = np.array( list_columns[1] ).astype(float)
        list_step_raise = np.array( list_columns[2] ).astype(float)
        list_fall       = np.array( list_columns[3] ).astype(float)
        list_step_fall  = np.array( list_columns[4] ).astype(float)
        
        # Initiate the sequence on which we gonna construct the sequence
        my_sequence = Sequence(name='Awesome Sequence')
        # Create each block
        for i in range(self.nb_block):
            # Create the block
            block = PulsePatternBlock(name='Block %d'%i)
            # Initiate a list of channel to add to the block
            list_channel = []
            # The following is to avoid to create two channels for one DIO
            list_existing_DIO = [] # List of unrepeated DIO in channels
            
            # For each block, create the channels
            for j in range(len(list_DIO)):
                
                # Get the raise and fall time, with the step included
                # Also Convert in us !
                t_raise = 1e-3* ( list_raise[j] + i*list_step_raise[j] )
                t_fall  = 1e-3* ( list_fall [j] + i*list_step_fall [j] )
                
                # Get the DIO
                DIO = int ( list_DIO[j]  )
                # Create the channel for the DIO if it doesn't exist yet
                if not(DIO in list_existing_DIO):
                    # Update the DIOs present
                    list_existing_DIO.append(DIO)
                    # Create the channel and update it to the list
                    channel = ChannelPulses(channel=DIO, name='Pew Pew') 
                    list_channel.append(channel)
                    
                else:
                    # Get the existing channel of this DIO
                    index = np.array( list_existing_DIO ) == DIO
                    channel = np.array( list_channel ) [index][0]
                    
                # Add the pulse to this channel
                channel.add_pulses([t_raise, t_fall])
                
            # Add The channels to the block
            block.add_channelEvents(list_channel)
            # Add the block to the sequence
            my_sequence.add_block(block)
        
        # Update the attribute
        self.sequence = my_sequence
        
        # At this point, we are finnaly done. We can go to rest. 
        return
        
    
    def get_sequence(self):
        """
        Update and get the pulse sequence from the element in the table. 
        """
        _debug('GuiPulseBuilder: get_sequence') 
        
        # Update
        self._build_sequence()
        # Return
        return self.sequence
        
     
    
if __name__ == '__main__':
    # Enable some debugging
    _debug_enabled     = True
    
    self = GuiPulseBuilder()
    self.show()





















