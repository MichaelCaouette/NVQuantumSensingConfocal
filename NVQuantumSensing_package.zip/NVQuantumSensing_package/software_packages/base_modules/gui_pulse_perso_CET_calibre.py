# -*- coding: utf-8 -*-
"""
Created on Sat Feb 27 16:40:21 2021

@author: Childresslab
"""


from pulses import ChannelPulses, PulsePatternBlock, Sequence
import api_fpga as _fc
from gui_signal_generator import GUISignalGenerator
from gui_pulse_runner import GuiPulseRunner
from count_interpreter import ProcessFPGACounts

# Other cool imports 
import time
import numpy as np
from spinmob import egg
import traceback
_p = traceback.print_last #Very usefull command to use for getting the last-not-printed error


_debug_enabled     = False
def _debug(*a):
    if _debug_enabled: 
        s = []
        for x in a: s.append(str(x))
        print(', '.join(s))
        
        
class GUICalibration(egg.gui.Window):
    """
    GUI for setting the count in each tick mode. This would be useful for 
    calibrating the time delay in the wires. 
    It uses various modules:
        - The signal generator
        - The pulse runner
        - It has its own sequence builder for building the pulse sequence
        - It has its own databox plotter for showing the data
        
    """
    
    def __init__(self, fpga, name="CET mode.", size=[1500,900]): 
        """
        Initialize

        fpga:
            "FPGA_api" object from api_fpga.py. 
            This is the object shared amoung the GUIs for controlling the fpga. 
            The session of he fpga must already be open.  
        
        """     
        _debug('GUICalibration:__init__')
        _debug('If you can’t make a mistake you can’t make anything. – Marva Collin')
        
        # Run the basic stuff for the initialization
        egg.gui.Window.__init__(self, title=name, size=size)
        
        # Steal the fpga, mouhahaha
        self.fpga = fpga
        # Overid a method that, hopefully, should prevent the freeze out of the
        # gui for long pulse sequence.
        self.fpga.dummy_event_pulse_is_long = self.process_events
        
        # Initialise the GUI
        self._initialize_GUI()
        
        
    def _initialize_GUI(self):
        """
        Fill up the GUI
        """        
        _debug('GUICalibration: _initialize_GUI')
        
        # A button for preparing stuff
        self.button_prepare_experiment = egg.gui.Button('Prepare',
                                                        tip='Prepare the measurement before running')
        self.place_object(self.button_prepare_experiment, row=0, column=0)
        self.connect(self.button_prepare_experiment.signal_clicked, 
                     self._button_prepare_experiment_clicked)

        # Place the pulse runner
        self.gui_pulse_runner = GuiPulseRunner(self.fpga)
        self.place_object(self.gui_pulse_runner, 
                          row=1, column=0, column_span=2)
        # Overid the method for processing properly after the loop.
        self.gui_pulse_runner.dummy_after_one_loop = self.after_one_loop   

        # Add the signal generator
        self.sig_gen = GUISignalGenerator(show=False)
        self.gui_sig_gen    = self.sig_gen.window    
        self.place_object(self.gui_sig_gen, 
                          row=1, column = 2)
            
        # tree dictionnarry for the settings
        self.treeDic_settings = egg.gui.TreeDictionary(autosettings_path='setting_pulse_CET_calibration')
        self.place_object(self.treeDic_settings, row=2, column=0, column_span=2)    
        

        self.treeDic_settings.add_parameter('t_read_start', 0, 
                                            type='float', step=0.1, 
                                            bounds=[0, None], suffix=' us',
                                            tip='Time at which we start to read') 
        
        self.treeDic_settings.add_parameter('t_laser_raise', 1, 
                                            type='float', step=0.1, 
                                            bounds=[0, None], suffix=' us',
                                            tip='Time at which the laser raises')      

        self.treeDic_settings.add_parameter('t_RF_raise', 2, 
                                            type='float', step=0.1, 
                                            bounds=[0, None], suffix=' us',
                                            tip='Time at which the RF modulation 1 raises')      
        self.treeDic_settings.add_parameter('t_RF_fall', 3, 
                                            type='float', step=0.1, 
                                            bounds=[0, None], suffix=' us',
                                            tip='Time at which the RF modulation 1 falls') 
        self.treeDic_settings.add_parameter('t_laser_fall', 6, 
                                            type='float', step=0.1, 
                                            bounds=[0, None], suffix=' us',
                                            tip='Time at which the laser fall') 
        self.treeDic_settings.add_parameter('t_read_end', 7, 
                                            type='float', step=0.1, 
                                            bounds=[0, None], suffix=' us',
                                            tip='Time at which we stop to read') 
 
        self.treeDic_settings.add_parameter('Power', 10, 
                                            type='float', step=1, 
                                            bounds=[-50,30], suffix=' dBm',
                                            tip='Constant power of the first RF for the first RF signal')
        self.treeDic_settings.add_parameter('Frequency', 3.01, 
                                            type='float', step=0.1, 
                                            bounds=[0,10], suffix=' GHz',
                                            tip='Frequency of the first RF for the first RF signal')           
        
        self.treeDic_settings.add_parameter('DIO_pulse_modulation', 3, 
                                            type='int', step=1, 
                                            bounds=[-1,16],
                                            tip='DIO for modulating the first RF signal. Put -1 for nothing.')       
        self.treeDic_settings.add_parameter('DIO_laser', 2, 
                                            type='int', step=1, 
                                            bounds=[0,16],
                                            tip='DIO for the laser')   
        self.treeDic_settings.add_parameter('DIO_sync_scope', 5, 
                                            type='int', step=1, 
                                            bounds=[-1,16],
                                            tip='DIO for synchronizing the oscilloscope. Put -1 for nothing')
        
        # Add a Data Box plotter for the incoming data
        self.databoxplot = egg.gui.DataboxPlot(autosettings_path='plot_RabiOscillation')
        self.place_object(self.databoxplot, row=2, column = 2, row_span=2) 
        self.databoxplot.button_multi.set_value(False) # Make all on the same plot
        
        # Some stretches for squeezing the wigdets
        self.set_row_stretch(1)
        self.set_column_stretch(2)
        

    def _button_prepare_experiment_clicked(self):
        """
        Prepare the experiment:
            Prepare the pulse sequence in the fpga
            Prepare the signal generator
            Prepare the plot
        """
        _debug('GUICalibration: _button_prepare_experiment_clicked')   
        
        # Prepare the pulse sequence
        self._prepare_pulse_sequence()

        # We want the fpga in each tick mode
        self.gui_pulse_runner.CheckBox_CET_mode.set_checked(value=True)
        
        
        # The following lines is for giving the sequence with delays
        # Remove the delay if there was previously
        if self.gui_pulse_runner.sequence_has_delay:
            self.gui_pulse_runner.button_set_delays.click()
        # Set the sequence
        self.gui_pulse_runner.set_sequence( self.sequence )
        # Set the delay
        self.gui_pulse_runner.button_set_delays.click()
        
        
        # Prepare the signal generator only if we want.
        if self.treeDic_settings['DIO_pulse_modulation']>=0:
            self.P1    = self.treeDic_settings['Power']
            self.f1    = self.treeDic_settings['Frequency']
            
            # Prepare the signal generator for the specific sequence
            #THE ORDER OF WHICH METHOD TO CALL FIRST MIGHT MATTER
            self.sig_gen.button_reset.click()  # Reset the parameters 
            # This method should set the pulse modulation to be external
            self.sig_gen.api.prepare_fixed_extmod() 
            self.sig_gen.combo_mode.set_value(index=0) # Set in Fixed mode
            self.sig_gen.number_dbm      .set_value(self.P1)
            self.sig_gen.number_frequency.set_value(self.f1*1e9 )#Convert into Hz

            #Switch on the RF output if it is not ON
            if not(self.sig_gen.button_rf.is_checked()):
                self.sig_gen.button_rf.click()
            
        
    def _prepare_pulse_sequence(self):
        """
        Prepare the pulse sequence.  
        It generates the objet to be converted into a data array. 
        """
        _debug('GUICalibration: _prepare_pulse_sequence')
        
        DIO_laser   = self.treeDic_settings['DIO_laser']
        DIO_sync    = self.treeDic_settings['DIO_sync_scope']
        DIO_PM1      = self.treeDic_settings['DIO_pulse_modulation']
        
        t_on_laser  = self.treeDic_settings['t_laser_raise']
        t_off_laser = self.treeDic_settings['t_laser_fall']
        
        self.t_on_read        = self.treeDic_settings['t_read_start']
        t_off_read_aimed = self.treeDic_settings['t_read_end']
        t_read_duration = t_off_read_aimed - self.t_on_read
        
        # FORCE THE TOTAL NUMBER OF TICKS TO BE MULTIPLE OF 32
        # THIS IS BECAUSE THE FPGA BUNDLE EACH 32 COUNTS INTO A SINGLE INT32
        # IF THE NUMBER OF TICKS IS NOT A MULTIPLE OF 32, IT WILL BUNDLE THE 
        # TICKS OF TWO SUCCESSIVE REPEATED SEQUENCE. THAT WOULD COMPLICATE 
        # THE UNBUNDLING PROCESS. THEREFORE, TO KEEP IT SIMPLE, WE GONNA FORCE
        # THE NUMBER OF TICKS TO BE MULTIPLE OF 32.
        self.aimed_duration = t_read_duration
        self.nb_aimed_ticks = self.aimed_duration*120 # That's the aimed number of ticks. 
        self.nb_excess_ticks = self.nb_aimed_ticks%32 # That's how much too much ticks there are
        # Compute a corrected number of ticks which will be a mutliple of 32
        self.nb_corrected_ticks = self.nb_aimed_ticks - self.nb_excess_ticks + 32 # Add 32 extra tick to have more counts than asked :)
        # Get the correction duration for reading
        self.t_read_duration  = self.nb_corrected_ticks/120
        
        
        t_off_read_corrected = self.t_on_read+self.t_read_duration
        
        dt_trigger = 0.1 # Duration of the trigger (us)
    
        # Create the ChannePulse for when to read
        channel_read = ChannelPulses(channel=1, name='Read')      
        channel_read.add_pulses([self.t_on_read, t_off_read_corrected])
        
        # Create the ChannePulse for the laser output
        channel_laser = ChannelPulses(channel=DIO_laser, name='Laser')      
        channel_laser.add_pulses([t_on_laser, t_off_laser])   
        
        # Create a channel for the pulse modulation of the RF1 if we want
        channel_RF1 = ChannelPulses(channel=DIO_PM1, name='RF modulation')
        if DIO_PM1 >= 0:
            t_RF1_on  = self.treeDic_settings['t_RF_raise']
            t_RF1_off = self.treeDic_settings['t_RF_fall']
            channel_RF1.add_pulses([t_RF1_on, t_RF1_off])
            
        
        # Create a channel for the end state (use full for the scope)
        channel_sync = ChannelPulses(channel=DIO_sync, name='Synchronize scope')
        # Add a pulse only if the DIO is not -1
        if DIO_sync >= 0:
            channel_sync.add_pulses([t_off_read_corrected, 
                                     t_off_read_corrected+dt_trigger]) # Same duration as trigger
        
        # Put the pulses into a block
        block = PulsePatternBlock(name='Block cool')
        block.add_channelEvents([channel_read, 
                                 channel_laser,
                                 channel_RF1,
                                 channel_sync])
        
        # Put the block into a sequence
        self.sequence = Sequence(name='Calibration')
        self.sequence.add_block(block)
        

    def _databoxplot_update(self):
        """
        Update the plot
        """
        _debug('GUICalibration: _databoxplot_update')
        # CLear the plot
        self.databoxplot.clear() 


        # Add important information in the header
        self.databoxplot.insert_header('repetition', self.rep)
        self.databoxplot.insert_header('iteration' , self.iteration)
        for key in self.treeDic_settings.get_keys():
            # Add each element of the dictionnary three
            self.databoxplot.insert_header(key , self.treeDic_settings[key])
        self.databoxplot.insert_header('date', time.ctime(time.time()))     
        self.databoxplot.insert_header('absolute_time_sec', time.time())    

        # Create the time axis
        tmin = self.t_on_read
        tmax = tmin+len(self.counts_total)/120  # Maximum time is the lenght times the tick duration       
        self.databoxplot['Time_(us)'] = np.linspace(tmin, tmax, len(self.counts_total))
        self.databoxplot['Total_counts'] = self.counts_total
        
        # Show it
        self.databoxplot.plot()      
        
    def after_one_loop(self, fpga_output, iteration, rep):
        """
        What to do after one loop of the fpga. 

        This is called after each loop (single run) of the fpga. 
        
        fpga_output:
            Output of the fpga for wich we extract the counts. 
            We should be in Count Each Tick (CET) mode. Therefore this 
            parameter should be an a array of number. Each number should 
            correspond to 32 ticks that we need to unbundle. 
        iteration:
            int corresponding to which iteration are we at
            
        rep:
            Number of repetition of the sequence into the fpga instruction
            """
        _debug('GUICalibration after_one_loop')

        # Note that for saving 
        self.rep = rep
        self.iteration = iteration
        self.fpga_output = fpga_output
        
        self.proc = ProcessFPGACounts()
        self.counts = self.proc.get_sum_count_per_repetition_CET_mode(fpga_output, rep)
        
        # Interprete the array 
        
        if iteration == 0:
            # Get the count and the correct shape for the array
            self.counts_total = np.array(self.counts)  
        else:
            # Increment the counts
            self.counts_total += np.array(self.counts) 
            
        
            
        _debug('Counts: ', self.counts)
        _debug('Lenght = ', len(self.counts))

        # Update the plot
        self._databoxplot_update()
            

if __name__=="__main__":
    # Enable some usefull debugger
    _debug_enabled = True
    
    # Get the fpga paths and ressource number
    import spinmob as sm
    cpu_specific_infos = sm.data.load('cpu_specifics.dat')
    # cpu_specific_infos is defined in the import of the base modules
    bitfile_path = cpu_specific_infos.headers['FPGA_bitfile_path']
    resource_num = cpu_specific_infos.headers['FPGA_resource_number']
    # Get the fpga API
    fpga = _fc.FPGA_api(bitfile_path, resource_num) 
    fpga.open_session()
    
#    # If we want a fake FPGA API for testing the code
#    from api_fpga import FPGA_fake_api
#    fpga = FPGA_fake_api('Pata', 'Pouf')
#    print()
#    print('!!! FAKE FPGA !!!!!')
#    print()
#    
    
    # Get the principal GUI
    self = GUICalibration(fpga)
    self.show()            
        
    
    