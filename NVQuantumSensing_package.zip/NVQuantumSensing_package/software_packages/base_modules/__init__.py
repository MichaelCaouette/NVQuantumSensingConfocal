# -*- coding: utf-8 -*-
"""
Created on Thu May 21 15:27:02 2020


Goal:
    import everything


@author: Childresslab, Michael
"""


#import sound


#
## This should import all the file in the curren folder
#from os.path import dirname, basename, isfile, join
#import glob
#modules = glob.glob(join(dirname(__file__), "*.py"))
#__all__ = [ basename(f)[:-3] for f in modules if isfile(f) and not f.endswith('__init__.py')]
#
#
## Attempt to import everything
#import importlib
#for name in __all__ :
#    importlib.__import__(name)
#
#
