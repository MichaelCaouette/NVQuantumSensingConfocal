# -*- coding: utf-8 -*-
"""
Created on Thu Aug 27 13:13:42 2020

Goal:
    Define some functions for making and viewing the lines to sweep with the
    magnet. 

@author: Childresslab
"""

import numpy as np
import spinmob as _s

from mpl_toolkits.mplot3d import Axes3D # This import registers the 3D projection, but is otherwise unused.
import matplotlib.pyplot as plt

import traceback
_p = traceback.print_last #Very usefull command to use for getting the last-not-printed error

# Debug stuff.
_debug_enabled                = False

def _debug(*a):
    if _debug_enabled: 
        s = []
        for x in a: s.append(str(x))
        print(', '.join(s))

#TODO create a general function for a plane perpendicular to a given normal direction

def tilted_plane():
    """
    Make a plabe tilted with respect to the axis. 
    It's gonna be a zigzag in the plane
    """
    xs = []
    ys = []
    zs = []

    # Define a plane tilted
    x1 = 10
    x2 = 17
    z1 = 15
    z2 = 22
    y_lines = np.linspace(14, 19, 10)
    
    for i in range(int(len(y_lines)/2)):
        
        y1 = y_lines[2*i]
        y2 = y_lines[2*i+1]
        
        xs.append(x1)
        xs.append(x2)
        ys.append(y1)
        ys.append(y2)
        zs.append(z1)
        zs.append(z2)    
        
    return xs, ys, zs


def parallel_plane():
    """
    Make a plane parallel to an axis.
    It's gonna be a zigzag in the plane.
    """
    xs = []
    ys = []
    zs = []

    # Define a plane tilted
    y1 = 14
    y2 = 16.7
    z1 = 23
    z2 = z1
    x_lines = np.linspace(14, 19, 4)
    
    for i in range(int(len(x_lines)/2)):
        x1 = x_lines[2*i]
        x2 = x_lines[2*i+1]
        
        xs.append(x1)
        xs.append(x2)
        ys.append(y1)
        ys.append(y2)
        zs.append(z1)
        zs.append(z2)    
        
    return xs, ys, zs

def rectangle_parallel_zfixed(c1, c3, Nzigzag=10, z=15):
    """
    Construct a zigzag path inside a rectangle with two opposite corner c1 and c2.
    z is fixed for this path. 
    
    
    c1:
        List of two number [x,y] for a corner of the rectangle. 
    c3:
        List of two number [x,y] for the opposite corner of the rectangle. 
        (opposite to c3)    
    Nzigzag:
        Number of zizag (back and forth) to make in the rectangle.
    z:
        (float) Value of the z position
    """
    xs = []
    ys = []
    zs = []

    xmin = c1[0]
    xmax = c3[0]
    ymin = c1[1]
    ymax = c3[1]
    
    # Make sure that the number of zigzag is even
    if Nzigzag %2 == 1:
        _debug('Warning: in rectangle_parallel_zfixed, Nzigzag is incremented to make it even')
        Nzigzag +=1
    
    
    # If the zigzags are going toward x
    y1 = ymin
    y2 = ymax
    
    x_lines = np.linspace(xmin, xmax, Nzigzag)
    
    for i in range(int(len(x_lines)/2)):
        x1 = x_lines[2*i]
        x2 = x_lines[2*i+1]
        
        xs.append(x1)
        xs.append(x2)
        ys.append(y1)
        ys.append(y2)
        zs.append(z)
        zs.append(z)    
        
    return xs, ys, zs

def rectangle_parallel_yfixed(c1, c3, Nzigzag=10, y=15):
    """
    Construct a zigzag path inside a rectangle with two opposite corner c1 and c3.
    y is fixed for this path. 
    
    
    c1:
        List of two number [x,z] for a corner of the rectangle. 
    c3:
        List of two number [x,z] for the opposite corner of the rectangle. 
        (opposite to c3)    
    Nzigzag:
        Number of zizag (back and forth) to make in the rectangle.
    y:
        (float) Value of the y position
    """
    xs = []
    ys = []
    zs = []

    xmin = c1[0]
    xmax = c3[0]
    zmin = c1[1]
    zmax = c3[1]
    
    # Make sure that the number of zigzag is even
    if Nzigzag %2 == 1:
        _debug('Warning: in rectangle_parallel_yfixed, Nzigzag is incremented to make it even')
        Nzigzag +=1
    
    
    # If the zigzags are going toward x
    z1 = zmin
    z2 = zmax
    
    x_lines = np.linspace(xmin, xmax, Nzigzag)
    
    for i in range(int(len(x_lines)/2)):
        x1 = x_lines[2*i]
        x2 = x_lines[2*i+1]
        
        xs.append(x1)
        xs.append(x2)
        zs.append(z1)
        zs.append(z2)
        ys.append(y)
        ys.append(y)    
        
    return xs, ys, zs

def rectangle_parallel_xfixed(c1, c3, Nzigzag=10, x=15):
    """
    Construct a zigzag path inside a rectangle with two opposite corner c1 and c3.
    x is fixed for this path. 
    
    
    c1:
        List of two number [y,z] for a corner of the rectangle. 
    c3:
        List of two number [y,z] for the opposite corner of the rectangle. 
        (opposite to c3)    
    Nzigzag:
        Number of zizag (back and forth) to make in the rectangle.
    x:
        (float) Value of the y position
    """
    xs = []
    ys = []
    zs = []

    ymin = c1[0]
    ymax = c3[0]
    zmin = c1[1]
    zmax = c3[1]
    
    # Make sure that the number of zigzag is even
    if Nzigzag %2 == 1:
        _debug('Warning: in rectangle_parallel_xfixed, Nzigzag is incremented to make it even')
        Nzigzag +=1
    
    
    # If the zigzags are going toward x
    z1 = zmin
    z2 = zmax
    
    y_lines = np.linspace(ymin, ymax, Nzigzag)
    
    for i in range(int(len(y_lines)/2)):
        y1 = y_lines[2*i]
        y2 = y_lines[2*i+1]
        
        ys.append(y1)
        ys.append(y2)
        zs.append(z1)
        zs.append(z2)
        xs.append(x)
        xs.append(x)    
        
    return xs, ys, zs

def parallelogram(c1, c2, c3):
    """
    Construct a path inside a parallelogram with three corner c1, c2 and c3. 
    The fourth corner c4 is determined by being opposite to c1. 
    
    
    c1, c2, c3:
        Each ci is a list of two number [x,y] for defining a corner.
        
    """
    _debug('parallelogram')
    
    # Please implement this awesome function
    

def plot_magSweepLinesSettings(databox, ax=-1, color='blue', 
                               show_corners=False,
                               title='Patate Chaude'):
    """
    Plot the lines that we aim to sweep. 
    
    databox:
        Object with three columns (xs, ys, zs), or a list of three array. 
    ax:
        Matplotlib axis object. If not specified, the function will pop-up
         its own figure

    """
    # Note that the following try/except might be overkill. 
    # Maybe calling databox[0] is equivalent that databox['xs'] for the 
    # databox.
    try:
        # Try if its a databox with named columns
        xs = databox['xs']
        ys = databox['ys']
        zs = databox['zs']   
    except:
        # Otherwise just take each column
        xs = databox[0]
        ys = databox[1]
        zs = databox[2]
        
    # Initialize the figure and axis
    if ax == -1:
        # Create the figure if the ax is note specified
        fig = plt.figure(tight_layout=True)
        ax  = fig.add_subplot(111, projection='3d') 

    ax.plot(xs, ys, zs, label='Goal', color=color) 
    if show_corners:
        ax.scatter(xs[1:-1], ys[1:-1], zs[1:-1]) 
        ax.scatter(xs[0], ys[0], zs[0]   , color='red',label='Start')
        ax.scatter(xs[-1], ys[-1], zs[-1], color='y'  ,label='End')
        plt.legend()
    ax.set_xlabel('x (mm)')
    ax.set_ylabel('y (mm)')
    ax.set_zlabel('z (mm)')
    # Set equal aspect
    # For this we need the extremum of all the pts
    allpts = np.concatenate((xs, ys, zs))
    max_all = np.max(allpts)
    min_all = np.min(allpts)
    radius = 0.5*(max_all - min_all)
    # Get the central position
    xmean = np.mean(xs)
    ymean = np.mean(ys)
    zmean = np.mean(zs)
    # Set the axe such that it span the same amount in each direction
    ax.set_xlim3d(xmean-radius, xmean+radius)
    ax.set_ylim3d(ymean-radius, ymean+radius)
    ax.set_zlim3d(zmean-radius, zmean+radius)

    # Slice the title if it's too long.
    if len(title)>20:
        t1 = title[:int(len(title)/2)]
        t2 = title[int(len(title)/2):]
        title = t1+'\n'+t2
        
    ax.set_title(title, fontsize=10) 
    
    return ax



#By default set the object
if __name__ == '__main__':
    _debug_enabled = True    

    # Uncomment the type of sweep that you want to create
#    xs, ys, zs = tilted_plane()
#    xs, ys, zs = parallel_plane()
#    xs, ys, zs = rectangle_parallel_zfixed(c1 = [20, 13],
#                                           c3 = [25, 18],
#                                           Nzigzag=23, z=8)
#    
#    # Save the data into a databox
#    databox = _s.data.databox()
#    # Put some header
#    databox.insert_header('name', 'Hakuna matata')
#    # Add each column
#    databox['xs'] = xs
#    databox['ys'] = ys
#    databox['zs'] = zs  
#    # Save it
#    databox.save_file()
#
#
#    plot_magSweepLinesSettings(databox, title='My path', show_corners=True)
    
    dload = _s.data.load()
    plot_magSweepLinesSettings(dload, title='My path', show_corners=True)















