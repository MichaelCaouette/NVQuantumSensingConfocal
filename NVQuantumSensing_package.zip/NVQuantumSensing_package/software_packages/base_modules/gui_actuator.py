# -*- coding: utf-8 -*-
"""
Created on Thu Jan 28 14:23:05 2021

Goal:
    Define the gui for manipulation a single actuator. 

@author: Childresslab
"""

# Import project related nice stuff
from api_actuator import ApiActuator

# Other cool stuf
import mcphysics   as _mp
from spinmob import egg
import time

#Debug
_debug_enabled           = False

def _debug(*a):
    if _debug_enabled: 
        s = []
        for x in a: s.append(str(x))
        print(', '.join(s))
                
        
class GUISingleActuator(_mp.visa_tools.visa_gui_base):
    """
    Graphical front-end for the actuator.
    
    Parameters
    ----------
    name='Anapico'
        Make this unique for each object in a larger project. This 
        will also be the first part of the filename for the other settings files.
   
    show=True
        Whether to show the window immediately.
         
    block=False
        Whether to block the command line while showing the window.
    
    pyvisa_py=False
        Whether to use pyvisa_py or not.
    """

    def __init__(self, name='Actuator', show=True, block=False, timeout=2e3, write_sleep=0.1, pyvisa_py=False):
        _debug('GUISingleActuator.__init__()')
        
        # Run the basic stuff.
        _mp.visa_tools.visa_gui_base.__init__(self, name, show, block, ApiActuator, timeout=timeout, write_sleep=write_sleep, pyvisa_py=pyvisa_py, hello_query='1VE?', baud_rate=921600)
    
        #Give a name to the GUI, for helping debugging
        self.name = 'Bibi'
    
        # Add stuff to the GUI.
        #On the top
        self.button_reset       = self.grid_top.add(egg.gui.Button('Reset', checkable=True)).set_width(60).disable()
        self.button_state       = self.grid_top.add(egg.gui.Button('State', checkable=True)).set_width(75).disable()
        self.button_move        = self.grid_top.add(egg.gui.Button('Move', checkable=True)).set_width(100).disable()
        self.button_stop        = self.grid_top.add(egg.gui.Button('STOP', checkable=True, )).set_width(100).enable()
        self.button_stop.set_colors(text='red', background='yellow') #Be fancy
        #Elsewhere
        self.label_position     = self.grid_top.place_object(egg.gui.Label('Position = XX mm'), 0,1,column_span=2)
        self.label_state        = self.grid_top.place_object(egg.gui.Label('State = LOL'), 2,1,column_span=2)  
        self.label_name        = self.grid_top.place_object(egg.gui.Label('Name = '+self.name), 4,1,column_span=1)  
        
        #This is some setting
        self.settings.add_parameter('Motion/Target_position', bounds=(0,25), suffix=' mm')
        self.settings.add_parameter('Motion/Speed'          , bounds=(0,2) , suffix=' units/sec')
        
        
        #Add a timer for some update when the actuator moves
        self.timer_moving = egg.gui.Timer(interval_ms=500, single_shot=False)
        self.timer_moving._widget.timeout.connect( self._update ) #Each time it tick, it gonna do the function self._update
        
        # Place the instrument name at a more convient place
        self.grid_top.place_object(self.label_instrument_name,0,2,column_span=1)
        
        #Connection of the button to the function
        self.button_state           .signal_toggled.connect(self._button_state_toggled)
        self.button_reset           .signal_toggled.connect(self._button_reset_toggled)
        self.button_move            .signal_toggled.connect(self._button_move_toggled)
        self.button_stop            .signal_toggled.connect(self._button_stop_toggled)
        self.button_connect         .signal_toggled.connect(self._update)
        
        #Enable the button, set them weither they are checked or not. 
        self.button_state.set_checked(False,  block_events=True).enable()
        self.button_reset.set_checked(False,  block_events=True).enable()
        self.button_move .set_checked(False,  block_events=True).enable()
           
        
    def set_name(self, name):
        """
        Set the name of the GUI
        """
        self.name = name
        #Update the name in the GUI
        self.label_name.set_text('Name = '+name)
        
    def get_name(self):
        """
        Get the name of the GUI
        """
        return self.name
        
    def _button_reset_toggled(self, *a):
        """
        Reset the actuator. 
        WARNING: this will put back the actuator in position 0. 
        """
        _debug('GUISingleActuator.button_reset_toggled()')
        
        self.timer_moving.start() #It's gonna move, so update
        self.api.reset()
        #Put back the button unchecked
        self.button_reset.set_checked(False,  block_events=True).enable()
        
    def _button_state_toggled(self, *a):
        """
        Update the state of the actuator. This calls self._update()
        """
        _debug('GUISingleActuator._button_state_toggled()')
        
        #Update
        self._update()
        #Put it back unchecked
        self.button_state.set_checked(False,  block_events=True).enable()
        
    def _button_move_toggled(self, *a):
        """
        Move the actuator to position set by the parameter Motion/Target_position
        """
        _debug('GUISingleActuator._button_move_toggled()')
        
        #Set the velocity
        v = self.settings['Motion/Speed'] #Extract the velocity from the parameters
        self.api.set_velocity(v)
        #Set the position
        r = self.settings['Motion/Target_position'] #Extract the position from the parameters
        self.api.set_position_abs(r)
        
        #Start to udpate
        self.timer_moving.start()
        
    def _button_stop_toggled(self, *a):
        """
        Stop the motion of the actuator !
        """
        _debug('GUISingleActuator._button_stop_toggled()')
        
        self.api.stop_motion()
        self._update() #udpate the state
        self.button_stop.set_checked(value=False) #Make it 'Clickable' again 
    
    def _update(self):
        """
        Update the information shown.
        """
        _debug('GUISingleActuator._update()')
        
        #Update only if the api exist
        if self.api != None: 
            #Update the position of the actuator.
            strpos = 'Position = ' + str(self.api.get_position()) + ' mm'
            self.label_position.set_text(strpos)
            _debug(strpos) 
            #Update the state         
            strState = 'State = ' + self.api.get_state()
            self.label_state.set_text(strState)
            _debug(strState) 
            
            #If the actuator doesn't move or is not homing. 
            cond1 = 'MOVING' == self.api.get_state()
            cond2 = 'HOMING' == self.api.get_state()
            if not(cond1 or cond2):
                #Stop to trigger the update with the timer
                self.timer_moving.stop()
                #Also uncheck the move button if there is not motion
                self.button_move .set_checked(False,  block_events=True).enable()
 
class GUIMagnet3(egg.gui.Window):
    """
    Class that combines:
        - 3 actuator GUIs, in order to control the position of the magnet. 
        
    """
    
    def __init__(self, name='Magnet', size=[1300,800]):
        """
        Create the GUI 
            
        """
        _debug('GUIMagnet3.__init__()', name)
        _debug('Success is going from failure to failure without losing your enthusiasm – Winston Churchill')

        # Run the basic stuff for the initialization
        egg.gui.Window.__init__(self, title=name, size=size)
        
        #Create the instance for the three actuator
        self.X = GUISingleActuator(show=False)
        self.X.settings['VISA/Device'] = 'COM5'
        self.X.set_name('Super-X')
        self.Y = GUISingleActuator(show=False)
        self.Y.settings['VISA/Device'] = 'COM4'
        self.Y.set_name('Mega-Y')
        self.Z = GUISingleActuator(show=False)
        self.Z.settings['VISA/Device'] = 'COM3'
        self.Z.set_name('Ultra-Z')

        # Add three actuator GUI
        self.place_object(egg.gui.Label('X: '), 0,0) #Set the label at position (0,0)
        self.place_object(self.X.window)
        self.new_autorow()
        self.place_object(egg.gui.Label('Y: '), 0,1) #Set the label at position (0,1)
        self.place_object(self.Y.window)
        self.new_autorow()
        self.place_object(egg.gui.Label('Z: '), 0,2) #Set the label at position (0,2)
        self.place_object(self.Z.window)
        
    def go_to_xyz(self, x, y, z, want_wait=False):
        """
        Cosy method for moving the 3 actuators in the direction of x,y,z.
        Go to x, y, z (in mm)
        
        want_wait:
            (boolean) Weither of not we want to wait before it finishes
        """
        _debug('GUIMagnet3: go_to_xyz'  )
               
        # Set the target positions
        self.X.settings['Motion/Target_position'] = x
        self.Y.settings['Motion/Target_position'] = y
        self.Z.settings['Motion/Target_position'] = z       
        
        # Go for real
        self.X.button_move.click()
        self.Y.button_move.click()
        self.Z.button_move.click()

        if want_wait:
            #Wait that the actuators finished to move. 
            condition = True
            while condition:
                # Wait for not exploding the CPU
                time.sleep(0.1)
                 #Allow the GUI to update. This is important to avoid freezing of the GUI inside loop
                self.process_events()
                # Note the condition for keeping doing
                # As long as the three actuator move
                condition1 = self.X.api.get_state() == 'MOVING'
                condition2 = self.Y.api.get_state() == 'MOVING'
                condition3 = self.Z.api.get_state() == 'MOVING'
                condition = condition1 or condition2 or condition3
            
            # Call a signal that can be used for performing a task
            self.signal_position_reached()
    
    def get_positions(self):
        """
        Convenient method for getting the position of the three actuator
        """
        _debug('GUIMagnet3: get_positions')
        
        x = self.X.api.get_position()
        y = self.Y.api.get_position()
        z = self.Z.api.get_position()
        
        return x, y, z
        
    
    def signal_position_reached(self):
        """
        Dummy function to be overid. 
        It is called when the position is reached in the method go_to_xyz.
        """
        _debug('GUIMagnet3: signal_position_reached')
        print('Congratulation, you reached the position alive')
                               
                
                
#By default set the object
if __name__ == '__main__':
    # Enable some debugs
    _debug_enabled = True
    import api_actuator
    api_actuator._debug_enabled
    
    # Pop up the gui
    self = GUISingleActuator(show=True)
    
    
    
    
