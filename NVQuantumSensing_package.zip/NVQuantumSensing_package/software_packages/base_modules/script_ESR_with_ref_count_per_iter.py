x = ( d[0] )
ii = d.headers['iteration']
rep = d.headers['repetition']
N = ii*rep # Total number of time that was counted per gate
y = ( d[1]/N, d[2]/N )

xlabels = 'Block index'
ylabels = ( 'Counts_0_per_iter', 'Counts_1_per_iter' )
