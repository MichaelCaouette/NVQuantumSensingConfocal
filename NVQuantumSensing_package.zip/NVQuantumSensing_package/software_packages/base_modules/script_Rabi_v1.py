x=(d[0]) 
y=( d[1],d[2],) 
xlabels = 'nb_block' 
ylabels = ( 'Counts_0'   'Counts_1'  )