# -*- coding: utf-8 -*-
"""
Created on Tue Feb 16 16:43:58 2021

Combine everything for having a succesful pulse sequence (thumbs up !)

@author: Childresslab
"""

# Import the relevant guis 
from gui_pulse_builder import GuiPulseBuilder
from gui_pulse_runner import GuiPulseRunner
from gui_signal_generator import GUISignalGenerator
from gui_pulse_interpreter import GUIPulseInterpreter

from spinmob import egg
import traceback
import numpy as np
# Very usefull command to use for getting the last-not-printed error
# Just type _p() in the console 
_p = traceback.print_last

#Debug
_debug_enabled           = False


def _debug(*a):
    if _debug_enabled: 
        s = []
        for x in a: s.append(str(x))
        print(', '.join(s))

class GUIMainCustomePulseSequence(egg.gui.Window):
    """
    GUI for building and performing customized pulse sequence. 
    It uses many building block:
        The pulse runner, for running the sequence in the FPGA. 
        The pulse builder, for building customized pulse sequence. 
        The signal generator, for telling the Radio Frequencies of Interest.
        The pulse interpretor, for interpreting the counts from the FPGA 
        
    Here is how it is meant to be used:
        1. The user defines a pulse sequency in the builder. 
        2. The user sets the signal generator to either list of fixed mode. 
           He has to set the frequencies and power that he wants. 
           Do not forget to send the list if in list mode !
        3. When satisfied, he click on "convert" in the pulse runner. This 
           sends the pulse sequence in the fpga. 
        4. The user runs the sequence. 
        5. The counts are sent, after each iteration of the pulse runner, to 
           the interpretor. The user can see them and choose the mode for
           interpreting them. He can save them. 
    
    """
    
    def __init__(self, fpga, name='The pulser you need.', show=True, size=[1500,900]):
        """
        Init. Ho yeaaaah. 
        
        fpga:
            "FPGA_api" object from api_fpga.py. 
            This is the object shared amoung the GUIs for controlling the fpga. 
            The session of the fpga must already be open. 
            
        """
        _debug('GUIMainPulseSequence: __init__', name)
        _debug('A reader lives a thousand lives before he dies. The man who never reads lives only one. ― George R.R. Martin')
        
        self.fpga = fpga
        
        # Run the basic stuff for the initialization
        egg.gui.Window.__init__(self, title=name, size=size)
        
        # =====================================================================
        # Build the masterpiece from base modules  
        # =====================================================================
        
        # The sacro-saint pulse runner
        self.gui_pulse_runner = GuiPulseRunner(self.fpga)
        # Remove the button set delay and replace it with a check box
        self.gui_pulse_runner.button_set_delays.hide()
        self.checkbox_delay = egg.gui.CheckBox(text='Add delays')
        self.gui_pulse_runner.place_object(self.checkbox_delay,
                                           row=5, column=2)
        self.place_object(self.gui_pulse_runner, row=0, column=0, row_span=2)
        
        # The not-equated signal generator
        self.sig_gen = GUISignalGenerator(show=False)
        self.gui_sig_gen = self.sig_gen.window  
        self.place_object(self.gui_sig_gen, row=0, column=1)
        
        # The unbelievable pulse builder
        self.gui_builder = GuiPulseBuilder()
        self.place_object(self.gui_builder, row=2, column=0)
        
        # The un-beated pulse interpretor 
        self.gui_interpret = GUIPulseInterpreter()
        self.place_object(self.gui_interpret, row=1, column=1, row_span=2)
        
        # =====================================================================
        # Connect the module together
        # =====================================================================  
        # Add task to the conversion button (and modify its labelling)
        txt = 'Built & Convert\n&Preprare everything'
        self.gui_pulse_runner.button_convert_sequence.set_text(txt)
        # Add some bad ass CSS style
        style = ('background-color: rgb(150, 255, 0);'+
               'border: 1px solid black;'+
               'margin-top: 2px;'+
               'margin-bottom: 2px;'+
               'margin-right: 2px;'+
               'margin-left: 2px;'+
               'padding: 6px;' )
        self.gui_pulse_runner.button_convert_sequence.set_style(style)        
        self.gui_pulse_runner.dummy_before_converting = self._prep_tasks
        # Make the interpretor reste his counts when the user clicks on reset
        self.gui_pulse_runner.dummy_before_resetting = self.gui_interpret.initiate_counts
        # Make the pulse runner to send the count to the interpretor. 
        self.gui_pulse_runner.dummy_after_one_loop = self.gui_interpret.add_count
        
        
        # Attempt to squeeze things together
        self.set_row_stretch(0)
        self.set_column_stretch(2)
        
    def _prep_tasks(self):
        """
        Make additional task to the conversion button. 
        Especially, take advantage of this moment to share some attribute 
        between the different modules .
        """
        _debug('GUIMainPulseSequence: _prep_tasks' )   

        # =====================================================================
        # Build the sequence and send it to the runner        
        # =====================================================================
        # Build and get the sequence
        self.sequence = self.gui_builder.get_sequence()
        # Send it to the pulse runner
        self.gui_pulse_runner.set_sequence(self.sequence)
        # Add the delays if we want
        if self.checkbox_delay.is_checked():
            # Remove the delay if there was previously
            if self.gui_pulse_runner.sequence_has_delay:
                self.gui_pulse_runner.button_set_delays.click()
            # Set the sequence
            self.gui_pulse_runner.set_sequence( self.sequence )
            # Set the delay
            self.gui_pulse_runner.button_set_delays.click()
            
        
        # =====================================================================
        # Prepare the signal generator for the sequence    
        # =====================================================================      
        #THE ORDER OF WHICH METHOD TO CALL FIRST SEEMS TO MATTER
        # For now, the way that we do it is not optimal, but 
        # The specific preparation depends on the mode
        mode_siggen = self.sig_gen.combo_mode.get_text()

            
        if mode_siggen == 'Fixed':
            # Note the fixed freq and power
            f = self.sig_gen.number_frequency.get_value()
            p = self.sig_gen.number_dbm.get_value()
            
            # Reset the parameters 
            self.sig_gen.button_reset.click()  
            # This method should set the pulse modulation to be external
            self.sig_gen.api.prepare_fixed_extmod()  
            # Set in Fixed mode and set the parameters
            self.sig_gen.combo_mode.set_value( index=0 )
            self.sig_gen.number_frequency.set_value( f )
            self.sig_gen.number_dbm      .set_value( p )
                    
        elif mode_siggen ==  'List' :
            # Reset the parameters 
            self.sig_gen.button_reset.click()  
            # This method should set the trigger to be external, pulse 
            # modulation, etc.
            self.sig_gen.api.prepare_list_extmod()
            # Prepare the list in the memory of the sig generator
            self.sig_gen.combo_mode.set_value(index=1) # Set in List mod
            # Now send the list, even if it was already done, because we just
            # reset
            self.sig_gen.button_send_list.click()
            
        #Switch on the RF output if it is not ON
        if not(self.sig_gen.button_rf.is_checked()):
            self.sig_gen.button_rf.click()
        

        # =====================================================================
        # Update the interpreter       
        # =====================================================================        
        # Tell the interpreter the number of block that the sequence has
        self.gui_interpret.set_nb_block( self.sequence.get_nb_block() ) 
        
        # Give him all the relevant info about the signal generator
        if mode_siggen == 'Fixed':
            fix_f = self.sig_gen.api.get_frequency() # In Hz
            fix_p = self.sig_gen.api.get_power()
            self.gui_interpret.set_sig_gen_fix(fix_f*1e-9, fix_p)
            
        elif mode_siggen ==  'List' :
            fs = np.array( self.sig_gen.api.get_list_frequencies() ) #This is in Hz
            ps = np.array( self.sig_gen.api.get_list_powers()      ) # In dBm
            self.gui_interpret.set_sig_gen_list(fs*1e-9, ps)
        
        
        
#By default set the object
if __name__ == '__main__':
    # Enable some debugs
    _debug_enabled = True
 
    # Open the FPGA
    import spinmob as sm
    infos = sm.data.load('cpu_specifics.dat')
    bitfile_path = infos.headers['FPGA_bitfile_path']
    resource_num = infos.headers['FPGA_resource_number']
    import api_fpga as _fc
    fpga = _fc.FPGA_api(bitfile_path, resource_num) 
    fpga.open_session()
    
#    from api_fpga import FPGA_fake_api
#    fpga = FPGA_fake_api('Pata', 'Pouf')
#    print()
#    print('!!! FAKE FPGA !!!!!')
#    print()
    
    self = GUIMainCustomePulseSequence(fpga)
    self.show()
    
    # When used with the confocal, we would connect the methods for optimizing
#    CONNECT THE OPTIMIZATION
    
    
    
    



        
        
        
        
        