# -*- coding: utf-8 -*-
"""
Created on Thu Aug 27 13:13:42 2020

Goal:
    Create a GUI for preparing the line sweep of the magnet. 

@author: Childresslab
"""

# Get usefull functions
import function_mag_sweep_line_settings as ff

import numpy as np
import spinmob as sm
from spinmob import egg

# For the plotting
from matplotlib.backends.backend_qt4agg import FigureCanvasQTAgg as FigureCanvas
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D # This import registers the 3D projection, but is otherwise unused.


import traceback
_p = traceback.print_last #Very usefull command to use for getting the last-not-printed error

# Debug stuff.
_debug_enabled                = False

def _debug(*a):
    if _debug_enabled: 
        s = []
        for x in a: s.append(str(x))
        print(', '.join(s))
        
        

class GUILinesSettings(egg.gui.Window):
    """
    Gui for generating and tweaking the settings for a line sweep of the magnet. 
    """
    def __init__(self, name='Sweep line setter', show=True, size=[1300,600]):
        """
        Create the GUI 
            
        """
        _debug('GUILinesSettings: __init__')
        _debug('Be happy with what you have while working for what you want. – Helen Keller')
        # Run the basic stuff for the initialization
        egg.gui.Window.__init__(self, title=name, size=size)

        # A combo box for the shpae of the sweep
        self.list_type = ['Flat_rectangle_parallel_z',
                          'Flat_rectangle_parallel_y',
                          'Flat_rectangle_parallel_x']
        self.comboxBox_type = egg.gui.ComboBox(self.list_type,
                                                        tip='Which type of sweep to create')
        self.place_object( self.comboxBox_type, 
                          row=0, column=0)
        self.connect(self.comboxBox_type.signal_changed, self._comboxBox_type_changed)
        self._comboxBox_type_changed() # Initiate the value
        
        # A Button for generating the sweep settings
        self.button_generate = self.place_object(egg.gui.Button('Generate'), 
                                            row=0, column=1, alignment=0)
        self.connect(self.button_generate.signal_clicked, self._button_generate_clicked )  

        # A Button for plotting the set of settings
        self.button_plot = self.place_object(egg.gui.Button('Plot in 3D'), 
                                            row=0, column=2, alignment=1)
        self.connect(self.button_plot.signal_clicked, self._button_plot_clicked ) 
        
        # A Button for saving the sweep settings
        self.button_save = self.place_object(egg.gui.Button('Save all that ;)'), 
                                            row=0, column=3, alignment=1)
        self.connect(self.button_save.signal_clicked, self._button_save_clicked )      

        
        # =====================================================================
        # The following are related to the table
        # =====================================================================
        
        # Add a numberbox for selecting which batch to show
        self.numberBox_batch = egg.gui.NumberBox(value=0, step=1, 
                                                      bounds=(0, None), int=True)
        self.place_object(egg.gui.Label('Batch #:'), row=1, column=3, alignment=-1)
        self.place_object(self.numberBox_batch, row=1, column=4, alignment=1)
        self.connect(self.numberBox_batch.signal_changed, self._numberBox_batch_changed)        
        
        # Add a table for the trajectories of the lines. 
        self.row_table      = 2
        self.column_table   = 3
        self.col_span_table = 4
        # Put an almost empty table for the beginning
        self.table_shown  = egg.gui.Table()
        self.place_object(self.table_shown, alignment=1,
                          row=self.row_table, 
                          column=self.column_table, 
                          column_span=self.col_span_table) 
        
        # =====================================================================
        # Attempt to make everything look nice
        # =====================================================================
        self.set_column_stretch(4)
        
        

    def _build_treeDict(self):
        """
        A methof to build the treeDictionnary for the rectangles.
        """
        _debug('GUILinesSettings: _build_treeDict')
        
        pos_bound = 25 # (mm) maximum position of the actuator
        
        
        if self.index_type == 0: 
            self.treeDic_settings = egg.gui.TreeDictionary(autosettings_path='setting_magsetting_rect_zfix')
            # The following is for specifying the top rectangle
            self.treeDic_settings.add_parameter('top_z', 20, 
                                                type='float',  
                                                bounds=[0,pos_bound], suffix=' mm',
                                                tip='Z position of the top rectangle ') 
            self.treeDic_settings.add_parameter('top_xmin', 5, 
                                                type='float',  
                                                bounds=[0,pos_bound], suffix=' mm',
                                                tip='X position of the bottom corner of the top rectangle') 
            self.treeDic_settings.add_parameter('top_xmax', 10, 
                                                type='float',  
                                                bounds=[0,pos_bound], suffix=' mm',
                                                tip='X position of the top corner of the top rectangle') 
            self.treeDic_settings.add_parameter('top_ymin', 5, 
                                                type='float',  
                                                bounds=[0,pos_bound], suffix=' mm',
                                                tip='Y position of the bottom corner of the top rectangle') 
            self.treeDic_settings.add_parameter('top_ymax', 10, 
                                                type='float',  
                                                bounds=[0,pos_bound], suffix=' mm',
                                                tip='Y position of the top corner of the top rectangle') 
            # The following is for specifying the bottom rectangle. 
            self.treeDic_settings.add_parameter('bot_z', 15, 
                                                type='float',  
                                                bounds=[0,pos_bound], suffix=' mm',
                                                tip='Z position of the bottom rectangle ') 
            self.treeDic_settings.add_parameter('bot_xmin', 5, 
                                                type='float',  
                                                bounds=[0,pos_bound], suffix=' mm',
                                                tip='X position of the bottom corner of the bottom rectangle') 
            self.treeDic_settings.add_parameter('bot_xmax', 7, 
                                                type='float',  
                                                bounds=[0,pos_bound], suffix=' mm',
                                                tip='X position of the top corner of the bottom rectangle') 
            self.treeDic_settings.add_parameter('bot_ymin', 5, 
                                                type='float',  
                                                bounds=[0,pos_bound], suffix=' mm',
                                                tip='Y position of the bottom corner of the bottom rectangle')         
            self.treeDic_settings.add_parameter('bot_ymax', 7, 
                                                type='float',  
                                                bounds=[0,pos_bound], suffix=' mm',
                                                tip='Y position of the top corner of the bottom rectangle') 
            # Other settings
            self.treeDic_settings.add_parameter('N_layer', 1, 
                                                type='int', 
                                                bounds=[1, None],
                                                tip='Number of layer to generate')
            self.treeDic_settings.add_parameter('N_zigzag', 6, 
                                                type='int', 
                                                bounds=[1, None],
                                                tip='Number of zigzag in a rectangle')
            self.treeDic_settings.add_parameter('Name', 'Fligh of Icarius', 
                                                type='str', 
    
                                                tip='Label for naming the settings when saved.')

        elif self.index_type == 1: 
            self.treeDic_settings = egg.gui.TreeDictionary(autosettings_path='setting_magsetting_rect_yfix')
            # The following is for specifying the top rectangle
            self.treeDic_settings.add_parameter('top_y', 20, 
                                                type='float',  
                                                bounds=[0,pos_bound], suffix=' mm',
                                                tip='Y position of the top rectangle ') 
            self.treeDic_settings.add_parameter('top_xmin', 5, 
                                                type='float',  
                                                bounds=[0,pos_bound], suffix=' mm',
                                                tip='X position of the bottom corner of the top rectangle') 
            self.treeDic_settings.add_parameter('top_xmax', 10, 
                                                type='float',  
                                                bounds=[0,pos_bound], suffix=' mm',
                                                tip='X position of the top corner of the top rectangle') 
            self.treeDic_settings.add_parameter('top_zmin', 5, 
                                                type='float',  
                                                bounds=[0,pos_bound], suffix=' mm',
                                                tip='Z position of the bottom corner of the top rectangle') 
            self.treeDic_settings.add_parameter('top_zmax', 10, 
                                                type='float',  
                                                bounds=[0,pos_bound], suffix=' mm',
                                                tip='Z position of the top corner of the top rectangle') 
            # The following is for specifying the bottom rectangle. 
            self.treeDic_settings.add_parameter('bot_y', 15, 
                                                type='float',  
                                                bounds=[0,pos_bound], suffix=' mm',
                                                tip='Y position of the bottom rectangle ') 
            self.treeDic_settings.add_parameter('bot_xmin', 5, 
                                                type='float',  
                                                bounds=[0,pos_bound], suffix=' mm',
                                                tip='X position of the bottom corner of the bottom rectangle') 
            self.treeDic_settings.add_parameter('bot_xmax', 7, 
                                                type='float',  
                                                bounds=[0,pos_bound], suffix=' mm',
                                                tip='X position of the top corner of the bottom rectangle') 
            self.treeDic_settings.add_parameter('bot_zmin', 5, 
                                                type='float',  
                                                bounds=[0,pos_bound], suffix=' mm',
                                                tip='Z position of the bottom corner of the bottom rectangle')         
            self.treeDic_settings.add_parameter('bot_zmax', 7, 
                                                type='float',  
                                                bounds=[0,pos_bound], suffix=' mm',
                                                tip='Z position of the top corner of the bottom rectangle') 
            # Other settings
            self.treeDic_settings.add_parameter('N_layer', 1, 
                                                type='int', 
                                                bounds=[1, None],
                                                tip='Number of layer to generate')
            self.treeDic_settings.add_parameter('N_zigzag', 6, 
                                                type='int', 
                                                bounds=[1, None],
                                                tip='Number of zigzag in a rectangle')
            self.treeDic_settings.add_parameter('Name', 'Dance of the Death', 
                                                type='str', 
    
                                                tip='Label for naming the settings when saved.')
            
        elif self.index_type == 2: 
            self.treeDic_settings = egg.gui.TreeDictionary(autosettings_path='setting_magsetting_rect_xfix')
            # The following is for specifying the top rectangle
            self.treeDic_settings.add_parameter('top_x', 20, 
                                                type='float',  
                                                bounds=[0,pos_bound], suffix=' mm',
                                                tip='X position of the top rectangle ') 
            self.treeDic_settings.add_parameter('top_ymin', 5, 
                                                type='float',  
                                                bounds=[0,pos_bound], suffix=' mm',
                                                tip='Y position of the bottom corner of the top rectangle') 
            self.treeDic_settings.add_parameter('top_ymax', 10, 
                                                type='float',  
                                                bounds=[0,pos_bound], suffix=' mm',
                                                tip='Y position of the top corner of the top rectangle') 
            self.treeDic_settings.add_parameter('top_zmin', 5, 
                                                type='float',  
                                                bounds=[0,pos_bound], suffix=' mm',
                                                tip='Z position of the bottom corner of the top rectangle') 
            self.treeDic_settings.add_parameter('top_zmax', 10, 
                                                type='float',  
                                                bounds=[0,pos_bound], suffix=' mm',
                                                tip='Z position of the top corner of the top rectangle') 
            # The following is for specifying the bottom rectangle. 
            self.treeDic_settings.add_parameter('bot_x', 15, 
                                                type='float',  
                                                bounds=[0,pos_bound], suffix=' mm',
                                                tip='X position of the bottom rectangle ') 
            self.treeDic_settings.add_parameter('bot_ymin', 5, 
                                                type='float',  
                                                bounds=[0,pos_bound], suffix=' mm',
                                                tip='Y position of the bottom corner of the bottom rectangle') 
            self.treeDic_settings.add_parameter('bot_ymax', 7, 
                                                type='float',  
                                                bounds=[0,pos_bound], suffix=' mm',
                                                tip='Y position of the top corner of the bottom rectangle') 
            self.treeDic_settings.add_parameter('bot_zmin', 5, 
                                                type='float',  
                                                bounds=[0,pos_bound], suffix=' mm',
                                                tip='Z position of the bottom corner of the bottom rectangle')         
            self.treeDic_settings.add_parameter('bot_zmax', 7, 
                                                type='float',  
                                                bounds=[0,pos_bound], suffix=' mm',
                                                tip='Z position of the top corner of the bottom rectangle') 
            # Other settings
            self.treeDic_settings.add_parameter('N_layer', 1, 
                                                type='int', 
                                                bounds=[1, None],
                                                tip='Number of layer to generate')
            self.treeDic_settings.add_parameter('N_zigzag', 6, 
                                                type='int', 
                                                bounds=[1, None],
                                                tip='Number of zigzag in a rectangle')
            self.treeDic_settings.add_parameter('Name', 'Dance of the Death', 
                                                type='str', 
                                                tip='Label for naming the settings when saved.')
            
        # Finally, place the treeDict in the GUI
        self.place_object(self.treeDic_settings, 
                          row=1, column=0, column_span=3, row_span=3)        

    def _comboxBox_type_changed(self):
        """
        Change the type of sweep to prepare
        """
        _debug('GUILinesSettings: _comboxBox_type_changed')
        
        self.index_type = self.comboxBox_type.get_value()
        # Build the treeDictionary in function of the type choosen
        self._build_treeDict()
            
            
        
    def _button_generate_clicked(self):
        """
        Generate the settings
        """
        _debug('GUILinesSettings: _button_generate_clicked')

        if self.index_type == 0:        
            # Extract the settings into variables for convenience
            # For the geometry
            dz = self.treeDic_settings['top_z'] - self.treeDic_settings['bot_z']
            dx_max = self.treeDic_settings['top_xmax'] - self.treeDic_settings['bot_xmax']
            dy_max = self.treeDic_settings['top_ymax'] - self.treeDic_settings['bot_ymax']
            dx_min = self.treeDic_settings['top_xmin'] - self.treeDic_settings['bot_xmin']
            dy_min = self.treeDic_settings['top_ymin'] - self.treeDic_settings['bot_ymin']
            # Other parameters
            N_layer = self.treeDic_settings['N_layer']
            N_zigzag = self.treeDic_settings['N_zigzag']
            
            # Initiate the list of settings
            self.list_settings = []
            # Generate each setting
            for i in range(N_layer):
                # Compute the corresponding bound by linearly interpolate the bound
                if N_layer > 1:
                    alpha = i/(N_layer-1) # Goes from 0 to 1
                else:
                    alpha = 0
                xmax = alpha*dx_max + self.treeDic_settings['bot_xmax']
                ymax = alpha*dy_max + self.treeDic_settings['bot_ymax']
                xmin = alpha*dx_min + self.treeDic_settings['bot_xmin']
                ymin = alpha*dy_min + self.treeDic_settings['bot_ymin']
                z    = alpha*dz     + self.treeDic_settings['bot_z']
               
                # Generate the layer
                layer = ff.rectangle_parallel_zfixed([xmin,ymin], [xmax,ymax], 
                                                     N_zigzag, z)
                # Keep it in note
                self.list_settings.append(layer)
                
        elif self.index_type == 1:
            # Extract the settings into variables for convenience
            # For the geometry
            dy = self.treeDic_settings['top_y'] - self.treeDic_settings['bot_y']
            dx_max = self.treeDic_settings['top_xmax'] - self.treeDic_settings['bot_xmax']
            dz_max = self.treeDic_settings['top_zmax'] - self.treeDic_settings['bot_zmax']
            dx_min = self.treeDic_settings['top_xmin'] - self.treeDic_settings['bot_xmin']
            dz_min = self.treeDic_settings['top_zmin'] - self.treeDic_settings['bot_zmin']
            # Other parameters
            N_layer = self.treeDic_settings['N_layer']
            N_zigzag = self.treeDic_settings['N_zigzag']
            
            # Initiate the list of settings
            self.list_settings = []
            # Generate each setting
            for i in range(N_layer):
                # Compute the corresponding bound by linearly interpolate the bound
                if N_layer > 1:
                    alpha = i/(N_layer-1) # Goes from 0 to 1
                else:
                    alpha = 0
                xmax = alpha*dx_max + self.treeDic_settings['bot_xmax']
                zmax = alpha*dz_max + self.treeDic_settings['bot_zmax']
                xmin = alpha*dx_min + self.treeDic_settings['bot_xmin']
                zmin = alpha*dz_min + self.treeDic_settings['bot_zmin']
                y    = alpha*dy     + self.treeDic_settings['bot_y']
               
                # Generate the layer
                layer = ff.rectangle_parallel_yfixed([xmin,zmin], [xmax,zmax], 
                                                     N_zigzag, y)
                # Keep it in note
                self.list_settings.append(layer)

        elif self.index_type == 2:
            # Extract the settings into variables for convenience
            # For the geometry
            dx = self.treeDic_settings['top_x'] - self.treeDic_settings['bot_x']
            dy_max = self.treeDic_settings['top_ymax'] - self.treeDic_settings['bot_ymax']
            dz_max = self.treeDic_settings['top_zmax'] - self.treeDic_settings['bot_zmax']
            dy_min = self.treeDic_settings['top_ymin'] - self.treeDic_settings['bot_ymin']
            dz_min = self.treeDic_settings['top_zmin'] - self.treeDic_settings['bot_zmin']
            # Other parameters
            N_layer = self.treeDic_settings['N_layer']
            N_zigzag = self.treeDic_settings['N_zigzag']
            
            # Initiate the list of settings
            self.list_settings = []
            # Generate each setting
            for i in range(N_layer):
                # Compute the corresponding bound by linearly interpolate the bound
                if N_layer > 1:
                    alpha = i/(N_layer-1) # Goes from 0 to 1
                else:
                    alpha = 0
                ymax = alpha*dy_max + self.treeDic_settings['bot_ymax']
                zmax = alpha*dz_max + self.treeDic_settings['bot_zmax']
                ymin = alpha*dy_min + self.treeDic_settings['bot_ymin']
                zmin = alpha*dz_min + self.treeDic_settings['bot_zmin']
                x    = alpha*dx     + self.treeDic_settings['bot_x']
               
                # Generate the layer
                layer = ff.rectangle_parallel_xfixed([ymin,zmin], [ymax,zmax], 
                                                     N_zigzag, x)
                # Keep it in note
                self.list_settings.append(layer)            
        
        # Show the first table
        # It shouyld trigger a signal that update the table shown.
        self._numberBox_batch_changed()
        
    def _button_plot_clicked(self):
        """
        Plot all the settings
        """
        _debug('GUILinesSettings: _button_plot_clicked')
        
        # Create a figure and prepare the plot
        # tight_layout make sure the labels are visible
        self.fig = plt.figure(tight_layout=True) 
        self.ax = self.fig.add_subplot(111, projection='3d') 
        
        # Plot each batch of setting
        for i, settings in enumerate( self.list_settings):
            # Thanks to the magical function
            ff.plot_magSweepLinesSettings(settings, ax=self.ax, 
                                          color='C%d'%i)
        
    def _button_save_clicked(self):
        """
        Save the list of settings
        """
        _debug('GUILinesSettings: _button_save_clicked')
        
        # Save a file for each set of settings. 
        name = self.treeDic_settings['Name']
        # Ask the user the location of the settings
        txt = 'Select a directory for saving the file'
        self.my_dir = sm.dialogs.select_directory(txt)
        
        # Save each settings separately
        for i, settings in enumerate(self.list_settings):
            # =================================================================
            # Prepare the databox
            # =================================================================
            self.databox_settings = sm.data.databox()
            
            # The three dictionary, why not.
            for key in self.treeDic_settings.get_keys():
                # Add each element of the dictionnary three
                self.databox_settings.insert_header(key , self.treeDic_settings[key])
                
            # Add the trajectories in the table
            N = len(settings[0]) # Number of points
            xs = []
            ys = []
            zs = []
            for jj in range (N):
                xs.append(float( settings[0][jj] ))
                ys.append(float( settings[1][jj] ))
                zs.append(float( settings[2][jj] ))
            self.databox_settings['xs'] = xs
            self.databox_settings['ys'] = ys
            self.databox_settings['zs'] = zs
            
            #Save it
            path = self.my_dir + '\\' + name + ' %.3d'%i + '.dat'
            self.databox_settings.save_file(path=path)
        
    def _numberBox_batch_changed(self):
        """
        What to do when the index for the number box changed.
        """
        _debug('GUILinesSettings: _numberBox_batch_changed')
        
        # Get the value
        value = self.numberBox_batch.get_value()
        
        # Make sure that we do not over shoot.
        if value >= len(self.list_settings):
            # Do not allow to overshoot the number of list element
            self.numberBox_batch.set_value(value-1)
            return
        
        # If we get here, it is safe to continue with the value
        
        # Update the value
        self.batch_shown = value
        _debug('GUILinesSettings: _numberBox_batch_changed: value = ', value)
        
        # Set the table shown
        settings = self.list_settings[self.batch_shown]
        self.table_shown = self._create_one_table(settings[0],
                                                 settings[1],
                                                 settings[2])
        # Show it by placing it in the gui
        self.place_object(self.table_shown, 
                          row=self.row_table, 
                          column=self.column_table, 
                          column_span=self.col_span_table)       
            
    def _create_one_table(self, xs=[0], ys=[0], zs=[0]):
        """
        Create a table with the input positions.
        Return this table.
        
        xs, ys,zs:
            Same size list of x, y and z. 
            
        """
        _debug('GUILinesSettings: table_trajectories_fill')
        
        #Try to open the data
        try: 
            #First check if the lenghts matche
            if not (len(xs) == len(ys)):
                return 'Lenght of xs and ys do not match !'
            if not (len(ys) == len(zs)):
                return 'Lenght of ys and zs do not match !'  
            if not (len(zs) == len(xs)):
                return 'Lenght of xs and zs do not match !'
            #If we pass here, we are ready to extract the position from the data 
            
            # Initiate the table
            a_table = egg.gui.Table(columns = 3)

            # The first row will be a label for indicating what are each collumns
            a_table.set_value(column=0, row=0, value='xs (um)')
            a_table.set_value(column=1, row=0, value='ys (um)') 
            a_table.set_value(column=2, row=0, value='zs (um)')                 
            # Then input the new one. 
            for i in range(0, len(xs) ):
                # X position 
                a_table.set_value(column=0, row=i+1, value=xs[i])
                # Y position 
                a_table.set_value(column=1, row=i+1, value=ys[i])                
                # Z position 
                a_table.set_value(column=2, row=i+1, value=zs[i]) 
                
            # Ready to return ;) 
            return a_table
            
        except: 
            print('GUILinesSettings: table_trajectories_fill '+
                  '\nError in reading the data from the file :S '    ) 
        
#By default set the object
if __name__ == '__main__':
    _debug_enabled = True 
    
    self = GUILinesSettings()
    self.show()
    
    














