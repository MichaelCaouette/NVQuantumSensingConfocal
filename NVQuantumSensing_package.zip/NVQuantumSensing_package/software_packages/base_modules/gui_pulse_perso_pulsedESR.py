# -*- coding: utf-8 -*-
"""
Created on Thu Oct  8 11:39:41 2020

Goal: Measure pulsed ESR

@author: Childresslab
"""


# Get some base modules
from gui_signal_generator import GUISignalGenerator
from gui_pulse_runner import GuiPulseRunner
from count_interpreter import ProcessFPGACounts
from pulses import ChannelPulses, PulsePatternBlock, Sequence
import api_fpga as _fc

# Other cool imports
import copy
import time
import numpy as np
from spinmob import egg
import traceback
_p = traceback.print_last #Very usefull command to use for getting the last-not-printed error


_debug_enabled     = False
def _debug(*a):
    if _debug_enabled: 
        s = []
        for x in a: s.append(str(x))
        print(', '.join(s))



class GUIPulsedESR(egg.gui.Window):
    """
    GUI for making the following measurement:
        A pulsed ESR (Fixed RF pulse duration, sweep the frequency)
    
    """   
    def __init__(self, fpga, name="How is your pulse ?", size=[1100,900]): 
        """
        Initialize

        fpga:
            "FPGA_api" object from api_fpga.py. 
            This is the object shared amoung the GUIs for controlling the fpga. 
            The session of he fpga must already be open.
        
        """    
        _debug('GUIPulsedESR:__init__')
        _debug('It might not be easy but it’ll be worth it. – Unknown')
        
        # Run the basic stuff for the initialization
        egg.gui.Window.__init__(self, title=name, size=size)

        # Steal the fpga, mouhahaha
        self.fpga = fpga
        # Overid a method that, hopefully, should prevent the freeze out of the
        # gui for long pulse sequence.
        self.fpga.dummy_event_pulse_is_long = self.process_events
        
        # Initialise the GUI
        self._initialize_GUI()
        
    def _initialize_GUI(self):
        """
        Fill up the GUI
        """        
        _debug('GUIPulsedESR: _initialize_GUI')
        
        # A button for preparing stuff
        self.button_prepare_experiment = egg.gui.Button('Prepare all settings',
                                                        tip='Prepare the measurement before running')
        self.place_object(self.button_prepare_experiment, row=0, column=0)
        self.connect(self.button_prepare_experiment.signal_clicked, 
                     self._button_prepare_experiment_clicked)
        
        # Add the pulse runner
        self.gui_pulse_runner = GuiPulseRunner(self.fpga)
        self.place_object(self.gui_pulse_runner, 
                          row=1, column=0, row_span=5)
        # Overid the method for processing properly after the loop.
        self.gui_pulse_runner.dummy_after_one_loop = self.after_one_loop     
        
        # Add the signal generator
        self.sig_gen = GUISignalGenerator(show=False, name='sig_gen_pulsed_ESR')
        self.gui_sig_gen    = self.sig_gen.window    
        self.place_object(self.gui_sig_gen, row=1, column = 1, row_span=1)
        
        # Add relevant stuffs in the three dictionnary of the signal generator
        # Copy it before to set it. This is an attempt to have the autosaving 
        # path to work. 
        self.new_setting = copy.copy(self.sig_gen.settings)
        self.new_setting.add_parameter('dt_rf_pulse', 1, 
                                            type='float', step=1/120, decimals=10,
                                            bounds=[0,None], suffix=' us',
                                            tip='Duration of the RF pulse') 
      
        self.new_setting.add_parameter('dt_readout', 0.4, 
                                            type='float',step=1/120, decimals=10,
                                            bounds=[0,None], suffix=' us',
                                            tip='Duration of the readout') 
        self.new_setting.add_parameter('dt_laser_init', 3, 
                                            type='float',step=1/120, decimals=10,
                                            bounds=[0,None], suffix=' us',
                                            tip='Duration of laser to initiate the state in ms=0') 
        
        self.new_setting.add_parameter('dt_wait_after_laser_init', 1, 
                                            type='float', step=1/120, decimals=10,
                                            bounds=[0,None], suffix=' us',
                                            tip='How much time to wait for considering the state /ninto ms=0 after shining with the laser. /n(i.e. Waiting for the singlet decay)')                
        self.new_setting.add_parameter('dt_read_after_RF', 1, 
                                            type='float', step=1/120, decimals=10,
                                            bounds=[0,None], suffix=' us',
                                            tip='How much time to wait before reading after the RF') 
        self.new_setting.add_parameter('delay_read_before_laser', 0.05, 
                                            type='float', step=1/120, decimals=10,
                                            bounds=[0,None], suffix=' us',
                                            tip='Delay that we read before shining the laser')  
        self.new_setting.add_parameter('delay_wait_list_change', 2000, 
                                            type='float', step=1/120, decimals=10,
                                            bounds=[0,None], suffix=' us',
                                            tip='Delay that we need to wait before the setting on the\nsignal generator changes the list element.')  
        self.new_setting.add_parameter('dt_trigger', 100, 
                                            type='float', step=1/120, decimals=10,
                                            bounds=[0,None], suffix=' us',
                                            tip='Duration of the trigger to change the frequency')  
        self.new_setting.add_parameter('duty_cycle_fraction', 0.8, 
                                            type='float', step=0.1, decimals=10,
                                            bounds=[0,1],
                                            tip='Fraction of time over which to perform the pulse sequence instead of waiting the signal generator.')  
         
        self.new_setting.add_parameter('DIO_laser', 2, 
                                            type='int', step=1, 
                                            bounds=[0,16],
                                            tip='DIO for the laser')          
        self.new_setting.add_parameter('DIO_pulse_modulation', 6, 
                                            type='int', step=1, 
                                            bounds=[0,16],
                                            tip='DIO for modulating the pulse')  
        self.new_setting.add_parameter('DIO_change_frequency', 7, 
                                            type='int', step=1, 
                                            bounds=[0,16],
                                            tip='DIO for triggering the change in frequency')  
        self.new_setting.add_parameter('DIO_sync_scope', 5, 
                                            type='int', step=1, 
                                            bounds=[-1,16],
                                            tip='DIO for synchronizing the oscilloscope. Put -1 for nothing')             
        
        self.sig_gen.settings = self.new_setting
        # Some connections
        self.sig_gen.settings.connect_any_signal_changed(self._round_off_fpga_times)
        self._round_off_fpga_times()
        
        # Add a Data Box plotter for the incoming data
        self.databoxplot = egg.gui.DataboxPlot(autosettings_path='plot_pulsed_ESR')
        self.place_object(self.databoxplot,
                          row=2, column = 1, row_span=3) 
        self.databoxplot.button_multi.set_value(False) # Make all on the same plot
        
        # Some streching for making the gui more beautiful
#        self.gui_sig_gen.set_row_stretch(2)
        self.set_row_stretch(1)
        self.set_column_stretch(2)
        
    def _round_off_fpga_times(self):
        """
        Round off the timing in the treeDictionnary such that they match interger 
        multiple of the fpga ticks. 
        """
        _debug('GUIPulsedESR: _round_off_fpga_times')
        # Block the events to avoid recalling of the method many times
        self.sig_gen.settings.block_events()
        
        # Get the resolution time
        t_reso = self.fpga.tickDuration 
        # List the keys of the parameters that we want to roundoff
        keys = ['dt_rf_pulse', 'dt_readout','dt_wait_after_laser_init',
                'dt_read_after_RF', 'delay_read_before_laser', 'dt_laser_init',
                'delay_wait_list_change']
        for key in keys:
            # Round off the relevant times
            t_aim = self.sig_gen.settings[key]
            N = np.round(t_aim/t_reso)
            t_true = N*t_reso
            self.sig_gen.settings.set_value(key, t_true, 
                                            ignore_error=True, block_key_signals=True)
            _debug('Rounding off %s from %f us to %f us'%(key, t_aim, t_true))
      
        # Unblock the event 
        self.sig_gen.settings.unblock_events()

    def _button_prepare_experiment_clicked(self):
        """
        Prepare the experiment:
            Prepare the pulse sequence class.
            Prepare the axis of the plot
        """
        _debug('GUIPulsedESR: _button_prepare_experiment_clicked')   
        
        # By default, we click on generate list, because it is more convient. 
        # However, at some point we would liek the user to use whatever list he 
        # wants. 
        
        self.prepare_pulse_experiment(click_generate_list=True)
    
    def prepare_pulse_experiment(self, click_generate_list=False):
        """
        Useful method to prepare the experiment without generating an automatic
        list of frequency and power. 
        This is useful especially for some funky protocol where we have our own
        list of frequency and power to sweep. 
        
        click_generate_list:
            (Boolean) If true, we will click on generate_list on the signal 
            generator gui. 
        
        For now, it is the exact same thing as 
        "_button_prepare_experiment_clicked"
        But with the click on generating list
        
        We could do better by having an if condition and merging the towo methods
        """
        _debug('GUIPulsedESR: prepare_pulse_experiment')

        # Prepare the sequence accoring to the best knowledge that we have so far. 
        self.prepare_pulse_sequence()
        
        # We want the fpga NOT in each tick mode
        self.gui_pulse_runner.CheckBox_CET_mode.set_checked(value=False)
        
        # The following lines is for giving the sequence with delays
        # Remove the delay if there was previously
        if self.gui_pulse_runner.sequence_has_delay:
            self.gui_pulse_runner.button_set_delays.click()
        # Set the sequence
        self.gui_pulse_runner.set_sequence( self.sequence )
        # Set the delay
        self.gui_pulse_runner.button_set_delays.click()

        # Make the instrumenbt ready for the pulse sequence
        #THE ORDER OF WHICH METHOD TO CALL FIRST MIGHT MATTER
        self.sig_gen.button_reset.click()  # Reset the parameters 

        # The method should set the trigger to be external, pulse modulatiion, etc. 
        self.sig_gen.api.prepare_list_extmod()
        # Prepare the signal generator for a list seep
        self.sig_gen.combo_mode.set_value(index=1) # Set in List mode
        if click_generate_list:
            self.sig_gen.button_generate_list.click()
        self.sig_gen.button_send_list.click()
        

        #Switch on the RF output if it is not ON
        if not(self.sig_gen.button_rf.is_checked()):
            self.sig_gen.button_rf.click()
        
        # Get the real frequency and power list
        self.fs_real = np.array(self.sig_gen.api.get_list_frequencies()) # This is in Hz
        self.x_axis = self.fs_real*1e-9 # In GHz     
        self.ps_real = np.array(self.sig_gen.api.get_list_powers()  )      
        
        
        
    def prepare_pulse_sequence(self):
        """
        Prepare the pulse sequence. 
        It generates the objet to be converted into a data array. 
        """
        _debug('GUIPulsedESR: prepare_pulse_sequence')
        
        # Initiate the sequence on which we gonna construct the  sequence
        sequence = Sequence(name='Wonderful Rabi')
        
        DIO_laser   = self.sig_gen.settings['DIO_laser']
        DIO_PM      = self.sig_gen.settings['DIO_pulse_modulation']
        DIO_sync    = self.sig_gen.settings['DIO_sync_scope']
        DIO_trig    = self.sig_gen.settings['DIO_change_frequency']
        
        # It is aimed, but we know that the real definition of the time is set
        # by the tick of the FPGA.        
        self.dt_rf_aim  = self.sig_gen.settings['dt_rf_pulse'] # Aim duration of the pi-pulse
        
        self.nb_block            = self.sig_gen.settings['List/N'] # Number of point to take at each sequence
        dt_readout               = self.sig_gen.settings['dt_readout'] # Readout time (us)
        delay_read               = self.sig_gen.settings['delay_read_before_laser'] # Delay (us) that we read before shining the laser
        dt_read_after_RF         = self.sig_gen.settings['dt_read_after_RF'] # How long to wait before reading after the RF (us)
        dt_wait_after_laser_init = self.sig_gen.settings['dt_wait_after_laser_init']
        dt_laser_init            = self.sig_gen.settings['dt_laser_init']
        delay_wait_list_change   = self.sig_gen.settings['delay_wait_list_change']        
        dt_trigger               = self.sig_gen.settings['dt_trigger']
        duty_cycle_fraction      = self.sig_gen.settings['duty_cycle_fraction']
        
        # Note for how much time we want to perfrom the pulse sequence
        self.time_to_perform_sequence = duty_cycle_fraction*delay_wait_list_change/(1-duty_cycle_fraction)


        # Initiate the channels
        # Create a channel for synching the scope if the user wants
        if DIO_sync>0:
            channel_sync = ChannelPulses(channel=DIO_sync, name='Sync with scope')
            channel_sync.add_pulses([0, 0.5]) # At the beggining
            
        # Channel for the laser output, which follows the readout
        channel_laser = ChannelPulses(channel=DIO_laser, name='Laser')             
        # Channel for the modulatiion of the RF
        channel_RF_mod = ChannelPulses(channel=DIO_PM, name='RF modulation')            
        # Channel for the readout
        channel_read = ChannelPulses(channel=1, name='Read') 
        # Channel for switching the frequency on the signal generator
        channel_trig = ChannelPulses(channel=DIO_trig, name='Trigger')
        
        
        # Now define what gonna happens in each channel for each block
        # (the pattern is the same in each block for this measurement. The
        #  settings will change from the signal generator
        
        # Wait that the list element in the signal generator changes
        t0 = delay_wait_list_change
        
        # Before looping, make a first initialization of the state
        # Initialize the state into ms=0 with the green laser
        channel_laser.add_pulses([t0, t0 + dt_laser_init])    
        
        # Note the last time for reference
        t_last = channel_laser.get_pulses_times()[-1]
            
        
        self.number_of_same_measure = 0 # Whil indicate how much time that the same sequence is repeated. 
        dt_total = 0 # Total added time of the pulse sequence
        while dt_total<=self.time_to_perform_sequence:
            self.number_of_same_measure += 1 
            t_in = t_last
            # Read the state (for a reference)
            t0 = t_in + dt_wait_after_laser_init
            channel_read.add_pulses([t0-delay_read, t0+dt_readout])
            # Also shine the laser for reading and re-iniating ms=0
            channel_laser.add_pulses([t0, t0 + dt_laser_init]) 
            
            # Send the pi-pulse 
            t0 = channel_laser.get_pulses_times()[-1] + dt_wait_after_laser_init
            # Only put a pulse if the duration is longer than one tick
            if self.dt_rf_aim >= self.fpga.tickDuration:
                # The RF spasn from time zero to the duration
                channel_RF_mod.add_pulses([t0, t0 + self.dt_rf_aim])
                # Note the real time interval for this pulse
                times_pulses = channel_RF_mod.get_pulses_times() # This gives all the raise and fall
                self.dt_rf_real = times_pulses[-1] - times_pulses[-2] # Last interval
            else:
                # Note the zero time interval
                self.dt_rf_real = 0
                
            # Read the population
            t0 = times_pulses[-1] + dt_read_after_RF
            channel_read.add_pulses([t0-delay_read, t0+dt_readout])
            # Also shine the laser for reading and re-iniating ms=0
            channel_laser.add_pulses([t0, t0 + dt_laser_init]) 
            
            # Read at the end for a reference
            t0 = channel_laser.get_pulses_times()[-1]
            channel_read.add_pulses([t0-dt_readout, t0])
            
            # Note the last time 
            t_last = channel_read.get_pulses_times()[-1]
            # Update the total time of the sequence
            dt_total += t_last - t_in
        
        # Trigger the signal generato to change the element of the list. 
        t0 = t_last
        channel_trig.add_pulses([t0, t0+dt_trigger])
          
        # Initiate the sequence on which we gonna construct the Rabi sequence
        sequence = Sequence(name='Pi-Pulse measurement')  
        
        for i in range(self.nb_block):
            # Build the block
            block = PulsePatternBlock(name='Block Pi-Pulse = %.2f us'%self.dt_rf_real)
            block.add_channelEvents([channel_sync,
                                     channel_RF_mod,
                                     channel_read ,
                                     channel_laser,
                                     channel_trig])
            # Add the block to the sequence
            sequence.add_block(block)
        
        self.sequence = sequence       
        

    def databoxplot_update(self):
        """
        Update the plot
        """
        _debug('GUIPulsedESR: databoxplot_update')
        
        # CLear the plot
        self.databoxplot.clear() 

        # Add important information in the header
        # Infor for recovering the total number of readout. Just multiply the 
        # three numbers
        self.databoxplot.insert_header('repetition', self.rep)
        self.databoxplot.insert_header('iteration' , self.iteration)
        self.databoxplot.insert_header('Nb_readout_per_sequence' , self.number_of_same_measure)

        # Add the date
        self.databoxplot.insert_header('date', time.ctime(time.time()))     
        self.databoxplot.insert_header('absolute_time_sec', time.time())  
        for key in self.sig_gen.settings.get_keys():
            # Add each element of the dictionnary three
            self.databoxplot.insert_header(key , self.sig_gen.settings[key])
            
        #  signal generator in this GUI. 
        self.databoxplot['Frequency_(GHz)'] = self.x_axis
        self.databoxplot['Power_(dBm)']     = self.ps_real
        # Loop over each readout 
        for i, count_per_readout in enumerate(self.counts_total):
            # Add a curve
            self.databoxplot['Total_counts_%d'%i] = count_per_readout
            
        # Show it
        self.databoxplot.plot()     
        
    def after_one_loop(self, counts, iteration, rep):
        """
        What to do after one loop of the fpga. 

        This is called after each loop (single run) of the fpga. 
        
        counts:
            Array of counts that the fpga get. 
        iteration:
            int corresponding to which iteration are we at
            
        rep:
            Number of repetition of the sequence into the fpga instruction
            """
        _debug('GUIPulsedESR: after_one_loop')
        
        # Note that for saving 
        self.rep = rep
        self.iteration = iteration
        self.counts_prior_to_process = counts # Save it for debugging
        
        # Get, for each block, the array of counts (summed over the repetitions)
        self.proc = ProcessFPGACounts()
        counts_per_block_s = self.proc.get_sum_count_per_block(self.counts_prior_to_process, 
                                                               self.rep, 
                                                               self.nb_block)
        
        # Initiate the array that gonna contain the total counts per block
        self.count1 = []
        self.count2 = []
        self.count3 = []
        
        # for each block, split the counts corresponding to the right 
        for counts_per_block in counts_per_block_s:
            # The following line makes many things. 
            # It split the array of counts based on how many time the same sequence
            # is repeated within the block.
            # Then it sums over each repetition. 
            # We end up, for this block, to have the counts for each gate
            self.summed_count_vs_gate = np.sum( np.split( counts_per_block, self.number_of_same_measure) ,axis=0)
            
            self.count1.append(self.summed_count_vs_gate[0])
            self.count2.append(self.summed_count_vs_gate[1])
            self.count3.append(self.summed_count_vs_gate[2])
            
        # If its the first iteration
        if iteration == 0:
            # Get the count and the correct shape for the array
            self.counts_total  = np.array([self.count1,
                                          self.count2,
                                          self.count3])  
        else:
            # Increment the counts
            self.counts_total += np.array([self.count1,
                                          self.count2,
                                          self.count3]) 
            
        # Update the total number of readout
        self.N_total_readout = self.rep * self.iteration * self.number_of_same_measure
            
        # Update the plot
        self.databoxplot_update()
        
    def get_data(self):
        """
        Convinient method for an external user. 
        It returns the collected measurements, in the form of a tuple of numpy
        arrays for each list of things. 
        
        return fs, ps, c0s, c1s, crefs
        TODO EXPLAIN this in more details
        
        """
        _debug('GUIPulsedESR: get_data')
        
        fs = self.databoxplot['Frequency_(GHz)']
        ps = self.databoxplot['Power_(dBm)']  
        c0s = self.databoxplot['Total_counts_0']
        c1s = self.databoxplot['Total_counts_1']
        crefs = self.databoxplot['Total_counts_2']
        
        return fs, ps, c0s, c1s, crefs
    
    def get_total_N_readout(self):
        """
        Return the total number of readout for the counts
        """
        _debug('GUIPulsedESR: get_total_N_readout')
        return self.N_total_readout
        
     
        
if __name__=="__main__":
    # Enable some usefull debugger
    _debug_enabled = True
    
    
    # Get the fpga paths and ressource number
    import spinmob as sm
    infos = sm.data.load('cpu_specifics.dat')
    bitfile_path = infos.headers['FPGA_bitfile_path']
    resource_num = infos.headers['FPGA_resource_number']
    # Get the fpga API
    fpga = _fc.FPGA_api(bitfile_path, resource_num) 
    fpga.open_session()
    
#    # If we want a fake FPGA API for testing the code
#    fpga = _fc.FPGA_fake_api(bitfile_path, resource_num) # Create the api   
#    fpga.open_session()
#    print()
#    print('FAKE FPGA API')
#    print()
    
    # Get the principal GUI
    self = GUIPulsedESR(fpga, size=[1800,800])
    self.show()     
        
        
        
        
        
        
        
        
        
        
        
        
        
