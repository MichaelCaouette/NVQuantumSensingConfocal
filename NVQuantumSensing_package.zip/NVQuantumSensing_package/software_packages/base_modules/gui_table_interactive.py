# -*- coding: utf-8 -*-
"""
Created on Tue Feb  2 17:46:30 2021


@author: Childresslab
"""

from spinmob import egg
import numpy as np

import traceback
# Very usefull command to use for getting the last-not-printed error
# Just type _p() in the console 
_p = traceback.print_last

#Debug
_debug_enabled           = False

def _debug(*a):
    if _debug_enabled: 
        s = []
        for x in a: s.append(str(x))
        print(', '.join(s))
        
        
class GUITableInteractive(egg.gui.Window):
    """
    GUI for building a table interactively. 
    
    The first row should be strings labeling each column.
    The other row are for the value of the column
    
    """
    
    def __init__(self, nb_columns=4, name='Table builder', show=True, size=[1300,600]):
        """
        Create the GUI. 
        
        nb_columns:
            Number of columns of the table. 
        """
        _debug('GUITableInteractive: __init__', name)
        _debug('You never know what you can do until you try. – William Cobbett')
        
        # Run the basic stuff for the initialization
        egg.gui.Window.__init__(self, title=name, size=size)
        
        # Some attribute
        self.nb_row = 0 # Number of row EXCLUDING the first one
        self.nb_columns = nb_columns # Number of columns
        # Will contain the list of each columns after the first row
        self.list_columns = [] 

        # =====================================================================
        # Build the GUI
        # =====================================================================
        
        #Add a button for add a row
        self.button_add_row = egg.gui.Button('Add a row :3')
        self.place_object(self.button_add_row,row=0, column=0, alignment=1)
        self.connect(self.button_add_row.signal_clicked, self._button_add_row_clicked )
        
        #Add a button for removing a row
        self.button_remove_row = egg.gui.Button('Remove a row :/')
        self.place_object(self.button_remove_row,row=0, column=1, alignment=1)
        self.connect(self.button_remove_row.signal_clicked, self._button_remove_row_clicked )
        
        # Add a button for resetting the table
        self.button_reset = egg.gui.Button('Reset :S')
        self.place_object(self.button_reset,row=0, column=2, alignment=1)
        self.connect(self.button_reset.signal_clicked, self._button_reset_clicked )        

        # Add the sacro-saint table
        self.table  = egg.gui.Table()
        self.place_object(self.table, row=1, column=0, 
                          column_span=10) 
        # Fill it up with some stuff
        list_row = []
        for i in range(self.nb_columns):
            list_row.append('Raow%d'%i )
        self.set_first_row(list_row)
        
        # Attempt to make the size look good
        self.set_column_stretch(10)

    def _button_add_row_clicked(self):
        """
        Add a row on the table
        """
        _debug('GUISweepLines: button_add_row_clicked')
        
        # Add an element at each column of the new row
        for i in range(self.nb_columns):
            self.table.set_value(column=i, row=self.nb_row+1, value=0)
            
        # Update the number of row EXCLUDING the first row. 
        self.nb_row = self.table.get_row_count() - 1
        
        return
        
    def _button_remove_row_clicked(self):
        """
        Remove the last row on the table
        """
        _debug('GUISweepLines: button_remove_row_clicked')
        
        # Remove the row only if these is one or more row
        if self.nb_row > 0:
            self.table._widget.removeRow(self.nb_row)   
            
        # Update the number of row EXCLUDING the first row. 
        self.nb_row = self.table.get_row_count() - 1
        
        return
            
    def _button_reset_clicked(self):
        """
        Reset the table
        """
        _debug('GUISweepLines: reset_table')
        
        # Remove all the rows
        while (self.table.get_row_count() > 0):
            self.table._widget.removeRow(0)
            
        # Put back the first row
        self.set_first_row(self.list_first_row)
        
        # Update the number of row EXCLUDING the first row. 
        self.nb_row = self.table.get_row_count() - 1
            
        return
    
    def _update_list_columns(self):
        """
        Make the list of columns to match the table of the gui. 
        """
        _debug('GUITableInteractive: _update_list_columns')
        # Reset the attribute
        self.list_columns = []
        
        N_row = self.table.get_row_count() - 1 # Exclude the first row
        # Add each column
        for i in range(self.nb_columns):
            col = []
            for j in range(N_row):
                col.append( self.table.get_value(column=i, row=j+1) )
            # Append this columns to the list
            self.list_columns.append(col)
        
        # At this point everything should be tigidou
        return

    def set_first_row(self, list_first_row):
        """
        Set the string for the first row.
        The number of the column of the table will be set to the number of 
        element in the input list. 
        
        list_first_row:
            List of string that will fill each column of the first row. 
            
        """
        _debug('GUISweepLines: set_first_row')
        
        # Verufy if the size of the input match what it should be.
        if len(list_first_row ) != self.nb_columns:
            print('ERROR in GUISweepLines.set_first_row --> The row dont have the same lenght as the number of columns. Autodestruction in 3-2-1...')
            return
        # At this point of the code, lenght should be tigidou.
        # Add each element of the list in each column of the first row. 
        for i, element in enumerate( list_first_row):
            self.table.set_value(column=i, row=0, value=element)
            
        # Keep in mind the first row
        self.list_first_row = list_first_row 
        
        return
        
            
    def set_table(self, list_columns):
        """
        Set the table to the input matrix.
        This will fill up the table after the first row. Such that the first
        row stay unchanged. 
        It will also save the attribute list_columns to the input.
        
        list_columns:
            List of array. Each array is the content of one columns. The first 
            array of the list correspond to the first columns. 
            
        """
        _debug('GUITableInteractive: set_table')
        
        # Set the list of columns
        self.list_columns = list_columns
        
        # Fill up the table 
        for i, column in enumerate(list_columns):
            for j, element in enumerate(column):
                self.table.set_value(column=i, row=j+1, value=element)
        
        # Update the number of row EXCLUDING the first row. 
        self.nb_row = self.table.get_row_count() - 1
        
        return
            
    def get_list_columns(self):
        """
        Return the list of columns in the table. 
        This DO NOT include the first row. 
        """
        _debug('GUITableInteractive: get_list_columns')
        # Update the list, such that it matches the table
        self._update_list_columns()
        # The list sould be ready
        return self.list_columns
    
    def get_list_rows(self):
        """
        Return the list of rows in the table. 
        This DO NOT include the first row. 
        """
        _debug('GUITableInteractive: get_list_rows')
        
        # Update the list of columns, such that it matches the table
        self._update_list_columns()
        
        # The list of rows is the transpose of the list of columns
        return np.array(self.list_columns).T
    
    

            
    def print_table(self):
        """
        Just for fun, print ithe table. 
        """
        _debug('GUITableInteractive')
        # Update the list, such that it matches the table
        self._update_list_columns()
        
        # Print all the row and column
        N_row = self.table.get_row_count()
        for i in range(N_row):
            print(end='|')
            for j in range(self.nb_columns):
                element = self.table.get_value(column= j, row=i)
                print(element, end='|')
            # Change row
            print()
            
        return
        
        
        
        
 #By default set the object
if __name__ == '__main__':
    # Enable some debugs
    _debug_enabled = True

    # Pop up the gui
    self = GUITableInteractive(nb_columns=5)
    self.show() # Pop it      
        
        
        
        
        
        
        
        
        
        
        