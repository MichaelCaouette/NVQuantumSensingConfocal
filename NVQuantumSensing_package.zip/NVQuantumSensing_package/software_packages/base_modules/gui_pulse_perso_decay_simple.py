# -*- coding: utf-8 -*-
"""
Created on Thu Oct  8 11:39:41 2020

Goal: define the measurer for the adaptive protocole of T1

@author: Childresslab
"""


# The following is for building the pulse
from pulses import ChannelPulses, PulsePatternBlock, Sequence
import api_fpga as _fc
from gui_signal_generator import GUISignalGenerator
from gui_pulse_runner import GuiPulseRunner
from count_interpreter import ProcessFPGACounts

import time
import numpy as np
from spinmob import egg
import traceback
_p = traceback.print_last #Very usefull command to use for getting the last-not-printed error


_debug_enabled     = False
def _debug(*a):
    if _debug_enabled: 
        s = []
        for x in a: s.append(str(x))
        print(', '.join(s))



class GUIDriftIndependentMeasurement(egg.gui.Window):
    """
    GUI for making the following measurement:
        Create and use a pulse sequence which will make a measurement 
        independant of drifting parameters (PL(t=0) and optical contrast). 
        It will make 5 measurement:
            - The counts of ms = 0   at t = 0
            - The counts of ms = 0   at t = t_probe
            - The counts of ms = +-1 at t = 0 
            - The counts of ms = +-1 at t = t_probe. 
            - A reference count
        The 4 firsts are to be combined in order to get a data which doesn't 
        depend on PL(t=0) and the optical constrast. The useful combination is
        the difference of the 2nd and 4th DIVIDED by the difference of the 1rst
        and the 3rd. 
        The reference count will be counts monitored during and at the end of 
        shining the exciation laser. It's purpose is to verify if everything is
        alright. 

    """   
    
    def __init__(self, fpga, name="Drift independant cool", size=[1000,500]): 
        """
        Initialize

        fpga:
            "FPGA_api" object from api_fpga.py. 
            This is the object shared amoung the GUIs for controlling the fpga. 
            The session of the fpga must already be open.              
        """    
        _debug('GUIDriftIndependentMeasurement:__init__')
        _debug('If you’re the smartest person in the room, you’re in the wrong room. – Unknown')
        
        # Run the basic stuff for the initialization
        egg.gui.Window.__init__(self, title=name, size=size)

        # Steal the fpga, mouhahaha
        self.fpga = fpga
        # Overid a method that, hopefully, should prevent the freeze out of the
        # gui for long pulse sequence.
        self.fpga.dummy_event_pulse_is_long = self.process_events
        
        # Initialise the GUI
        self._initialize_GUI()
        
    def _initialize_GUI(self):
        """
        Fill up the GUI
        """        
        _debug('GUIDriftIndependentMeasurement: _initialize_GUI')
        _debug('Punctuality is not just limited to arriving at a place at right time, it is also about taking actions at right time. ― Amit Kalantri')
        
        # A button for preparing stuff
        self.button_prepare_experiment = egg.gui.Button('Prepare all settings',
                                                        tip='Prepare the measurement before running')
        self.place_object(self.button_prepare_experiment, row=0, column=0)
        self.connect(self.button_prepare_experiment.signal_clicked, 
                     self._button_prepare_experiment_clicked)
        
        # Add the pulse runner
        self.gui_pulse_runner = GuiPulseRunner(self.fpga)
        self.place_object(self.gui_pulse_runner, 
                          row=1, column=0, column_span=2)
        
        # Add the signal generator
        self.sig_gen = GUISignalGenerator(show=False)
        self.gui_sig_gen    = self.sig_gen.window    
        self.place_object(self.gui_sig_gen, 
                          row=1, column = 2)
        
        # tree dictionnarry for the settings
        self.treeDic_settings = egg.gui.TreeDictionary(autosettings_path='setting_T1_singleTime_2states')
        self.place_object(self.treeDic_settings, row=2, column=0, column_span=2)

        self.treeDic_settings.add_parameter('Power', -20, 
                                            type='float', step=1, decimals=10,
                                            bounds=[-50,30], suffix=' dBm',
                                            tip='Constant power of the RF for the pipulse')
        self.treeDic_settings.add_parameter('Frequency', 3, 
                                            type='float', step=0.1, decimals=10,
                                            bounds=[0,10], suffix=' GHz',
                                            tip='Frequency of the RF for the pipulse') 
        
        self.treeDic_settings.add_parameter('t_probe', 10, 
                                            type='float', step=0.1, decimals=10,
                                            bounds=[0,None], suffix=' us',
                                            tip='Time to probe.') 

        self.treeDic_settings.add_parameter('dt_pi_pulse', 0.3, 
                                            type='float', step=0.1, decimals=10,
                                            bounds=[0,None], suffix=' us',
                                            tip='Duration of pi pulse') 
        
        self.treeDic_settings.add_parameter('dt_laser_initiate', 3, 
                                            type='float', step=0.1, decimals=10,
                                            bounds=[0,None], suffix=' us',
                                            tip='Duration of laser for initiating into ms=0')  
        self.treeDic_settings.add_parameter('dt_wait_after_initiate', 1.1, 
                                            type='float', step=0.1, decimals=10,
                                            bounds=[0,None], suffix=' us',
                                            tip='Duration of time to wait bafter the laser initialization into ms=0.\n It is the time require for assuming that the state is mostly ms=0 (due to transient decays).') 
        
        self.treeDic_settings.add_parameter('dt_readout', 0.4, 
                                            type='float', step=0.1, decimals=10,
                                            bounds=[0,None], suffix=' us',
                                            tip='Duration of the readout') 
        self.treeDic_settings.add_parameter('delay_read_before_laser', 0.05, 
                                            type='float', step=0.01, decimals=10,
                                            bounds=[0,None], suffix=' us',
                                            tip='Delay that we read before shining the laser')  
        
        self.treeDic_settings.add_parameter('DIO_laser', 2, 
                                            type='int', step=1, 
                                            bounds=[0,16],
                                            tip='DIO for the laser')          
        self.treeDic_settings.add_parameter('DIO_pulse_modulation', 3, 
                                            type='int', step=1, 
                                            bounds=[0,16],
                                            tip='DIO for modulating the pi pulse. AKA for sending the RF.')  

        self.treeDic_settings.add_parameter('DIO_sync_scope', 5, 
                                            type='int', step=1, 
                                            bounds=[-1,16],
                                            tip='DIO for synchronizing the oscilloscope. Put -1 for nothing')

        # Add a Data Box plotter for the incoming data
        self.databoxplot = egg.gui.DataboxPlot(autosettings_path='plot_drifIndependentMeasurement')
        self.place_object(self.databoxplot, 
                          row=2, column = 2, row_span=2, column_span=2) 
        self.databoxplot.button_multi.set_value(False) # Make all on the same plot
        
        # Make a label for showing some estimate
        self.label_estimates = egg.gui.Label('We have the best T1 prober on the market.')
        self.place_object(self.label_estimates, row=2, column=3, alignment=1) 
        
        # Some stretches for squeezing the wigdets
        self.set_row_stretch(1)
        self.set_column_stretch(3)        

    def _button_prepare_experiment_clicked(self):
        """
        Prepare the experiment:
            Prepare the pulse sequence in the fpga
            Prepare the signal generator
            Prepare the plot
        """
        _debug('GUIDriftIndependentMeasurement: _button_prepare_experiment_clicked')   

        # Prepare the pulse sequence 
        self.prepare_pulse_sequence()
        
        # We want the fpga NOT in each tick mode
        self.gui_pulse_runner.CheckBox_CET_mode.set_checked(value=False)
        
        # The following lines is for giving the sequence with delays
        if self.gui_pulse_runner.sequence_has_delay:
            # Remove the delay if there was previously
            self.gui_pulse_runner.button_set_delays.click()
        # Set the sequence
        self.gui_pulse_runner.set_sequence( self.sequence )
        # Set the delay
        self.gui_pulse_runner.button_set_delays.click()
        
        # Get the setting for the signal generator
        self.P    = self.treeDic_settings['Power']
        self.f    = self.treeDic_settings['Frequency']
        
        # Prepare the signal generator for the specific sequence
        # The first signal generator
        #THE ORDER OF WHICH METHOD TO CALL FIRST MIGHT MATTER 
        #(CARPICE OF MACHINE)
        self.sig_gen.button_reset.click()  # Reset the parameters 
        self.sig_gen.api.prepare_fixed_extmod() # Set the pulse modulation to be external
        self.sig_gen.combo_mode.set_value(index=0) # Set in Fixed mode
        self.sig_gen.number_dbm      .set_value(self.P)
        self.sig_gen.number_frequency.set_value(self.f*1e9 )#Convert into Hz
        # Turn on the RF !
        if not(self.sig_gen.button_rf.is_checked()):
            self.sig_gen.button_rf.set_checked(True)
            
        # Overid the method for dealing after the loop.
        self.gui_pulse_runner.dummy_after_one_loop = self.after_one_loop        
       
    def prepare_pulse_sequence(self):
        """
        Prepare the pulse sequence. 
        It generates the objet to be converted into a data array. 
        """
        _debug('GUIDriftIndependentMeasurement: prepare_pulse_sequence')
        
        # =====================================================================
        # Extract informations
        # =====================================================================
        # The channels
        DIO_laser         = self.treeDic_settings['DIO_laser']
        DIO_PM          = self.treeDic_settings['DIO_pulse_modulation']
        DIO_sync          = self.treeDic_settings['DIO_sync_scope']
        # The three dictionnary
        dt_laser      = self.treeDic_settings['dt_laser_initiate'] # Interval of time for shining the laser
        dt_readout    = self.treeDic_settings['dt_readout']
        dt_wait_ms0   = self.treeDic_settings['dt_wait_after_initiate'] #How much time to wait after the laser initiate ms=0 (for assuming that the population is mostly ms=0)
        dt_pi_pulse   = self.treeDic_settings['dt_pi_pulse'] # Duration of the pi-pulse
        delay_read    = self.treeDic_settings['delay_read_before_laser'] # Delay (us) that we read before shining the laser             
        self.t_probe = self.treeDic_settings['t_probe']
        # Duration of the trigger for synchronizing the scope (us)
        dt_sync_scope = 1 # It is not in the three dictionnary for now. 
        dt_wait_ms1 = dt_wait_ms0 # We also gonna way a bit after the pi-pulse. 
        
        # =====================================================================
        # Initiate the pulse sequence
        # =====================================================================
        # To be efficient, we gonna use the laser for reading and as an 
        # initialization in ms=0 for the next measurement. 
        # Initiate the sequence on which we gonna construct
        self.sequence = Sequence(name='T1 2 states at single probing time')
        # Create a channel for the synchronization with the scope. 
        channel_sync = ChannelPulses(channel=DIO_sync, name='Sync oscilloscope')
        channel_sync.add_pulses([0, dt_sync_scope]) # Add the sync pulse
        # Laser channel for each ms state
        channel_laser = ChannelPulses(channel=DIO_laser, name='Laser')      
        # Read channel for each state
        channel_read  = ChannelPulses(channel=1, name='Read')
        # Channel for the Pi-pulse initializing
        channel_RF    = ChannelPulses(channel=DIO_PM , name='Pi pulse')     
        # Set the reference time
        t0 = dt_sync_scope

        # =====================================================================
        # Measure ms=0 at t=0 
        # =====================================================================
        # First prepare the state ms=0 
        channel_laser.add_pulses([t0, t0+dt_laser])
        # Wait for the transients
        t0 = channel_laser.get_pulses_times()[-1] + dt_wait_ms0
        # Now the state is ms = 0
        # Read it immediately and read a little bit before the laser is shone
        channel_read.add_pulses([t0 - delay_read, t0 + dt_readout])   
        # Shine the laser for both reading and for reinitializing into ms=0
        channel_laser.add_pulses([t0, t0+dt_laser])
        # Update the reference time. 
        t0 = channel_laser.get_pulses_times()[-1] + dt_wait_ms0
        # At this point, the state is ms=0
        
        # =====================================================================
        # Measure ms=0 at t=t_probed 
        # =====================================================================
        # Wait t_probed
        t0 = t0 + self.t_probe
        # Read a little bit before the laser is shone
        channel_read.add_pulses([t0 - delay_read, t0 + dt_readout])   
        # Shine the laser for both reading and for reinitializing into ms=0
        channel_laser.add_pulses([t0, t0+dt_laser])
        # Update the reference time. 
        t0 = channel_laser.get_pulses_times()[-1] + dt_wait_ms0        
        # At this point, the state is ms=0

        # =====================================================================
        # Measure ms=+-1 at t=0
        # =====================================================================        
        # Send the pi-pulse for flipping the state from ms=0 to ms=+-1
        channel_RF.add_pulses([t0, t0 + dt_pi_pulse])
        # Update the reference time
        t0 = channel_RF.get_pulses_times()[-1] + dt_wait_ms1
        # Now the state is ms=+-1
        # Read a little bit before the laser is shone
        channel_read.add_pulses([t0 - delay_read, t0 + dt_readout])   
        # Shine the laser for both reading and for reinitializing into ms=0
        channel_laser.add_pulses([t0, t0+dt_laser])        
        # Update the reference time. 
        t0 = channel_laser.get_pulses_times()[-1] + dt_wait_ms0        
        # At this point, the state is ms=0
        
        # =====================================================================
        # Measure ms=+-1 at t=t_probed
        # ===================================================================== 
        # Send the pi-pulse for flipping the state from ms=0 to ms=+-1
        channel_RF.add_pulses([t0, t0 + dt_pi_pulse])
        # Update the reference time
        t0 = channel_RF.get_pulses_times()[-1] + dt_wait_ms1
        # Now the state is ms=+-1
        # Wait t_probed
        t0 = t0 + self.t_probe
        # Read a little bit before the laser is shone
        channel_read.add_pulses([t0 - delay_read, t0 + dt_readout])   
        # Shine the laser for both reading and for reinitializing into ms=0
        channel_laser.add_pulses([t0, t0+dt_laser])   
        
        # =====================================================================
        # Measure the reference counts
        # =====================================================================         
        # Not the reference time
        t0 = channel_laser.get_pulses_times()[-1]
        # At this point, the state is a mixture, because of the green laser.
        # Read at the far end of the excitation shining.
        channel_read.add_pulses([t0 - dt_readout, t0])  

        # =====================================================================
        # Put all the pulses together into a block and into a sequence.
        # ===================================================================== 
        # What a masterpice. 
        block = PulsePatternBlock(name='Block tprobe = %.2f us'%self.t_probe)
        block.add_channelEvents([channel_laser, 
                                 channel_RF, 
                                 channel_read,
                                 channel_sync])
        # Add the block to the sequence
        self.sequence.add_block(block)  

    def databoxplot_update(self):
        """
        Update the plot
        """
        _debug('GUIDriftIndependentMeasurement: databoxplot_update')
        
        # Clear the plot
        self.databoxplot.clear() 
        
        # Feed the databox plot with the data
        self.databoxplot['ms0_t0']        = self.count_per_iter_ms0_t0_s
        self.databoxplot['ms0_tprobed']   = self.count_per_iter_ms0_tprobed_s
        self.databoxplot['ms-+1_t0']      = self.count_per_iter_msmp1_t0_s
        self.databoxplot['ms-+1_tprobed'] = self.count_per_iter_msmp1_tprobed_s
        self.databoxplot['ref']           = self.count_per_iter_ref_s
        
        # Add important information in the header
        self.databoxplot.insert_header('repetition', self.rep)
        self.databoxplot.insert_header('iteration' , self.iteration)
        self.databoxplot.insert_header('Time', time.time())
        for key in self.treeDic_settings.get_keys():
            # Add each element of the dictionnary three
            self.databoxplot.insert_header(key , self.treeDic_settings[key])
        
        # Show it
        self.databoxplot.plot()   
        
    def after_one_loop(self, counts, iteration, rep):
        """
        What to do after one loop of the fpga. 

        This is called after each loop (single run) of the fpga. 
        
        counts:
            (array) Array of counts that the fpga get. 
        iteration:
            (int) Which iteration are we at.
        rep:
            (int) Number of repetition of the sequence into the fpga instruction
            """
        _debug('GUIT1probeOneTimes: after_one_loop')
        
        # Note that for saving 
        self.rep = rep
        self.iteration = iteration
        self.counts_prior_to_process = counts # Save it for debugging
        
        # Get the counts per readout per block
        self.proc = ProcessFPGACounts()
        self.counts_per_block_s =  self.proc.get_sum_count_per_block(counts, 
                                                                     rep, 
                                                                     nb_block=1)
        
        # Get the number of counts for each measurement
        self.counts_ms0_t0           = self.counts_per_block_s[0][0] 
        self.counts_ms0_tprobed      = self.counts_per_block_s[0][1]
        self.counts_msmp1_t0         = self.counts_per_block_s[0][2]
        self.counts_msmp1_tprobed    = self.counts_per_block_s[0][3]
        self.counts_ref              = self.counts_per_block_s[0][4]
        
        # If its the first iteration
        if iteration == 0:
            # Note the total number of readout for each state
            self.total_nb_readout = rep
            # Get the summed count per iteration
            self.count_per_iter_ms0_t0_s        = [self.counts_ms0_t0       ]
            self.count_per_iter_ms0_tprobed_s   = [self.counts_ms0_tprobed  ]
            self.count_per_iter_msmp1_t0_s      = [self.counts_msmp1_t0     ]
            self.count_per_iter_msmp1_tprobed_s = [self.counts_msmp1_tprobed]
            self.count_per_iter_ref_s           = [self.counts_ref          ]
        else:
            # Note the total number of readout for each state
            self.total_nb_readout += rep
            # Appened the summed count per iteration
            self.count_per_iter_ms0_t0_s       .append(self.counts_ms0_t0       )
            self.count_per_iter_ms0_tprobed_s  .append(self.counts_ms0_tprobed  )
            self.count_per_iter_msmp1_t0_s     .append(self.counts_msmp1_t0     )
            self.count_per_iter_msmp1_tprobed_s.append(self.counts_msmp1_tprobed)
            self.count_per_iter_ref_s          .append(self.counts_ref          )
        
        # Update the plot
        self.databoxplot_update()
            
        # Update the label
        self.mean_count_per_readout_ms0_t0        = np.sum(self.count_per_iter_ms0_t0_s  )/rep/iteration
        self.mean_count_per_readout_ms0_tprobed   = np.sum(self.count_per_iter_ms0_tprobed_s)/rep/iteration
        self.mean_count_per_readout_msmp1_t0      = np.sum(self.count_per_iter_msmp1_t0_s  )/rep/iteration
        self.mean_count_per_readout_msmp1_tprobed = np.sum(self.count_per_iter_msmp1_tprobed_s  )/rep/iteration
        self.mean_count_per_readout_ref           = np.sum(self.count_per_iter_ref_s  )/rep/iteration
        
        text = (  'Mean count per readout'+
                '\nms0_t0       : %f'%self.mean_count_per_readout_ms0_t0 +
                '\nms0_tprobed  : %f'%self.mean_count_per_readout_ms0_tprobed +
                '\nmsmp1_t0     : %f'%self.mean_count_per_readout_msmp1_t0+
                '\nmsmp1_tprobed: %f'%self.mean_count_per_readout_msmp1_tprobed+
                '\nref          : %f'%self.mean_count_per_readout_ref )
        self.label_estimates.set_text(text)        

        
     
        
if __name__=="__main__":
    _debug_enabled = True
    
    # Get the fpga paths and ressource number
    import spinmob as sm
    infos = sm.data.load('cpu_specifics.dat')
    bitfile_path = infos.headers['FPGA_bitfile_path']
    resource_num = infos.headers['FPGA_resource_number']
    # Get the fpga API
    # Get the fpga API
#    fpga = _fc.FPGA_api(bitfile_path, resource_num) 
#    fpga.open_session()
    
    # If we want a fake FPGA API for testing the code
    fpga = _fc.FPGA_fake_api(bitfile_path, resource_num) # Create the api   
    fpga.open_session()
    print()
    print('!!! FAKE FPGA !!!!!')
    print()
                
    self = GUIDriftIndependentMeasurement(fpga, size=[1800,800])
    self.show()    
    
    
    
#    # Uncomment the following for making a loop of measurement over vairous time. 
#    # =========================================================================
#    # Loop over many time to measure
#    # =========================================================================
#    # Define the list of time to probe
#    tmin = 10 # Minimum time to probe (us)
#    tmax = 1000 # Maximum time to probe (us)
#    N_tprobe = 15 # Number of point to probe
#    # Other parameters
#    log_factor = 3.5 # Factor for the logaritmic spacing (how squeezed will be the point near tmin) 
#    N_readout = 8e5 # Number of readout per point. 
#    time_per_iteration = 1e6 # (us) How long one iteration of the FPGA should last. 
#    Nrepeat_the_whole_thing = 20 # Name say it
#    #Transform it to a log scale
#    tlin = np.linspace(tmin  , tmax , N_tprobe) 
#    beta  = log_factor/(tmax-tmin) #
#    B_log = (tmax-tmin)/(np.exp(beta*tmax)-np.exp(beta*tmin))
#    A_log = tmin - B_log*np.exp(beta*tmin) 
#    t_probe_s = A_log + B_log*np.exp(beta*tlin)  #Lograritmic spacing    
#    
#    # Check the estimate of the duration
#    estimate = Nrepeat_the_whole_thing*np.sum(2*2*t_probe_s*1e-6*N_readout)/3600
#    print(estimate, ' hours')
#    # Select the file to save the data    
#    my_dir = sm.dialogs.select_directory()
#    # Note the initial time for a reference
#    t_initial = time.time()
#    
#    # Create a loop over the loop such that it never ends !
#    for j in range(Nrepeat_the_whole_thing):
#        # Make the pulse sequence for each time to probe
#        for i in range(N_tprobe):
#            
#            # =====================================================================
#            # Set the time to probe
#            # =====================================================================        
#            # Note the time probed
#            t_probe = t_probe_s[i]
#            self.treeDic_settings['t_probe'] = t_probe
#            
#            # =====================================================================
#            # Set the number of readout per iteration 
#            # =====================================================================
#            # Estimate how many readout per iteration
#            time_per_readout = 2*t_probe + 20 # Roughly the time elapsed by readout
#            N_readout_per_iter = int(time_per_iteration/ time_per_readout)
#            self.gui_pulse_runner.NumberBox_repetition.set_value(N_readout_per_iter)
#            
#            # =====================================================================
#            # Set the total number of FPGA loop
#            # =====================================================================        
#            # Estimate how many iteration
#            N_fpga_loop = int(np.ceil( N_readout / N_readout_per_iter ))
#            self.gui_pulse_runner.NumberBox_N_loopFPGA.set_value(N_fpga_loop)
#    
#            # =====================================================================
#            # Start the pulse sequence
#            # =====================================================================     
#            # Optimize at the beginning
#            self.gui_pulse_runner.dummy_please_optimize()
#            # Prepare the pulse sequence
#            self.button_prepare_experiment.click()
#            # Convert the pulse sequence into FPGA data
#            self.gui_pulse_runner.button_convert_sequence.click()
#            # Reset the pulse runner
#            self.gui_pulse_runner.button_reset.click()
#            # Start the pulse sequence
#            self.gui_pulse_runner.button_start.click()
#    
#            # =====================================================================
#            # Save the data
#            # ===================================================================== 
#            # Add information
#            self.databoxplot.insert_header('t_initial', t_initial)
#            
#            path = my_dir+'/Drift_indep rep%d t_probed_%d.dat'%(j,i)
#            self.databoxplot.save_file(path)

        
        
        
        
        
        
        
        
        
        
        
        
        
