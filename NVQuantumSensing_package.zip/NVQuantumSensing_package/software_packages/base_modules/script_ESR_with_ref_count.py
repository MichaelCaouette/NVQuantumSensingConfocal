x=(d['list_f_GHz']) 
y=( d[1],d[2],) 
xlabels = 'list_f_GHz' 
ylabels = ( 'Counts_0'   'Counts_1'  )