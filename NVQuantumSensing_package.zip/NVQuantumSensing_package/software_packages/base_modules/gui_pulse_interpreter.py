# -*- coding: utf-8 -*-
"""
Created on Tue Feb 16 17:00:56 2021

Intepret the counts from the fpga

@author: Childresslab
"""

from count_interpreter import ProcessFPGACounts

import numpy as np
import time
from spinmob import egg
import traceback
_p = traceback.print_last #Very usefull command to use for getting the last-not-printed error

# Debug stuff.
_debug_enabled     = True

def _debug(*a):
    if _debug_enabled: 
        s = []
        for x in a: s.append(str(x))
        print(', '.join(s))
        
        
class GUIPulseInterpreter(egg.gui.Window):
    """
    A gui for visualizing the incoming counts from the fpga. 
    It provifs various interpretation modes, for satisfying various situation. 
    
    This object is meant to be with the pulse runner. 
    """
    def __init__(self,
                 name="Great count plotter", size=[200,600]): 
        """
        Yep, this is the initialization ;) 
        """    
        _debug('GUIPulseInterpreter: __init__')
        _debug('Education is the most powerful weapon you can use to change the world. – Nelson Mandela')
        
        # Run the basic stuff for the initialization
        egg.gui.Window.__init__(self, title=name, size=size)

        # A Combo Box for choosing how to interpret the fpga counts
        self.list_mode = ['Per_block', 'CET', 'No_plotting']
        self.place_object(egg.gui.Label('Interpretation:'))
        self.combobox_mode = egg.gui.ComboBox(self.list_mode)
        self.place_object(self.combobox_mode)
        self.connect(self.combobox_mode.signal_changed, self._combobox_mode_changed )
        # trigger if once for fixing the attribute
        self._combobox_mode_changed()

        # For plotting the data !! :D 
        self.new_autorow()
        self.databoxplot = egg.gui.DataboxPlot(autosettings_path='plot_count_interpreter')
        self.place_object(self.databoxplot, column_span=3) 
        
        # Attempt to strecht nicely the gui
        self.set_row_stretch(2)
        self.set_column_stretch(2)
        
        # Initiate the counts
        self.initiate_counts()
        
        
        
    def _combobox_mode_changed(self):
        """
        Change the mode for interpreting and plotting the data
        
        """
        _debug('GUIPulseInterpreter: _combobox_mode_changed')
        
        self.mode = self.combobox_mode.get_text()
        
        
    def _interprete(self):
        """
        Interpret the count array, according to the choosen mode.
        """
        _debug('GUIPulseInterpreter: _interprete')
        
        # Initiate the processor of the counts. 
        process = ProcessFPGACounts()


            
        if self.mode == self.list_mode[0]:
            # The x-axis correspond to the block number
            
            # We will get the list of block index, which will be the x-axis.
            # Each y-axis curve will be the count of one readout in a block. 
            
            # Sum all the counts for this mode. 
            self.sum_counts += self.counts            
            inputs = (self.sum_counts, self.repetition, self.nb_block)
            outputs = process.get_count_per_readout_vs_block(*inputs)
            block_inds, list_count_array = outputs
            
            # Update the plot
            self.databoxplot.clear()   # Clear the plot   
            # Set the x-axis
            
            self.databoxplot['Block_index'] = block_inds
            # Loop over each readout 
            list_label = []
            for i, count_per_readout in enumerate(list_count_array):
                # Add a curve
                list_label.append('Counts_%d'%i)
                self.databoxplot[ list_label[-1] ] = count_per_readout      

        if self.mode == self.list_mode[1]:
            # For CET mode (Count Each Tick)
            # The count array that the FPGA outputs is crypted. Therefore we
            # cannot add these array before to process them. This is why we add 
            # after. 
            
            inputs = (self.counts, self.repetition)
            self.counts_per_tick = process.get_sum_count_per_repetition_CET_mode(*inputs)
            self.ticks = np.arange(0, len(self.counts_per_tick))
            
            self.summed_CET_counts += np.array( self.counts_per_tick ) 
            
            # Update the plot
            self.databoxplot.clear()   # Clear the plot       
            self.databoxplot['Tick'] = self.ticks # x-axis
            self.databoxplot['Total_counts'] = self.summed_CET_counts # single y-axis

                    
        # Add the information of the signal generator, depending on its mode.
        if self.mode_sig_gen == 'FIXED':
            self.databoxplot.insert_header('fix_f_GHz', self.fix_f_GHz) 
            self.databoxplot.insert_header('fix_p_dBm', self.fix_p_dBm) 
        elif self.mode_sig_gen == 'LIST':
            # If there is a mismatch in the list, DO NOT send the info in the 
            # databox. And warn the user. 
            cond1 = len(self.list_f_GHz) != len(block_inds) 
            cond2 = len(self.list_p_dBm) != len(block_inds) 
            if cond1 or cond2:
                print()
                print('WARNING in GUIPulseInterpreter: _interprete')
                print('The list of the signal generator does not match the number of block of the pulse sequence.')
                print('This list is NOT being sent to the databoxplot.')
                print()
            else:
                # It makes sense to save the list. 
                self.databoxplot['list_f_GHz'] = self.list_f_GHz
                self.databoxplot['list_p_dBm'] = self.list_p_dBm            
        
        # Add neat headers
        self.databoxplot.insert_header('mode_plot', self.mode)  
        self.databoxplot.insert_header('date', time.ctime(time.time()))  
        self.databoxplot.insert_header('absolute_time_sec', time.time())  
        self.databoxplot.insert_header('repetition', self.repetition)
        self.databoxplot.insert_header('iteration' , self.iteration)
        
        # Show the master piece
        self.databoxplot.plot()      
            
            
        return 
        
    def initiate_counts(self):
        """
        Initiate the counts
        """
        _debug('GUIPulseInterpreter: initiate_counts')
        # Reset the counts, obviously. 
        self.sum_counts = 0
        self.summed_CET_counts = 0
        
        
    def set_nb_block(self, nb_block):
        """
        Set the number of block that the sequence has. 
        
        nb_block:
            Number of block that the sequence has.
        """
        _debug('GUIPulseInterpreter: set_nb_block')
        # Set the number of block, obviously. 
        self.nb_block = nb_block

    def set_sig_gen_fix(self, fix_f_GHz, fix_p_dBm):
        """
        Set the information about the signal generator, for when the signal
        generator is in FIXED mode
        
        fix_f_GHz:
            (Float) Fixed frequency set in the signal generator. In GHz.
        fix_p:
            (Float) Fixed power set in the signal generator. In dBm
        
        """
        _debug('GUIPulseInterpreter: set_sig_gen_fix')
        
        # Note the mode that we are at
        self.mode_sig_gen = 'FIXED'
        self.fix_f_GHz = fix_f_GHz
        self.fix_p_dBm = fix_p_dBm
        
    def set_sig_gen_list(self, list_f_GHz, list_p_dBm):
        """
        Set the information about the signal generator, for when the signal
        generator is in LIST mode
        
        list_f_GHz:
            List of frequencies in the memory of the signal generator. In GHz.
        list_p_GHz:
            List of powerss in the memory of the signal generator. In dBm.
        
        """
        _debug('GUIPulseInterpreter: set_sig_gen_list')
        
        # Note the mode that we are at
        self.mode_sig_gen = 'LIST'
        self.list_f_GHz = list_f_GHz
        self.list_p_dBm = list_p_dBm
    
        
    def add_count(self, counts, iteration, repetition):
        """
        Add incoming counts.
        Set the counts , interprete them and update the plot
        
        counts:
            Data structure for the counts that FPGA_api gives. 
            (The method FPGA_api.get_counts returns the right structure)
            
        iteration:
            (int) Corresponds to which iteration are we at.
        rep:
            Number of repetition of the sequence into the fpga instruction            
                       
        """
        _debug('GUIPulseInterpreter: add_count')
        
        # Note the inputs
        # In case we want to debug. Otherwise we are adding the counts.
        self.counts = np.array( counts )
        self.repetition = repetition
        self.iteration = iteration
        # Interprete the counts
        self._interprete()
        

if __name__=="__main__":
    # Enable some usefull debugger
    _debug_enabled = True
    
    
    self = GUIPulseInterpreter()
    self.show()
    
    print('Try to give some count array')
    
    
    
    