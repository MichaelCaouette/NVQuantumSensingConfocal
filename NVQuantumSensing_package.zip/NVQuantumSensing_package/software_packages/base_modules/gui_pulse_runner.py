# -*- coding: utf-8 -*-
"""
Created on Thu May 21 15:27:02 2020

A GUI for playing with the FPGA

@author: Childresslab, Michael
"""

from spinmob import egg
import traceback
_p = traceback.print_last #Very usefull command to use for getting the last-not-printed error

import api_fpga as _fc
from converter import Converter # This convert the sequence object into fpga data
from pulses import GUIPulsePattern
import pulses
from converter import GUIFPGAInstruction
from predefined_sequence import PredefinedSequence

import numpy as np

import time



# Debug stuff.
_debug_enabled     = False

def _debug(*a):
    if _debug_enabled: 
        s = []
        for x in a: s.append(str(x))
        print(', '.join(s))
        

class GuiPulseRunner(egg.gui.Window):
    """
    Main GUI for running the FPGA with pulse sequence. 
    """
    def __init__(self, fpga, 
                 name="Best pulser of the world", size=[200,600]): 
        """
        fpga:
            "FPGA_api" object from api_fpga.py. 
            This is the object shared amoung the GUIs for controlling the fpga. 
            The session of the fpga must already be open. 
        """    
        _debug('GuiPulseRunner:__init__')
        _debug('Don’t watch the clock; do what it does. Keep going. – Sam Levenson')
        
        # Run the basic stuff for the initialization
        egg.gui.Window.__init__(self, title=name, size=size)
        
        # Get the inputs
        self.fpga = fpga           

        # Fill the GUI
        self._initialize_GUI() 
        
        # Some attributes
        self.is_running = False # Weither or not the pulse sequence is running   
        self.iter = -1 # Will monitor how many loop is performed so far
        self.label_iteration.set_text('Iteration reseted')   
        self.is_reseted = True # Tells weither or not the info was reset

        # Initialize variable
        self.data_array = []
        self.length_data_block_s = []
        self.selected_experiment = 'Predefined' # This tells which experiment is selected
        # Give a simple sequence by default
        self.sequence = PredefinedSequence().get_sequence('rabi_fake_clean')

    def _initialize_GUI(self):
        """
        Fill up the GUI
        """        
        _debug('GuiPulseRunner: _initialize_GUI')

        # Place the run button and connect it
        self.button_start = egg.gui.Button('Start',
                                           tip='Start/Pause the fpga sequence.')
        self.place_object(self.button_start)
        self.connect(self.button_start.signal_clicked, self._button_start_clicked)
        self.button_start.disable() # Disable is until data are available

        # Place the button reset and connect it. 
        self.button_reset= egg.gui.Button("Reset :O")
        self.place_object(self.button_reset)
        self.connect(self.button_reset.signal_clicked, self._button_reset_clicked)
        
        # Place the conversion button and connect it
        self.button_convert_sequence = egg.gui.Button("Convert")
        self.place_object(self.button_convert_sequence, column_span=2)
        self.connect(self.button_convert_sequence.signal_clicked, 
                     self._button_convert_sequence_clicked)         
        
        
        self.new_autorow()
        # Place a label for the FPGA length 
        self.label_data_length = egg.gui.Label('FPGA data length: XX')
        self.place_object(self.label_data_length, column_span=3)
       
        self.new_autorow()
        # Place a qt SpinBox for the number of FPGA loop
        self.place_object(egg.gui.Label('Maximum Nb of \nFPGA loop'))
        self.NumberBox_N_loopFPGA = egg.gui.NumberBox(value=100000, step=1, 
                                                      bounds=(1, None), int=True)
        self.place_object(self.NumberBox_N_loopFPGA, alignment=0)
        
        # Place a label for the number of iteration performed
        self.label_iteration = egg.gui.Label('Iteration of FPGA:XX')
        # Add some bad ass CSS style
        self.label_iteration.set_style('background-color: rgb(100, 255, 255);'+
                                       'border: 1px solid black;'+
                                       'margin-top: 2px;'+
                                       'margin-bottom: 2px;'+
                                       'margin-right: 2px;'+
                                       'margin-left: 2px;'+
                                       'padding: 6px;')
        self.place_object(self.label_iteration)     
         

        self.new_autorow()
        # Number box for setting the number of repetition of the sequence
        self.place_object(egg.gui.Label('Repetion of \nsequence')) #Set the label at position (0,0)
        self.NumberBox_repetition = egg.gui.NumberBox(value=1000, step=1, 
                                                      bounds=(0, None), int=True)
        self.place_object(self.NumberBox_repetition, alignment=1)    
        
        # A check box for setting the CET mode
        self.CheckBox_CET_mode = egg.gui.CheckBox('CET mode?')
        self.place_object(self.CheckBox_CET_mode)   
        
        
        self.new_autorow()
        # A spinbox for the number of iteration before optimization
        self.place_object(egg.gui.Label('Number of FPGA loop\nbefore optimization\n0=Not use this.'))
        self.NumberBox_Nloop_before_optimize = egg.gui.NumberBox(value=100, step=1, 
                                                      bounds=(0, None), int=True)
        self.place_object(self.NumberBox_Nloop_before_optimize, alignment=0)  
        
        # A check box for setting the CET mode
        self.CheckBox_use_opt_threshold = egg.gui.CheckBox('Use Optimizer\nThreshold?',
                                                           tip='Will optimize each time that the count falls bellow the \nthreshold set in the GUI of the optimizer.' )
        self.place_object(self.CheckBox_use_opt_threshold)          
        
        self.new_autorow()
        # Place the show_fpga_data button and connect it
        self.button_show_fpga_data = self.place_object(egg.gui.Button("Show FPGA data"))
        self.connect(self.button_show_fpga_data.signal_clicked, self._button_show_fpga_data_clicked)  
        
        # Place the show_sequence button and connect it
        self.button_show_sequence = self.place_object(egg.gui.Button("Show sequence"))
        self.connect(self.button_show_sequence.signal_clicked, self._button_show_sequence_clicked)     
        
        
        self.new_autorow()
        # A button for setting the delays
        self.sequence_has_delay = False # This will be true if the sequence contain delays, false otherwise
        self.button_set_delays = egg.gui.Button('Set the delays', tip='Set/remove the delays into the sequence.\nRemove and set again for updating new values.')
        self.button_set_delays.set_style('background-color: rgb(255, 155, 255);')         
        self.place_object(self.button_set_delays)
        self.connect(self.button_set_delays.signal_clicked, self._button_set_delays_clicked)     

        self.new_autorow()
        # Prepare the list of delays for pulse
        #Place the AOs with tree dictionary
        self.treeDict_delays  = egg.gui.TreeDictionary(autosettings_path='setting_DIOs_delays')
        self.place_object(self.treeDict_delays, column_span=3)   
        for i in range(8):
            # NOTE: I limited up to DIO7, just to have a smaller dictionary tree, but it can go up to DIO15
            key = 'Delay_raise_DIO%d'%i
            self.treeDict_delays.add_parameter(key, 0, 
                                               type='float', step=0.01, 
                                               bounds=[None,None], suffix=' us',
                                               tip='Time delay for the raise time of DIO%d'%i)        
        for i in range(8):
            # NOTE: I limited up to DIO7, just to have a smaller dictionary tree, but it can go up to DIO15
            key = 'Delay_fall_DIO%d'%i
            self.treeDict_delays.add_parameter(key, 0, 
                                               type='float', step=0.01, 
                                               bounds=[None,None], suffix=' us',
                                               tip='Time delay for the fall time of DIO%d'%i)     
        
   
        
        # Squeeze everything together
        self.set_column_stretch(20)



    def _button_convert_sequence_clicked(self):
        """
        What to do is the button convert is clicked.
        
        It resets the measurement. 
        It convert the sequence into FPGA instruction. 
        It updates some info on the gui
        """
        _debug('GuiPulseRunner: _button_convert_sequence_clicked')
        
        # Call a dummy function for a task that we would like to do just 
        # before starting the conversion.
        self.dummy_before_converting()
        
        # =====================================================================
        # Reset the runner
        # =====================================================================
        self._button_reset_clicked()

        # =====================================================================
        # Convert
        # =====================================================================
        # Extract important information from the pulse sequence
        self.rep  = self.NumberBox_repetition.get_value()    
        self.label_iteration.set_text("Converting...")
        self.process_events() # For updating the text on the button
        # Measure the time it takes for the conversion
        time_start = time.time()
        # Create the converter and convert
        cc = Converter()
        self.data_array = cc.sequence_to_FPGA(self.sequence, repetition=self.rep)
        time_elapsed = time.time() - time_start
        self.label_iteration.set_text("Converted ;)")
        
        # =================================================================
        # Update the gui
        # =================================================================
        # Note the lentght of each block
        self.length_data_block_s = cc.get_length_data_block_s() 
        # Note the data lenght
        length = len(self.data_array)
        text = ('FPGA data length: %d'%length+
                '\nTime for conversion: %f sec'%time_elapsed)
        self.label_data_length.set_text(text )  
        # Unable the run button, because there are now data to be sent  
        self.button_start.enable()
        self.button_start.set_text('Run')
        self.button_start.set_colors(background='green')
        
            
    def _button_start_clicked(self):
        """
        What to do when the run instruction button is clicked
        """
        _debug('GuiPulseRunner: _button_start_clicked')
        
        if self.is_running == False:
            self.is_running = True
            self.button_start.set_text('Pause')
            self.button_start.set_colors(background='blue')
            
            # Rewrite the data in the FPGA, in case they were changed by an other 
            # gui (example: the optimizer between loops)
            self._prepare_THE_run_loop()
            # Launch the loop
            self._run_loops()
            
        else:
            # Stop to run if it is running
            self.is_running = False
            if self.is_reseted:
                self.button_start.set_text('Start')
                self.button_start.set_colors(background='green')       
            else:
                self.button_start.set_text('Continue')
                self.button_start.set_colors(background='green')  

    def _button_reset_clicked(self):
        """
        Reset the data
        """
        _debug('GuiPulseRunner:  _button_reset_clicked')

        # Call a dummy function for a task that we would like to do just 
        # before resetting     
        self.dummy_before_resetting()
        
        # =====================================================================
        # Stop to run 
        # =====================================================================   
        if self.is_running:
            self._button_start_clicked()
            
        # =====================================================================
        # Reset the attributes
        # =====================================================================        
        # Reset the number of iterations
        self.iter = -1  
        # Update the label for the number of iteration
        self.label_iteration.set_text('Iteration reseted')   
        # Note that it is resetted
        self.is_reseted = True
        # Also restart the threshold optimization procedure
        try:       
            self.optimizer.restart_threshold_opt()
            print('Succesfully restarted the refocusing threshold')
        except:
            print('WARNING IN GuiPulseRunner:  _button_reset_clicked  Not able to restart the optimizer')
            pass

        # =====================================================================
        # Update the GUI
        # =====================================================================           
        # Reupdate the button, because the if was not met the first time. 
        self.button_start.set_text('Start')
        self.button_start.set_colors(background='green')         
        
    def _button_show_sequence_clicked(self):
        """
        Pop up a window for showing the pulse sequence
        """
        _debug('GuiPulseRunner: _button_show_sequence_clicked') 
        
        # Show the block
        GUIPulsePattern(self.sequence)  
        
    def _button_show_fpga_data_clicked(self):
        """
        Pop up a window showing the pulses from the fpga data
        """
        _debug('GuiPulseRunner: _button_show_fpga_data_clicked')
        
        # Show the GUI
        GUIFPGAInstruction(self.data_array,self.rep, self.length_data_block_s,
                           list_DIO_to_show=range(8)) # Only show the 8 first DIO

    def _button_set_delays_clicked(self):
        """
        Add the delays in the sequence
        """
        _debug('GUIPulseBuilder: _button_set_delays_clicked') 
        
        # Put the delays only if the sequence do not contain them
        if not(self.sequence_has_delay):
            
            # Keepin memory the sequence with no delay
            self.sequence_no_delay = self.sequence
            
            # Extract the raise delays
            delays_raise = []
            DIOs = []
            for i in range(8):
                DIOs.append(i)
                delays_raise.append( self.treeDict_delays['Delay_raise_DIO%d'%i])
            # Set the raise delay
            new_sequence = pulses.add_raise_delays(self.sequence, DIOs, delays_raise)
    
            # Extract the fall delays
            delays_fall = []
            DIOs = []
            for i in range(8):
                DIOs.append(i)
                delays_fall.append( self.treeDict_delays['Delay_fall_DIO%d'%i])
            # Set the fall delay
            new_sequence = pulses.add_fall_delays(new_sequence, DIOs, delays_fall)   
            
            # Set the sequence to be this one
            self.set_sequence(new_sequence)
            # Note that the sequence has delay
            self.sequence_has_delay = True
            
            #Adjust the button 
            self.button_set_delays.set_text('Remove the delays')
            self.button_set_delays.set_style('background-color: rgb(255, 155, 0);')  
        else:
            # Set the sequence with no delay
            self.set_sequence(self.sequence_no_delay)
            # Note that the sequence has NO delay
            self.sequence_has_delay = False
            #Adjust the button 
            self.button_set_delays.set_text('Set the delays')
            self.button_set_delays.set_style('background-color: rgb(255, 155, 255);')              
                    
            

        
    def _prepare_THE_run_loop(self):
        """
        Prepare the fpga settings for the run loop. 
        And get the attributes
        """
        _debug('GuiPulseRunner: _prepare_THE_run_loop')
        
        # Note the value of the various settings
        self.Nloop_before_optimize = self.NumberBox_Nloop_before_optimize.get_value()
        self.N_loopFPGA = self.NumberBox_N_loopFPGA.get_value()
        
        # Send the data_array to the FPGA and prepare it
        # IMPORTANT We are adding 120 ticks (us) off at both end of the total
        # sequence. This is in order to give some extra time to the fpga to 
        # process the fifo or other stuff. 
        self.fpga.prepare_pulse(self.data_array, nb_ticks_off=120) 
        
        # Specify the counting mode 
        if self.CheckBox_CET_mode.is_checked() == 0:
            # Zero means Unchecked
            self.fpga.set_counting_mode(False)
        else:
            self.fpga.set_counting_mode(True)
                    
    def _run_loops(self):
        """
        Perform the loop of the fpga has long as the conditions are met. 
        """
        _debug('GuiPulseRunner: _run_loops')

        condition_loop = True
        while condition_loop:
            _debug('GuiPulseRunner: _run_loops: BEFORE self.iter, self.N_loopFPGA, self.is_running, condition_loop',
                   self.iter,self.N_loopFPGA, self.is_running, condition_loop)
            
            self.iter += 1
            # Update the label for the number of iteration
            self.label_iteration.set_text('Iteration %d'%self.iter)
            _debug('GuiPulseRunner: _run_loops %d/%d'%(self.iter, self.N_loopFPGA))
            self.fpga.run_pulse() 

            # Allow the GUI to update. This is important to avoid freezing of the GUI inside loops
            self.process_events()    
            
            # Get the counts and proceed
            self.fpga_output = self.fpga.get_counts()
            
            # Call a dummy function that can be overidden in an other class. 
            self.dummy_after_one_loop(self.fpga_output, self.iter, self.rep) 

            # Note that the data are no longer reseted
            self.is_reseted = False
            
            # Allow the GUI to update. This is important to avoid freezing of the GUI inside loops
            self.process_events()    
            # Update the condition for the while loop
            condition_loop = (self.iter<self.N_loopFPGA) and self.is_running    
            _debug('GuiPulseRunner: _run_loops: MIDDLE self.iter, self.N_loopFPGA, self.is_running, condition_loop',
                   self.iter,self.N_loopFPGA, self.is_running, condition_loop)
            
            # Call the function for optimizing if the condition is met
            # Note that the condition is not meet if N=0. Clever. 
            if self.Nloop_before_optimize>0:
                if self.iter%self.Nloop_before_optimize == self.Nloop_before_optimize-1:
                    _debug('GuiPulseRunner: _run_loops: event_optimize sent!')
                    self.dummy_please_optimize() # Dummy function to be overid in an other class
                    # The fpga settings change during optimization. 
                    #We need to put them back.
                    self._prepare_THE_run_loop()
                    
            # Also optimize with the threshold if we want
            if not(self.CheckBox_use_opt_threshold.is_checked() == 0):
                # Zero means Unchecked
                # Just use the total count from the fpga
                c_tot = np.sum( self.fpga_output )
                has_optimized = self.dummy_check_optimize_threshold( c_tot )
                
                if has_optimized:
                    # The fpga settings change during optimization. 
                    #We need to put them back.
                    self._prepare_THE_run_loop()
                            
            _debug('GuiPulseRunner: _run_loops: END self.iter, self.N_loopFPGA, self.is_running, condition_loop',
                   self.iter,self.N_loopFPGA, self.is_running, condition_loop)
        
        # Loop ended.         
        # Update the buttons
        if self.is_running:
            # Click on stop if it is still running
            self._button_start_clicked()   

    def set_sequence(self, sequence):
        """
        Give the sequence to the pulse runner
        It is this sequence that gonna be transfered into fpgd data and THEN 
        repeated. 
        """
        _debug('GuiPulseRunner: set_sequence')
        
        self.sequence = sequence
            
    def connect_opt_method(self, optimizer):
        """
        Connect the proper optimization method of the optimizer
        
        optimizer:
            Class of the GUI that optimizes and contain the proper method.
        """
        _debug('GuiPulseRunner: connect_opt_method')
        
        self.dummy_please_optimize = optimizer.button_optimize.click
        self.dummy_check_optimize_threshold = optimizer.check_threshold_opt 
        
        # Useful for manipulating the optimizer
        self.optimizer = optimizer
        
        return 
        

    def dummy_before_resetting(self):
        """
        Dummy function to be overrid.
        It is the first method called when we click on reset
        
        This method can be used for, example, resetting the count on an 
        external GUI.
        
        """
        _debug('GuiPulseRunner: dummy_before_resetting')
        
    def dummy_before_converting(self):
        """
        Dummy function to be overrid.
        It is the first method called when we click on convert.
        
        This method can be used for setting the pulse sequence with an external
        GUI. 
        
        """
        _debug('GuiPulseRunner: dummy_before_converting')
        
        
    def dummy_after_one_loop(self, fpga_output, iteration, rep):
        """
        Dummy function to be overrid
        This is called after each loop (single run) of the fpga. 
        
        fpga_output:
            Array of counts that the fpga outputs. It can be crypted counts, 
            as the CET mode provide a fancy way to tell the counts. 
        iteration:
            int corresponding to which iteration are we at
            
        rep:
            Number of repetition of the sequence into the fpga instruction
            """
        _debug('GuiPulseRunner: dummy_after_one_loop')

    def dummy_please_optimize(self):
        """
        Dummy method to be overid. 
        This is called each time that we want an optimization, in the method
        "_run_loops". 
        For example, this dummy method should be overid by the optimization
        function of the confocal optimizer.
        """
        _debug('GuiPulseRunner: dummy_please_optimize')
        
    def dummy_check_optimize_threshold(self,  count ):
        """
        Dummy method to be overid by the corresponding optimization method.        
        count:
            (float) Incoming count to send for comparing. 
        """
        _debug('GuiPulseRunner: dummy_check_optimize_threshold')
        

     
    
if __name__ == '__main__':
    # Enable some debugging
    _fc._debug_enabled = False
    _debug_enabled     = True


    # Open the FPGA
    import spinmob as sm
    infos = sm.data.load('cpu_specifics.dat')
    bitfile_path = infos.headers['FPGA_bitfile_path']
    resource_num = infos.headers['FPGA_resource_number']
    fpga = _fc.FPGA_api(bitfile_path, resource_num) 
    fpga.open_session()

    
    self = GuiPulseRunner(fpga) 
    self.show()
    
    
     # Uncomment if we want to use the optimizer (for testing) 
#    import gui_confocal_optimizer
#    optimizer = gui_confocal_optimizer.GUIOptimizer(fpga)
#    optimizer.show() # Hoh yess, we want to see it !
#    self = GuiPulseRunner(fpga,optimizer) 
#    self.show()
    
    # Send a simple pulse sequence for testing it
    pred = PredefinedSequence()
    my_seq = pred.get_sequence('Rabi')
    self.set_sequence(my_seq)





















