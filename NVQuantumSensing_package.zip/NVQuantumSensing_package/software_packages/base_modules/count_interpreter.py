# -*- coding: utf-8 -*-
"""
Created on Tue Feb 16 17:09:30 2021



@author: Childresslab
"""


from converter import Converter

import numpy as np
import traceback
_p = traceback.print_last #Very usefull command to use for getting the last-not-printed error

_debug_enabled     = False
def _debug(*a):
    if _debug_enabled: 
        s = []
        for x in a: s.append(str(x))
        print(', '.join(s))
        

class ProcessFPGACounts():
    """
    Various, convenient, methods for processing the array of counts that the fpga outputs
    """ 
    def __init__(self):
        """
        Init, as ever.
        """             
        _debug('ProcessFPGACounts: __init__')
        _debug('I’m still learning. – Michelangelo')
        
        # Not much thing to initiate, because this class is mostly used for 
        # using the methods directly.
        
    def unboundle_CET_int32(self, int32):
        """
        Unboundle the counts from a single int 32 created by count each tick 
        mode (CET).
        int32: 
            Number (a int32) that we will unboundle. 
        """
        _debug('ProcessFPGACounts: unboundle_CET_int32')
        
        #Each bit of the int32 correspond to one tick.
        # Get the count (0 or 1) from each bit
        array_binary = Converter().binary(int32) # Array of lenght 32. Each element correspond to the count for the corresponding tick
        # The lenght might be lower than 32. Therefore let's create the lenght 32 array
        counts = np.zeros(32)
        for i in range(32):
            if i < len(array_binary):
                counts[i] = array_binary[i]
            else:
                counts[i] = 0
            
        return counts

    def get_sum_count_per_repetition_CET_mode(self, counts, repetition):
        """
        FOR CET (Count Each Tick) MODE
        Split the array of counts into arrays of counts for each repetition. 
        Interpretere (unbundle) the element of each array to get the counts
        for each ticks. 
        
        Return the sum of the resulting arrays. 

        counts:
            Data structure for the counts that FPGA_api gives. 
            (The method FPGA_api.get_counts returns the right structure)
            
        repetition:
            Number of time that the sequence is repeated in the FPGA instruction. 
            
        """     
        _debug('ProcessFPGACounts: get_sum_count_per_repetition_CET_mode')
        
        self.counts = counts
        
        # Get the arrays for each repetition
        self.counts_each_seq = np.split( self.counts, repetition)
        
        # Go trough each array
        for i, count_to_unbundle in enumerate(self.counts_each_seq):
            self.count_single_rep = [] # Array of count for a single repetition
            # Unbundle each element and append them
            for int32 in count_to_unbundle:
                # Get the count for the 32ticks
                array_counts_32ticks = self.unboundle_CET_int32(int32)
                self.count_single_rep = np.concatenate((self.count_single_rep, 
                                                       array_counts_32ticks))
            if not(i == 0):               
                # Add the counts of each repetition together
                self.counts_sum_over_rep = self.counts_sum_over_rep + self.count_single_rep
            else:
                # Initialise the total array with the first computed.
                self.counts_sum_over_rep = self.count_single_rep
                            
        # Return the sum over each repetition 
        return self.counts_sum_over_rep
                
        
    def get_sum_count_per_repetition(self, counts, repetition):
        """
        Split the array of counts into arrays of counts for each repetition. 
        Return the sum of the resulting arrays. 
        
        counts:
            Data structure for the counts that FPGA_api gives. 
            (The method FPGA_api.get_counts returns the right structure)        
        
        repetition:
            Number of time that the sequence is repeated in the FPGA instruction. 
        """
        _debug('ProcessFPGACounts: get_sum_count_per_repetition')
        
        self.counts = counts
        
        self.counts_each_seq = np.split( self.counts, repetition)
        return np.sum(self.counts_each_seq, axis=0)              
    
    def get_sum_count_per_block(self, counts, repetition, nb_block):
        """
        Get the arrays for the total counts at each block

        counts:
            Data structure for the counts that FPGA_api gives. 
            (The method FPGA_api.get_counts returns the right structure)  

        repetition:
            Number of time that the sequence is repeated in the FPGA instruction. 

        nb_block:
            Number of block in the sequence. 
            
        Return: 
            An array of subarray. Each subarray is the counts for one block. 
        """
        _debug('ProcessFPGACounts: get_sum_count_per_block') 
        
        self.counts = counts
        
        # Get the total count array of all the repetition 
        self.sum_count_per_rep = self.get_sum_count_per_repetition(counts, repetition)
        # Split counts of the sequence into blocks
        return np.split(self.sum_count_per_rep, nb_block) 
    
    def get_count_per_readout_vs_block(self, counts, repetition, nb_block):
        """
        Restructure the array of counts, more convenient for plotting. 
        Get the count for each readout in each block. 

        counts:
            Data structure for the counts that FPGA_api gives. 
            (The method FPGA_api.get_counts returns the right structure) 
            
        repetition:
            Number of time that the sequence is repeated in the FPGA instruction. 
            
        nb_block:
            Number of block in the sequence. 
                        
        return:
            block_indices:
                array of iteger [0,1,2,...,N-1], where N is the number of block. 
            counts:
                counts[i] is an array conresponding to the i'th count VS blocks
                
        """
        _debug('ProcessFPGACounts: get_count_per_readout_vs_block') 
        
        self.counts = counts
        
        # We want that the array i correspond to the i'th count VS blocks
        y = self.get_sum_count_per_block(counts, repetition, nb_block)
        counts = np.zeros([len(y[0]), len(y)])
        block_indices = []
        
        for j, cs_block in enumerate(y):
            block_indices.append(j)
            for i, cs in enumerate(cs_block):
                counts[i][j] = cs        
                
        return block_indices, counts
    
    
    
              
import matplotlib.pyplot as plt
def plot_counts_vs_block(counts, repetition, nb_block):
    """
    Input:
        counts: FPGA count array
    """
    process = ProcessFPGACounts(counts)
    block_indices, counts = process.get_count_per_readout_vs_block(repetition, nb_block)
    
    # Now we can plot the counts VS blocks
    fig, ax = plt.subplots(tight_layout=True)
    
    for i in range(len(counts)):
        plt.plot(block_indices, counts[i], '.-', label='Readout %d'%i)
    plt.legend()
    plt.xlabel('Block index')
    plt.ylabel('Counts')
    if len(counts)==0:
        plt.title('No counts !')
    else:
        plt.title('Counts VS blocks')
        
    return fig, ax


if __name__=="__main__":
    # Enable some usefull debugger
    _debug_enabled = True
    
    
    self = ProcessFPGACounts()
    
    #TODO try some structure of counts and interprete them !
    
    
    
    
    
    