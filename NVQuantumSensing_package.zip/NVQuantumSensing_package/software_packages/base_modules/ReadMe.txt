Hello,

This folder contains all the basic modules that are used by the software. 
The sofware is built by assembling these base modules. 
Most of these base modules can be run alone for testing the class that they define. 

The scripts for which the names starts by "gui_" define the class of GUIs. 
These GUI are meant to control various tasks:
	- FPGA
	- Pulse sequence
	- Signal generator
	- etc. 

The scripts for which the names starts by "api_" define the class of APIs. 
They are meant to create an interface between various machine and Python. 
Most of the GUIs relay on these APIs. Example of machine that we use:
	- Actuators (for controlling the magnet)
	- Signal generator (for sending Radio-Frequency signals)
	- FPGA (for controlling the voltages and the pulses of the experiment). 

The scripts for which the names starts by "script_" are used for convenient plotting 
in GUIs that uses EGG from spinmob.  

The other scripts are defining various functions or classes that are used by other scripts. 
 

Michael Caouette-Mansour
michael.caouette-mansour@mail.mcgill.ca
Childress Laboratory





