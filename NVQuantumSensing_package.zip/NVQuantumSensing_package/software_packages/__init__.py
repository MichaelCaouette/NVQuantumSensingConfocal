# -*- coding: utf-8 -*-
"""
Created on Thu Jan 28 12:31:10 2021

@author: Childresslab
"""

# =============================================================================
# Add the path of the base module
# =============================================================================

# Get the current path
import os 
dir_path = os.path.dirname(os.path.realpath(__file__))

# Add the base modules folder to this path
import sys
new_path = dir_path + '\\base_modules'
sys.path.insert(0, new_path)
#sys.path.append(new_path)