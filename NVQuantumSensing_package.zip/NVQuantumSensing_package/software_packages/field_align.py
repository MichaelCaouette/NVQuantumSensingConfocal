# -*- coding: utf-8 -*-
"""
Created on Fri Aug 21 10:41:45 2020

@author: Childresslab

"""


# Get the base modules
import __init__  as doesntmatter# Make 100% sure that the path is uploaded
from base_modules.gui_actuator import GUIMagnet3
import base_modules.api_fpga as _fc # For using the FPGA
from base_modules.gui_mag_sweep_line_settings import GUILinesSettings
import base_modules.function_mag_sweep_line_settings as ff


# Other cool imports
import spinmob     as _s
from spinmob import egg
import time
import numpy as np
# For plotting
from mpl_toolkits.mplot3d import Axes3D # This import registers the 3D projection, but is otherwise unused.
import matplotlib.pyplot as plt

import traceback
# Very usefull command to use for getting the last-not-printed error
# Just type _p() in the console 
_p = traceback.print_last

#Debug
_debug_enabled           = False



def _debug(*a):
    if _debug_enabled: 
        s = []
        for x in a: s.append(str(x))
        print(', '.join(s))
          
class GUIMainSweepLines(egg.gui.Window):
    """
    Gui for making the actuators to sweep along various lines. 
    
    """
    def __init__(self, fpga,
                 name='Magnet sweep lines', show=True,size=[1500,900]):
        """
        Create the GUI 
        
        fpga:
            "FPGA_api" object from api_fpga.py. 
            This is the object shared amoung the GUIs for controlling the fpga. 
            The session of the fpga must already be open.   
            
        """
        _debug('GUISweepLines: __init__')
        _debug('The best way to predict your future is to create it. – Abraham Lincoln')
        
        # Take the inputs
        self.fpga = fpga

        # Run the basic stuff for the initialization of the gui
        egg.gui.Window.__init__(self, title=name, size=size)        
        
        # Create the gui for accessing the actuators
        self.gui_magnet3 = GUIMagnet3()
        
        # Get each axis component for saving precious characters lol
        self.X = self.gui_magnet3.X
        self.Y = self.gui_magnet3.Y
        self.Z = self.gui_magnet3.Z
        
        # Some useful attribute
        self.is_running = False # Tell if the sweep is running
        self.nb_total_batch = 0 # Total number of batch of setting to make
        self.iter_batch     = 0 # Which batch of setting we are measuring.
        self.nb_total_lines = 0 # Total number of iteration to perform (number of lines to scan)
        self.iter_line = 0 # At which iteration we are in one batch (Which line is being swept)
        self.path_folder_save  = 'Not selected yet' # Path to the folder of where to save the file
        self.path_setting = 'No File loaded ;)' # This is the string for the path of the settinggs
        self.statut = 'Waiting for loading settings.' # This will inform where we are in the tasks
        self.data_w = 0 # This is the 4-dimensional data to take at each magnet posiiont. Example: the photo-counts at each position. 
        self.info_date = 'No scan' # String for the date at which the scan is done
        self.speed = 999 # This will be the speed of the magnet along the line
        
        
        # =====================================================================
        # Prepare the gui
        # =====================================================================
        
        # Put the three actuators
        self.place_object(self.gui_magnet3, row=0, column=0, 
                          row_span=10)
        
        # A Button for starting the line sweep
        self.button_run = self.place_object(egg.gui.Button('Start'), 
                                            row=0, column=1, alignment=1)
        self.button_run.disable() # Disable until we have imported or set the settings
        self.connect(self.button_run.signal_clicked, self.button_run_clicked )  
        
        # A Button for resetting the sweep
        self.button_reset = self.place_object(egg.gui.Button('Reeeset'), 
                                              row=0, column=2, alignment=1)
        self.connect(self.button_reset.signal_clicked, self.button_reset_clicked )
        
        # Add a button for loading the settings
        self.button_load_settings = self.place_object(egg.gui.Button('Load settings'),
                                                  row=1, column=1, alignment=1)
        self.connect(self.button_load_settings.signal_clicked, self.button_load_settings_clicked )
        
        # Add a button for looking at the loaded settings
        self.button_look_setting = self.place_object(egg.gui.Button('Look loaded settings'), 
                                                     row=1, column=2, alignment=1)
        self.connect(self.button_look_setting.signal_clicked, self.button_look_setting_clicked )

        # Add a button for creating settings
        self.button_create_settings = self.place_object(egg.gui.Button('Create settings'), 
                                                     row=1, column=3, alignment=1)
        self.connect(self.button_create_settings .signal_clicked, 
                     self.button_create_settings_clicked )        
        
        # tree dictionnarry for some settings
        self.treeDic_settings = egg.gui.TreeDictionary(autosettings_path='setting_magSweepLines')
        self.place_object(self.treeDic_settings, row=2, column=1, column_span=3)

        self.treeDic_settings.add_parameter('time_per_point_ms', 10, 
                                            type='float',  
                                            bounds=[0,None], suffix=' ms',
                                            tip='How much time to elapsed between recorded points. ') 
        self.treeDic_settings.add_parameter('Npts_per_line', 10, 
                                            type='int', 
                                            bounds=[1, None],
                                            tip='Approximate number of point to probe along each line swept.\nIt can be higher is the required speed is above the bound.')
        self.treeDic_settings.add_parameter('Name_save', 'Master of Puppets', 
                                            type='str', 
                                            tip='Label for naming the data when saved')
        self.treeDic_settings.add_parameter('nb_line_before_optimize', 1, 
                                            type='int', 
                                            bounds=[0, None],
                                            tip='Number of line to sweep before triggering the optimization.\nPut zero for never optimizing')

        
        # Add the data plotter
        self.plotter_data = GUIPlotData()
        self.place_object(self.plotter_data, row=1, column=4, 
                              row_span=3,alignment=0)
        # Add a label
        self.label_info = self.place_object(egg.gui.Label(), row=4, column=4 )
        self.label_info_update() 
   
        
    def label_info_update(self):
        """
        Adjust the info shown.
        """
        _debug('GUISweepLines.label_info_update')
        #Set the text. If sucess, the text is the name of the file. Otherwise it is an error message. 
        txt = ('Statut: '+ self.statut +
               '\nCurrent setting: ' + self.path_setting +
               '\nLocation of saving file: ' + self.path_folder_save +
               '\nSpeed along line: %f mm/s'%self.speed+
               '\nCurrent batch: %d/%d'%(self.iter_batch, self.nb_total_batch)+
               '\nCurrent line: %d/%d'%(self.iter_line,self.nb_total_lines-1)
               )
        
        self.label_info.set_text( txt ) 
 
    def button_load_settings_clicked(self, *a):
        """
        Load a list of x,y,z points for the magnetic field sweep
        """
        _debug('GUISweepLines: button_load_settings_clicked')
        
        #Load the many databox for each batch of settings to explore. 
        self.list_databox_settings = _s.data.load_multiple(text='Load many settings')
        # Get the total number of batch
        self.nb_total_batch = len(self.list_databox_settings)

        self.path_setting = self.list_databox_settings[0].path
        self.statut = 'Settings are now loaded. Waiting to start.'
        self.label_info_update()
            
        # Enable the run button, since we now have data
        self.button_run.enable()
        self.button_run.set_colors(background='green')
        
    def button_look_setting_clicked(self):
        """
        Show the lines that the magnet should follow
        """
        _debug('GUISweepLines: button_look_setting_clicked')
        
        # Create a figure and prepare the plot
        # tight_layout make sure the labels are visible
        self.fig = plt.figure(tight_layout=True) 
        self.ax = self.fig.add_subplot(111, projection='3d') 
        
        # Plot each batch of setting
        for i, settings in enumerate( self.list_databox_settings):
            # Thanks to the magical function
            ff.plot_magSweepLinesSettings(settings, ax=self.ax, 
                                          color='C%d'%i)
            
    def button_create_settings_clicked(self):
        """
        Pop up the gui for creating settings
        """
        _debug('GUISweepLines: button_create_settings_clicked')
        # This should pop-up the window for creating settings
        self.gui_create_settings = GUILinesSettings().show()

    def button_reset_clicked(self):
        """
        Reset the iteration and stop the running
        """
        _debug('GUISweepLines: button_reset_clicked')
        
        # Stop to run 
        if self.is_running:
            self.button_run_clicked()

        # Reset the iterators
        self.iter_batch = 0
        self.iter_line = 0
        
        # Update the status shown
        self.statut = 'Sweep is resetted'
        self.label_info_update()   
        
        # Reupdate the button, because clicking it doesn't make it above.
        self.button_run.set_text('Start')
        self.button_run.set_colors(background='green')          
                    

    def button_run_clicked(self):
        """
        Button for controlling the experiement, 
        """
        _debug('GUISweepLines: button_run_clicked')
        
        # The action depends on the state of the experiment
        
        if self.is_running == False:
            self.is_running = True
            self.button_run.set_text('Pause')
            self.button_run.set_colors(background='blue')
            
            # Ask the user the repository for saving the files
            txt = 'Select a directory for saving the data from each batch of line swept.'
            self.path_folder_save = _s.dialogs.select_directory(txt)
            
            # Launch the loop over each batch of settings
            self.run_all_batch()
            
        else:
            # Stop to run if it is running
            self.is_running = False
            self.button_run.set_text('Continue')
            self.button_run.set_colors(background='green')  
            
    def save_current_data(self):
        """
        Save the result of the sweep over a single set of lines.
        
        """
        _debug('GUISweepLines: save_current_data')
        
        # Prepare the databox to save
        self.databox_save_scan = _s.data.databox()
        # Put some header
        self.databox_save_scan.insert_header('name', 'Hakuna matata')
        self.databox_save_scan.insert_header('date', self.info_date)
        self.databox_save_scan.insert_header('setting_file', self.path_setting)
        
        # Copy the tree dictionnary
        for key in self.treeDic_settings.get_keys():
            # Add each element of the dictionnary three
            self.databox_save_scan.insert_header(key , self.treeDic_settings[key])        
        # Add each column for the scanned points
        self.databox_save_scan['xs'] = self.xs_scanned
        self.databox_save_scan['ys'] = self.ys_scanned
        self.databox_save_scan['zs'] = self.zs_scanned  
        self.databox_save_scan['ws'] = self.ws_scanned  
        
        # Automatically save the data
        self.name_save = self.treeDic_settings['Name_save']
        path_save = (self.path_folder_save  + '\\' + self.name_save +
                     ' %.3d'%self.iter_batch + '.dat')
        self.databox_save_scan.save_file(path_save)               
    
    def run_all_batch(self):
        """
        Loop over all the batch of setting
        """
        _debug('GUISweepLines: run_all_batch')
        
        # Reset the iterators
        self.iter_batch = 0
        
        # Loop over each batch
        condition = self.is_running and self.iter_batch<self.nb_total_batch
        while(condition):
            # Allow the GUI to update. 
            # This is important to avoid freezing of the GUI inside loops.
            self.process_events()   
            # Launch it
            self.run_one_batch()
            # Update the iterator
            self.iter_batch += 1
            # Update the condition of the loop
            condition = self.is_running and self.iter_batch<self.nb_total_batch
            
        # Re initiate the experiment
        self.button_reset.click()
        # Update the info shown
        self.statut = 'All the batch done. Waiting for next experiment'
        self.label_info_update()

    def initiate_one_batch(self):
        """
        Initiate many things prior to the sweep
        """
        _debug('GUISweepLines: initiate_one_batch')

        # =====================================================================
        # Prepare the settings
        # =====================================================================     
        
        # Extract the settings for easier access
        self.nb_line_before_optimize = self.treeDic_settings['nb_line_before_optimize']
        self.Npts_per_line = self.treeDic_settings['Npts_per_line']
        self.time_per_point = self.treeDic_settings['time_per_point_ms']

        # Get the setting for this particular batch
        self.databox_settings = self.list_databox_settings[self.iter_batch]
        # Get the path of these settings
        self.path_setting = self.databox_settings.path
        # Extract the settings
        self.xs_setting = self.databox_settings['xs']
        self.ys_setting = self.databox_settings['ys']
        self.zs_setting = self.databox_settings['zs']
        self.nb_total_lines = len(self.xs_setting)

        # Prepare the plot
        self.plotter_data.initiate_plot(Nline = self.nb_total_lines)
 
        # =====================================================================
        # Reach the initial position
        # =====================================================================      
        
        self.statut = 'Reaching the initial position'
        self.label_info_update()   
        # Have a descent speed
        self.X.settings['Motion/Speed'] = 1 # mm/sec
        self.Y.settings['Motion/Speed'] = 1 # mm/sec
        self.Z.settings['Motion/Speed'] = 1 # mm/sec
        # Then reach the position
        self.gui_magnet3.go_to_xyz(self.xs_setting[0],
                              self.ys_setting[0],
                              self.zs_setting[0],
                              want_wait=True ) # Wait that we reach the position before continuing
        # This will store the positions that the actuatores reach at each checkpoint
        self.xs_scanned = []
        self.ys_scanned = []
        self.zs_scanned = []
        # This will store the 4-Dimensional data, for example the photo-counts
        self.ws_scanned = []
        
        # Set the iterator for not scanning the first point to the first
        # point !
        self.iter_line = 1
        
        # =====================================================================
        # Optimize just before the batch and prepare the FPGA
        # =====================================================================
        self.statut = 'Optimizing before starting the batch'
        self.label_info_update()  
        self.dummy_please_optimize()
        # The optimization change the fpga setting
        #First get the count time
        self.count_time_ms = self.treeDic_settings['time_per_point_ms']
        # Put 120 tick off, because Labview also put 120 ticks off (=1us)
        self.fpga.prepare_counting_pulse(self.count_time_ms, nb_ticks_off=120)        
        
    def run_one_batch(self):
        """
        Run the sweep along the lines. 
        First go on the initial position
        """
        _debug('GUISweepLines: run_one_batch')

        # Initiate the batch
        self.initiate_one_batch()        
        
        # Loop over each lines of this batch
        condition=self.is_running and self.iter_line<self.nb_total_lines
        while condition:
            _debug('GUISweepLines: run_one_batch: iter', self.iter_line)
            # Allow the GUI to update. This is important to avoid freezing of the GUI inside loops
            self.process_events()    
            # Update the info shown
            self.statut = 'Sweeping along line %d'%self.iter_line
            self.label_info_update()
            # Move along the line
            x = self.xs_setting[self.iter_line]
            y = self.ys_setting[self.iter_line]
            z = self.zs_setting[self.iter_line]
            xyzw = self.scan_one_line(x,y,z)
            
            # Update the plot
            self.plotter_data.add_line(xyzw[0],
                                       xyzw[1],
                                       xyzw[2],
                                       xyzw[3])
            
            # Append the data
            self.xs_scanned.extend(xyzw[0])
            self.ys_scanned.extend(xyzw[1])
            self.zs_scanned.extend(xyzw[2])
            self.ws_scanned.extend(xyzw[3])
            
            # Update the info shown
            self.statut = 'The line %d is completed'%self.iter_line
            self.label_info_update()

            # Optimize if it is appropriate
            if self.nb_line_before_optimize>0:
                if self.iter_line%self.nb_line_before_optimize == self.nb_line_before_optimize-1:
                    _debug('GUISweepLines: run_one_batch: event_optimize sent!')
                    # Update the info
                    self.statut = 'Optimizing after the line %d'%self.iter_line
                    self.label_info_update()
                    # Optimize !
                    self.dummy_please_optimize()
                    # The fpga settings change during optimization. 
                    # So put them back
                    self.count_time_ms = self.treeDic_settings['time_per_point_ms']
                    # Put 120 tick off, because Labview also put 120 ticks off (=1us)
                    self.fpga.prepare_counting_pulse(self.count_time_ms, nb_ticks_off=120)
            
            # Update the condition of the scan
            self.iter_line += 1
            condition = self.is_running and self.iter_line<self.nb_total_lines
            
        # Update the data
        self.info_date = time.ctime(time.time())
        _debug('GUISweepLines: run_one_batch: done')
        
        # Save the data collected
        self.save_current_data()
        self.statut = 'One batch done. Data saved.'
        self.label_info_update()
        
        
    def scan_one_line(self, xend=0, yend=0, zend=0):
        """
        Move in a straight line from the current position to the target position. 
        Has it scans along the line and calls the method take_counts at each 
        target point. 
        
        xend:
            (in mm) Target x position
        yend:
            (in mm) Target y position
        zend:
            (in mm) Target z position    
            
        The function returns:
            xzyw:
                A tuple (xs, ys, zs, ws), where xs, ys and zs are array for the 
                positions of the actuator at each checkpoint. ws is the array 
                of the 4-dimension data taken (for example, the counts)
        """
        _debug('GUISweepLines: scan_one_line')
        
        # =====================================================================
        # Set the target positions        
        # =====================================================================
        self.X.settings['Motion/Target_position'] = xend
        self.Y.settings['Motion/Target_position'] = yend
        self.Z.settings['Motion/Target_position'] = zend

        # =====================================================================
        # Find the speed of each actuator    
        # =====================================================================
        
        # We want them to reach the end at the same time and move in a straight 
        # line.
        # We need to know the distance that they will have to travel 
        self.xin, self.yin, self.zin = self.gui_magnet3.get_positions()
        self.dx = np.abs(self.xin - xend)
        self.dy = np.abs(self.yin - yend)
        self.dz = np.abs(self.zin - zend)
        # (mm) Total distance to travel
        self.ds = np.sqrt(self.dx**2 + self.dy**2 + self.dz**2) 

        # Determine the scalar speed of the magnet
        # It should be in mm/s. The distance is in mm and the time in ms
        # Mean distance between points (mm)
        self.resolution = self.ds/self.Npts_per_line # Mean distance between points
        self.speed = 1e3*self.resolution / self.time_per_point # mm/sec
        # Adjust the settings if that makes a speed to high
        if self.speed > 2:
            # Set the speed to its maximum value
            self.speed = 2 
            print('Warning. Speed was too high. The speed is set to its maximum value.')
            
        # Compute the speed based on the number of points and counting time.       
        # Now project this speed along each axis
        self.vx = self.speed*self.dx/self.ds
        self.vy = self.speed*self.dy/self.ds
        self.vz = self.speed*self.dz/self.ds
        self.X.settings['Motion/Speed'] = self.vx
        self.Y.settings['Motion/Speed'] = self.vy
        self.Z.settings['Motion/Speed'] = self.vz
        
        # =====================================================================
        # Go along the line
        # =====================================================================        
        
        # These will store the position of the magnet at each checkpoint
        xs = []
        ys = []
        zs = []
        # This will store the 4-dimension data at each x,y,z. 
        #For example, the photo-counts
        ws = [] 
 
         #Allow the GUI to update. This is important to avoid freezing of the GUI inside loop
        self.process_events()        
        
        # Go for real
        self.X.button_move.click()
        self.Y.button_move.click()
        self.Z.button_move.click()
        
        # Note the condition for keeping doing
        # As long as at least one actuator move
        condition1 = self.X.api.get_state() == 'MOVING'
        condition2 = self.Y.api.get_state() == 'MOVING'
        condition3 = self.Z.api.get_state() == 'MOVING'
        condition = condition1 or condition2 or condition3
        while condition:

            # Let's take the positions
            x, y, z = self.gui_magnet3.get_positions()
            xs.append( x )
            ys.append( y)
            zs.append( z )
            _debug('GUISweepLines: scan_xyz_line: Done')
            _debug('GUISweepLines: scan_xyz_line: %f %f %f'%(xs[-1], ys[-1], zs[-1]))
             #Allow the GUI to update. This is important to avoid freezing of the GUI inside loop
            self.process_events()
            
            # Take the counts from the fpga
            # This function is in charge to give the time delay for not blowing 
            # the CPU with an almost infinite loop
            self.take_counts() # It updates self.data_w
            ws.append(self.data_w)
            
            # Note the condition for keeping doing
            # As long as at least one actuator move
            condition1 = self.X.api.get_state() == 'MOVING'
            condition2 = self.Y.api.get_state() == 'MOVING'
            condition3 = self.Z.api.get_state() == 'MOVING'
            condition = condition1 or condition2 or condition3
        
        _debug('GUISweepLines: scan_xyz_line: Done')
        
        return (xs, ys, zs, ws)

    def take_counts(self):
        """
        Take the photocounts and update the value. 
        The time spend trhough this method should be roughly the counting time
        """
        _debug('GUISweepLines: take_counts')
        # The fpga should already contain the pulse sequence for taking the counts
        
        # Get the counts (d'uh !)
        # Two step: runt he pulse pattern and get the counts. 
        self.fpga.run_pulse() 
        self.counts =  self.fpga.get_counts()[0]
        self.data_w = self.counts    


    def dummy_please_optimize(self):
        """
        Dummy method to be overid. 
        This is called each time that we want an optimization. 
        For example, this dummy method should be overid by the optimization
        function of the confocal optimizer.
        """
        _debug('GUISweepLines: dummy_please_optimize')        
        



from matplotlib.backends.backend_qt4agg import FigureCanvasQTAgg as FigureCanvas
class GUIPlotData(egg.gui.Window):
    """
    A cosy GUI for showing the incoming data. 
    
    """
    def __init__(self): 
        """
        Initialize D'uh !
        """ 
        _debug('GUIPlotData: __init__')
        
        #Run the basic stuff for the initialization
        # This make in sort that we can use the gui as an egg window
        egg.gui.Window.__init__(self,title='Banane')
        
        #This prevent to have a second figure poping out outside of the gui
        plt.ioff() # It doesn't seem to work each time lol
        
        #Create a figure and canvas
        self.fig = plt.figure(tight_layout=True) #tight_layout make sure the labels are visible
        self.canvas = FigureCanvas(self.fig) # this is the Canvas Widget that displays the `figure`. It takes the `figure` instance as a parameter to __init__
        self.canvas.draw()
        #Add it to the GUI
        self.place_object(self.canvas)      
        
        #Prepare the plot
        self.ax = self.fig.add_subplot(111) 
        self.initiate_plot()
    
    def initiate_plot(self, Nline=10):
        """
        Reinitiate the plot
        
        Nline:
            Total number of lines swepts. 
        """
        # Reset some parameters
        self.nb_line = 0 # Current line
        self.nb_total_line = Nline # Total number of line
        
        # Reset the plot
        self.ax.cla()  
        self.ax.set_xlabel('# of Line swept')
        self.ax.set_ylabel('Distance on the line ')
        self.ax.set_xlim(0, Nline+1)
        
        # If the colobar exist, restart it
        try:
            self.cbar.cla()
        except:
            pass
            
        
    def add_line(self, xs, ys, zs, ws):
        """
        Add a scanned line in the plot. 
        
        
        xs, ys zs:
            List of x,y,z position to plot
        ws:
            List of counts at the same position
        """
        _debug('GUIPlotData: add_line')
        
        # Some parameter the user could control
        alpha_level = 0.3
        size_pts = 10
        
        # Update the number of lines
        self.nb_line += 1
        
        # The first line deserve special care
        if self.nb_line == 1:
            # Initiate the extrem values 
            self.vmin = np.min(ws)
            self.vmax = np.max(ws)
        else:
            wmin = np.min(ws)
            if wmin < self.vmin:
                self.vmin = wmin
            wmax = np.max(ws)
            if wmax > self.vmax:
                self.vmax = wmax
        
        
        # Get the data into numpy array
        xs = np.array(xs)
        ys = np.array(ys)
        zs = np.array(zs)
        # Get the relative distance made
        dx = xs - xs[0]
        dy = ys - ys[0]
        dz = zs - zs[0]
        self.distance = np.sqrt(dx*dx + dy*dy + dz*dz)
        # Revert the relative distance at each two line. 
        # This is if we assum a zigzag sweep and can be an option
        if self.nb_line % 2 == 0:
            self.distance = self.distance[-1] - self.distance
        
        # Get the correspond position on the x axis
        x_axis = self.nb_line + 0*self.distance 
        
        # Add the line in the plot
        myplot = self.ax.scatter(x_axis, self.distance, c=np.array(ws)*1e-3, 
                                 vmin=self.vmin, vmax=self.vmax, 
                                 alpha=alpha_level)
        # Update the colorbar
        if self.nb_line == 1:
            # Add it if it is the first plot
            self.cbar = plt.colorbar(myplot)
            self.cbar.set_label("KiloCounts") 
        else:
            # Just Re-adjust the limit
            self.cbar.set_clim(self.vmin, self.vmax)

        #The following update the plot. 
        self.fig.canvas.draw_idle()           

        


#By default set the object
if __name__ == '__main__':
    _debug_enabled = True
    import api_actuator
    api_actuator._debug_enabled
    
    # Get the fpga paths and ressource number
    cpu_specific_infos = _s.data.load('base_modules\\cpu_specifics.dat')
    # cpu_specific_infos is defined in the import of the base modules
    bitfile_path = cpu_specific_infos.headers['FPGA_bitfile_path']
    resource_num = cpu_specific_infos.headers['FPGA_resource_number']
    # Get the fpga API
    fpga = _fc.FPGA_api(bitfile_path, resource_num) 
    fpga.open_session()
    
    # Also get the confocal
    import confocal
    confo = confocal.GUIMainConfocal(fpga)
    confo.show() # Hoh yess, we want to see it !
    # Import also the pulse sequence for being able to calibrate stuffs
    from pulse_sequences import GUIPulseSequences
    pulse = GUIPulseSequences(fpga)
    # Add it to the confocal for avoiding too many openned window
    tab_pulse = confo.tabs1.add_tab('Pulse Sequence')
    tab_pulse.place_object(pulse)  
    
    # Show the main gui :D 
    self = GUIMainSweepLines(fpga, name='Magnet sweeeeeeeep') 
    self.show()
    
    # Connect the optimization !
    f_optimize = confo.gui_optimizer.button_optimize.click
    self.dummy_please_optimize = f_optimize
    pulse.set_optimization_function(confo.gui_optimizer)





#
#    self.set_optimization(confo.gui_optimizer)
#    # For other GUI
#    f_optimize = confo.gui_optimizer.button_optimize.click
#    pulse.set_optimization_function(f_optimize)
#
#
#








    