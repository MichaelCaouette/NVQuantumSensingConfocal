Rebonjour, reHi !

This folder contains the scripts for running various experiment. 
The principal GUI classes in the script can be opened together. 
This allows to have, for example, the confocal at the same type of the pulse sequence.

In general, most of these script can be run alone, because they contain the line
"if __name__=="__main__":"
Under this condition, there are the codes for launching the corresponding experiment plus others. 
This is useful if you want to learn how to use the corresponding class,
and how to connect the various experiment together. 

Here is the explaination for some common script:
   - confocal.py
     Meant for doing confocal microscopy only. 
     It contains the photo-counter, the controller of DIOS/AOS, the confocal mapper, the optizer, the saturation curver. 

   - field_align.py
     Meant for finding the alignment of the magnetic field with the NV. 
     It sweeps the magnet position while monitor the photo-counts. 
     This allows to find the magnet position that has the more counts. 

   - pulse_sequences.py
     Meant to run the common pulse sequences and also the customized one. 

   - T1_adaptive.py
     Meant to run an adaptive protocole for finding the decay rates of the NV. 
     It is a good example of how to combine the various GUIs together. 

The folder "base_modules" contains all base-scripts for the experiment.

Most of the gui uses the FPGA api. It is shared between guis. 
The role of many widget can be known by hovering the cursor over it. A tip message should pop-up.
For each script, you will notice the _debug function. This is used to print information when we set _debug_enabled=True.  
Each __init__ of the classes contains a motivational quote in the debugger. You are encouraged to pursue this mission. 
You can find many such quote at https://www.oberlo.com/blog/motivational-quotes

Michael Caouette-Mansour
michael.caouette-mansour@mail.mcgill.ca
Childress Laboratory
