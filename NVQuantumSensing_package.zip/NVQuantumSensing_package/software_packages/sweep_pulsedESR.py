# -*- coding: utf-8 -*-
"""
Created on Thu May 21 15:27:02 2020


@author: Childresslab, Michael
"""

# Get the base modules
import __init__  as doesntmatter# Make 100% sure that the path is uploaded
from base_modules.gui_map_2D import Map2D
from base_modules.gui_pulse_perso_pulsedESR import GUIPulsedESR


# other nice cool imports
import numpy as np
from spinmob import egg
import spinmob as sm
import time



import traceback
_p = traceback.print_last #Very usefull command to use for getting the last-not-printed error


# Debug stuff.
_debug_enabled     = False

def _debug(*a):
    if _debug_enabled: 
        s = []
        for x in a: s.append(str(x))
        print(', '.join(s))
        

 
class GUISweepPulsedESR(egg.gui.Window):
    """
    GUI meant for optimizing a pipulse by sweeping the power of a pulsed ESR.
    It uses various modules for making the experiment
    
    """
    
    def __init__(self, fpga, name="Friend of pulsed ESR", size=[1100,900]): 
        """
        fpga:
            "FPGA_api" object from api_fpga.py. 
            This is the object shared amoung the GUIs for controlling the fpga. 
            The session of the fpga must already be open. 
            
        """    
        _debug('GUISweepPulsedESR:__init__')
        
        # Run the basic stuff for the initialization
        egg.gui.Window.__init__(self, title=name, size=size)
        
        self.fpga = fpga
        
        # Initialise the GUI
        self._initialize_GUI()
        
        # Initiate the parameters of the loop
        # It also initiate the label
        self._initiate_loop()
        
        
    def _initialize_GUI(self):
        """
        Fill up the GUI
        """        
        _debug('GUISweepPulsedESR: _initialize_GUI')
        _debug('Forget your excuses. You either want it bad or don’t want it at all. – Unknown')
        
        # We will have a tabe for each task
        self.tabs = self.place_object(egg.gui.TabArea(), alignment=0)
        
        # =====================================================================
        # The main experiment control
        # =====================================================================
        self.tab_control_main = self.tabs.add_tab('Main')
        # A button for preparing stuff
        self.button_run = egg.gui.Button('Start', tip='Launch the experiment')
        self.button_run.set_style('background-color: rgb(0, 200, 0);')
        self.tab_control_main.place_object(self.button_run, row=0, column=0)
        self.connect(self.button_run.signal_clicked, 
                     self._button_run_clicked)
        # Important: a button for resetting the iteration
        self.button_reset = egg.gui.Button('Reset/Set experiment', tip='Reset the loop and prepare the experiment')
        self.button_reset.set_style('background-color: rgb(0, 200, 0);')
        self.tab_control_main.place_object(self.button_reset, row=0, column=1)
        self.connect(self.button_reset.signal_clicked, 
                     self._button_reset_clicked)
        # Add a label
        self.label_info = self.tab_control_main.place_object(egg.gui.Label(), 
                                            row=1, column=2)
        
        # tree dictionnarry for the settings
        self.treeDic_settings = egg.gui.TreeDictionary(autosettings_path='setting_sweep_pulsed_ESR')
        self.tab_control_main.place_object(self.treeDic_settings, row=1, column_span=2)

        # All the other parameter are set in the pulse sequence ;)
       
        self.treeDic_settings.add_parameter('f_min', 2.5, 
                                            type='float', step=0.1, 
                                            bounds=[0,10], suffix=' GHz',
                                            tip='Minimum frequency to sweep')
        self.treeDic_settings.add_parameter('f_max', 3.1, 
                                            type='float', step=0.1, 
                                            bounds=[0,10], suffix=' GHz',
                                            tip='Maximum frequency to sweep')        
        self.treeDic_settings.add_parameter('P_min', -5, 
                                            type='float', step=0.1, 
                                            bounds=[-30,30], suffix=' dBm',
                                            tip='Minimum Power to sweep')
        self.treeDic_settings.add_parameter('P_max', 5, 
                                            type='float', step=0.1, 
                                            bounds=[-30,30], suffix=' dBm',
                                            tip='Maximum Power to sweep')       
        self.treeDic_settings.add_parameter('N_f', 50, 
                                            type='int', step=10, 
                                            bounds=[0,None],
                                            tip='Number of frequency to sweep')    
        self.treeDic_settings.add_parameter('N_P', 15, 
                                            type='int', step=10, 
                                            bounds=[0,None],
                                            tip='Number of Power to sweep')              
        self.treeDic_settings.add_parameter('Name_save', 'Welcome to the Jungle', 
                                            type='str', 
                                            tip='Label for naming the data when saved')   
        
        # Attempts to squeeze the widgets for estetism
        self.tab_control_main.set_column_stretch(2)
        
        # =====================================================================
        # The gui of the pulsed ESR
        # =====================================================================   
        self.tab_pulsed_ESR = self.tabs.add_tab('Pulsed ESR')
        self.gui_pulsed_ESR = GUIPulsedESR(self.fpga)
        self.tab_pulsed_ESR.place_object(self.gui_pulsed_ESR)
        
        # =====================================================================
        # A map for the incoming data
        # =====================================================================  
        self.tab_map = self.tabs.add_tab('Data map')
        self.map =  Map2D()
        self.tab_map.place_object(self.map, alignment=0)      

    def _label_info_update(self):
        """
        Adjust the info shown.
        """
        _debug('GUISweepPulsedESR: _label_info_update')
        
        #Set the text. If sucess, the text is the name of the file. Otherwise it is an error message. 
        txt = ('Statut: '+ self.statut +
               '\n\nLocation of saving file: ' + self.path_folder_save 
               )
        self.label_info.set_text( txt ) 
        
    def _button_reset_clicked(self):
        """
        Stop and reset the iterations
        """
        _debug('GUISweepPulsedESR: _button_reset_clicked')
        
        # Stop to run 
        if self.is_running:
            self.button_run.click()
        
        # Reinitiate the loop, which reset the iterators and everything
        self._initiate_loop()
        
    def _button_run_clicked(self):
        """
        Start or stop the experiment
        """
        _debug('GUISweepPulsedESR: _button_run_clicked')
        
        if self.is_running == False:
            # If we are starting
            if self.iter == 0:
                # Update all the parameters
                self._initiate_loop()
                # Ask the user the repository for saving the files
                txt = 'Select a directory for saving the data from each pulsed ESR'
                self.path_folder_save = sm.dialogs.select_directory(txt)                  
            # Update the run button
            self.is_running = True
            self.button_run.set_text('Pause')
            self.button_run.set_colors(background='blue')
            # Run the loop
            self._run_loop()
            
        else:
            # Stop to run if it is running (Pause)
            self.is_running = False
            self.button_run.set_text('Continue')
            self.button_run.set_style('background-color: rgb(0, 200, 0);')
            self.statut += '\n\nPaused !'
            self._label_info_update()

    def _initiate_loop(self):
        """
        Initiate the element in the loop
        """
        _debug('GUISweepPulsedESR: _initiate_loop')
        
        # =====================================================================
        # Prepare the sweep
        # =====================================================================
        self.fmin = self.treeDic_settings['f_min'] 
        self.fmax = self.treeDic_settings['f_max'] 
        self.Nf   = self.treeDic_settings['N_f'  ] 
        self.Pmin = self.treeDic_settings['P_min'] 
        self.Pmax = self.treeDic_settings['P_max'] 
        self.NP   = self.treeDic_settings['N_P'  ] 
        self.name_save = self.treeDic_settings['Name_save'] 
        # Initiate the map
        self.Z = np.zeros((self.NP, self.Nf))
        self.map.set_data(self.Z, 
                          y_info=(self.Pmin,self.Pmax, self.NP),
                          x_info=(self.fmin, self.fmax, self.Nf),
                          label_y = 'Power (dBm)', 
                          label_x = 'Frequency (Ghz)')
        
        # =====================================================================
        # We will vary the power as we sweep
        # =====================================================================        
        self.list_power = np.linspace(self.Pmin, self.Pmax, self.NP)
        
        # =====================================================================
        # Some attribute for monitoring the experiment
        # ===================================================================== 
        self.is_running = False # Important for the buttons
        self.iter = 0 # Iteration in the loop
        self.statut = 'Loop reinitiated. Waiting to start' # This will inform where we are in the tasks
        self.path_folder_save  = 'Will be selected when starting.' # Path to the folder of where to save the file   
        self.time_start = time.time() 
        # Update the status shown
        self._label_info_update()   
        
        # Update the run button, because we are ready to start
        self.button_run.set_text('Start')
        self.button_run.set_style('background-color: rgb(0, 200, 0);')         
        
        
    def _run_loop(self):
        """
        run the measurement
        """
        _debug('GUISweepPulsedESR: _run_loop')
        
        # Let's go
        condition = self.is_running and (self.iter < self.NP)
        while condition:
            # =================================================================
            # Update the attributes 
            # =================================================================
            self.current_P = self.list_power[self.iter]
            _debug('GUISweepPulsedESR: _run_loop: i/N, P = %d/%d, %f'%(self.iter, 
                                                                 self.NP, 
                                                                 self.current_P))
           
            self.statut = ('Running the loop %d/%d'%(self.iter, self.NP) )
            # Note how much time it gonna takes if we can have an estimate
            if self.iter > 0:
                # After one loop, we know exactly how much time it takes
                self.time_elapsed = time.time() - self.time_start
                self.time_total = self.time_elapsed * self.NP / self.iter
                self.time_remaining = self.time_total - self.time_elapsed
                self.statut += '\nEstimate of time remaining: %f min /%f min'%(self.time_remaining/60, self.time_total/60)
            # Update the information shown
            self._label_info_update()
            
            
            # Allow the GUI to update. 
            # This is important to avoid freezing of the GUI inside loops
            self.process_events()              

            # =================================================================
            # The first step is to prepare the pulse sequence.   
            # =================================================================
            self.gui_pulsed_ESR.sig_gen.settings['List/f1'] = self.fmin*1e9 # Hz
            self.gui_pulsed_ESR.sig_gen.settings['List/f2'] = self.fmax*1e9 # Hz
            self.gui_pulsed_ESR.sig_gen.settings['List/P1'] = self.current_P # dBm
            self.gui_pulsed_ESR.sig_gen.settings['List/P2'] = self.current_P # dBm
            self.gui_pulsed_ESR.sig_gen.settings['List/N'] = self.Nf
            
            #Prepare the signal generator and the sequence
            self.gui_pulsed_ESR.button_prepare_experiment.click()

            # Convert the sequence into FPGA instruction only on the first 
            # iteration, because the pulse sequence is the same each time.
            if self.iter == 0:
                self.gui_pulsed_ESR.gui_pulse_runner.button_convert_sequence.click()
                
            # Reset the data 
            self.gui_pulsed_ESR.gui_pulse_runner.button_reset.click()
            
            # =================================================================
            # Launch the measurement
            # =================================================================    
            self.gui_pulsed_ESR.gui_pulse_runner.button_start.click()
            
            # =================================================================
            # Update the map, save the data and update the condition of the loop
            # =================================================================  
            # Update the map
            self.data = self.gui_pulsed_ESR.databoxplot
            c0 = self.data['Total_counts_0']
            c1 = self.data['Total_counts_1']
            self.Z[self.iter] = c0 - c1
            self.map.set_data(self.Z)
            # Save
            path_save = (self.path_folder_save  + '\\' + self.name_save +
                         ' %.3d'%self.iter + '.dat')
            self.gui_pulsed_ESR.databoxplot.save_file(path_save)       
            # Update the condition
            self.iter += 1
            condition = self.is_running and (self.iter < self.NP)
            
        # Do special stuff if we finish the whole loop
        if self.iter == self.NP:
            self.statut = ('%d/%d Congratualition ! All the iterations are done. '%(self.iter, self.NP) )
            self._label_info_update()
            

    
if __name__ == '__main__':
    _debug_enabled     = True

    # Get the fpga
    import base_modules.api_fpga as _fc # For using the FPGA
    # Get the fpga paths and ressource number
    cpu_specific_infos = sm.data.load('base_modules\\cpu_specifics.dat')
    # cpu_specific_infos is defined in the import of the base modules
    bitfile_path = cpu_specific_infos.headers['FPGA_bitfile_path']
    resource_num = cpu_specific_infos.headers['FPGA_resource_number']
    # Get the fpga API
    fpga = _fc.FPGA_api(bitfile_path, resource_num) 
    fpga.open_session()

#    # Uncomment for a fake api of the fpga
#    fpga = _fc.FPGA_fake_api(bitfile_path, resource_num) # Create the api   
#    fpga.open_session()
#    print('\nFAKE FPGA API\n')

    
    # Also get the confocal
    import confocal
    confo = confocal.GUIMainConfocal(fpga)
    confo.show() # Hoh yess, we want to see it !

    # Import also the pulse sequence for being able to calibrate. 
    from pulse_sequences import GUIPulseSequences
    pulse = GUIPulseSequences(fpga)
    # Add it to the confocal for avoiding too many openned window
    tab_pulse = confo.tabs1.add_tab('Pulse Sequence')
    tab_pulse.place_object(pulse)  
    
    self = GUISweepPulsedESR(fpga)
    self.show()
    
    # Connect the optimization !
    f_optimize = confo.gui_optimizer.button_optimize.click
    self.gui_pulsed_ESR.gui_pulse_runner.dummy_please_optimize = f_optimize
    pulse.set_optimization_function(f_optimize)

    





















