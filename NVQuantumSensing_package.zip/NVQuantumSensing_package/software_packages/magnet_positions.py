# -*- coding: utf-8 -*-
"""
Created on Tue Feb  2 17:18:39 2021

Goal:
    Create a gui for going making the magnet to go at a single position and
    call a task. 

@author: Childresslab
"""

# Import the relevant guis
import __init__  as doesntmatter# Make 100% sure that the path is uploaded

from base_modules.gui_table_interactive import GUITableInteractive
from base_modules.gui_actuator import GUIMagnet3

import spinmob     as _s
from spinmob import egg

import traceback
# Very usefull command to use for getting the last-not-printed error
# Just type _p() in the console 
_p = traceback.print_last

#Debug
_debug_enabled           = False


def _debug(*a):
    if _debug_enabled: 
        s = []
        for x in a: s.append(str(x))
        print(', '.join(s))

class GUIMagnetPositions(egg.gui.Window):
    """
    Gui for making the actuators to go at each position in alist and perform 
    a task at each single position.
    
    The list is editable
    """
    
    def __init__(self, name='Magnet reach positions', show=True, size=[1000,800]):
        """
        Create the GUI 
        
        magnet3:
            The gui object "GUIMagnet" that is used to control the three actuator. 
        """
        _debug('GUIMagnetPositions: __init__', name)
        _debug('When someone says you can’t do it, do it twice and take pictures. - Anonymous')
        
        # Run the basic stuff for the initialization
        egg.gui.Window.__init__(self, title=name, size=size)
        
        # Create the gui for accessing the actuators
        self.gui_magnet3 = GUIMagnet3()
        
        # Get each axis component for saving precious characters lol
        self.X = self.gui_magnet3.X
        self.Y = self.gui_magnet3.Y
        self.Z = self.gui_magnet3.Z
        
        # Some useful atrribute
        self.is_running = False # Weither or not the main action is running
        self.iter = 0 # Iterator for the element in the list that we are at.
        self.nb_total_iter = 0 # Total number of element in the list to scan
        self.list_positions = [] # List of [x,y,z] for the various positions
        self.status = 'Waiting to start' # Label for showing the status
        
        # =====================================================================
        # Prepare the GUI
        # =====================================================================
        
        # Put the three actuators
        self.place_object(self.gui_magnet3, row=0, column=0, 
                          row_span=10)

        # A Button for starting the main action
        self.button_run = self.place_object(egg.gui.Button('Start'), 
                                            row=0, column=1, alignment=1)
        self.connect(self.button_run.signal_clicked, self._button_run_clicked )          

        # A Button for resetting the sweep
        self.button_reset = self.place_object(egg.gui.Button('Reset :o'), 
                                              row=0, column=2, alignment=1)
        self.connect(self.button_reset.signal_clicked, self._button_reset_clicked )
        
        # Add a button for loading the settings
        self.button_load_settings = self.place_object(egg.gui.Button('Load settings'),
                                                  row=0, column=3, alignment=1)
        self.connect(self.button_load_settings.signal_clicked, self._button_load_settings_clicked )        

        # Add a button for saving the settings
        self.button_save_settings = self.place_object(egg.gui.Button('Save settings'),
                                                  row=0, column=4, alignment=1)
        self.connect(self.button_save_settings.signal_clicked, self._button_save_settings_clicked )   
        
        # Add an interactive table
        self.gui_table = GUITableInteractive(nb_columns=3)
        self.gui_table.set_first_row(['xs (um)', 'ys (um)', 'zs (um)'])
        self.place_object(self.gui_table, 
                          row=1, column=1,row_span=9, column_span=3)
        
        # A label to inform what is going on
        self.label_info = self.place_object(egg.gui.Label(), 
                                            row=1, column=4, alignment=1 )
        self.label_info_update() 
        
        # Attempt to make stuff looks good
        self.set_column_stretch(column=4)
   
        
    def label_info_update(self, info_supp=''):
        """
        Adjust the info shown.
        
        info_supp:
            Supplementary info to show (useful when this gui is used with other
            experiment)
        """
        _debug('GUISweepLines.label_info_update')
        #Set the text. If sucess, the text is the name of the file. Otherwise it is an error message. 
        txt = ('Status: '+ self.status +
               '\nCurrent row: %d/%d'%(self.iter, self.nb_total_iter) + 
               '\n' + info_supp# Extra infor to be given externally
               )
        
        self.label_info.set_text( txt )   
        
        return 
        

    def _button_run_clicked(self):
        """
        Start or stop the main action
        """
        _debug('GUIMagnetPositions: _button_run_clicked')
        
        # The action depends on the state of the experiment
        
        if self.is_running == False:
            self.is_running = True
            self.button_run.set_text('Pause')
            self.button_run.set_colors(background='blue')
            
            # Launch the main action
            # Update the list of positions for it to match the table
            self._update_list_positions()      
            # Call the begining task
            self.dummy_before_starting()
            # Then go for it
            self._loop_over_positions()
            
        else:
            # Stop to run if it is running
            self.is_running = False
            self.button_run.set_text('Continue')
            self.button_run.set_colors(background='green')  
            
    
    def _button_reset_clicked(self):
        """
        Reset the parameters and stop running
        """
        _debug('GUIMagnetPositions: _button_reset_clicked')
        
        # Stop to run 
        if self.is_running:
            self._button_run_clicked()

#        #TODO ERAS THAT AND SET IT TO ZERO !
#        # THIS IS A TEMPORARY QUICK SOLUTION
#        self.iter = int( input('\nPlease select a mag pos to start at : ') )
            
        # Reset the iterators
        self.iter = 0       

        
        # Update the status shown
        self.status = 'Experiment restarted. Waiting to start the next one.'
        self.label_info_update()   
        
        # Reupdate the button, because clicking it doesn't make it above.
        self.button_run.set_text('Start')
        self.button_run.set_colors(background='green')     
        
    def _button_load_settings_clicked(self):
        """
        Load the settings. 
        
        The settings load must be a databix file with three columns. 
        Each three element of the rows is one of x,y,z. 
        """
        _debug('GUIMagnetPositions: _button_load_settings_clicked')
        
        self.setting = _s.data.load(text='Load list of x,y,z positions ;)')
            
        # Fill up the table
        self.gui_table.button_reset.click()
        self.gui_table.set_table(self.setting)
        
        # Update the list of positions for it to match the table
        self._update_list_positions()

        # Update the status shown
        self.status = 'Settings loading. You can modify them before to start.'
        self.label_info_update()       
        return 

    def _button_save_settings_clicked(self):
        """
        Save the current settings into a file.
        """
        _debug('GUIMagnetPositions: _button_save_settings_clicked')

        # Update the list of positions for it to match the table
        self._update_list_positions()
        
        # Get the colunms
        list_columns = self.list_positions.T # Transpose 

        # Create the data box
        self.databox_setting = _s.data.databox()
        
        # Fill it up
        self.databox_setting['xs'] = list_columns[0]
        self.databox_setting['ys'] = list_columns[1]
        self.databox_setting['zs'] = list_columns[2]
        
        # Save it with a dialog box
        self.databox_setting.save_file()
        
        return
        
        
    def _update_list_positions(self):
        """
        Make the attribute list_positions to match the table. 
        """
        _debug('GUIMagnetPositions: _update_list_positions')
        
        # Make the list of positions to match the table
        self.list_positions = self.gui_table.get_list_rows()
        # Update the total number of positions
        self.nb_total_iter = len(self.list_positions)
        
        return 

    def _loop_over_positions(self):
        """
        Go to each position in the list and call a task. 
        This task should be overid by what the user wants 
        (example: Perform a pulse sequence, a Bayesian T1, etc.)
        
        """
        _debug('GUIMagnetPositions: _loop_over_positions')
        
        condition = self.is_running and (self.iter < self.nb_total_iter)
        while(condition):
            # Allow the GUI to update. 
            # This is important to avoid freezing of the GUI inside loops
            self.process_events()  
            
            # Update the status shown
            self.status = 'Loop: Reaching a target position.'
            self.label_info_update()      
            
            # Get string of the positions
            x, y, z = self.list_positions[self.iter]            
            # Reach the position. Important to convert into float.
            self.gui_magnet3.go_to_xyz(float(x), float(y), float(z),
                                             want_wait=True)

            # Update the status shown
            self.status = 'Loop: Position reached. Now doing the task'
            self.label_info_update()               
            # Call the task
            self.dummy_task()
            
            # Update the iterator
            self.iter += 1
            # Update the condition of the loop
            condition = self.is_running and (self.iter < self.nb_total_iter)
        
        # It is done. So we can reset the experiement
        self.button_reset.click()

        # Update the status shown
        self.status = 'Loop done. Waiting to start the next experiment.'
        self.label_info_update()           
        
        return 
    
    def get_iter(self):
        """
        Return the current iteration
        """
        _debug('GUIMagnetPositions: get_iter')
        
        return self.iter
    
    def dummy_before_starting(self):
        """
        Dummy function to be overid. 
        It is called just before the loop over the positions
        """
        _debug('GUIMagnetPositions: dummy_before_starting')
        
        # For fun
        print()
        print('==============================================================')
        print('You look good today ! Keep in mind that you are awesome !! ;) ')
        print('==============================================================')
        print()
        
        return
    
    def dummy_task(self):
        """
        Dummy function to be overid. 
        It is called whenever the magnet reachs a desired position.
        """
        _debug('GUIMagnetPositions: dummy_task')
        
        # For fun, let's print the reached position
        x, y, z = self.gui_magnet3.get_positions()
        print('Congratulation ! You reach position: %f, %f, %f'%(x,y,z) )
        
        x, y, z = self.list_positions[self.iter]
        print('Aimed position: %f, %f, %f'%(float(x),
                                            float(y),
                                            float(z)) )
        
        return


        
#By default set the object
if __name__ == '__main__':
    # Enable some debugs
    _debug_enabled = True
    import api_actuator
    api_actuator._debug_enabled
    
    # Pop up the gui
    self = GUIMagnetPositions()
    self.show()
    
    
    
    
