# -*- coding: utf-8 -*-
"""
Created on Tue Feb 16 16:43:58 2021

Combine various personalized way to perform pulse sequences

@author: Childresslab
"""

# Import the relevant guis 
import __init__  as doesntmatter# Make 100% sure that the path is uploaded
from base_modules.gui_pulse_custome_main import GUIMainCustomePulseSequence
from base_modules.gui_pulse_perso_ESR import GUIESR
from base_modules.gui_pulse_perso_Rabi import GUIRabiOscillation
from base_modules.gui_pulse_perso_pulsedESR import GUIPulsedESR
from base_modules.gui_pulse_perso_decay import GUIDriftIndependentMeasurement
from base_modules.gui_pulse_perso_CET_calibre import GUICalibration
from base_modules.gui_pulse_perso_decay_trace import GUI4ptsTrace

from spinmob import egg
import traceback
# Very usefull command to use for getting the last-not-printed error
# Just type _p() in the console 
_p = traceback.print_last

#Debug
_debug_enabled           = False


def _debug(*a):
    if _debug_enabled: 
        s = []
        for x in a: s.append(str(x))
        print(', '.join(s))

class GUIPulseSequences(egg.gui.Window):
    """
    GUI for performing pulse sequences. 
    
    It is just gathering many gui that each is doing a pulse sequence
    
    """
    
    def __init__(self, fpga, name='The pulser you need.', show=True, size=[1500,900]):
        """
        Init. Ho yeaaaah. 
        
        fpga:
            "FPGA_api" object from api_fpga.py. 
            This is the object shared amoung the GUIs for controlling the fpga. 
            The session of the fpga must already be open. 
            
        """
        _debug('GUIPulseSequences: __init__', name)
        _debug('A reader lives a thousand lives before he dies. The man who never reads lives only one. ― George R.R. Martin')

        # Run the basic stuff for the initialization
        egg.gui.Window.__init__(self, title=name, size=size)
        
        # The heroic fpga
        self.fpga = fpga
        
        # Set the list of guis 
        self.list_label_design = ['Custome', 'ESR', 'Rabi', 'Pulsed_ESR', 
                                  'T1_single_time', 'CET Calibration', '4ptstrace']  
        self.list_gui_exp = [GUIMainCustomePulseSequence(self.fpga),
                             GUIESR(self.fpga)  ,
                             GUIRabiOscillation(self.fpga),
                             GUIPulsedESR(self.fpga),
                             GUIDriftIndependentMeasurement(self.fpga),
                             GUICalibration(self.fpga),
                             GUI4ptsTrace(self.fpga)]

        # Place a tab for each gui
        self.tab_main = self.place_object(egg.gui.TabArea(), alignment=0) 
        for i in range( len(self.list_label_design ) ):
            label = self.list_label_design[i]
            gui   = self.list_gui_exp[i]
            self.tab_main.add_tab(label).place_object(gui)
        
        
    def set_optimization_function(self, optimizer):
        """
        Set which function will be called when the optimization signal of the 
        pulse runner will be called
        
        function:
            Function of signature () to be called when its time to optimize.
        """
        _debug('GUIPulseSequences: set_optimization_method')

        for gui in self.list_gui_exp:
            try:
                # Overid for each pulse runner method
                gui.gui_pulse_runner.connect_opt_method(optimizer)  
            except:
                print('The gui '+str (type(gui) ), ' cannot apply the method .gui_pulse_runner.connect_opt_method(optimizer) ')        
        
        
        
#By default set the object
if __name__ == '__main__':
    # Enable some debugs
    _debug_enabled = True
    
    # Get and open the FPGA
    import spinmob as sm
    import base_modules.api_fpga as _fc 
    # Get the fpga paths and ressource number
    cpu_specific_infos = sm.data.load('base_modules\\cpu_specifics.dat')
    # cpu_specific_infos is defined in the import of the base modules
    bitfile_path = cpu_specific_infos.headers['FPGA_bitfile_path']
    resource_num = cpu_specific_infos.headers['FPGA_resource_number']
    fpga = _fc.FPGA_api(bitfile_path, resource_num) 
    fpga.open_session()
    
#    # If we want a fake FPGA API for testing the code
#    fpga = _fc.FPGA_fake_api(bitfile_path, resource_num) # Create the api   
#    fpga.open_session()
#    print()
#    print('!!! FAKE FPGA !!!!!')
#    print()
    
    
    # Also get the confocal
    import confocal
    confo = confocal.GUIMainConfocal(fpga)
    confo.show() # Hoh yess, we want to see it !
    
    self = GUIPulseSequences(fpga)
    # Add it to the confocal for avoiding too many openned window
    tab_pulse = confo.tabs1.add_tab('Pulse Sequence')
    tab_pulse.place_object(self )  
    
    # Connect the signal for optimizing
    self.set_optimization_function(confo.gui_optimizer)


        
        
        
        
        