# -*- coding: utf-8 -*-
"""
Created on Mon Aug 17 16:34:14 2020

@author: Childresslab
"""

# Get the base modules
import __init__  as doesntmatter# Make 100% sure that the path is uploaded
from base_modules.gui_pulse_perso_decay_trace import GUI4ptsTrace
from base_modules.T1_finder_functions import uDiffRatio

#The following is for plotting matplotlib object in the gui
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt4agg import FigureCanvasQTAgg as FigureCanvas
from PyQt5.QtCore import *
from PyQt5.QtGui import *

# Other useful library
import time
import numpy as np
from spinmob import egg
import spinmob as sm
import traceback
_p = traceback.print_last #Very usefull command to use for getting the last-not-printed error


_debug_enabled     = True
def _debug(*a):
    if _debug_enabled: 
        s = []
        for x in a: s.append(str(x))
        print(', '.join(s))

def estimate_t_total(tmin, tmax, N_time, N_readout, 
                     measure_both=True, duty_cycle=0.7):
    """
    Function for quicly estimate how long will be the total.
    
    
    
    Inputs:
        Time in us. 
        
        measure_both:
            (bool) True if both type of experiment are measured
        duty_cycle:
            Fraction of time spent to way t_probe
    
    Return the total estimated time, in hour. 
    """
    t_total = np.sum( sm.fun.erange(tmin, tmax, N_time) )*1e-6*N_readout*2 /3600 
    if measure_both:
        t_total *= 2
        
    return t_total/duty_cycle # Consider the duty cycle

class PlotResult(egg.gui.Window):
    """
    A window showing for showing the result of Bayes
    
    """
    def __init__(self): 
        """
        Initialize 
        """    
        #Run the basic stuff for the initialization
        egg.gui.Window.__init__(self)
        #Create a figure and canvas
        self.fig = plt.figure(tight_layout=True) #tight_layout make sure the labels are visible
        self.canvas = FigureCanvas(self.fig) # this is the Canvas Widget that displays the `figure`. It takes the `figure` instance as a parameter to __init__
        self.canvas.draw()
        #Add it to the GUI
        self.place_object(self.canvas)  

        #Initialise the plot
        self.initializeFigures()
        
    def initializeFigures(self):
        """
        Initialize the figures
        """
     
        #Set the axe
        self.ax = self.fig.add_subplot(111) 
        self.ax.set_autoscalex_on(True)
        
        self.ax.plot([1,1,2,5,8.5,-9], [1,4,2,5,8.7,-7])

        #The following update the plot. 
        self.fig.canvas.draw_idle()            

    def update_plot(self, t_us, y, ey):
        """
        Update the plot
            
        """    
        
        #Clean the graph before adding stuffs 
        self.ax.cla() 
        
        #Set the axe
        self.ax = self.fig.add_subplot(111) 
        self.ax.set_autoscalex_on(True)
        self.ax.errorbar(t_us, y, yerr=ey,
                     fmt='.-')   
        self.ax.set_xlim( (0.8*min(t_us), 1.2*max(t_us)) )
        self.ax.legend()
        self.ax.set_xlabel('Time (us)')
        self.ax.set_ylabel('Diff-Ratio')    
        self.ax.set_title('Processed data')     
        
        #The following update the plot. 
        self.fig.canvas.draw_idle()    
        
class GUIT1TimeTrace(egg.gui.Window):
    """
    GUI for taking a non-adaptive time trace for T1 measurement.    
    """   
    
    def __init__(self, fpga,  name="T1 Bad Ass Time Trace", size=[1000,500]): 
        """
        Initialize
        
        fpga:
            "FPGA_api" object from api_fpga.py. 
            This is the object shared amoung the GUIs for controlling the fpga. 
            The session of the fpga must already be open.   
            
        """    
        _debug('GUIT1TimeTrace: __init__')
        _debug('Oh yes, the past can hurt. But the way I see it, you can either run from it or learn from it. – The Lion King')
        
        # Run the basic stuff for the initialization
        egg.gui.Window.__init__(self, title=name, size=size)
        
        # Steal the pulser, mouhahaha
        self.fpga = fpga
        
        # Initialise the GUI widgets. 
        self._initialize_GUI()   
        
        # Initiate the parameters of the loop
        # It also initiate the label
        self._initiate_loop()        
        self.is_running = False
        
    def _initialize_GUI(self):
        """
        Fill up the GUI
        """      
        _debug('GUIT1TimeTrace: _initialize_GUI')

        # A button for preparing stuff
        self.button_run = egg.gui.Button('Start', tip='Launch the experiment')
        self.button_run.set_style('background-color: rgb(0, 200, 0);')
        self.button_run.set_checkable(True)
        self.place_object(self.button_run, row=0, column=0)
        self.connect(self.button_run.signal_clicked, self._button_run_clicked)

        # Important: a button for resetting the iteration
        self.button_reset = egg.gui.Button('Reset/Set experiment', tip='Reset the loop and prepare the experiment')
        self.button_reset.set_style('background-color: rgb(0, 200, 0);')
        self.place_object(self.button_reset, row=0, column=1)
        self.connect(self.button_reset.signal_clicked, 
                     self._button_reset_clicked)
       
        # tree dictionnarry for the settings
        self.treeDic_settings = egg.gui.TreeDictionary(autosettings_path='setting_non_adaptiveT1Bayes_4pts_trace')
        self.place_object(self.treeDic_settings, row=1, column=0, column_span=3)
        # The settings of the pulse sequence are set inside it. 
        self.treeDic_settings.add_parameter('save_each_sec', 10, 
                                            type='float', step=1, 
                                            bounds=[1, None], suffix=' min',
                                            tip='How long do we wait before saving the data.\nThis is for a security.')        
        
        # The following is related to the acquisition
        self.list_type = [+1, -1] # Type of pulse sequence to use
        self.treeDic_settings.add_parameter('Type_measurement', self.list_type[0], 
                                           type='list', values=self.list_type,
                                           tip='Will perform the time trace on only the select type.\nIf both, will perform the time trace on each type of measurement.')  
        self.treeDic_settings.add_parameter('want_measure_both', False, 
                                            type='bool',
                                            tip='If checked, will measure for each type of measurement')  
        self.treeDic_settings.add_parameter('N_readout', 2e5, 
                                            type='int', step=1, 
                                            bounds=[1,None],
                                            tip='Number of readout at each time to probe.') 

        self.treeDic_settings.add_parameter('time_per_fpga_loop', 1, 
                                            type='float', 
                                            bounds=[0.001,None], suffix=' s',
                                            tip='Aim spent time for the FPGA on one sequence (per iteration).\nOne second is good, but a smaller time can help for avoiding too much FPGA data at the same time.')          
        self.treeDic_settings.add_parameter('Name_save', 'Leper Messiah', 
                                            type='str', 
                                            tip='Label for naming the data of the pulse sequence when saved')  
        # Specific things for the pulse sequence for ms=+1
        self.treeDic_settings.add_parameter('Pipulse+/frequency', 3.1, 
                                            type='float', step=0.1, decimals=10,
                                            bounds=[0,None], suffix=' GHz',
                                            tip='Frequency of the pipulse for initiating the ms=+1 state')
        self.treeDic_settings.add_parameter('Pipulse+/dt', 0.3, 
                                            type='float', step=0.1, decimals=10,
                                            bounds=[0,None], suffix=' us',
                                            tip='Duration of pi pulse for ms=+1(RF)') 
        self.treeDic_settings.add_parameter('Pipulse+/power', -20, 
                                            type='float', step=1, decimals=10,
                                            bounds=[-50,30], suffix=' dBm',
                                            tip='Constant power of the RF for the pipulse of ms=+1')
        self.treeDic_settings.add_parameter('Pipulse+/DIO_modulation', 2, 
                                            type='int', step=1, 
                                            bounds=[0,16],
                                            tip='DIO for modulating the pi pulse of ms=+1. AKA for sending the RF.')
        
        
        # Specific things for the pulse sequence for ms=-1
        self.treeDic_settings.add_parameter('Pipulse-/frequency', 2.7, 
                                            type='float', step=0.1, suffix=' GHz',
                                            bounds=[0,None], decimals=10,
                                            tip='Frequency of the pipulse for initiating the ms=-1 state')
        self.treeDic_settings.add_parameter('Pipulse-/dt', 0.3, 
                                            type='float', step=0.1, decimals=10,
                                            bounds=[0,None], suffix=' us',
                                            tip='Duration of pi pulse for ms=-1(RF)') 
        self.treeDic_settings.add_parameter('Pipulse-/power', -20, 
                                            type='float', step=1, decimals=10,
                                            bounds=[-50,30], suffix=' dBm',
                                            tip='Constant power of the RF for the pipulse of ms=-1')
        self.treeDic_settings.add_parameter('Pipulse-/DIO_modulation', 4, 
                                            type='int', step=1, 
                                            bounds=[0,16],
                                            tip='DIO for modulating the pi pulse of ms=-1. AKA for sending the RF.')  
 
        
        # Add a tab for each step of the protocol
        self.tabs_steps = egg.gui.TabArea(autosettings_path='tabs_steps')
        self.place_object(self.tabs_steps,row=1, column=3,
                          column_span=4, alignment=0)
        
        # Tab for the measurer
        self.tab_measurer = self.tabs_steps.add_tab('Measurer')
        self.gui_measurer = GUI4ptsTrace(self.fpga)
        self.tab_measurer.place_object(self.gui_measurer, 
                                      alignment=0)
        # Tab for the showing information about the inference
        # Add the map for the posterior
        self.plot_info = PlotResult()
        self.tab_inference = self.tabs_steps.add_tab('Collected Data')
        self.tab_inference.place_object(self.plot_info, alignment=0)
        
        # Add a label for showing the status
        # Make a label for showing some estimate
        self.label_status = egg.gui.Label()
        self.place_object(self.label_status, row=0, column=3) 

    def _initiate_loop(self):
        """
        Initiate the attribute from the parameter choosen. 
        Prepare the prior based on the parameters choosen. 
        """
        _debug('GUIT1TimeTrace: _initiate_loop') 

        # =====================================================================
        # Initiate variables
        # =====================================================================
        # Some attributes
        self.iter = 0
        self.N_readout_gonna_happend = 0
        self.statut = 'Loop reinitiated. Waiting to start' # This will inform where we are in the tasks
        self.type_of_measurement = -999 # Funky number to show that it is not started yet
        self.name_save = self.treeDic_settings['Name_save']
        self.T_per_fpga_loop = self.treeDic_settings['time_per_fpga_loop'] 
        self.estimate_time_per_readout = -999 # Funky number to show that it is not started yet-
        # Note the initial time
        self.t_initiale = time.time()
        
        # Update the info shown
        self._label_info_update() 
        # Update the run button, because we are ready to start
        self.button_run.set_text('Start')
        self.button_run.set_style('background-color: rgb(0, 200, 0);')  
     
    def _label_info_update(self):
        """
        Update the label showing the status
        """
        _debug('GUIT1TimeTrace: _label_info_update')
        
        txt = ('Statut: '+ self.statut + 
             '\nReal Number of readout: %d'%self.N_readout_gonna_happend+
             '\nEstimate time of iter : %f min'%(self.N_readout_gonna_happend*self.estimate_time_per_readout/60)+
             '\nMeasurement type      : %d'%self.type_of_measurement+
             '\nIteration             : %d'%self.iter)
        self.label_status.set_text(txt)   

    def _button_reset_clicked(self):
        """
        Stop and reset the iterations
        """
        _debug('GUIAdaptivePiPulseFinder: _button_reset_clicked')
        
        # Stop to run 
        if self.is_running:
            self.button_run.click()
        
        # Reinitiate the loop, which reset the iterators and everything
        self._initiate_loop()
        
        
    def _button_run_clicked(self, dir_save=-1):
        """
        Run the protocole
        
        dir_save:
            (String) If a string, it will pop-up a window for 
            asking where to save the file. Otherwise the file will be saved in 
            the path given. 
            
        """
        _debug('GUIT1TimeTrace: _button_run_clicked')
        
        # Run only if it is not already running
        if self.is_running == False:            
            # If we are starting
            if self.iter == 0:            
                # Set the saving directory
                if not ( type(dir_save) == str ):
                    # Ask the user the repository for saving the files
                    txt = 'Select a directory for saving the incoming data'
                    self.path_folder_save_main = sm.dialogs.select_directory(txt)  
                else:
                    self.path_folder_save_main = dir_save
            
            # Prepare to launch the serie of measurement
            # The path to save is the main 
            # (This redundancy is for if we want to split the different 
            # measurement in different folders)
            self.path_folder_save = self.path_folder_save_main
            # Run the loop
            self._initiate_loop()
            self.is_running = True
            self.button_run.set_text('Pause')
            self.button_run.set_colors(background='blue')
            self._run_loop()

        else:
            # Stop to run if it is running (Pause)
            self.is_running = False
            self.button_run.set_text('Continue')
            self.button_run.set_style('background-color: rgb(0, 200, 0);')
            self.statut += '\n\nPaused !'
            self._label_info_update()
      
       # I know that it is dangerous, but I do it anyway:
       # I am commenting the following line that I noted for myself. 
      #  I AM HERE TO CHECK UP
    def _run_loop(self):
        """
        Run the loop of the measurement
        """
        _debug('GUIT1TimeTrace: _run_loop')
        
        while self.get_condition_loop():     
            # 
            if self.treeDic_settings['want_measure_both']:
                # Interleave each type of measurement per loop. 
                for i in range(len(self.list_type)):
                    # Update the statut shown
                    self.statut = ('Running the loop %d/%d'%(self.iter, 
                                                             self.N_t) ) 
                    self._label_info_update()                       
                    self.treeDic_settings['Type_measurement'] = self.list_type[i] 
                    self._all_step_per_iteration()               
            else:                                
                # Update the statut shown
                self.statut = ('Running the loop %d/%d'%(self.iter, self.N_t) )
                # Update the information shown
                self._label_info_update()   
                self._all_step_per_iteration()            
            # Update the condition
            self.iter += 1     
            
        # Do special stuff if we finish the whole loop
        if not(self.condition2):
            # I will not reset, because it is customary to check what is going on.
#            # Reset the parameters for the next experiment
#            self._button_reset_clicked()
            self.statut = ('%d/%d Congratualition ! All the iterations are done. '%(self.iter, self.N_t) )
            self._label_info_update()                   

    def _all_step_per_iteration(self):
        """
        Run all the steps for one iteration. 
        """
        _debug('GUIT1TimeTrace: _all_step_per_iteration')
        
        # Step 1: Set the parameters
        self.step1_set_parameters()
        self.process_events() # Important to refresh the GUI
        
        # Step 2: Take a measurement with that.
        self.step2_run_measurement()
        self.process_events() # Important to refresh the GUI
        
        # Step 3: Feed the measurement data to the bayes inferencer
        self.step3_process_measurement()
        self.process_events() # Important to refresh the GUI
        
        # Step 4: Recored relevant information
        self.step4_record_info()
        self.process_events() # Important to refresh the GUI 
            
    def get_condition_loop(self):
        """
        Determine the condition for the loop. 
        Return True or False, for iff we must continue or not the loop. 
        """      
        _debug('GUIT1TimeTrace: get_condition_loop')
        
        self.condition1 = self.is_running
        self.condition2 = self.iter < self.N_t
        
        # Return True if all these condition are true
        return  self.condition1 * self.condition2
        
    def step1_set_parameters(self):
        """
        Adapt the set of parameters for the next measurement. 
        It take the information from the posterior of the Bayes inference. 
        """
        _debug('GUIT1TimeTrace: step1_set_parameters')
        
        # =====================================================================
        # Determine the best setting
        # =====================================================================    
        t0 = time.time()
        self.type_of_measurement  = float(self.treeDic_settings['Type_measurement']) 
        self.t_probe = self.list_t_probe[self.iter]
        self.t_find_settings = time.time() - t0
            
        # =====================================================================
        # Prepare the parameters of the pulse sequence
        # =====================================================================          
        # Set the parameters of the pulse sequence 
        if self.type_of_measurement == -1:
            # Adapt the parameters of the pulse sequence
            # The pipulse is the pi-pulse for ms=-
            p   = self.treeDic_settings['Pipulse-/power']
            f   = self.treeDic_settings['Pipulse-/frequency']
            dt  = self.treeDic_settings['Pipulse-/dt']
            DIO = self.treeDic_settings['Pipulse-/DIO_modulation']
        if self.type_of_measurement == +1:
            # Adapt the parameters of the pulse sequence
            # The pipulse is the pi-pulse for ms=-
            p   = self.treeDic_settings['Pipulse+/power']
            f   = self.treeDic_settings['Pipulse+/frequency']
            dt  = self.treeDic_settings['Pipulse+/dt']
            DIO = self.treeDic_settings['Pipulse+/DIO_modulation']     
        # Set the parameters of the pulse sequence
        self.gui_measurer.treeDic_settings['t_probe']     = self.t_probe*1e6 # In us
        self.gui_measurer.treeDic_settings['Frequency']   = f
        self.gui_measurer.treeDic_settings['Power']       = p
        self.gui_measurer.treeDic_settings['dt_pi_pulse'] = dt # in us
        self.gui_measurer.treeDic_settings['DIO_pulse_modulation'] = DIO
        
        # =====================================================================
        # Determine the number of fpga loop and get the real number of readout.
        # =====================================================================                     
        # Determine the number of readout for the next measurement. 
        self.N_readout_target = self.treeDic_settings['N_readout']
        # We roughly want the fpga_loop to last less than few second. This is in
        # order to avoid freeze out of the GUI
        self.estimate_time_per_readout = 2*self.t_probe + 500*1e-6 # (second) Roughly the time elapsed by readout
        self.N_readout_per_FPGA_loop = int(np.ceil( self.T_per_fpga_loop/(self.estimate_time_per_readout) ))  
        # Determine how many FPGA loop to perfom. 
        # We take the ceil, such that we have at least 1 loop. 
        self.N_FPGA_loop = int( np.ceil(self.N_readout_target/self.N_readout_per_FPGA_loop ) )
        # The true number of readout that should happen
        self.N_readout_gonna_happend = self.N_readout_per_FPGA_loop*self.N_FPGA_loop
        
        # Update the label
        self._label_info_update()
        
    def step2_run_measurement(self):
        """
        Perform a measurement at the time probed.
        
        """
        _debug('GUIT1TimeTrace: step2_run_measurement')

        # =====================================================================
        # Optimize at the beginning.
        # =====================================================================          
        self.dummy_please_optimize() # This needs to be overid with the real function to optimize

        # =====================================================================
        # Prepare the pulse sequence
        # =====================================================================   
        t0 = time.time()
        self.gui_measurer.button_prepare_experiment.click()        
        # Set the number of readout
        self.gui_measurer.gui_pulse_runner.NumberBox_repetition.set_value(self.N_readout_per_FPGA_loop) 
        # Set the number of FPGA loop to have. 
        self.gui_measurer.gui_pulse_runner.NumberBox_N_loopFPGA.set_value(self.N_FPGA_loop)
        # Convert the pulse sequence
        # The button reset is automatically clicked in the method for converting
        self.gui_measurer.gui_pulse_runner.button_convert_sequence.click()
        self.t_prep_measurement = time.time() - t0

        # =====================================================================
        # Run it !
        # =====================================================================                  
        # It should stop after that the number of FPGA loop is performed
        _debug('GUIT1TimeTrace: step2_run_measurement: Measurement started...')
        t0 = time.time()
        self.gui_measurer.gui_pulse_runner.button_start.click()
        self.t_pulse_sequence = time.time() - t0
        _debug('GUIT1TimeTrace: step2_run_measurement: Measurement done !')     
        
    def step3_process_measurement(self):
        """
        Extract the data from the measurement taken
        """
        _debug('GUIT1TimeTrace: step3_process_measurement')
        
        # Get the real number of readout that happened
        self.N_loop_perfomed = self.gui_measurer.gui_pulse_runner.iter
        self.N_readout_per_FPGA_loop_performed = self.gui_measurer.gui_pulse_runner.NumberBox_repetition.get_value()
        self.N_readout = self.N_loop_perfomed*self.N_readout_per_FPGA_loop_performed

        # =====================================================================
        # Compute the mean photocount and uncertainty
        # =====================================================================  
        # Mean count of ms=0 at t = 0
        PL0_0  = np.sum(self.gui_measurer.count_per_iter_PL1_t0_s         )/self.N_readout 
        # Mean count of ms=0 at t = t_probe
        PL0_t = np.sum(self.gui_measurer.count_per_iter_PL1_tprobed_s     )/self.N_readout 
        # Mean count of ms=+-1 at t = 0
        PL1_0 = np.sum(self.gui_measurer.count_per_iter_PL2_t0_s        )/self.N_readout 
        # Mean count of ms=+-1 at t = t_probe
        PL1_t = np.sum(self.gui_measurer.count_per_iter_PL2_tprobed_s   )/self.N_readout 
        # Uncertainty in each of these four measurement
        ePL0_0 = np.sqrt( PL0_0 / self.N_readout )
        ePL0_t = np.sqrt( PL0_t / self.N_readout )
        ePL1_0 = np.sqrt( PL1_0 / self.N_readout )
        ePL1_t = np.sqrt( PL1_t / self.N_readout )        
        
        # =====================================================================
        # Combine the results to obtain the famous drif-independent measurement
        # =====================================================================     
        self.result, self.uncertainty = uDiffRatio(PL0_t, ePL0_t, PL1_t, ePL1_t,
                                                   PL0_0, ePL0_0, PL1_0, ePL1_0 )
        self.list_result     .append(self.result)
        self.list_uncertainty.append(self.uncertainty)
        self.list_t_probed_acc.append(self.t_probe)
        
        # Update the inference
        self.plot_info.update_plot(np.array(self.list_t_probed_acc)*1e6, 
                                   self.list_result, self.list_uncertainty)
        
    def step4_record_info(self):
        """
        Record the infor in the object.
        """
        _debug('GUIT1TimeTrace: step4_record_info')

        # =====================================================================
        # SAVE THE DATA
        # =====================================================================  
        # Add some stuff in the data boxe
        self.gui_measurer.databoxplot.insert_header('Type_measure', self.type_of_measurement)
        self.gui_measurer.databoxplot.insert_header('Time_initial', self.t_initiale)
        self.gui_measurer.databoxplot.insert_header('Time_finish' , time.time())
        # Related to various elapsed time for the stats
        self.gui_measurer.databoxplot.insert_header('duration_find_settings', self.t_find_settings)
        self.gui_measurer.databoxplot.insert_header('duration_prep_settings', self.t_prep_measurement)
        self.gui_measurer.databoxplot.insert_header('duration_pulse_sequence', self.t_pulse_sequence)
        
        # Also add all the stuff from the main three dictionary
        for key in self.treeDic_settings.get_keys():
            # Add each element of the dictionnary three
            value = self.treeDic_settings[key]
            self.gui_measurer.databoxplot.insert_header(key , value )        
        
        # Give a unique name to the file and save it. 
        self.total_name = self.name_save +'_type'+str(int(self.type_of_measurement)) +'_%d.dat'%self.iter
        path = self.path_folder_save + '/' + self.total_name
        self.gui_measurer.databoxplot.save_file(path)        
        

    def dummy_please_optimize(self):
        """
        Dummy method to be overid. 
        This is called each time that we want an optimization, in the method
        "step2_run_measurement". 
        For example, this dummy method should be overid by the optimization
        function of the confocal optimizer.
        """
        _debug('GUIT1TimeTrace:: dummy_please_optimize')

    

    
if __name__=="__main__":
    _debug_enabled = True
    
    # Get the fpga  
    import base_modules.api_fpga as _fc # For using the FPGA
    # Get the fpga paths and ressource number
    cpu_specific_infos = sm.data.load('base_modules\\cpu_specifics.dat')
    # cpu_specific_infos is defined in the import of the base modules
    bitfile_path = cpu_specific_infos.headers['FPGA_bitfile_path']
    resource_num = cpu_specific_infos.headers['FPGA_resource_number']
    # Get the fpga API
    fpga = _fc.FPGA_api(bitfile_path, resource_num) 
    fpga.open_session()

#    # Uncomment for a fake api of the fpga
#    fpga = _fc.FPGA_fake_api(bitfile_path, resource_num) # Create the api   
#    fpga.open_session()
#    print('\nFAKE FPGA API\n')
    
    
    # Also get the confocal
    import confocal
    confo = confocal.GUIMainConfocal(fpga)
    confo.show() # Hoh yess, we want to see it !

    # Import also the pulse sequence for being able to calibrate stuffs
    from pulse_sequences import GUIPulseSequences
    pulse = GUIPulseSequences(fpga)
    # Add it to the confocal for avoiding too many openned window
    tab_pulse = confo.tabs1.add_tab('Pulse Sequence')
    tab_pulse.place_object(pulse)  
    
#    # Get a pi-pulse finder, because it is always useful
#    from pipulse_find_auto import GUIPiPulseFinderAuto
#    pipulse = GUIPiPulseFinderAuto(fpga)
#    pipulse.show()
        
    # Finnaly, show the usual adpater
    self = GUIT1TimeTrace(fpga, size=[1800,1000])
    self.show()
    
    # Connect the optimization !
    self.gui_measurer.gui_pulse_runner.connect_opt_method(confo.gui_optimizer)    
    f_optimize = confo.gui_optimizer.button_optimize.click
    self.dummy_please_optimize = f_optimize
    pulse.set_optimization_function(f_optimize)
#    pipulse.connect_optimization(f_optimize)
    
#    # Also put the magnet positioner. Always useful
#    from magnet_positions import GUIMagnetPositions
#    magnet = GUIMagnetPositions()
#    magnet.show()
#    
    
    
#     Bonus
#    from sweep_pulsedESR import GUISweepPulsedESR
#    sweepy = GUISweepPulsedESR(fpga)
#    sweepy.gui_pulsed_ESR.gui_pulse_runner.dummy_please_optimize = f_optimize
#    sweepy.show()
#    
#    
    
    
    
    
    
    
    
    
