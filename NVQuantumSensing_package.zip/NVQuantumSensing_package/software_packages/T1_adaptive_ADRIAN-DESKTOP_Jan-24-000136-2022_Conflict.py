# -*- coding: utf-8 -*-
"""
Created on Mon Aug 17 16:34:14 2020

@author: Childresslab
"""

# Get the base modules
import __init__  as doesntmatter# Make 100% sure that the path is uploaded
from base_modules.gui_pulse_perso_decay import GUIDriftIndependentMeasurement
from base_modules.T1_finder_functions import uDiffRatio
from base_modules.T1_finder import T1Finder


# Define right now the model function
# Defines the models function        
def model_00m0(m, t, gp, gm):
    """
    
    Model for the behavior of the experimental measurement. 
    It of the type 00m0; where m is either +1 or -1. 
    
    m:
        +1 or -1 
        (Depending on the tuype of the pulse sequence to use)   
    t:
        Time    
    gp, gm:
        Rates
        
    Choice of unit: 
        As long as the time multiplied by the rate is unitless.
        
    """    
    g0 = ( gp*gp + gm*gm - gp*gm )**0.5
    beta_p = gp + gm + g0
    beta_m = gp + gm - g0   
    
    # This trick outputs gp is m=+1 and gm if m=-1
    gamma = 0.5*(1+m)*gp + 0.5*(1-m)*gm 
    
    term1 = (g0 + gamma) *np.exp(-beta_p * t)
    term2 = (g0 - gamma)*np.exp(-beta_m * t)
    
    return (term1 + term2 ) / (2*g0)  
def model_plus(t, gp, gm):
    return model_00m0(+1, t, gp, gm)
def model_minus(t, gp, gm):
    return model_00m0(-1, t, gp, gm)  

#The following is for plotting matplotlib object in the gui
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt4agg import FigureCanvasQTAgg as FigureCanvas
from PyQt5.QtCore import *
from PyQt5.QtGui import *

# Other useful library
import time
import numpy as np
from spinmob import egg
import spinmob as sm
import traceback
_p = traceback.print_last #Very usefull command to use for getting the last-not-printed error


_debug_enabled     = True
def _debug(*a):
    if _debug_enabled: 
        s = []
        for x in a: s.append(str(x))
        print(', '.join(s))

class PlotResult(egg.gui.Window):
    """
    A window showing for showing the result of Bayes
    
    """
    def __init__(self): 
        """
        Initialize 
        """    
        #Run the basic stuff for the initialization
        egg.gui.Window.__init__(self)
        #Create a figure and canvas
        self.fig = plt.figure(tight_layout=True) #tight_layout make sure the labels are visible
        self.canvas = FigureCanvas(self.fig) # this is the Canvas Widget that displays the `figure`. It takes the `figure` instance as a parameter to __init__
        self.canvas.draw()
        #Add it to the GUI
        self.place_object(self.canvas)  

        #Initialise the plot
        self.initializeFigures()
        
    def initializeFigures(self):
        """
        Initialize the figures
        """
     
        #Set the axe
        self.ax = self.fig.add_subplot(111) 
        self.ax.set_autoscalex_on(True)
        
        self.ax.plot([1,1,2,5,8.5,-9], [1,4,2,5,8.7,-7])

        #The following update the plot. 
        self.fig.canvas.draw_idle()            

    def update_plot_NIST(self, bayes_class):
        """
        Update the plot
        
        bayes_class:
            Class used to extract all the parameters
            
        """    
        # Extract nice parameters
        means, stds, covs = bayes_class.get_parameters()
        self.best_gp  = means[0]
        self.std_gp   = stds[0]
        self.best_gm  = means[1]
        self.std_gm   = stds[1]
        
        #Clean the graph before adding stuffs 
        self.ax.cla() 
        
        #Set the axe
        self.ax = self.fig.add_subplot(111) 
        self.ax.set_autoscalex_on(True)

        # PLot the cloud of parameters
        parms = bayes_class.my_obe.parameters # This contains the arrays of each parameter
        self.ax.scatter(parms[0]*1e-3, parms[1]*1e-3, color='k', alpha=0.1)
        # Show the infered value 
        label = ('Best estimate' +  
                 '\n$\Gamma_+$ = %f +- %f kHz'%(self.best_gp *1e-3, self.std_gp*1e-3) +
                 '\n$\Gamma_-$ = %f +- %f kHz'%(self.best_gm *1e-3, self.std_gm*1e-3))
        self.ax.errorbar(self.best_gp *1e-3, self.best_gm*1e-3, 
                     xerr=self.std_gp*1e-3, yerr=self.std_gm*1e-3,
                     fmt='.', color='red', label=label)   
        self.ax.legend()
        self.ax.set_xlabel('Rate+ (kHz)')
        self.ax.set_ylabel('Rate- (kHz)')    
        self.ax.set_title('Cloud representation of the posterior')     
        
        #The following update the plot. 
        self.fig.canvas.draw_idle()   

    def update_plot_Delta(self, bayes_class):
        """
        Update the plot
        
        bayes_class:
            Class used to extract all the parameters
            
        """    
        
        # Extract nice parameters
        means, stds, covs = bayes_class.get_parameters()
        self.best_gp  = means[0]
        self.std_gp   = stds[0]
        self.best_gm  = means[1]
        self.std_gm   = stds[1]
        
        #Clean the graph before adding stuffs 
        self.ax.cla() 
        
        #Set the axe
        self.ax = self.fig.add_subplot(111) 
        self.ax.set_autoscalex_on(True)

        # PLot the pdf
        Z, mesh_gp, mesh_gm = bayes_class.my_bayes.get_post()
        self.ax.pcolor(mesh_gp*1e-3, mesh_gm*1e-3, Z, cmap=plt.cm.jet)
        # Show the infered value 
        label = ('Best estimate' +  
                 '\n$\Gamma_+$ = %f +- %f kHz'%(self.best_gp *1e-3, self.std_gp*1e-3) +
                 '\n$\Gamma_-$ = %f +- %f kHz'%(self.best_gm *1e-3, self.std_gm*1e-3))
        self.ax.errorbar(self.best_gp *1e-3, self.best_gm*1e-3, 
                     xerr=self.std_gp*1e-3, yerr=self.std_gm*1e-3,
                     fmt='.', color='red', label=label)   
        self.ax.legend()
        self.ax.set_xlabel('Rate+ (kHz)')
        self.ax.set_ylabel('Rate- (kHz)')    
        self.ax.set_title('Pdf')     
        
        #The following update the plot. 
        self.fig.canvas.draw_idle()           
        
        
class GUIAdaptT1(egg.gui.Window):
    """
    GUI for managing the adaptive protocole for T1 measurement. 
    This gui is the head of the protocol:
        - It Run the measurement
        - It send the data to the Bayes inferecencer
        - It determine the best set of parameters for the next measurement. 
    
    """   
    
    def __init__(self, fpga,  name="Super adaptive T1 Bad Ass", size=[1000,500]): 
        """
        Initialize
        
        fpga:
            "FPGA_api" object from api_fpga.py. 
            This is the object shared amoung the GUIs for controlling the fpga. 
            The session of the fpga must already be open.   
            
        """    
        _debug('GUIAdaptT1: __init__')
        _debug('Oh yes, the past can hurt. But the way I see it, you can either run from it or learn from it. – The Lion King')
        
        # Run the basic stuff for the initialization
        egg.gui.Window.__init__(self, title=name, size=size)
        
        # Steal the pulser, mouhahaha
        self.fpga = fpga
        
        # Initialise the GUI widgets. 
        self._initialize_GUI()   
        
        # Initiate the parameters of the loop
        # It also initiate the label
        self._initiate_loop()        
        
    def _initialize_GUI(self):
        """
        Fill up the GUI
        """      
        _debug('GUIAdaptT1: _initialize_GUI')

        # A button for preparing stuff
        self.button_run = egg.gui.Button('Start', tip='Launch the experiment')
        self.button_run.set_style('background-color: rgb(0, 200, 0);')
        self.button_run.set_checkable(True)
        self.place_object(self.button_run, row=0, column=0)
        self.connect(self.button_run.signal_clicked, self._button_run_clicked)

        # Important: a button for resetting the iteration
        self.button_reset = egg.gui.Button('Reset/Set experiment', tip='Reset the loop and prepare the experiment')
        self.button_reset.set_style('background-color: rgb(0, 200, 0);')
        self.place_object(self.button_reset, row=0, column=1)
        self.connect(self.button_reset.signal_clicked, 
                     self._button_reset_clicked)
        
        # Place a button for saving the data
        self.button_save = self.place_object(egg.gui.Button(), row=0, column=2,
                                             alignment=1)
        self.button_save.set_text('Save :D :D :D')
        self.connect(self.button_save.signal_clicked, self._button_save_clicked)  
       
        # tree dictionnarry for the settings
        self.treeDic_settings = egg.gui.TreeDictionary(autosettings_path='setting_adaptiveT1Bayes')
        self.place_object(self.treeDic_settings, row=1, column=0, column_span=3)
        # The following is related to the settings
        self.treeDic_settings.add_parameter('t_probe_min', 50, 
                                            type='float', 
                                            bounds=[1,None], suffix=' us',
                                            tip='Minimum time to probe.')
        self.treeDic_settings.add_parameter('t_probe_max', 1000, 
                                            type='float', 
                                            bounds=[1,None], suffix=' us',
                                            tip='Maximum time to probe.')        
        self.treeDic_settings.add_parameter('N_setting', 1000, 
                                            type='int', step=1, 
                                            bounds=[2,None],
                                            tip='Number of possible timeto probe.\nIt sets the resolution of the time probed.') 
        self.treeDic_settings.add_parameter('want_log_t_domain', True, 
                                            type='bool', 
                                            tip='Weither or not to have a logarithm possible time to probe.')         
        # The following is related to the prior knowledge on the rates
        self.treeDic_settings.add_parameter('Rate_+_min', 0.01, 
                                            type='float', step=0.1, 
                                            bounds=[0,None], suffix=' kHz',
                                            tip='Guess for the minimum value of the rate gamma+') 
        self.treeDic_settings.add_parameter('Rate_+_max', 100, 
                                            type='float', step=0.1, 
                                            bounds=[0,None], suffix=' kHz',
                                            tip='Guess for the maximum value of the rate gamma+') 
        self.treeDic_settings.add_parameter('Rate_-_min', 0.01, 
                                            type='float', step=0.1, 
                                            bounds=[0,None], suffix=' kHz',
                                            tip='Guess for the minimum value of the rate gamma-')         
        self.treeDic_settings.add_parameter('Rate_-_max', 100, 
                                            type='float', step=0.1, 
                                            bounds=[0,None], suffix=' kHz',
                                            tip='Guess for the maximum value of the rate gamma-')
        self.treeDic_settings.add_parameter('N_grid', 200, 
                                            type='int', step=1, 
                                            bounds=[10,None],
                                            tip='Number of points in the grid for the pdf.\nThe more, the finer is the pdf.')         

        # The following is related to the acquisition
        self.treeDic_settings.add_parameter('N_readout', 2e5, 
                                            type='int', step=1, 
                                            bounds=[1,None],
                                            tip='Number of readout to make at each iteration of the adaptive protocole') 
        self.treeDic_settings.add_parameter('N_adaptation', 10, 
                                            type='int', step=10, 
                                            bounds=[1,None],
                                            tip='Number of iteration to perfom the adaptive protocole') 
        self.treeDic_settings.add_parameter('time_per_fpga_loop', 1, 
                                            type='float', 
                                            bounds=[0.001,None], suffix=' s',
                                            tip='Aim spent time for the FPGA on one sequence (per iteration).\nOne second is good, but a smaller time can help for avoiding too much FPGA data at the same time.')          
        
        self.list_algo_type = ['Delta']
        self.treeDic_settings.add_parameter('Algo_type', 0, 
                                           type='list', values=self.list_algo_type,
                                           tip='Which algorithm to use for making the adaption')  
        self.treeDic_settings.add_parameter('want_rel_sens', True, 
                                            type='bool', 
                                            tip='If checkeck, will optimize the combined relative sensitivity.\nOtherwise it will optimize the absolute sensitivity.')   
        
        self.treeDic_settings.add_parameter('Name_save', 'Harvester of Sorrow', 
                                            type='str', 
                                            tip='Label for naming the data of the pulse sequence when saved')  
        # Specific things for the pulse sequence for ms=+1
        self.treeDic_settings.add_parameter('Pipulse+/frequency', 3.1, 
                                            type='float', step=0.1, decimals=10,
                                            bounds=[0,None], suffix=' GHz',
                                            tip='Frequency of the pipulse for initiating the ms=+1 state')
        self.treeDic_settings.add_parameter('Pipulse+/dt', 0.3, 
                                            type='float', step=0.1, decimals=10,
                                            bounds=[0,None], suffix=' us',
                                            tip='Duration of pi pulse for ms=+1(RF)') 
        self.treeDic_settings.add_parameter('Pipulse+/power', -20, 
                                            type='float', step=1, decimals=10,
                                            bounds=[-50,30], suffix=' dBm',
                                            tip='Constant power of the RF for the pipulse of ms=+1')
        self.treeDic_settings.add_parameter('Pipulse+/DIO_modulation', 2, 
                                            type='int', step=1, 
                                            bounds=[0,16],
                                            tip='DIO for modulating the pi pulse of ms=+1. AKA for sending the RF.')  
        
        # Specific things for the pulse sequence for ms=-1
        self.treeDic_settings.add_parameter('Pipulse-/frequency', 2.7, 
                                            type='float', step=0.1, suffix=' GHz',
                                            bounds=[0,None], decimals=10,
                                            tip='Frequency of the pipulse for initiating the ms=-1 state')
        self.treeDic_settings.add_parameter('Pipulse-/dt', 0.3, 
                                            type='float', step=0.1, decimals=10,
                                            bounds=[0,None], suffix=' us',
                                            tip='Duration of pi pulse for ms=-1(RF)') 
        self.treeDic_settings.add_parameter('Pipulse-/power', -20, 
                                            type='float', step=1, decimals=10,
                                            bounds=[-50,30], suffix=' dBm',
                                            tip='Constant power of the RF for the pipulse of ms=-1')
        self.treeDic_settings.add_parameter('Pipulse-/DIO_modulation', 4, 
                                            type='int', step=1, 
                                            bounds=[0,16],
                                            tip='DIO for modulating the pi pulse of ms=-1. AKA for sending the RF.')  
 
        
        # Add a tab for each step of the protocol
        self.tabs_steps = egg.gui.TabArea(autosettings_path='tabs_adaptiveT1_steps')
        self.place_object(self.tabs_steps,row=1, column=3,
                          column_span=4, alignment=0)
        
        # Tab for the measurer
        self.tab_measurer = self.tabs_steps.add_tab('Measurer')
        self.gui_measurer = GUIDriftIndependentMeasurement(self.fpga)
        self.tab_measurer.place_object(self.gui_measurer, 
                                      alignment=0)
        # Tab for the showing information about the inference
        # Add the map for the posterior
        self.plot_info = PlotResult()
        self.tab_inference = self.tabs_steps.add_tab('Inference')
        self.tab_inference.place_object(self.plot_info, alignment=0)
        
        # Add a label for showing the status
        # Make a label for showing some estimate
        self.label_status = egg.gui.Label()
        self.place_object(self.label_status, row=0, column=3) 


    def _initiate_loop(self):
        """
        Initiate the attribute from the parameter choosen. 
        Prepare the prior based on the parameters choosen. 
        """
        _debug('GUIAdaptT1: _initiate_loop') 

        # =====================================================================
        # Initiate variables
        # =====================================================================
        # Some attributes
        self.t_probe   = 0 # Actual time probed
        self.iter = 0
        self.is_running = False # Important for the buttons
        self.N_readout_gonna_happend = 0
        self.statut = 'Loop reinitiated. Waiting to start' # This will inform where we are in the tasks
        self.type_of_measurement = -999 # Funky number to show that it is not started yet
        self.name_save = self.treeDic_settings['Name_save']
        self.T_per_fpga_loop = self.treeDic_settings['time_per_fpga_loop'] 
        # How much time to run the loop of the adaptive protocole. 
        self.N_adaptation = self.treeDic_settings['N_adaptation']
        self.want_rel_sens = self.treeDic_settings['want_rel_sens']
        self.estimate_time_per_readout = -999 # Funky number to show that it is not started yet
        # The following are information to store at each iteration
        self.recorded_t_probe_p_s = []
        self.recorded_t_probe_m_s = []
        self.recorded_t_probe_s   = []
        self.recorded_N_readout    = []
        self.recorded_type_of_measurement = []
        self.recorded_best_gp_s = []
        self.recorded_best_gm_s = []
        self.recorded_std_gp_s  = []
        self.recorded_std_gm_s  = []
        self.recorded_measure_ms0 = []
        self.recorded_measure_msp = []
        self.recorded_measure_msm = []
        self.recorded_iteration_s = []
        # Note the initial time
        self.t_initiale = time.time()
        
        # =====================================================================
        # Initiate the bayes class
        # =====================================================================     
        # Set the time to probe IN SECOND
        self.t_probe_min = self.treeDic_settings['t_probe_min'] * 1e-6 # sec
        self.t_probe_max = self.treeDic_settings['t_probe_max'] * 1e-6 # sec
        self.N_setting   = self.treeDic_settings['N_setting'] 
        want_log_t_domain = self.treeDic_settings['want_log_t_domain']
        if want_log_t_domain:
            self.list_t_probe = sm.fun.erange(self.t_probe_min, 
                                              self.t_probe_max,
                                              self.N_setting)
        else:
            self.list_t_probe = np.linspace(self.t_probe_min, self.t_probe_max,
                                              self.N_setting)     
        # Set the prior
        # Extract the bounds
        Gp_min       = self.treeDic_settings['Rate_+_min']*1e3 # (Hz) Minimum guess for gamma plus
        Gp_max       = self.treeDic_settings['Rate_+_max']*1e3 # (Hz) Maximun guess for gamma plus 
        Gm_min       = self.treeDic_settings['Rate_-_min']*1e3 # (Hz) Minimum guess for gamma minus 
        Gm_max       = self.treeDic_settings['Rate_-_max']*1e3 # (Hz) Maximun guess for gamma minus    
        N_grid = self.treeDic_settings['N_grid']
            
        if self.treeDic_settings['Algo_type'] == 'Delta':  
            tuple_prior_info = (Gp_min, Gp_max, Gm_min, Gm_max, N_grid)
            self.finder = T1Finder(self.list_t_probe, 
                                   model_plus, model_minus, 
                                   tuple_prior_info)              
            # Update the inference
            try:
                self.plot_info.update_plot_Delta(self.finder)
            except:
                print('Error In GUIAdaptT1: Cannot update the plot!')
        else:
            print("Error in GUIAdaptT1: _initiate_loop. self.treeDic_settings['Algo_type'] is wrong. It is set to ", self.treeDic_settings['Algo_type'])
        
        
        # Update the infor shown
        self._label_info_update() 
        # Update the run button, because we are ready to start
        self.button_run.set_text('Start')
        self.button_run.set_style('background-color: rgb(0, 200, 0);')  
        
    def _label_info_update(self):
        """
        Update the label showing the status
        """
        _debug('GUIAdaptT1: _label_info_update')
        
        txt = ('Statut: '+ self.statut + 
             '\nTime probed           : %f ms '%(self.t_probe*1e3)+
             '\nReal Number of readout: %d'%self.N_readout_gonna_happend+
             '\nUnder-Estimate time of iter : %f min'%(self.N_readout_gonna_happend*self.estimate_time_per_readout/60)+
             '\nMeasurement type      : %d'%self.type_of_measurement+
             '\nIteration             : %d'%self.iter)
        self.label_status.set_text(txt)   
         
        
    def _button_save_clicked(self):
        """
        Save everything !
        """
        _debug('GUIAdaptT1: _button_save_clicked')
        self.databox = sm.data.databox()
        
        # Put cool headers
        for key in self.treeDic_settings.get_keys():
            # Add each element of the dictionnary three
            self.databox.insert_header(key , self.treeDic_settings[key])
            
            
        # Put the recorded info
        # Feed the databox plot with the data
        self.databox['iteration_s'] = self.recorded_iteration_s
        self.databox['t_probe_p_s'] = self.recorded_t_probe_p_s
        self.databox['t_probe_m_s'] = self.recorded_t_probe_m_s        
        self.databox['t_probe_s'  ] = self.recorded_t_probe_s
        self.databox['N_readout_s'] = self.recorded_N_readout
        self.databox['type_of_measurement_s'  ] =self.recorded_type_of_measurement
        self.databox['best_gp_s'  ] = self.recorded_best_gp_s
        self.databox['best_gm_s'  ] = self.recorded_best_gm_s
        self.databox['std_gp_s'  ] = self.recorded_std_gp_s
        self.databox['std_gm_s'  ] = self.recorded_std_gm_s
        # Save on the CPU !
        self.databox.save_file(filters='')

    def _button_reset_clicked(self):
        """
        Stop and reset the iterations
        """
        _debug('GUIAdaptivePiPulseFinder: _button_reset_clicked')
        
        # Stop to run 
        if self.is_running:
            self.button_run.click()
        
        # Reinitiate the loop, which reset the iterators and everything
        self._initiate_loop()
        
        
    def _button_run_clicked(self, dir_save=-1):
        """
        Run the protocole
        
        dir_save:
            (String) If a string, it will pop-up a window for 
            asking where to save the file. Otherwise the file will be saved in 
            the path given. 
            
        """
        _debug('GUIAdaptT1: _button_run_clicked')
        
        # Run only if it is not already running
        if self.is_running == False:
            
            # If we are starting
            if self.iter == 0:            
                # Make the attribute to match with the settings
                self._initiate_loop()
                # Set the saving directory
                if not ( type(dir_save) == str ):
                    # Ask the user the repository for saving the files
                    txt = 'Select a directory for saving the data from each iteration'
                    self.path_folder_save = sm.dialogs.select_directory(txt)  
                else:
                    self.path_folder_save = dir_save
            # Update the run button
            self.is_running = True
            self.button_run.set_text('Pause')
            self.button_run.set_colors(background='blue')
            # Run the loop
            self._run_loop()

        else:
            # Stop to run if it is running (Pause)
            self.is_running = False
            self.button_run.set_text('Continue')
            self.button_run.set_style('background-color: rgb(0, 200, 0);')
            self.statut += '\n\nPaused !'
            self._label_info_update()


            
    def _run_loop(self):
        """
        Run the loop of the measurement
        """
        _debug('GUIAdaptT1: _run_loop')
        
        while self.get_condition_loop():

            # =============================================================================
            # Estimate the overhead time of the previous iteration
            # The estimate is based on the previous iteration
            # =============================================================================
            if self.iter == 0:
                # Assume no overhead time yet. 
                self.T_overhead = 0 
                 # Assum that N_readout is the aimed one (because this variable need to be initiated)
                 # But this can be any non-negative and non-zero number if T_overhead is zero.
                self.N_readout_gonna_happend = self.treeDic_settings['N_readout']
                # Start the timer for estimating the oerhead time of the next iteration
                self.t_begin_overhead = time.time()
                self.total_time_last_iter = 0
            else:
                # Estimate the ovehead time 
                # Total time elapsed since the beginning of the adaption
                self.total_time_last_iter = time.time() - self.t_begin_overhead
                # Start the timer for estimating the oerhead time of the next iteration
                self.t_begin_overhead = time.time()
                # Estimate time spent on measurement at t_probe
                self.mean_meas_time_per_iter = 2*self.N_readout_gonna_happend*(self.t_probed_1 + self.t_probed_2)
                # The overhead time is all the time elapsed that is not measuring
                self.T_overhead = self.total_time_last_iter  - self.mean_meas_time_per_iter
                # Verify if something unusual happen. 
                if self.T_overhead <0:
                    # This should not happen if our calculation is consistant with the experiment. 
                    print('WARNING in GUIAdaptT1: _run_all_steps. T_overhead was negative. Why ? It is now set to zero.')
                    self.T_overhead = 0
                
            # =============================================================================
            #             # Update the statut shown
            # =============================================================================
            self.statut = ('Running the loop %d/%d'%(self.iter, 
                                                     self.N_adaptation) +
                            '\nOverhead time: %f sec; Time of last iter: %f sec'%(self.T_overhead, self.total_time_last_iter) )

            # =============================================================================
            # Launch the iteration
            # =============================================================================    
            if self.treeDic_settings['Algo_type'] == 'Delta':                
                self._iter_for_Delta()   
            else:
                # If, for any funky reason, this setting is wrong. 
                print("Error in GUIAdaptT1: _run_loop. self.treeDic_settings['Algo_type'] is wrong. It is set to ", self.treeDic_settings['Algo_type'] )
            
        # Do special stuff if we finish the whole loop
        if not(self.condition2):
            # I comment, because I prefer to reset myself
#            # Reset the parameters for the next experiment
#            self._button_reset_clicked()
            self.statut = ('%d/%d Congratualition ! All the iterations are done. '%(self.iter, self.N_adaptation) )
            self._label_info_update()    
    
    def _iter_for_Delta(self):
        """
        Perform one iteration when using the Delta algorithm
        """
        _debug('GUIAdaptT1: _iter_for_Delta')        
 
        # =====================================================================
        # Determine the best setting. Including overhead effect
        # =====================================================================    
        t0 = time.time()
        self.t_probed_1, self.t_probed_2 = self.finder.get_best_setting(T_overhead=self.T_overhead, 
                                                                        N_rep     =self.N_readout_gonna_happend,
                                                                        want_rel_sens=self.want_rel_sens)
        self.t_find_settings = time.time() - t0
        self.process_events() # Important to refresh the GUI
        
        # =====================================================================
        # Repeat the step for each type of measurement
        # =====================================================================  
        list_type = [+1, -1]
        list_t_probe   = [self.t_probed_1, self.t_probed_2]
        for i in range(2):            
            if self.get_condition_loop():
                # Note the type and time for the measurement
                self.type_of_measurement = list_type[i]
                self.t_probe = list_t_probe[i]            
                # Run the steps
                self._run_all_steps()
         
    def _run_all_steps(self):
        """
        Consecutively run each step of one iteration.
        
        We also use this for estimating the overhead time 
        (ie, the time extra time that is not used for measuring)
        
        """   
        _debug('GUIAdaptT1: _run_all_steps') 
        
        # =============================================================================
        # Run the iteration for real.        
        # =============================================================================
                        
        # Step 1: Prepare the experiment
        self.step1_prep_experiment()
        self.process_events() # Important to refresh the GUI
        
        # Step 2: Take a measurement with that.
        self.step2_run_measurement()
        self.process_events() # Important to refresh the GUI
        
        # Step 3: Feed the measurement data to the bayes inferencer
        self.step3_process_measurement()
        self.process_events() # Important to refresh the GUI
        
        # Step 4: Recored relevant information
        self.step4_record_info()
        self.process_events() # Important to refresh the GUI   
        
        # Update the condition
        self.iter += 1
            
    def get_condition_loop(self):
        """
        Determine the condition for the loop. 
        Return True or False, for iff we must continue or not the loop. 
        """      
        _debug('GUIAdaptT1: get_condition_loop')
        
        self.condition1 = self.is_running
        self.condition2 = self.iter < self.N_adaptation
        
        # Return True if all these condition are true
        return  self.condition1 * self.condition2
        
    def step1_prep_experiment(self):
        """
        Prepare the experiment based on the type of measurement and on the 
        time to probe.
        
        """
        _debug('GUIAdaptT1: step1_prep_experiment')
                    
        # =====================================================================
        # Prepare the parameters of the pulse sequence
        # =====================================================================          
        # Set the parameters of the pulse sequence 
        if self.type_of_measurement == -1:
            # Adapt the parameters of the pulse sequence
            # The pipulse is the pi-pulse for ms=-
            p   = self.treeDic_settings['Pipulse-/power']
            f   = self.treeDic_settings['Pipulse-/frequency']
            dt  = self.treeDic_settings['Pipulse-/dt']
            DIO = self.treeDic_settings['Pipulse-/DIO_modulation']
        if self.type_of_measurement == +1:
            # Adapt the parameters of the pulse sequence
            # The pipulse is the pi-pulse for ms=-
            p   = self.treeDic_settings['Pipulse+/power']
            f   = self.treeDic_settings['Pipulse+/frequency']
            dt  = self.treeDic_settings['Pipulse+/dt']
            DIO = self.treeDic_settings['Pipulse+/DIO_modulation']     
        # Set the parameters of the pulse sequence
        self.gui_measurer.treeDic_settings['t_probe']     = self.t_probe*1e6 # In us
        self.gui_measurer.treeDic_settings['Frequency']   = f
        self.gui_measurer.treeDic_settings['Power']       = p
        self.gui_measurer.treeDic_settings['dt_pi_pulse'] = dt # in us
        self.gui_measurer.treeDic_settings['DIO_pulse_modulation'] = DIO
        
        # =====================================================================
        # Determine the number of fpga loop and get the real number of readout.
        # =====================================================================                     
        # Determine the number of readout for the next measurement. 
        self.N_readout_target = self.treeDic_settings['N_readout']
        # We roughly want the fpga_loop to last less than few second. This is in
        # order to avoid freeze out of the GUI
        self.estimate_time_per_readout = 2*self.t_probe + 20*1e-6 # (second) Roughly the time elapsed by readout
        self.N_readout_per_FPGA_loop = int(np.ceil( self.T_per_fpga_loop/(self.estimate_time_per_readout) ))  
        # Determine how many FPGA loop to perfom. 
        # We take the ceil, such that we have at least 1 loop. 
        self.N_FPGA_loop = int( np.ceil(self.N_readout_target/self.N_readout_per_FPGA_loop ) )
        # The true number of readout that should happen
        self.N_readout_gonna_happend = self.N_readout_per_FPGA_loop*self.N_FPGA_loop
        
        # Update the label
        self._label_info_update()
             
    def step2_run_measurement(self):
        """
        Perform a measurement at the time probed.
        
        """
        _debug('GUIAdaptT1: step2_run_measurement')

        # =====================================================================
        # Optimize at the beginning.
        # =====================================================================          
        self.dummy_please_optimize() # This needs to be overid with the real function to optimize

        # =====================================================================
        # Prepare the pulse sequence
        # =====================================================================   
        t0 = time.time()
        self.gui_measurer.button_prepare_experiment.click()        
        # Set the number of readout
        self.gui_measurer.gui_pulse_runner.NumberBox_repetition.set_value(self.N_readout_per_FPGA_loop) 
        # Set the number of FPGA loop to have. 
        self.gui_measurer.gui_pulse_runner.NumberBox_N_loopFPGA.set_value(self.N_FPGA_loop)
        # Convert the pulse sequence
        # The button reset is automatically clicked in the method for converting
        self.gui_measurer.gui_pulse_runner.button_convert_sequence.click()
        self.t_prep_measurement = time.time() - t0

        # =====================================================================
        # Run it !
        # =====================================================================                  
        # It should stop after that the number of FPGA loop is performed
        _debug('GUIAdaptT1: step2_run_measurement: Measurement started...')
        t0 = time.time()
        self.gui_measurer.gui_pulse_runner.button_start.click()
        self.t_pulse_sequence = time.time() - t0
        _debug('GUIAdaptT1: step2_run_measurement: Measurement done !')     
        
    def step3_process_measurement(self):
        """
        Extract the data from the measurement taken
        """
        _debug('GUIAdaptT1: step3_process_measurement')
        
        # Get the real number of readout that happened
        self.N_loop_perfomed = self.gui_measurer.gui_pulse_runner.iter
        self.N_readout_per_FPGA_loop_performed = self.gui_measurer.gui_pulse_runner.NumberBox_repetition.get_value()
        self.N_readout = self.N_loop_perfomed*self.N_readout_per_FPGA_loop_performed

        # =====================================================================
        # Compute the mean photocount and uncertainty
        # =====================================================================  
        t0 = time.time()
        # Mean count of ms=0 at t = 0
        PL0_0  = np.sum(self.gui_measurer.count_per_iter_PL1_t0_s     )/self.N_readout 
        # Mean count of ms=0 at t = t_probe
        PL0_t = np.sum(self.gui_measurer.count_per_iter_PL1_tprobed_s )/self.N_readout 
        # Mean count of ms=+-1 at t = 0
        PL1_0 = np.sum(self.gui_measurer.count_per_iter_PL2_t0_s      )/self.N_readout 
        # Mean count of ms=+-1 at t = t_probe
        PL1_t = np.sum(self.gui_measurer.count_per_iter_PL2_tprobed_s )/self.N_readout 
        # Uncertainty in each of these four measurement
        ePL0_0 = np.sqrt( PL0_0 / self.N_readout )
        ePL0_t = np.sqrt( PL0_t / self.N_readout )
        ePL1_0 = np.sqrt( PL1_0 / self.N_readout )
        ePL1_t = np.sqrt( PL1_t / self.N_readout )        
        
        # =====================================================================
        # Combine the results to obtain the famous drif-independent measurement
        # =====================================================================     
        self.result, self.uncertainty = uDiffRatio(PL0_t, ePL0_t, PL1_t, ePL1_t,
                                                   PL0_0, ePL0_0, PL1_0, ePL1_0 )
                
        # =====================================================================
        # Feed the Bayes optimizer with this measurement
        # =====================================================================  
        self.finder.give_measurement(self.result, self.uncertainty,
                                    self.t_probe, self.type_of_measurement)

        # =====================================================================
        # Extract the parameters
        # =====================================================================          
        means, stds, corr = self.finder.get_parameters()
        self.t_update_inference = time.time() - t0
        self.best_gp  = means[0]
        self.std_gp   = stds[0]
        self.best_gm  = means[1]
        self.std_gm   = stds[1]
        self.corr_gpgm = corr # Correlation (in unit of square the rate)
        # Update the inference
        try:
            self.plot_info.update_plot_Delta(self.finder)
        except:
            print('Error In GUIAdaptT1: Cannot update the plot!')
        
    def step4_record_info(self):
        """
        Record the infor in the object.
        """
        _debug('GUIAdaptT1: step4_record_info')

        # =====================================================================
        # SAVE THE DATA
        # =====================================================================  
        # Add some stuff in the data boxe
        self.gui_measurer.databoxplot.insert_header('Type_measure', self.type_of_measurement)
        self.gui_measurer.databoxplot.insert_header('Time_initial', self.t_initiale)
        self.gui_measurer.databoxplot.insert_header('Time_finish', time.time())
        self.gui_measurer.databoxplot.insert_header('Estimate_T_overhead', self.T_overhead)
        # Related to various elapsed time for the stats
        self.gui_measurer.databoxplot.insert_header('duration_find_settings', self.t_find_settings)
        self.gui_measurer.databoxplot.insert_header('duration_prep_settings', self.t_prep_measurement)
        self.gui_measurer.databoxplot.insert_header('duration_pulse_sequence', self.t_pulse_sequence)
        self.gui_measurer.databoxplot.insert_header('duration_update_inference', self.t_update_inference)
        
        # Also add nie info on the inference so far
        self.gui_measurer.databoxplot.insert_header('gamma_plus', self.best_gp)
        self.gui_measurer.databoxplot.insert_header('egamma_plus', self.std_gp)
        self.gui_measurer.databoxplot.insert_header('gamma_minus', self.best_gm)
        self.gui_measurer.databoxplot.insert_header('egamma_minus', self.std_gm) 
        self.gui_measurer.databoxplot.insert_header('correlation', self.corr_gpgm)
        # Also add all the stuff from the main three dictionary
        for key in self.treeDic_settings.get_keys():
            # Add each element of the dictionnary three
            value = self.treeDic_settings[key]
            self.gui_measurer.databoxplot.insert_header(key , value )        
        
        # Give a unique name to the file and save it. 
        path = self.path_folder_save + '/' + self.name_save + '_%d.dat'%self.iter
        self.gui_measurer.databoxplot.save_file(path)        

        # =====================================================================
        # Record some awesome stuff
        # =====================================================================          
        self.recorded_iteration_s.append(self.iter)
        self.recorded_t_probe_s  .append(self.t_probe)
        self.recorded_N_readout  .append(self.N_readout)
        self.recorded_best_gp_s  .append(self.best_gp)
        self.recorded_best_gm_s  .append(self.best_gm)    
        self.recorded_std_gp_s  .append(self.std_gp)
        self.recorded_std_gm_s  .append(self.std_gm)   
        self.recorded_type_of_measurement.append(self.type_of_measurement)
        
    def set_optimization(self, gui_optimizer):
        """
        Setup the connections for the refocusing. 
        
        gui_optimizer:
            GUI used for the task of refocusing the beam on the emitter. 
        """
        _debug('GUIAdaptT1: set_optimization')
        
        # Keep the optimizer in mind
        self.gui_optimizer = gui_optimizer
        # Connect the pulse runner
        self.gui_measurer.gui_pulse_runner.connect_opt_method(self.gui_optimizer)   
        # Connect the dummy function
        f_optimize = self.gui_optimizer.button_optimize.click
        self.dummy_please_optimize = f_optimize       
        
    
    def dummy_please_optimize(self):
        """
        Dummy method to be overid. 
        This is called each time that we want an optimization, in the method
        "step2_run_measurement". 
        For example, this dummy method should be overid by the optimization
        function of the confocal optimizer.
        """
        _debug('GUIAdaptT1:: dummy_please_optimize')

    
if __name__=="__main__":
    _debug_enabled = True
    import base_modules.gui_pulse_perso_decay
    base_modules.gui_pulse_perso_decay._debug_enabled = True
    # Get the fpga  
    import base_modules.api_fpga as _fc # For using the FPGA
    # Get the fpga paths and ressource number
    cpu_specific_infos = sm.data.load('base_modules\\cpu_specifics.dat')
    # cpu_specific_infos is defined in the import of the base modules
    bitfile_path = cpu_specific_infos.headers['FPGA_bitfile_path']
    resource_num = cpu_specific_infos.headers['FPGA_resource_number']
    # Get the fpga API
    fpga = _fc.FPGA_api(bitfile_path, resource_num) 
    fpga.open_session()

#    # Uncomment for a fake api of the fpga
#    fpga = _fc.FPGA_fake_api(bitfile_path, resource_num) # Create the api   
#    fpga.open_session()
#    print('\nFAKE FPGA API\n')
    
    
    # Also get the confocal
    import confocal
    confo = confocal.GUIMainConfocal(fpga)
    confo.show() # Hoh yess, we want to see it !

    # Import also the pulse sequence for being able to calibrate stuffs
    from pulse_sequences import GUIPulseSequences
    pulse = GUIPulseSequences(fpga)
    # Add it to the confocal for avoiding too many openned window
    tab_pulse = confo.tabs1.add_tab('Pulse Sequence')
    tab_pulse.place_object(pulse)  
        
    # Finnaly, show the usual adpater
    self = GUIAdaptT1(fpga, size=[1800,1000])
    self.show()
    
    # Connect the optimization !   
    # For this gui
    self.set_optimization(confo.gui_optimizer)
    # For other GUI
    f_optimize = confo.gui_optimizer.button_optimize.click
    pulse.set_optimization_function(f_optimize)
    
#     Bonus
#    from sweep_pulsedESR import GUISweepPulsedESR
#    sweepy = GUISweepPulsedESR(fpga)
#    sweepy.gui_pulsed_ESR.gui_pulse_runner.dummy_please_optimize = f_optimize
#    sweepy.show()
#    
#    
    
    
    
    
    
    
    
    
