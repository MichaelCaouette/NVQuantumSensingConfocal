# -*- coding: utf-8 -*-
"""
Created on Sat Dec 19 11:05:40 2020

Goal: Import the necessary path

@author: Childresslab
"""


#import sys
#sys.path.append(sys.path[0]+'\\software_modules')
##import gui_confocal_counts as gui_confocal_counts

# Import files that are relevant for the use of the package. 
import gui_confocal_main
import gui_adaptive_T1_main
import gui_pulse_runner

