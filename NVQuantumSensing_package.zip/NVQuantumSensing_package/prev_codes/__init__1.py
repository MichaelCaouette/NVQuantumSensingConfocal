# -*- coding: utf-8 -*-
"""
Created on Sat Dec 19 11:05:40 2020

Goal: define some useful init

@author: Childresslab
"""


import sys
# Append the software module location
path_splitted = sys.path[0].split('\\')
new_path = ''
for i in range(len(sys.path[0].split('\\'))-1):
    # This is adding the path without the current folder, so one step before. 
    new_path += path_splitted[i] + '\\'
# Finnally add the folder that we care
new_path += 'software_modules'
# Add this path
sys.path.append(new_path)


##import gui_confocal_main
#import sys
#sys.path.append(sys.path[0]+'\\Adaptive_protocole')
##import gui_confocal_counts as gui_confocal_counts
#
