# -*- coding: utf-8 -*-
"""
Created on Thu Aug 27 13:13:42 2020

Goal:
    Create a GUI for preparing the line sweep of the magnet. 

@author: Childresslab
"""

import function_mag_sweep_line_settings as ff

import numpy as np
import spinmob as sm
from spinmob import egg

import traceback
_p = traceback.print_last #Very usefull command to use for getting the last-not-printed error

# Debug stuff.
_debug_enabled                = False

def _debug(*a):
    if _debug_enabled: 
        s = []
        for x in a: s.append(str(x))
        print(', '.join(s))
        
        

class GUILinesSettings(egg.gui.Window):
    """
    Gui for generating the settings for a line sweep of the magnet. 
    """
    def __init__(self, name='Sweep line setter', show=True, size=[1300,600]):
        """
        Create the GUI 
            
        """
        _debug('GUILinesSettings: __init__')
        _debug('Be happy with what you have while working for what you want. – Helen Keller')
        # Run the basic stuff for the initialization
        egg.gui.Window.__init__(self, title=name, size=size)

        # A Button for generating the sweep settings
        self.button_generate = self.place_object(egg.gui.Button('Generate'), 
                                            0,0, alignment=1)
        self.connect(self.button_generate.signal_clicked, self.button_generate_clicked )  
        
        # A Button for saving the sweep settings
        self.button_save = self.place_object(egg.gui.Button('save'), 
                                            row=0, column=1, alignment=1)
        self.connect(self.button_save.signal_clicked, self.button_save_clicked )          
        
        #  Settings for layers of rectangle in the plane perp to z
        # We specify the shape of the rectangle on top and the shape of the 
        # rectabgle on bottom and the number of layers. 
        # The intermediate rectangle will be bounded by a linear continuation 
        # of the corner of top/bottm rectangle.
        pos_bound = 25 # (mm) maximum position of the actuator
        self.treeDic_settings = egg.gui.TreeDictionary(autosettings_path='setting_magsetting_rect_zfix')
        self.place_object(self.treeDic_settings, row=1, column=0, column_span=2)
        # The following is for specifying the top rectangle
        self.treeDic_settings.add_parameter('top_z', 20, 
                                            type='float',  
                                            bounds=[0,pos_bound], suffix=' mm',
                                            tip='Z position of the top rectangle ') 
        self.treeDic_settings.add_parameter('top_xmax', 10, 
                                            type='float',  
                                            bounds=[0,pos_bound], suffix=' mm',
                                            tip='X position of the top corner of the top rectangle') 
        self.treeDic_settings.add_parameter('top_ymax', 10, 
                                            type='float',  
                                            bounds=[0,pos_bound], suffix=' mm',
                                            tip='Y position of the top corner of the top rectangle') 
        self.treeDic_settings.add_parameter('top_xmin', 5, 
                                            type='float',  
                                            bounds=[0,pos_bound], suffix=' mm',
                                            tip='X position of the bottom corner of the top rectangle') 
        self.treeDic_settings.add_parameter('top_ymin', 5, 
                                            type='float',  
                                            bounds=[0,pos_bound], suffix=' mm',
                                            tip='Y position of the bottom corner of the top rectangle') 
        # The following is for specifying the bottom rectangle. 
        self.treeDic_settings.add_parameter('bot_z', 15, 
                                            type='float',  
                                            bounds=[0,pos_bound], suffix=' mm',
                                            tip='Z position of the bottom rectangle ') 
        self.treeDic_settings.add_parameter('bot_xmax', 7, 
                                            type='float',  
                                            bounds=[0,pos_bound], suffix=' mm',
                                            tip='X position of the top corner of the bottom rectangle') 
        self.treeDic_settings.add_parameter('bot_ymax', 7, 
                                            type='float',  
                                            bounds=[0,pos_bound], suffix=' mm',
                                            tip='Y position of the top corner of the bottom rectangle') 
        self.treeDic_settings.add_parameter('bot_xmin', 5, 
                                            type='float',  
                                            bounds=[0,pos_bound], suffix=' mm',
                                            tip='X position of the bottom corner of the bottom rectangle') 
        self.treeDic_settings.add_parameter('bot_ymin', 5, 
                                            type='float',  
                                            bounds=[0,pos_bound], suffix=' mm',
                                            tip='Y position of the bottom corner of the bottom rectangle')         
        # Other settings
        self.treeDic_settings.add_parameter('N_layer', 1, 
                                            type='int', 
                                            bounds=[1, None],
                                            tip='Number of layer to generate')
        self.treeDic_settings.add_parameter('N_zigzag', 6, 
                                            type='int', 
                                            bounds=[1, None],
                                            tip='Number of zigzag in a rectangle')
        self.treeDic_settings.add_parameter('Name', 'Fligh of Icarius', 
                                            type='str', 
                                            tip='Label for naming the settings when saved.')
        
        
    def button_generate_clicked(self):
        """
        Generate the settings
        """
        _debug('GUILinesSettings: button_generate_clicked')
        
        # Extract the settings into variables for convenience
        # For the geometry
        dz = self.treeDic_settings['top_z'] - self.treeDic_settings['bot_z']
        dx_max = self.treeDic_settings['top_xmax'] - self.treeDic_settings['bot_xmax']
        dy_max = self.treeDic_settings['top_ymax'] - self.treeDic_settings['bot_ymax']
        dx_min = self.treeDic_settings['top_xmin'] - self.treeDic_settings['bot_xmin']
        dy_min = self.treeDic_settings['top_ymin'] - self.treeDic_settings['bot_ymin']
        # Other parameters
        N_layer = self.treeDic_settings['N_layer']
        N_zigzag = self.treeDic_settings['N_zigzag']
        
        # Initiate the list of settings
        self.list_settings = []
        # Generate each setting
        for i in range(N_layer):
            # Compute the corresponding bound by linearly interpolate the bound
            alpha = i/(N_layer-1) # Goes from 0 to 1
            xmax = alpha*dx_max + self.treeDic_settings['bot_xmax']
            ymax = alpha*dy_max + self.treeDic_settings['bot_ymax']
            xmin = alpha*dx_min + self.treeDic_settings['bot_xmin']
            ymin = alpha*dy_min + self.treeDic_settings['bot_ymin']
            z    = alpha*dz     + self.treeDic_settings['bot_z']
           
            # Generate the layer
            layer = ff.rectangle_parallel_zfixed([xmin,ymin], [xmax,ymax], 
                                                 N_zigzag, z)
            # Keep it in note
            self.list_settings.append(layer)
        
        # Pop a window to view the settings
        GUIPlotSettings(self.list_settings)
        
    def button_save_clicked(self):
        """
        Save the list of settings
        """
        # Save a file for each set of settings. 
        name = self.treeDic_settings['Name']
        # Ask the user the location of the settings
        txt = 'Select a directory for saving the file'
        self.my_dir = sm.dialogs.select_directory(txt)
        
        # Save each settings separately
        for i, settings in enumerate(self.list_settings):
            # =================================================================
            # Prepare the databox
            # =================================================================
            self.databox_settings = sm.data.databox()
            
            # The three dictionary, why not.
            for key in self.treeDic_settings.get_keys():
                # Add each element of the dictionnary three
                self.databox_settings.insert_header(key , self.treeDic_settings[key])
            # Add the trajectories in the table
            N = len(self.list_settings)
            xs = []
            ys = []
            zs = []
            for jj in range (1, N):
                xs.append(float( settings[0][jj] ))
                ys.append(float( settings[1][jj] ))
                zs.append(float( settings[2][jj] ))
            self.databox_settings['xs'] = xs
            self.databox_settings['ys'] = ys
            self.databox_settings['zs'] = zs
            
            #Save it
            path = self.my_dir + '\\' + name + ' %.3d'%i + '.dat'
            self.databox_settings.save_file(path=path)


from matplotlib.backends.backend_qt4agg import FigureCanvasQTAgg as FigureCanvas
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D # This import registers the 3D projection, but is otherwise unused.

#class GUIPlotSettings(egg.gui.Window):
# TODO Have this a regular function instead of a class if it is simple as this.
class GUIPlotSettings():
    """
    A cosy GUI for showing the setting
    
    """
    def __init__(self, list_settings): 
        """
        list_settings:
            List of the setting to plot.
        """ 
        _debug('GUIPlotSettings: __init__')

#        #Run the basic stuff for the initialization
#        # This make in sort that we can use the gui as an egg window
#        egg.gui.Window.__init__(self,title='Banane')
#        #This prevent to have a second figure poping out outside of the gui
#        plt.ioff() # It doesn't seem to work each time lol
        
        self.list_settings = list_settings
        
        # Create a figure and canvas 
        # tight_layout make sure the labels are visible
        self.fig = plt.figure(tight_layout=True)
#        # this is the Canvas Widget that displays the `figure`. It takes the `figure` instance as a parameter to __init__
#        self.canvas = FigureCanvas(self.fig) 
#        self.canvas.draw()
#        # Add it to the GUI
#        self.place_object(self.canvas)      
        
        # Prepare the plot
        self.ax = self.fig.add_subplot(111, projection='3d') 
        
        for i, settings in enumerate( self.list_settings):
            ff.plot_magSweepLinesSettings(settings, ax=self.ax, 
                                          color='C%d'%i)
            
        return
        
        
        
        
#By default set the object
if __name__ == '__main__':
    _debug_enabled = True 
    
    self = GUILinesSettings()
    self.show()
    
    














