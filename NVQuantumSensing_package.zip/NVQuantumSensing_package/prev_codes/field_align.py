# -*- coding: utf-8 -*-
"""
Created on Fri Aug 21 10:41:45 2020

@author: Childresslab

"""


# Get the base modules
import __init__  as doesntmatter# Make 100% sure that the path is uploaded
from base_modules.gui_actuator import GUISingleActuator
import base_modules.api_fpga as _fc # For using the FPGA
from base_modules.gui_mag_sweep_line_settings import GUILinesSettings

# Other cool imports
import spinmob     as _s
from spinmob import egg
import time
import numpy as np
# For plotting
from mpl_toolkits.mplot3d import Axes3D # This import registers the 3D projection, but is otherwise unused.
import matplotlib.pyplot as plt

import traceback
# Very usefull command to use for getting the last-not-printed error
# Just type _p() in the console 
_p = traceback.print_last

#Debug
_debug_enabled           = False



def _debug(*a):
    if _debug_enabled: 
        s = []
        for x in a: s.append(str(x))
        print(', '.join(s))
                

def plot_magSweepLinesResult(dataResult, settings=-1, 
                             title='Patate Chaude', vmin=-1, vmax=-1):
    """
    Plot the result of a sweep
    
    #TODO EXPLAIN THE INPUT
    
    """
    _debug('plot_magSweepLinesResult')
    
    xs = dataResult['xs']
    ys = dataResult['ys']
    zs = dataResult['zs']   
    ws = dataResult['ws'] # The color of the point will be that
    dt = dataResult.h('time_per_point_ms') # Counting time (ms)

    # Initialize the figure and axis
    fig = plt.figure(tight_layout=True)
    ax  = fig.add_subplot(111, projection='3d') 

    # Add the points with the color proportional to the counts
    ws_mod = ws/dt # get the Kcounts per sec
    if (vmax<0) and (vmin>=0):
        _debug('plot_magSweepLinesResult: just set vmin')
        myplot = ax.scatter(xs, ys, zs, c=ws_mod,label='Scanned points', 
                            vmin=vmin) 
    elif (vmax>=0) and (vmin<0):
        _debug('plot_magSweepLinesResult: just set vmax')
        myplot = ax.scatter(xs, ys, zs, c=ws_mod,label='Scanned points', 
                            vmax=vmax) 
    elif (vmax>=0) and (vmin>=0):
        _debug('plot_magSweepLinesResult: set vmax AND vmin')
        myplot = ax.scatter(xs, ys, zs, c=ws_mod,label='Scanned points', 
                            vmin=vmin, vmax=vmax) 
    else:
        _debug('plot_magSweepLinesResult: not set vmin and vmax')
        myplot = ax.scatter(xs, ys, zs, c=ws_mod,label='Scanned points')         
        
    cbar = plt.colorbar(myplot)
    cbar.set_label("KiloCounts/sec")    
    
    if settings !=-1:
        # Show the settings if we input some
        xs_goal = settings['xs']
        ys_goal = settings['ys']
        zs_goal = settings['zs']
        ax.plot(xs_goal, ys_goal, zs_goal, label='Goal') 
#        ax.plot(xs_goal[1:-1], ys_goal[1:-1], zs_goal[1:-1], label='Goal') 
#        ax.scatter(xs_goal[0], ys_goal[0], zs_goal[0]   , color='red',label='Start')
#        ax.scatter(xs_goal[-1], ys_goal[-1], zs_goal[-1], color='y'  ,label='End')        
        
    plt.legend(loc='lower left')
    ax.set_xlabel('x (mm)')
    ax.set_ylabel('y (mm)')
    ax.set_zlabel('z (mm)')
    # Set equal aspect
    # For this we need the extermum of all the pts
    allpts = np.concatenate((xs, ys, zs))
    maximum = np.max(allpts)
    minimum = np.min(allpts)
    ax.set_xlim3d(minimum, maximum)
    ax.set_ylim3d(minimum, maximum)
    ax.set_zlim3d(minimum, maximum)
    # Slice the title if it's too long (for example, by including the whol path)
    if len(title)>20:
        t1 = title[:int(len(title)/2)]
        t2 = title[int(len(title)/2):]
        title = t1+'\n'+t2
        
    ax.set_title(title, fontsize=10)     
                
def plot_magSweepLinesSettings(databox, title='Patate Chaude'):
    """
    Plot the lines that we aim to sweep. 
    TODO:
        Explain the structure of the input !
    """
    
    xs = databox['xs']
    ys = databox['ys']
    zs = databox['zs']   

    # Initialize the figure and axis
    fig = plt.figure(tight_layout=True)
    ax  = fig.add_subplot(111, projection='3d') 

    ax.plot(xs, ys, zs, label='Goal') 
    ax.scatter(xs[1:-1], ys[1:-1], zs[1:-1]) 
    ax.scatter(xs[0], ys[0], zs[0]   , color='red',label='Start')
    ax.scatter(xs[-1], ys[-1], zs[-1], color='y'  ,label='End')
    plt.legend()
    ax.set_xlabel('x (mm)')
    ax.set_ylabel('y (mm)')
    ax.set_zlabel('z (mm)')
    # Set equal aspect
    # For this we need the extermum of all the pts
    allpts = np.concatenate((xs, ys, zs))
    maximum = np.max(allpts)
    minimum = np.min(allpts)
    ax.set_xlim3d(minimum, maximum)
    ax.set_ylim3d(minimum, maximum)
    ax.set_zlim3d(minimum, maximum)
    # Slice the title if it's too long (for example, by including the whol path)
    if len(title)>20:
        t1 = title[:int(len(title)/2)]
        t2 = title[int(len(title)/2):]
        title = t1+'\n'+t2
        
    ax.set_title(title, fontsize=10) 

class GUIMainMagnet(egg.gui.Window):
    """
    Class that combines:
        - 3 actuator GUIs, in order to control the position of the magnet. 
        - Line sweeper
        
        
    """
    
    def __init__(self, fpga, optimizer=-1,
                 name='Magnet', size=[1300,800]):
        """
        Create the GUI 
        
        fpga:
            "FPGA_api" object from api_fpga.py. 
            This is the object shared amoung the GUIs for controlling the fpga. 
            The session of the fpga must already be open.    
        optimizer:
            GUIOptimizer class object. It is for dealing with the optimization
            during the run of the pulse sequence. This object should be the 
            optimizer used in the higher level gui. Taking it as an input is
            just allowing us to use its functionnalities. 
            If it is set to -1, there will be just nothing happening when it 
            is time to optimize. 
            
        """
        _debug('GUIMainMagnet.__init__()', name)
        _debug('Success is going from failure to failure without losing your enthusiasm – Winston Churchill')

        # Get the inputs
        self.fpga = fpga           
        self.optimizer = optimizer

        # Run the basic stuff for the initialization
        egg.gui.Window.__init__(self, title=name, size=size)
        
        # Remember the name. It is important a name, you know. 
        self.name = name
        
        #Save path to save file (useful when this GUI is inside probe_station)
        self.path_save_file = ''
                
        
        #Create the instance for the three actuator
        self.X = GUISingleActuator(show=False)
        self.X.settings['VISA/Device'] = 'COM5'
        self.X.set_name('Super-X')
        self.Y = GUISingleActuator(show=False)
        self.Y.settings['VISA/Device'] = 'COM4'
        self.Y.set_name('Mega-Y')
        self.Z = GUISingleActuator(show=False)
        self.Z.settings['VISA/Device'] = 'COM3'
        self.Z.set_name('Ultra-Z')

        # Add three actuator GUI
        self.place_object(egg.gui.Label('X: '), 0,0) #Set the label at position (0,0)
        self.place_object(self.X.window)
        self.new_autorow()
        self.place_object(egg.gui.Label('Y: '), 0,1) #Set the label at position (0,1)
        self.place_object(self.Y.window)
        self.new_autorow()
        self.place_object(egg.gui.Label('Z: '), 0,2) #Set the label at position (0,2)
        self.place_object(self.Z.window)
        
        # Place the gui for sweeping lines
        self.gui_sweep_lines = GUISweepLines(self, self.fpga, self.optimizer)
        self.tabs1 = self.place_object(self.gui_sweep_lines, 
                                       row=0, column=1,
                                       column_span=5,  row_span=10,
                                       alignment=0)  
        
    def go_to_xyz(self, x, y, z, want_wait=False):
        """
        Cosy method for moving the 3 actuators in the direction of x,y,z.
        Go to x, y, z (in mm)
        
        want_wait:
            (boolean) Weither of not we want to wait before it finishes
        """
        _debug('GUIMainMagnet: go_to_xyz'  )
               
        # Set the target positions
        self.X.settings['Motion/Target_position'] = x
        self.Y.settings['Motion/Target_position'] = y
        self.Z.settings['Motion/Target_position'] = z       
        
        # Go for real
        self.X.button_move.click()
        self.Y.button_move.click()
        self.Z.button_move.click()

        if want_wait:
            #Wait that the actuators finished to move. 
            condition = True
            while condition:
                # Wait for not exploding the CPU
                time.sleep(0.1)
                 #Allow the GUI to update. This is important to avoid freezing of the GUI inside loop
                self.process_events()
                # Note the condition for keeping doing
                # As long as the three actuator move
                condition1 = self.X.api.get_state() == 'MOVING'
                condition2 = self.Y.api.get_state() == 'MOVING'
                condition3 = self.Z.api.get_state() == 'MOVING'
                condition = condition1 or condition2 or condition3
            

class GUISweepLines(egg.gui.Window):
    """
    Gui for making the actuator to sweep along various lines. 
    """
    def __init__(self, magnet3, fpga, optimizer=-1,
                 name='Magnet sweep lines', show=True,size=[1300,600]):
        """
        Create the GUI 
        
        magnet3:
            The gui object "GUIMainMagnet" that is used to control the three 
            actuators. 
        fpga:
            "FPGA_api" object from api_fpga.py. 
            This is the object shared amoung the GUIs for controlling the fpga. 
            The session of the fpga must already be open.    
        optimizer:
            GUIOptimizer class object. It is for dealing with the optimization
            during the run. This object should be the optimizer used in the 
            higher level gui. Taking it as an input is just allowing us to use 
            its functionnalities. 
            If it is set to -1, there will be just nothing happening when it 
            is time to optimize. 
            
        """
        _debug('GUISweepLines: __init__')
        _debug('The best way to predict your future is to create it. – Abraham Lincoln')
        
        # Take the inputs
        self.magnet   = magnet3 # Steal the magnet gui, mouahhaha
        self.fpga     = fpga
        self.optimizer = optimizer
        
        
        # Get each axis component for saving precious characters lol
        self.X = magnet3.X
        self.Y = magnet3.Y
        self.Z = magnet3.Z
        
        # Some useful attribute
        self.is_running = False # Tell is the sweep is running
        self.iter = 0 # At which iteration we are on
        self.nb_iter = 0 # How many iteration to perform (number of lines to scan)
        self.path_setting = 'Data: No File loaded ;)' # This is the string for the path of the data
        self.statut = 'Waiting for settings.' # This will inform where we are in the tasks
        self.data_w = 0 # This is the 4-dimensional data to take at each magnet posiiont. Example: the photo-counts at each position. 
        self.info_date = 'No scan' # String for the data at which the scan is done
        self.speed = 999 # This gonna be the speed along the line
        
        # Run the basic stuff for the initialization
        egg.gui.Window.__init__(self, title=name, size=size)

        # A Button for starting the line sweep
        self.button_run = self.place_object(egg.gui.Button('Start'), 
                                            0,0, alignment=1)
        self.button_run.disable() # Disable until we have imported or set the settings
        self.connect(self.button_run.signal_clicked, self.button_run_clicked )  
        
        # A Button for resetting the sweep
        self.button_reset = self.place_object(egg.gui.Button('Reeeset'), 
                                              0,1, alignment=1)
        self.connect(self.button_reset.signal_clicked, self.button_reset_clicked )
        
        #Add a button for loading the data
        self.button_load_settings = self.place_object(egg.gui.Button('Load settings'),
                                                  1,0, alignment=1)
        self.connect(self.button_load_settings.signal_clicked, self.button_load_settings_clicked )
        #Add a button for looking at the settings
        self.button_look_setting = self.place_object(egg.gui.Button('Look the settings'), 
                                                     1,1, alignment=1)
        self.connect(self.button_look_setting.signal_clicked, self.button_look_setting_clicked )
        #Add a button for comparing the scan and with the setting
        self.button_compare = self.place_object(egg.gui.Button('Compare scan and settings'), 
                                                     2,1, alignment=1)
        self.connect(self.button_compare.signal_clicked, self.button_compare_clicked )
        #Add a button for saving the scanned data
        self.button_save_sweep = self.place_object(egg.gui.Button('Save sweep :D'),
                                                  2,0, alignment=1)
        self.connect(self.button_save_sweep.signal_clicked, self.button_save_sweep_clicked )
        
        # tree dictionnarry for some settings
        self.treeDic_settings = egg.gui.TreeDictionary(autosettings_path='setting_magSweepLines')
        self.place_object(self.treeDic_settings, row=5, column=0, column_span=2)

        self.treeDic_settings.add_parameter('time_per_point_ms', 10, 
                                            type='float',  
                                            bounds=[0,None], suffix=' ms',
                                            tip='How much time to elapsed between recorded points. ') 
        self.treeDic_settings.add_parameter('resolution_um', 1, 
                                            type='float', 
                                            bounds=[0.0001, None], suffix=' um',
                                            tip='Distance between each point to record')
        self.treeDic_settings.add_parameter('nb_line_before_optimize', 1, 
                                            type='int', 
                                            bounds=[0, None],
                                            tip='Number of line to sweep before triggering the optimization.\nPut zero for never optimizing')
        # Add a table for the trajectories of the lines. 
        self.table_trajectories  = egg.gui.Table()
        self.place_object(self.table_trajectories, row=4, column=0, column_span=3) 
        # Fill it with some data
        xs = np.linspace(1,4, 7)
        ys = np.linspace(5,7, 7)
        zs = np.linspace(19, 23, 7)
        self.table_trajectories_fill(xs, ys, zs)

        #Add a button for removing a row
        self.button_remove_row = egg.gui.Button('Remove a row :/')
        self.place_object(self.button_remove_row,row=3, column=0, alignment=1)
        self.connect(self.button_remove_row.signal_clicked, self.button_remove_row_clicked )

        #Add a button for add a row
        self.button_add_row = egg.gui.Button('Add a row :3')
        self.place_object(self.button_add_row,row=3, column=1, alignment=1)
        self.connect(self.button_add_row.signal_clicked, self.button_add_row_clicked )
        
        #Add a button for saving the current settings
        self.button_save_settings = egg.gui.Button('Save current settings')
        self.place_object(self.button_save_settings,row=3, column=2, alignment=1)
        self.connect(self.button_save_settings.signal_clicked, self.button_save_settings_clicked )

        
        # Add the data plotter
        self.plotter_data = GUIPlotData()
        self.place_object(self.plotter_data, row=1, column=4, 
                              row_span=3,alignment=0)
        # Add a label
        self.label_info = self.place_object(egg.gui.Label(), row=4, column=4 )
        self.label_info_update() 
        
#        # Attempt to make the button together
#        self.set_row_stretch(6, 10)
#        self.set_column_stretch(2, 10)    

    def table_trajectories_fill(self, xs, ys, zs):
        """
        Fill up the table with the positions.
        
        xs, ys,zs:
            Same size list of x, y and z. 
        
        Return a string being:
            A succes message or 
            An error message corresponding to what happened. 
        """
        _debug('GUISweepLines: table_trajectories_fill')
        
        #Try to open the data
        try: 
            #First check if the lenghts matche
            if not (len(xs) == len(ys)):
                return 'Lenght of xs and ys do not match !'
            if not (len(ys) == len(zs)):
                return 'Lenght of ys and zs do not match !'  
            if not (len(zs) == len(xs)):
                return 'Lenght of xs and zs do not match !' 
            
            #If we pass here, we are ready to extract the position from the data 
            #First destroy the previous table
            while (self.table_trajectories.get_row_count() > 0):
                self.table_trajectories._widget.removeRow(0)

            # The first row will be a label for indicating what are each collumns
            self.table_trajectories.set_value(column=0, row=0, value='xs (um)')
            self.table_trajectories.set_value(column=1, row=0, value='ys (um)') 
            self.table_trajectories.set_value(column=2, row=0, value='zs (um)')                 
            #Then input the new one. 
            for i in range(0, len(xs) ):
                #Extract the x position 
                self.table_trajectories.set_value(column=0, row=i+1, value=xs[i])
                #Extract the y position 
                self.table_trajectories.set_value(column=1, row=i+1, value=ys[i])                
                #Extract the z position 
                self.table_trajectories.set_value(column=2, row=i+1, value=zs[i]) 
                
            return 'Successfully fill up the table'
            
        except: 
            return 'Error in reading the data from the file :S '        

    def databox_setting_update(self):
        """
        Update the contain of the databox_setting for it to matche the settings
        shown on the gui. 
        """
        _debug('GUISweepLines: databox_setting_update')
        
        # Reinitiead the databox of the settings
        self.databox_settings = _s.data.databox()
        
        # The three dictionary
        for key in self.treeDic_settings.get_keys():
            # Add each element of the dictionnary three
            self.databox_settings.insert_header(key , self.treeDic_settings[key])
        # Add the trajectories in the table
        N = self.table_trajectories.get_row_count()
        xs = []
        ys = []
        zs = []
        for i in range (1, N):
            x = self.table_trajectories.get_value(column=0, row=i)
            y = self.table_trajectories.get_value(column=1, row=i)
            z = self.table_trajectories.get_value(column=2, row=i)
            xs.append(float(x))
            ys.append(float(y))
            zs.append(float(z))
        self.databox_settings['xs'] = xs
        self.databox_settings['ys'] = ys
        self.databox_settings['zs'] = zs
        
    def label_info_update(self):
        """
        Adjust the info shown with respect to the settings
        """
        _debug('GUISweepLines.label_info_update')
        #Set the text. If sucess, the text is the name of the file. Otherwise it is an error message. 
        txt = ('Settings: '+ self.path_setting.split('/')[-1]+
               '\nStatut: '+ self.statut +
               '\nSpeed along line: %f mm/s'%self.speed+
               '\nNumber of lines: %d'%(self.nb_iter-1)+
               '\nCurrent line: %d'%self.iter)
        
        self.label_info.set_text( txt ) 

    def save_current_data(self):
        """
        Save the result of the sweep over a single set of lines.
        
        """
        _debug('GUISweepLines: save_current_data')
        
        # Prepare the databox to save
        self.databox_save_scan = _s.data.databox()
        # Put some header
        self.databox_save_scan.insert_header('name', 'Hakuna matata')
        self.databox_save_scan.insert_header('date', self.info_date)
        self.databox_save_scan.insert_header('setting_file', self.path_setting)
        
        # Copy the tree dictionnary
        for key in self.treeDic_settings.get_keys():
            # Add each element of the dictionnary three
            self.databox_save_scan.insert_header(key , self.treeDic_settings[key])        
        # Add each column for the scanned points
        self.databox_save_scan['xs'] = self.xs_scanned
        self.databox_save_scan['ys'] = self.ys_scanned
        self.databox_save_scan['zs'] = self.zs_scanned  
        self.databox_save_scan['ws'] = self.ws_scanned  
        
        # Pop up the window for saving the data
        self.databox_save_scan.save_file()        
        
    def button_add_row_clicked(self):
        """
        Add a row on the table
        """
        _debug('GUISweepLines.button_add_row_clicked')
        N = self.table_trajectories.get_row_count()
        self.table_trajectories.set_value(column=0, row=N, value=0)
        self.table_trajectories.set_value(column=1, row=N, value=0) 
        self.table_trajectories.set_value(column=2, row=N, value=0)      
        
    def button_remove_row_clicked(self):
        """
        Remove the last row on the table
        """
        _debug('GUISweepLines.button_remove_row_clicked')
        N = self.table_trajectories.get_row_count()
        if N>1:
            self.table_trajectories._widget.removeRow(N-1)    
               
    def button_load_settings_clicked(self, *a):
        """
        Load a list of x,y,z points for the magnetic field sweep
        """
        _debug('GUISweepLines: button_load_settings_clicked')
        
        #Load the list. 
        self.databox_settings = _s.data.load(text='Load the set of lines to sweep')
        self.path_setting = self.databox_settings.path
        
        #Updat the info shown
        self.statut = 'Settings are now loaded'
        self.label_info_update()
        # Fill up the table
        self.table_trajectories_fill(self.databox_settings['xs'],
                                     self.databox_settings['ys'],
                                     self.databox_settings['zs'])
        # Fill up the three dictionnary if the corresponding settings exists in the databox
        for key in self.treeDic_settings.get_keys():
            _debug('The key is ', key)
            # For each available settings
            try:
                # Set it if it is present in the databox
                self.treeDic_settings[key] = self.databox_settings.h(key)
            except:
                _debug('Didnt found the key', key, 'And its fine. We are just not updating this key.')
                pass
            
        # Enable the run button, since we now have data
        self.button_run.enable()
        self.button_run.set_colors(background='green')

    def button_save_settings_clicked(self, *a):
        """
        Save the settings of the line sweep
        """
        _debug('GUISweepLines._button_save_list_toggled()')
        
        # First need to update all the settings in the databox
        self.databox_setting_update()
        
        # Now save
        self.databox_settings.save_file()
        
    def button_look_setting_clicked(self):
        """
        Show the lines that the magnet should follow
        """
        _debug('GUISweepLines: button_look_setting_clicked')

        # First need to update all the settings in the databox
        self.databox_setting_update()
        
        # Pop up a GUI
        plot_magSweepLinesSettings(self.databox_settings, self.path_setting)
        
    def button_compare_clicked(self):
        """
        Compare the scanned data to the settings 
        """
        _debug('GUISweepLines: button_compare_clicked')
        
        # Load the scanned data
        d_scanned_data = _s.data.load(text='Load a scanned data set')
        # Load the setting
        d_settings     = _s.data.load(text='Load the setting fpor comparison')
        # Pop up a GUI
        plot_magSweepLinesResult(d_scanned_data, d_settings,
                                 title = d_scanned_data.path)


        

    def button_reset_clicked(self):
        """
        Reset the iteration and stop the running
        """
        _debug('GUISweepLines: button_reset_clicked')

        # Reset
        self.iter = 0
        
        # Stop to run 
        if self.is_running:
            self.button_run_clicked()

        self.statut = 'Sweep is resetted'
        self.label_info_update()   
        
        # Reupdate the button, because the if was not met the first time. 
        self.button_run.set_text('Start')
        self.button_run.set_colors(background='green')          
                    

    def button_run_clicked(self):
        """
        Button for controlling the experiement, 
        """
        _debug('GUISweepLines: button_run_clicked')
        
        if self.is_running == False:
            self.is_running = True
            self.button_run.set_text('Pause')
            self.button_run.set_colors(background='blue')
            
            # =================================================================
            # Initiate the batch
            # =================================================================
            # Ask the user the repository for saving the files
            txt = 'Select a directory for saving the data from each batch of line swept.'
            self.dir_save = _s.dialogs.select_directory(txt)
            # Initiate the iterator for the batch of line sweep
            self.current_batch = 1            
            
            # Loop over each batch
            while(self.is_running):
                # Allow the GUI to update. This is important to avoid freezing of the GUI inside loops
                self.process_events()      

                # Initiate the batch
                self.initiate_lines_sweep()
            
                # Launch it
                self.run_sweep()
            
        else:
            # Stop to run if it is running
            self.is_running = False
            self.button_run.set_text('Continue')
            self.button_run.set_colors(background='green')         
        
    
   
        

    def initiate_lines_sweep(self):
        """
        Initiate many thing prior to the sweep
        """
        _debug('GUISweepLines: initiate_lines_sweep')
        
        # The main idea is to prepare the fpga for counting the right interval of time. 
        #First get the count time
        self.count_time_ms = self.treeDic_settings['time_per_point_ms']
        # Put 120 tick off, because Labview also put 120 ticks off (=1us)
        self.fpga.prepare_counting_pulse(self.count_time_ms, nb_ticks_off=120)
        
        
        # Prepare the plot
        self.plotter_data.initiate_plot(Nline = self.nb_iter)
        


        # Update the settings of the databox
        self.databox_setting_update()
        
        # Extract the settings for easier access
        self.resolution = self.treeDic_settings['resolution_um']
        self.time_per_point = self.treeDic_settings['time_per_point_ms']
        self.nb_line_before_optimize = self.treeDic_settings['nb_line_before_optimize']
        # Determine the scalar speed of the magnet
        self.speed = self.resolution/self.time_per_point # It should be in mm/s. The settings are in um/ms = mm/sec. Cool 
        # Adjust the settings if that makes a speed to high
        if self.speed > 2:
            # Set the speed to its maximum value
            self.speed = 2 
            # Inccrease the count time accordingly
            self.time_per_point = self.resolution/self.speed
            self.treeDic_settings['time_per_point_ms'] = self.time_per_point
            print('Warning. Speed was too high. Auto set the time for maximum allowed speed.')

        # Get the path 
        self.xs_setting = self.databox_settings['xs']
        self.ys_setting = self.databox_settings['ys']
        self.zs_setting = self.databox_settings['zs']
        self.nb_iter = len(self.xs_setting)
        
        # Signal the initialization
        self.initiate_line_sweep()
        # Go on the initial position 
        self.statut = 'Reaching the initial position'
        self.label_info_update()   
        # Have a descent speed
        self.X.settings['Motion/Speed'] = 1 # mm/sec
        self.Y.settings['Motion/Speed'] = 1 # mm/sec
        self.Z.settings['Motion/Speed'] = 1 # mm/sec
        # Then reach the position
        self.magnet.go_to_xyz(self.xs_setting[0],
                              self.ys_setting[0],
                              self.zs_setting[0],
                              want_wait=True ) # Wait that we reach the position before continuing
        # This will store the positions that the actuatores reach at each checkpoint
        self.xs_scanned = []
        self.ys_scanned = []
        self.zs_scanned = []
        # This will store the 4-Dimensional data, for example the photo-counts
        self.ws_scanned = []
        # Increase ther iteration for not scanning the first poitn to the first point !
        self.iter = 1

          
    def run_sweep(self):
        """
        Run the sweep along the lines. 
        First go on the initial position
        """
        _debug('GUISweepLines: run_sweep')
        
        condition=True
        while condition:
            _debug('GUISweepLines: run_sweep: iter', self.iter)
            # Allow the GUI to update. This is important to avoid freezing of the GUI inside loops
            self.process_events()    
            # Update the info shown
            self.statut = 'Sweeping along line %d'%self.iter
            self.label_info_update()
            # Move along the line
            x = self.xs_setting[self.iter]
            y = self.ys_setting[self.iter]
            z = self.zs_setting[self.iter]
            xyzw = self.scan_single_line(x,y,z, 
                                        speed=self.speed)
            
            # Update the plot
            self.plotter_data.add_line(xyzw[0],
                                       xyzw[1],
                                       xyzw[2],
                                       xyzw[3])
            
            # Append the data
            self.xs_scanned.extend(xyzw[0])
            self.ys_scanned.extend(xyzw[1])
            self.zs_scanned.extend(xyzw[2])
            self.ws_scanned.extend(xyzw[3])
            
            # Update the info shown
            self.statut = 'The line %d is completed'%self.iter
            self.label_info_update()

            # Optimize if it is appropriate
            if (self.nb_line_before_optimize>0) and not(self.optimizer==-1):
                if self.iter%self.nb_line_before_optimize == self.nb_line_before_optimize-1:
                    _debug('GUISweepLines: run_sweep: event_optimize sent!')
                    # Update the info
                    self.statut = 'Optimizing after the line %d'%self.iter
                    self.label_info_update()
                    # Optimize !
                    self.optimizer.button_optimize.click()
                    # The fpga settings change during optimization. 
                    #We need to put them back.
                    self.initiate_line_sweep()
            
            # Update the condition of the scan
            self.iter += 1
            condition = self.is_running and self.iter<self.nb_iter
            
        # Update the data
        self.info_date = time.ctime(time.time())
        _debug('GUISweepLines: run_sweep: done')
        # If the scan is finished
        if self.iter>=self.nb_iter:
            # Reset everything 
            self.button_reset_clicked()
        
    def scan_single_line(self, xend=0, yend=0, zend=0, speed=1):
        """
        Move in a straight line from the current position to the target position. 
        Has it scans along the line, it is calling a dummy function to be overrid 
        for making some task. 
        
        xend:
            (in mm) Target x position
        yend:
            (in mm) Target y position
        zend:
            (in mm) Target z position    
        speed:
            (in mm/sec) Speed of the displacement along the line
            
        The function returns:
            xzyw:
                A tuple (xs, ys, zs, ws), where xs, ys and zs are array for the 
                positions of the actuator at each checkpoint. ws is the array 
                of the 4-dimension data taken (for example, the counts)
        """
        _debug('GUISweepLines: scan_xyz_line')
        
        # Set the target positions
        self.X.settings['Motion/Target_position'] = xend
        self.Y.settings['Motion/Target_position'] = yend
        self.Z.settings['Motion/Target_position'] = zend
        
        # Find the speed of each actuator for them to reach the end at the same 
        # time and move in a straight line. 
        # We need to know the distance that they will have to travel 
        self.xin = self.X.api.get_position()
        self.yin = self.Y.api.get_position()
        self.zin = self.Z.api.get_position()
        self.dx = np.abs(self.xin - xend)
        self.dy = np.abs(self.yin - yend)
        self.dz = np.abs(self.zin - zend)
        ds = np.sqrt(self.dx**2 + self.dy**2 + self.dz**2) # Total distance to travel
        # Now project this speed along each axis
        self.vx = speed*self.dx/ds
        self.vy = speed*self.dy/ds
        self.vz = speed*self.dz/ds
        self.X.settings['Motion/Speed'] = self.vx
        self.Y.settings['Motion/Speed'] = self.vy
        self.Z.settings['Motion/Speed'] = self.vz
        
        # These will store the position of the magnet at each checkpoint
        xs = []
        ys = []
        zs = []
        # This will store the 4-dimension data at each x,y,z. For example, the photo-counts
        ws = [] 
 
         #Allow the GUI to update. This is important to avoid freezing of the GUI inside loop
        self.process_events()        
        
        # Go for real
        self.X.button_move.click()
        self.Y.button_move.click()
        self.Z.button_move.click()
        
        # Note the condition for keeping doing
        # As long as the three actuator move
        condition1 = self.X.api.get_state() == 'MOVING'
        condition2 = self.Y.api.get_state() == 'MOVING'
        condition3 = self.Z.api.get_state() == 'MOVING'
        condition = condition1 or condition2 or condition3
        while condition:

            # Let's take the positions
            xs.append( self.X.api.get_position() )
            ys.append( self.Y.api.get_position() )
            zs.append( self.Z.api.get_position() )
            _debug('GUISweepLines: scan_xyz_line: Done')
            _debug('GUISweepLines: scan_xyz_line: %f %f %f'%(xs[-1], ys[-1], zs[-1]))
             #Allow the GUI to update. This is important to avoid freezing of the GUI inside loop
            self.process_events()
            
            # Take the counts from the fpga
            # This function is in charge to give the time delay for not blowing the CPU with an almost infinite loop
            self.take_counts() # It updates self.data_w
            ws.append(self.data_w)
            
            # Note the condition for keeping doing
            # As long as the three actuator move
            condition1 = self.X.api.get_state() == 'MOVING'
            condition2 = self.Y.api.get_state() == 'MOVING'
            condition3 = self.Z.api.get_state() == 'MOVING'
            condition = condition1 or condition2 or condition3
        
        _debug('GUISweepLines: scan_xyz_line: Done')
        
        return (xs, ys, zs, ws)

    def take_counts(self):
        """
        Take the photocounts and update the value. 
        """
        _debug('GUISweepLines: take_counts')
        # The fpga should already contain the pulse sequence for taking the counts
        
        # Get the counts (d'uh !)
        # Two step: runt he pulse pattern and get the counts. 
        self.fpga.run_pulse() 
        self.counts =  self.fpga.get_counts()[0]
        self.data_w = self.counts    

    #TODO: Remove the following lines if they are not used
#    def one_line_is_swept(self):
#        """
#        Trigger the optimization. 
#        """
#        _debug('GUISweepLines: scan_line_optimize')
#        
#        # Optimizae only if the sweep is still running. 
#        #TODO Remove the first if, because if this is called, it is necessarly 
#        #     because the magnet scan was running ! Check the example of 
#        #     the optimizer ?
#        if self.is_running:
#            iteration = self.gui_magnet.gui_sweep_lines.iter
#            m = self.gui_magnet.gui_sweep_lines.treeDic_settings['nb_line_before_optimize']
#            if m != 0:
#                # If it's zero, we never optimize
#                if iteration % m == (m-1):
#                    _debug('GUIMainExperiment: magnet_scan_line_optimize:decide to optimize')
#                    
#                    # Note that it was the magnet line scan that was running
#                    self.magnet_scan_line_was_running_before_optimizing = True
#                    # Optimize
#                    self.gui_confocal.gui_optimizer.button_optimize_clicked()       



from matplotlib.backends.backend_qt4agg import FigureCanvasQTAgg as FigureCanvas
class GUIPlotData(egg.gui.Window):
    """
    A cosy GUI for showing the incoming data. 
    
    """
    def __init__(self): 
        """
        Initialize D'uh !
        """ 
        _debug('GUIPlotData: __init__')
        
        #Run the basic stuff for the initialization
        # This make in sort that we can use the gui as an egg window
        egg.gui.Window.__init__(self,title='Banane')
        
        #This prevent to have a second figure poping out outside of the gui
        plt.ioff() # It doesn't seem to work each time lol
        
        #Create a figure and canvas
        self.fig = plt.figure(tight_layout=True) #tight_layout make sure the labels are visible
        self.canvas = FigureCanvas(self.fig) # this is the Canvas Widget that displays the `figure`. It takes the `figure` instance as a parameter to __init__
        self.canvas.draw()
        #Add it to the GUI
        self.place_object(self.canvas)      
        
        #Prepare the plot
        self.ax = self.fig.add_subplot(111) 
        self.initiate_plot()
    
    def initiate_plot(self, Nline=10):
        """
        Reinitiate the plot
        
        Nline:
            Total number of lines swepts. 
        """
        # Reset some parameters
        self.nb_line = 0 # Current line
        self.nb_total_line = Nline # Total number of line
        
        # Reset the plot
        self.ax.cla()  
        self.ax.set_xlabel('# of Line swept')
        self.ax.set_ylabel('Distance on the line ')
        self.ax.set_xlim(0, Nline+1)
        
    def add_line(self, xs, ys, zs, ws):
        """
        Add a scanned line in the plot. 
        
        
        xs, ys zs:
            List of x,y,z position to plot
        ws:
            List of counts at the same position
        """
        _debug('GUIPlotData: add_line')
        
        # Some parameter the user could control
        alpha_level = 0.3
        size_pts = 10
        
        # Update the number of lines
        self.nb_line += 1
        
        # The first line deserve special care
        if self.nb_line == 1:
            # Initiate the extrem values 
            self.vmin = np.min(ws)
            self.vmax = np.max(ws)
        else:
            wmin = np.min(ws)
            if wmin < self.vmin:
                self.vmin = wmin
            wmax = np.max(ws)
            if wmax > self.vmax:
                self.vmax = wmax
        
        
        # Get the data into numpy array
        xs = np.array(xs)
        ys = np.array(ys)
        zs = np.array(zs)
        # Get the relative distance made
        dx = xs - xs[0]
        dy = ys - ys[0]
        dz = zs - zs[0]
        self.distance = np.sqrt(dx*dx + dy*dy + dz*dz)
        # Revert the relative distance at each two line. 
        # This is if we assum a zigzag sweep and can be an option
        if self.nb_line % 2 == 0:
            self.distance = self.distance[-1] - self.distance
        
        # Get the correspond position on the x axis
        x_axis = self.nb_line + 0*self.distance 
        
        # Add the line in the plot
        myplot = self.ax.scatter(x_axis, self.distance, c=np.array(ws)*1e-3, 
                                 vmin=self.vmin, vmax=self.vmax, 
                                 alpha=alpha_level)
        # Update the colorbar
        if self.nb_line == 1:
            # Add it if it is the first plot
            self.cbar = plt.colorbar(myplot)
            self.cbar.set_label("KiloCounts") 
        else:
            # Just Re-adjust the limit
            self.cbar.set_clim(self.vmin, self.vmax)

        #The following update the plot. 
        self.fig.canvas.draw_idle()           

        


#By default set the object
if __name__ == '__main__':
    _debug_enabled = True
    import api_actuator
    api_actuator._debug_enabled
    
    # Get the fpga paths and ressource number
    cpu_specific_infos = _s.data.load('base_modules\\cpu_specifics.dat')
    # cpu_specific_infos is defined in the import of the base modules
    bitfile_path = cpu_specific_infos.headers['FPGA_bitfile_path']
    resource_num = cpu_specific_infos.headers['FPGA_resource_number']
    # Get the fpga API
    fpga = _fc.FPGA_api(bitfile_path, resource_num) 
    fpga.open_session()
    
    # Also get the confocal
    import confocal
    confo = confocal.GUIMainConfocal(fpga)
    confo.show() # Hoh yess, we want to see it !

    self = GUIMainMagnet(fpga, 
                     optimizer = confo.gui_optimizer, 
                     name='Magnetooooo') 
    self.show()


    