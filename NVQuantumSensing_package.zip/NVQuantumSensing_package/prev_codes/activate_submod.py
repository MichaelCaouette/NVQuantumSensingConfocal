# -*- coding: utf-8 -*-
"""
Created on Sat Dec 19 11:05:40 2020

Goal: Import the path of the important modules AND load the 

@author: Childresslab
"""

# =============================================================================
# Import the module
# =============================================================================

# Get the current path
import os 
dir_path = os.path.dirname(os.path.realpath(__file__))

import sys
# Append the software module location
path_splitted = dir_path .split('\\')
new_path = ''
for i in range(len(path_splitted)-1):
    # This is adding the path without the current folder, so one step before. 
    new_path += path_splitted[i] + '\\'
# Finnally add the folder that we care
new_path += 'base_modules'
# Add this path
sys.path.append(new_path)



# =============================================================================
# 
# =============================================================================
# Get the fpga paths and ressource number that are located in the submodule
import spinmob as sm
cpu_specific_infos = sm.data.load(new_path + '\\cpu_specifics.dat')