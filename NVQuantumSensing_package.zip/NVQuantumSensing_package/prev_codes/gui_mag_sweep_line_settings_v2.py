# -*- coding: utf-8 -*-
"""
Created on Thu Aug 27 13:13:42 2020

Goal:
    Create a GUI for preparing the line sweep of the magnet. 

@author: Childresslab
"""

import function_mag_sweep_line_settings as ff

import numpy as np
import spinmob as sm
from spinmob import egg

import traceback
_p = traceback.print_last #Very usefull command to use for getting the last-not-printed error

# Debug stuff.
_debug_enabled                = False

def _debug(*a):
    if _debug_enabled: 
        s = []
        for x in a: s.append(str(x))
        print(', '.join(s))
        
        

class GUILinesSettings(egg.gui.Window):
    """
    Gui for generating and tweaking the settings for a line sweep of the magnet. 
    """
    def __init__(self, name='Sweep line setter', show=True, size=[1300,600]):
        """
        Create the GUI 
            
        """
        _debug('GUILinesSettings: __init__')
        _debug('Be happy with what you have while working for what you want. – Helen Keller')
        # Run the basic stuff for the initialization
        egg.gui.Window.__init__(self, title=name, size=size)

        # A Button for generating the sweep settings
        self.button_generate = self.place_object(egg.gui.Button('Generate'), 
                                            row=0, column=0, alignment=1)
        self.connect(self.button_generate.signal_clicked, self.button_generate_clicked )  

        # A Button for plotting the set of settings
        self.button_plot = self.place_object(egg.gui.Button('Plot in 3D'), 
                                            row=0, column=1, alignment=1)
        self.connect(self.button_plot.signal_clicked, self.button_plot_clicked ) 
        
        # A Button for saving the sweep settings
        self.button_save = self.place_object(egg.gui.Button('Save all that ;)'), 
                                            row=0, column=2, alignment=1)
        self.connect(self.button_save.signal_clicked, self.button_save_clicked )      
        
        
        #  Settings for layers of rectangle in the plane perp to z
        # We specify the shape of the rectangle on top and the shape of the 
        # rectabgle on bottom and the number of layers. 
        # The intermediate rectangle will be bounded by a linear continuation 
        # of the corner of top/bottm rectangle.
        self.treeDic_settings = egg.gui.TreeDictionary(autosettings_path='setting_magsetting_rect_zfix')
        self.place_object(self.treeDic_settings, 
                          row=1, column=0, column_span=3, row_span=3)
        # Built it
        self.build_treeDict()
        
        
        # =============================================================================
        # The following are related to the table
        # =============================================================================

        # Add a button for adding a row
        self.button_add_row = egg.gui.Button('Add a row :3')
        self.place_object(self.button_add_row, row=1, column=2, alignment=1)
        self.connect(self.button_add_row.signal_clicked, self.button_add_row_clicked )

        # Add a button for removing a row
        self.button_remove_row = egg.gui.Button('Remove a row :/')
        self.place_object(self.button_remove_row, row=1, column=3, alignment=1)
        self.connect(self.button_remove_row.signal_clicked, self.button_remove_row_clicked )
        
        # Add a numberbox for selecting which batch
        self.numberBox_batch = egg.gui.NumberBox(value=0, step=1, 
                                                      bounds=(0, None), int=True)
        self.place_object(self.numberBox_batch, row=1, column=4, alignment=1)
        self.connect(self.numberBox_batch.signal_changed, self.numberBox_batch_changed)        
        
        # Add a table for the trajectories of the lines. 
        self.row_table      = 2
        self.column_table   = 2
        self.col_span_table = 3
        # Put an almost empty table for the beginning
        self.table_shown  = egg.gui.Table()
        self.place_object(self.table_shown, 
                          row=self.row_table, 
                          column=self.column_table, 
                          column_span=self.col_span_table) 
        

    def build_treeDict(self):
        """
        A methof to build the treeDictionnary for the rectangles.
        """
        _debug('GUILinesSettings: build_treeDict')
        
        pos_bound = 25 # (mm) maximum position of the actuator
        # The following is for specifying the top rectangle
        self.treeDic_settings.add_parameter('top_z', 20, 
                                            type='float',  
                                            bounds=[0,pos_bound], suffix=' mm',
                                            tip='Z position of the top rectangle ') 
        self.treeDic_settings.add_parameter('top_xmax', 10, 
                                            type='float',  
                                            bounds=[0,pos_bound], suffix=' mm',
                                            tip='X position of the top corner of the top rectangle') 
        self.treeDic_settings.add_parameter('top_ymax', 10, 
                                            type='float',  
                                            bounds=[0,pos_bound], suffix=' mm',
                                            tip='Y position of the top corner of the top rectangle') 
        self.treeDic_settings.add_parameter('top_xmin', 5, 
                                            type='float',  
                                            bounds=[0,pos_bound], suffix=' mm',
                                            tip='X position of the bottom corner of the top rectangle') 
        self.treeDic_settings.add_parameter('top_ymin', 5, 
                                            type='float',  
                                            bounds=[0,pos_bound], suffix=' mm',
                                            tip='Y position of the bottom corner of the top rectangle') 
        # The following is for specifying the bottom rectangle. 
        self.treeDic_settings.add_parameter('bot_z', 15, 
                                            type='float',  
                                            bounds=[0,pos_bound], suffix=' mm',
                                            tip='Z position of the bottom rectangle ') 
        self.treeDic_settings.add_parameter('bot_xmax', 7, 
                                            type='float',  
                                            bounds=[0,pos_bound], suffix=' mm',
                                            tip='X position of the top corner of the bottom rectangle') 
        self.treeDic_settings.add_parameter('bot_ymax', 7, 
                                            type='float',  
                                            bounds=[0,pos_bound], suffix=' mm',
                                            tip='Y position of the top corner of the bottom rectangle') 
        self.treeDic_settings.add_parameter('bot_xmin', 5, 
                                            type='float',  
                                            bounds=[0,pos_bound], suffix=' mm',
                                            tip='X position of the bottom corner of the bottom rectangle') 
        self.treeDic_settings.add_parameter('bot_ymin', 5, 
                                            type='float',  
                                            bounds=[0,pos_bound], suffix=' mm',
                                            tip='Y position of the bottom corner of the bottom rectangle')         
        # Other settings
        self.treeDic_settings.add_parameter('N_layer', 1, 
                                            type='int', 
                                            bounds=[1, None],
                                            tip='Number of layer to generate')
        self.treeDic_settings.add_parameter('N_zigzag', 6, 
                                            type='int', 
                                            bounds=[1, None],
                                            tip='Number of zigzag in a rectangle')
        self.treeDic_settings.add_parameter('Name', 'Fligh of Icarius', 
                                            type='str', 
                                            tip='Label for naming the settings when saved.')
        
    def button_generate_clicked(self):
        """
        Generate the settings
        """
        _debug('GUILinesSettings: button_generate_clicked')
        
        # Extract the settings into variables for convenience
        # For the geometry
        dz = self.treeDic_settings['top_z'] - self.treeDic_settings['bot_z']
        dx_max = self.treeDic_settings['top_xmax'] - self.treeDic_settings['bot_xmax']
        dy_max = self.treeDic_settings['top_ymax'] - self.treeDic_settings['bot_ymax']
        dx_min = self.treeDic_settings['top_xmin'] - self.treeDic_settings['bot_xmin']
        dy_min = self.treeDic_settings['top_ymin'] - self.treeDic_settings['bot_ymin']
        # Other parameters
        N_layer = self.treeDic_settings['N_layer']
        N_zigzag = self.treeDic_settings['N_zigzag']
        
        # Initiate the list of settings
        self.list_settings = []
        # Generate each setting
        for i in range(N_layer):
            # Compute the corresponding bound by linearly interpolate the bound
            alpha = i/(N_layer-1) # Goes from 0 to 1
            xmax = alpha*dx_max + self.treeDic_settings['bot_xmax']
            ymax = alpha*dy_max + self.treeDic_settings['bot_ymax']
            xmin = alpha*dx_min + self.treeDic_settings['bot_xmin']
            ymin = alpha*dy_min + self.treeDic_settings['bot_ymin']
            z    = alpha*dz     + self.treeDic_settings['bot_z']
           
            # Generate the layer
            layer = ff.rectangle_parallel_zfixed([xmin,ymin], [xmax,ymax], 
                                                 N_zigzag, z)
            # Keep it in note
            self.list_settings.append(layer)
        
        # Send this list in the list of tables and fill them up. 
        self.set_all_tables(self.list_settings)
        
        # Show the first table
        # It shouyld trigger a signal that update the table shown.
        self.numberBox_batch_changed()
        
    def button_plot_clicked(self):
        """
        Plot all the settings
        """
        _debug('GUILinesSettings: button_plot_clicked')
        
        # Update the settings
        self.update_list_settings()
        
        # Pop a window to view the settings
        GUIPlotSettings(self.list_settings)
        
    def button_save_clicked(self):
        """
        Save the list of settings
        """
        _debug('GUILinesSettings: button_save_clicked')
        
        # Save a file for each set of settings. 
        name = self.treeDic_settings['Name']
        # Ask the user the location of the settings
        txt = 'Select a directory for saving the file'
        self.my_dir = sm.dialogs.select_directory(txt)
        
        # Update the settings with the tables
        self.update_list_settings()
        
        # Save each settings separately
        for i, settings in enumerate(self.list_settings):
            # =================================================================
            # Prepare the databox
            # =================================================================
            self.databox_settings = sm.data.databox()
            
            # The three dictionary, why not.
            for key in self.treeDic_settings.get_keys():
                # Add each element of the dictionnary three
                self.databox_settings.insert_header(key , self.treeDic_settings[key])
                
            # Add the trajectories in the table
            N = len(self.list_settings)
            xs = []
            ys = []
            zs = []
            for jj in range (1, N):
                xs.append(float( settings[0][jj] ))
                ys.append(float( settings[1][jj] ))
                zs.append(float( settings[2][jj] ))
            self.databox_settings['xs'] = xs
            self.databox_settings['ys'] = ys
            self.databox_settings['zs'] = zs
            
            #Save it
            path = self.my_dir + '\\' + name + ' %.3d'%i + '.dat'
            self.databox_settings.save_file(path=path)

    def button_add_row_clicked(self):
        """
        Add a row on the  table shown
        """
        _debug('GUILinesSettings: button_add_row_clicked')
        
        # Extract the table shown
        table = np.copy( self.list_table[self.batch_shown] )
        
        # Modify it
        N = table.get_row_count()
        table.set_value(column=0, row=N, value=0)
        table.set_value(column=1, row=N, value=0) 
        table.set_value(column=2, row=N, value=0)      
        
        # Put it back in the list
        self.list_table[self.batch_shown] = table
        
        # Update the table shown
        self.numberBox_batch_changed()
        
        
    def button_remove_row_clicked(self):
        """
        Remove the last row on the table shown
        """
        _debug('GUILinesSettings: button_remove_row_clicked')

        # Extract the table shown
        table = np.copy( self.list_table[self.batch_shown] )
        
        # Modify it
        # Remove the row only if there is more than one row !
        N = table.get_row_count()
        if N>1:
            table._widget.removeRow(N-1)    

        # Put it back in the list
        self.list_table[self.batch_shown] = table
        
    def numberBox_batch_changed(self):
        """
        What to do when the index for the number box changed.
        """
        _debug('GUILinesSettings: numberBox_batch_changed')
        
        # Get the value
        value = self.numberBox_batch.get_value()
        
        # Make sure that we do not over shoot.
        if value >= len(self.list_table):
            # Do not allow to overshoot the number of list element
            self.numberBox_batch.set_value(value-1)
            return
        
        # If we get here, it is safe to continue with the value
        
        # Update the value
        self.batch_shown = value
        _debug('GUILinesSettings: numberBox_batch_changed: value = ', value)
        
        # Set the table shown
#        self.table_shown = self.list_table[self.batch_shown]

        self.place_object(self.list_table[self.batch_shown], 
                          row=self.row_table, 
                          column=self.column_table, 
                          column_span=self.col_span_table)        
#        self.table_shown.show()
        

    def update_list_settings(self):
        """
        Update the list of settings such that it matches the table shown
        """
        _debug('GUILinesSettings: update_list_settings')
        
        # Re initiate the list of settings
        self.list_settings = []
        
        # Add the content of each table
        for i in range( len(self.list_table) ):
            # Get the table
            table = self.list_table[i]
            
            # Scan each row
            # Add the trajectories in the table
            N = table.get_row_count()
            xs = []
            ys = []
            zs = []
            for i in range (1, N):
                x = table.get_value(column=0, row=i)
                y = table.get_value(column=1, row=i)
                z = table.get_value(column=2, row=i)
                xs.append(float(x))
                ys.append(float(y))
                zs.append(float(z))
            
            # Add this to the settings
            self.list_settings.append([xs, ys, zs])
        
        return
        
        
    def set_all_tables(self, list_settings):
        """
        Set the list of table to the input list. 
        
        list_settings:
            List of set of settings. See the method button_generate_clicked
            for learning more about this list. 
        """
        _debug('GUILinesSettings: set_all_tables')
        
        # Initiate the list of each table. 
        self.list_table = [] 
        
        # Convert each element in the inpiut list into a table
        for i in range( len(list_settings) ):
            # Get the setting 
            settings = list_settings[i]
            # Create the table
            a_table = self.create_one_table(settings[0],
                                            settings[1],
                                            settings[2])
            # Add this table in the list
            self.list_table.append(a_table)
            
    def create_one_table(self, xs=[0], ys=[0], zs=[0]):
        """
        Create a table with the input positions.
        Return this table.
        
        xs, ys,zs:
            Same size list of x, y and z. 
            
        """
        _debug('GUILinesSettings: table_trajectories_fill')
        
        #Try to open the data
        try: 
            #First check if the lenghts matche
            if not (len(xs) == len(ys)):
                return 'Lenght of xs and ys do not match !'
            if not (len(ys) == len(zs)):
                return 'Lenght of ys and zs do not match !'  
            if not (len(zs) == len(xs)):
                return 'Lenght of xs and zs do not match !'
            #If we pass here, we are ready to extract the position from the data 
            
            # Initiate the table
            a_table = egg.gui.Table(columns = 3)

            # The first row will be a label for indicating what are each collumns
            a_table.set_value(column=0, row=0, value='xs (um)')
            a_table.set_value(column=1, row=0, value='ys (um)') 
            a_table.set_value(column=2, row=0, value='zs (um)')                 
            # Then input the new one. 
            for i in range(0, len(xs) ):
                # X position 
                a_table.set_value(column=0, row=i+1, value=xs[i])
                # Y position 
                a_table.set_value(column=1, row=i+1, value=ys[i])                
                # Z position 
                a_table.set_value(column=2, row=i+1, value=zs[i]) 
                
            # Ready to return ;) 
            return a_table
            
        except: 
            print('GUILinesSettings: table_trajectories_fill '+
                  '\nError in reading the data from the file :S '    ) 
        



from matplotlib.backends.backend_qt4agg import FigureCanvasQTAgg as FigureCanvas
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D # This import registers the 3D projection, but is otherwise unused.

#class GUIPlotSettings(egg.gui.Window):
# TODO Have this a regular function instead of a class if it is simple as this.
class GUIPlotSettings():
    """
    A cosy GUI for showing the setting
    
    """
    def __init__(self, list_settings): 
        """
        list_settings:
            List of the setting to plot.
        """ 
        _debug('GUIPlotSettings: __init__')

#        #Run the basic stuff for the initialization
#        # This make in sort that we can use the gui as an egg window
#        egg.gui.Window.__init__(self,title='Banane')
#        #This prevent to have a second figure poping out outside of the gui
#        plt.ioff() # It doesn't seem to work each time lol
        
        self.list_settings = list_settings
        
        # Create a figure and canvas 
        # tight_layout make sure the labels are visible
        self.fig = plt.figure(tight_layout=True)
#        # this is the Canvas Widget that displays the `figure`. It takes the `figure` instance as a parameter to __init__
#        self.canvas = FigureCanvas(self.fig) 
#        self.canvas.draw()
#        # Add it to the GUI
#        self.place_object(self.canvas)      
        
        # Prepare the plot
        self.ax = self.fig.add_subplot(111, projection='3d') 
        
        for i, settings in enumerate( self.list_settings):
            ff.plot_magSweepLinesSettings(settings, ax=self.ax, 
                                          color='C%d'%i)
            
        return
        
        
        
        
#By default set the object
if __name__ == '__main__':
    _debug_enabled = True 
    
    self = GUILinesSettings()
    self.show()
    
    














