# -*- coding: utf-8 -*-
"""
Created on Thu May 21 15:27:02 2020


A GUI for optimizing the x,y and z axis

@author: Childresslab, Michael
"""

import numpy as np

from scipy.optimize import curve_fit

import spinmob as sm
from spinmob import egg
import time
import traceback
_p = traceback.print_last #Very usefull command to use for getting the last-not-printed error

# Debug stuff.
_debug_enabled     = False

def _debug(*a):
    if _debug_enabled: 
        s = []
        for x in a: s.append(str(x))
        print(', '.join(s))
        
        
def func_fit(x, x0, dx, y0):
    """
    Function for fitting a one-dimensionnal cut of the emmiter. 
    
    The specific choice of the form and the parameters is such that it is easy 
    to extract the parameter that we care about
    (such as the maximum and the center)
    """
    #A inverted parabola for the curve_fit function
#    return y0-((x-x0)/dx)**2
    # A Gaussian
    return y0*np.exp( - (x-x0)**2 / (y0*dx**2)   )

def fit_1D_cut(xdata, ydata, eydata, list_guess):
    """
    Chi2 fit the 1D cut data. 
    
    Return popt and perr and fitter
    popt and perr are the array of best estimate and standard deviation. 
    fitter is the object from spinmob for fitting
        
    """
    _debug('fit_1D_cut') 
    
    # Create the fitter object
    fitter = sm.data.fitter(autoplot = False)
    # Set the two function that we simultaneuously fit
    fitter.set_functions('pants(x, x0, dx, y0)', 
                         'x0, dx, y0', 
                         pants=func_fit)
    _debug('fit_1D_cut: Set the function') 
    
    # Set the data
    fitter.set_data(xdata, ydata, eydata)
    _debug('fit_1D_cut: Set the function') 
    
    #Set the guess
    fitter.set(x0=list_guess[0], 
               dx=list_guess[1],
               y0=list_guess[2])
    _debug('fit_1D_cut: Set the guess') 
    
    # Fit !
    fitter.fit()
    _debug('fit_1D_cut: Fitted') 
    
    # Extract the rates
    x0_fit  = fitter.results.params['x0'].value
    dx_fit  = fitter.results.params['dx'].value
    y0_fit  = fitter.results.params['y0'].value
    ex0_fit = fitter.results.params['x0'].stderr
    edx_fit = fitter.results.params['dx'].stderr
    ey0_fit = fitter.results.params['y0'].stderr 
    print('fit_1D_cut: Parameters extracted') 
    
    popt = [ x0_fit , dx_fit , y0_fit]
    perr = [ex0_fit, edx_fit, ey0_fit]
#    chi2 = fitter.get_reduced_chi_squared()
#    dof  = fitter.get_degrees_of_freedom()
    
    return popt, perr, fitter
  

class GUIOptimizer(egg.gui.Window):
    """
    GUI for optimizing around an NV. 
    """
    def __init__(self, fpga, name="Optimizer", size=[1500,800]): 
        """
        Initialize 
        
        fpga:
            "FPGA_api" object from api_fpga.py. 
            This is the object shared amoung the GUIs for controlling the fpga. 
            The session of the fpga must already be open.
            
        """    
        _debug('GUIOptimizer:__init__')
        _debug('I am enjoying my life because things aren’t going the way I planned. – Rohit Pandita')
        
        # Run the basic stuff for the initialization
        egg.gui.Window.__init__(self, title=name, size=size)
        
        # Take possession of the fpga Mouahahaha...
        self.fpga = fpga
        self.t0 = time.time() # A reference time
        
        # Initiate the checkup routine
        self.n_checkup = 0
        
        # Other variables
        self.is_optimizing = False # Weither or not we are optimizing
        self.is_updating_gui_with_fpga = False # Weither or not we are updating the gui to match the fpga value

        # Fill up the GUI 
        self._initialize_GUI()
        
    def _initialize_GUI(self):
        """
        Fill up the GUI
        """        
        _debug('GUIOptimizer: _initialize_GUI')
        
        # Place a buttong for the scan
        self.button_optimize = self.place_object(egg.gui.Button('Optimize'))
        self.button_optimize.set_text('Optimize')
        self.button_optimize.set_style('background-color: rgb(0, 200, 0);')          
        self.connect(self.button_optimize.signal_clicked, self._button_optimize_clicked)
        
        # Place the dictionay three for all the parameters
        self.treeDic_settings  = egg.gui.TreeDictionary(autosettings_path='setting_optimizer')
        self.new_autorow()
        self.place_object(self.treeDic_settings)   
        # The next three are for setting the range under which to optimize
        self.treeDic_settings.add_parameter('Usual/Range_Vx', 0.1, 
                                           type='float', step=0.1, 
                                           bounds=[0,None], suffix=' V',
                                           tip='Range on which to optimize in Vx direction')
        self.treeDic_settings.add_parameter('Usual/Range_Vy', 0.1, 
                                           type='float', step=0.1, 
                                           bounds=[0,None], suffix=' V',
                                           tip='Range on which to optimize in Vy direction')
        self.treeDic_settings.add_parameter('Usual/Range_Vz', 0.1, 
                                           type='float', step=0.1, 
                                           bounds=[0,None], suffix=' V',
                                           tip='Range on which to optimize in Vz direction')  
        # Other useful parameters
        self.treeDic_settings.add_parameter('Usual/Count_time', 50, 
                                           type='float', step=0.1, 
                                           bounds=[0, None], suffix=' ms')
        self.treeDic_settings.add_parameter('Usual/Scan_points', 25, 
                                           type='int', step=1, 
                                           bounds=[3, None])
        # THe next three are for the offsets voltages if we want to optimize
        # elsewehre than the position probed. 
        self.treeDic_settings.add_parameter('Usual/Offset_Vx', 0, 
                                           type='float', step=0.1, 
                                           bounds=[-20,20], suffix=' V',
                                           tip='X_opt - X_probe')
        self.treeDic_settings.add_parameter('Usual/Offset_Vy', 0, 
                                           type='float', step=0.1, 
                                           bounds=[-20,20], suffix=' V',
                                           tip='Y_opt - Y_probe')
        self.treeDic_settings.add_parameter('Usual/Offset_Vz', 0, 
                                           type='float', step=0.1, 
                                           bounds=[-20,20], suffix=' V',
                                           tip='Z_opt - Z_probe')
        
        # The next parameters are used only for automatic optimization during
        # Pulse sequences or something else. 
        self.treeDic_settings.add_parameter('Automatic/Threshold_fraction', 0.95, 
                                           type='float', step=0.1, 
                                           bounds=[0,None], 
                                           tip='Like in Labview. Threshold fraction under which BLABLA PLEASE EXPLAIN')    

        # Add a table for showing the selected R_probed and R_optimize
        self.table_Rs  = egg.gui.Table()
        self.place_object(self.table_Rs, row=2, column=0, column_span=2) 
        # Put some values
        self.table_Rs.set_value(column=1, row=0, value='Vx')
        self.table_Rs.set_value(column=2, row=0, value='Vy')
        self.table_Rs.set_value(column=3, row=0, value='Vz')
        self.table_Rs.set_value(column=0, row=1, value='R_probe')
        self.table_Rs.set_value(column=0, row=2, value='R_opt')      
        self.table_Rs.set_value(column=1, row=1, value=0)
        self.table_Rs.set_value(column=2, row=1, value=0)
        self.table_Rs.set_value(column=3, row=1, value=0)
        self.table_Rs.set_value(column=1, row=2, value=0)
        self.table_Rs.set_value(column=2, row=2, value=0)
        self.table_Rs.set_value(column=3, row=2, value=0)        

        # Place a button for setting r_probe
        self.button_set_r_probe = self.place_object(
                egg.gui.Button('Set R_probe'), row=3, column=0)       
        self.connect(self.button_set_r_probe.signal_clicked, self._button_set_r_probe_clicked)  
        # Place a button for setting r_optimize
        self.button_set_r_opt = self.place_object(
                egg.gui.Button('Set R_opt'), row=4, column=0)       
        self.connect(self.button_set_r_opt.signal_clicked, self._button_set_r_opt_clicked) 
        # Place a button for setting the offset
        self.button_set_r_offset = self.place_object(
                egg.gui.Button('Set R_offset'), row=5, column=0)       
        self.connect(self.button_set_r_offset.signal_clicked, self._button_set_r_offset_clicked)         
        
        # Tabs !
        self.tabs1 = self.place_object(
                egg.gui.TabArea(autosettings_path='optimizer_tabs1'),
                row_span=6)
        
        
        # A tab for the fits
        self.tab_fits = self.tabs1.add_tab('Fits')
        # Place the plot for showing the fits 
        self.win_plot_fits = egg.pyqtgraph.GraphicsWindow(title="Optimization")
        self.win_plot_fits.resize(1000,600)
        self.tab_fits.place_object(self.win_plot_fits,
                          row=0, column=1, row_span=3, alignment =1) 
        # Add the three plot for each direction        
        self.plot_fit_x = self.win_plot_fits.addPlot(title="X direction")
        self.plot_fit_y = self.win_plot_fits.addPlot(title="Y direction")
        self.plot_fit_z = self.win_plot_fits.addPlot(title="Z direction")
    
        
        # A tab for tracking the positions
        self.tab_track = self.tabs1.add_tab('Track position')
        # A databoxplot for the three directions VS optimizations
        self.databoxplot_pos = egg.gui.DataboxPlot(autosettings_path='plot_optimzation_pos')
        self.tab_track.place_object(self.databoxplot_pos)   

        # A tab for tracking checking the threshold stuff
        self.tab_threshold = self.tabs1.add_tab('Track threshold')
        # A databoxplot for the counts and threshold of optimization
        self.databoxplot_thresh = egg.gui.DataboxPlot(autosettings_path='plot_optimzation_thresh')
        self.tab_threshold.place_object(self.databoxplot_thresh)   

        # Make a label for showing the statut
        self.label_statut = egg.gui.Label('We have the best optimzer on the market.')
        self.place_object(self.label_statut, row=2, column=3)           
    
    def _prepare_acquisition_pulse(self):
        """
        Prepare the acquisition of counts. 
        
        It prepares the pulse pattern and set the wait time. 
        
        """
        _debug('GUIOptimizer: prepare_acquisition')
        
        # Upate the waiting time
        self.fpga.prepare_wait_time(self.wait_after_AOs_us)

        self.count_time_ms = self.treeDic_settings['Usual/Count_time']        
        # Put 120 tick off, because Labview also put 120 ticks off (=1us)
        self.fpga.prepare_counting_pulse(self.count_time_ms, nb_ticks_off=120)
        
        # Call the event to say "hey, stuff changed on the fpga"
        if not(self.is_updating_gui_with_fpga):
            # Call it only if we are not updating the gui with the fpga
            self.event_fpga_change()        
        
    def _button_optimize_clicked(self):
        """
        Button optimize clicked! 
        """
        _debug('GUIOptimizer: _button_optimize_clicked')
        
        if self.is_optimizing == False:
            # Note that we are taking counts
            self.button_optimize.set_text('Stop Optimizing')
            self.button_optimize.set_style('background-color: rgb(255, 100, 100);')
            self.is_optimizing = True
            # Send a event saying "Hey everyone, optimization is starting !"
            self.event_optimize_starts()
            # Allow the GUI to update. This is important to avoid freezing of the GUI inside loops
            self.process_events()               
            
            # Optimize !
            self._run_optimizing()
        else:
            # Stop to take counts if we were taking counts
            self.is_optimizing  = False
            # Update the GUI
            self.button_optimize.set_text('Optimize')
            self.button_optimize.set_style('background-color: rgb(0, 200, 0);')  
            # Send a event saying "Holla, optimization is done !"
            self.event_optimize_ends()

    def _button_set_r_probe_clicked(self):
        """
        Note the actuall probed position
        """
        _debug('GUIOptimizer: _button_set_r_probe_clicked')

        # Steal the AOs information of x,y,z from the map
        self._steal_AO_info() # This make sure that we have the good AO
        # Get the voltages
        Vx = self.fpga.get_AO_voltage(self.AOx)
        Vy = self.fpga.get_AO_voltage(self.AOy)
        Vz = self.fpga.get_AO_voltage(self.AOz)
        # Update the table
        self.table_Rs.set_value(column=1, row=1, value=Vx)
        self.table_Rs.set_value(column=2, row=1, value=Vy)
        self.table_Rs.set_value(column=3, row=1, value=Vz)        

    def _button_set_r_opt_clicked(self):
        """
        Note the position to optimize
        """
        _debug('GUIOptimizer: _button_set_r_opt_clicked')

        # Steal the AOs information of x,y,z from the map
        self._steal_AO_info() # This make sure that we have the good AO
        # Get the voltages
        Vx = self.fpga.get_AO_voltage(self.AOx)
        Vy = self.fpga.get_AO_voltage(self.AOy)
        Vz = self.fpga.get_AO_voltage(self.AOz)
        # Update the table
        self.table_Rs.set_value(column=1, row=2, value=Vx)
        self.table_Rs.set_value(column=2, row=2, value=Vy)
        self.table_Rs.set_value(column=3, row=2, value=Vz)   
        
    def _button_set_r_offset_clicked(self):
        """
        Set the relative position for optimizing. 
        """
        _debug('GUIOptimizer: _button_set_r_offset_clicked')  
        
        # Take the position to optimize
        Vopt_x = float(self.table_Rs.get_value(column=1, row=2))
        Vopt_y = float(self.table_Rs.get_value(column=2, row=2))
        Vopt_z = float(self.table_Rs.get_value(column=3, row=2))
        # Take the position to probe
        Vprobe_x = float(self.table_Rs.get_value(column=1, row=1))
        Vprobe_y = float(self.table_Rs.get_value(column=2, row=1))
        Vprobe_z = float(self.table_Rs.get_value(column=3, row=1))
        # Get the offset voltages 
        Voffset_x = Vopt_x - Vprobe_x
        Voffset_y = Vopt_y - Vprobe_y
        Voffset_z = Vopt_z - Vprobe_z
        # Save this in the tree dictionnary
        self.treeDic_settings['Usual/Offset_Vx'] = Voffset_x
        self.treeDic_settings['Usual/Offset_Vy'] = Voffset_y
        self.treeDic_settings['Usual/Offset_Vz'] = Voffset_z
        
    def _offset_put_them(self):
        """
        Shift the position of the piezo by the offset
        """        
        _debug('GUIOptimizer: _offset_put_them')
        
        # Note the value of the offsets
        self.Voffset_x = self.treeDic_settings['Usual/Offset_Vx']
        self.Voffset_y = self.treeDic_settings['Usual/Offset_Vy']
        self.Voffset_z = self.treeDic_settings['Usual/Offset_Vz']  
        # Note the new position
        self.vx_new = self.fpga.get_AO_voltage(self.AOx) + self.Voffset_x
        self.vy_new = self.fpga.get_AO_voltage(self.AOy) + self.Voffset_y
        self.vz_new = self.fpga.get_AO_voltage(self.AOz) + self.Voffset_z
        _debug('GUIOptimizer: _offset_put_them: ',
               self.vx_new, self.vy_new, self.vz_new)
        
        # Set the fpga in this new position 
        self.fpga.prepare_AOs([int(self.AOx), int(self.AOy), int(self.AOz)], 
                               [self.vx_new, self.vy_new, self.vz_new]) 
        
        # Run the FPGA for updating its settings
        # It gonna run also the pre-existing pulse sequence. Hopefully it's 
        # gonna be the counter. 
        self.fpga.lets_go_FPGA()            

    def _offset_remove_them(self):
        """
        Shift the position of the piezo to remove the offset
        """        
        _debug('GUIOptimizer: _offset_remove_them')
        
        # Note the new position
        self.vx_new = self.fpga.get_AO_voltage(self.AOx) - self.Voffset_x
        self.vy_new = self.fpga.get_AO_voltage(self.AOy) - self.Voffset_y
        self.vz_new = self.fpga.get_AO_voltage(self.AOz) - self.Voffset_z
        _debug('GUIOptimizer: _offset_remove_them: ',
               self.vx_new, self.vy_new, self.vz_new)
        
        # Set the fpga in this new position 
        self.fpga.prepare_AOs([int(self.AOx), int(self.AOy), int(self.AOz)], 
                               [self.vx_new, self.vy_new, self.vz_new]) 
        # Run the FPGA for updating its settings
        # It gonna run also the pre-existing pulse sequence. Hopefully it's 
        # gonna be the counter. 
        self.fpga.lets_go_FPGA()
        
        # Call the event to say "hey, stuff changed on the fpga"
        if not(self.is_updating_gui_with_fpga):
            # Call it only if we are not updating the gui with the fpga
            self.event_fpga_change()               
            

        
    def _scan_1D(self):
        """
        Scan along one direction defined by the attribute self.AO
        The range of the scan is between the attributes self.Vmin and self.Vmax
        
        """
        _debug('GUIOptimizer: _scan_1D: AO ', self.AO) 
        
        # Create an array of voltages centered on V0 with the range from the settings. 
        Npts = self.treeDic_settings['Usual/Scan_points']
        self.Vs = np.linspace(self.Vmin, self.Vmax, Npts)
        
        # Scan the array--> note the counts at each value
        self. count_array = []
        self.ecount_array = [] # Uncertaionty in the count (will assum poissonian)
        
        i = -1
        while self.is_optimizing and (i<(len(self.Vs)-1)):
            i += 1
            V = self.Vs[i]
            self.fpga.prepare_AOs([int(self.AO)], [V])
            
            # Get the count, finally ;) 
            # Two step: runt he pulse pattern and get the counts. 
            self.fpga.run_pulse() # This will also write the AOs
            self.counts =  self.fpga.get_counts()[0]
            
#            # FOR TESTING ONLY Add some fake to the data
             # UNCOMMENT ONLY IF YOU WANT TO TEST
#            self.counts+= np.random.poisson(1000-200*(V-self.V0)**2/(self.Vmax-self.V0)**2)
#            print(self.counts)
            
            self. count_array.append(self.counts)
            self.ecount_array.append(np.sqrt(self.counts)) # Assum poissonian
            # Allow the GUI to update. This is important to avoid freezing of the GUI inside loops
            self.process_events()   
            
            # Call the event to say "hey, stuff changed on the fpga"
            if not(self.is_updating_gui_with_fpga):
                # Call it only if we are not updating the gui with the fpga
                self.event_fpga_change()   
        # Reconvert into numpy array
        self. count_array = np.array(self. count_array)
        self.ecount_array = np.array(self.ecount_array)
            
    def _find_max(self):
        """
        Find the voltage which maximizes the counts. 
        Fit with the function func_fit
        """
        _debug('GUIOptimizer: _find_max') 
        print('GUIOptimizer: _find_max')
        
        # Prepare the fit
        xdata = self.Vs
        ydata  = self. count_array
        eydata = self.ecount_array
        x0_guess = self.V0
        y0_guess = np.mean(ydata)
        dx1 = (xdata[-1]-x0_guess)/np.sqrt(np.abs(y0_guess-ydata[-1]))
        dx2 = (xdata[0]-x0_guess)/np.sqrt(np.abs(y0_guess-ydata[0]))
        dx_guess = max([dx1, dx2])
        self.p0 = [self.V0, dx_guess, y0_guess]
        self.dof = len(ydata) - len(self.p0)
        
        # Try to fit. If it fails, do not change the AO
        try:
            self.popt, self.perr, self.fitter = fit_1D_cut(xdata,
                                                           ydata, eydata, 
                                                           self.p0)
            
            v_fit = self.popt[0]
            if v_fit > self.Vmax:
                _debug('GUIOptimizer: _find_max: choose vmax!')
                self.v_best = self.Vmax
                self.ev_best = float('NaN')
                self.chi2    = float('NaN')
                
            elif v_fit < self.Vmin:
                _debug('GUIOptimizer: _find_max: choose vmin!')
                self.v_best = self.Vmin
                self.ev_best = float('NaN')
                self.chi2    = float('NaN')
                
            else:
                _debug('GUIOptimizer: _find_max: choose in the fit !')
                self.v_best = v_fit                
                self.ev_best = self.perr[0]
                # Get the reduced chi2
                y_model = func_fit(xdata, *self.popt)
                self.chi2 = np.sum( ((y_model-ydata)/eydata)**2) / self.dof
                
            # Put the FPGA with this AO at the voltage of maximum counts
            self.fpga.prepare_AOs([int(self.AO)], [self.v_best])  
            
            # Call the event to say "hey, stuff changed on the fpga"
            if not(self.is_updating_gui_with_fpga):
                # Call it only if we are not updating the gui with the fpga
                self.event_fpga_change()                   
            
            self.fit_worked = True
            
        except:
            _debug('GUIOptimizer: _find_max: Cannot fit!')
            # Do not change the AO
            self.fit_worked = False
            # Still not the best V, for keeping track of it..
            self.v_best = self.V0 
            self.ev_best = float('NaN')
            self.chi2    = float('NaN')
            
        _debug('GUIOptimizer: _find_max: v_best = ', self.v_best)
 
    def _steal_AO_info(self):
        """
        Steal the AOs information of x,y,z from the setting of the map
        """
        _debug('GUIOptimizer: _steal_AO_info') 
        self.treeDict_map = egg.gui.TreeDictionary(autosettings_path='setting_map')
        self.treeDict_map.add_parameter('AO_x')
        self.treeDict_map.add_parameter('AO_y')
        self.treeDict_map.add_parameter('AO_z')
        self.treeDict_map.add_parameter('Wait_after_AOs')
        self.AOx = self.treeDict_map['AO_x']
        self.AOy = self.treeDict_map['AO_y']
        self.AOz = self.treeDict_map['AO_z']
        self.wait_after_AOs_us = int(self.treeDict_map['Wait_after_AOs'])
        _debug('GUIOptimizer: _steal_AO_info: ', 
               self.AOx, self.AOy, self.AOz, self.wait_after_AOs_us)
               
        
    def _run_optimizing(self):
        """
        Run the optimization procedure.
        """
        _debug('GUIOptimizer: _run_optimizing') 
        
        # Restart the checkup routine. 
        # I also restart it here because this method might be called from o
        # optimizing in an other way.
        self.n_checkup  = 0
        
        # Update the statut
        text = (  'Statut:\nPreparing the optimization.')
        self.label_statut.set_text(text)
        
        # This will note the results of the fit
        self.list_fit_pos  = [] # Positions of the center
        self.list_fit_epos = [] # Uncertainty in the positions of the center
        self.list_fit_chi2 = [] # Reduced chi2 of the fits
        self.list_fit_dof  = [] # Degree of freedom of the fits
        
        # Steal the AOs information of x,y,z from the map
        self._steal_AO_info()

        if _debug_enabled:
            # Verifye the voltages. 
            for i in [self.AOx,self.AOy, self.AOz]:
                V = self.fpga.get_AO_voltage(i)
                print('GUIOptimizer: _run_optimizing before offset V_%d'%i, V)   
        
        # Put the offsets
        self._offset_put_them()
        
        if _debug_enabled:
            # Verifye the voltages. 
            for i in [self.AOx,self.AOy, self.AOz]:
                V = self.fpga.get_AO_voltage(i)
                print('GUIOptimizer: _run_optimizing after offset V_%d'%i, V)            

        # Prepare the pulse sequence for getting the counts
        self._prepare_acquisition_pulse()
        # Optimize the X direction
        # Update the statut
        text = (  'Statut:\nOptimizing X')
        self.label_statut.set_text(text)
        # Note the corresponding AO
        self.AO = self.AOx
        # The center voltage will be the actual voltage
        self.V0 = self.fpga.get_AO_voltage(self.AO) 
        self.Vmin = self.V0 - self.treeDic_settings['Usual/Range_Vx']/2
        self.Vmax = self.V0 + self.treeDic_settings['Usual/Range_Vx']/2
        # Trigger the scan
        self._scan_1D()
        # Process the scan only if it wasn't interrupted
        if self.is_optimizing:
            # Find the maxima
            self._find_max()
            # Update the plots
            self._update_plot_fit(self.plot_fit_x)   
            # Save info
            self.list_fit_pos .append(self. v_best)
            self.list_fit_epos.append(self.ev_best)
            self.list_fit_chi2.append(self.chi2)
            self.list_fit_dof .append(self.dof)
        else:
            # We still need to complte the arrays
            # Set a Nan
            self.list_fit_pos .append(float('NaN'))            
            self.list_fit_epos.append(float('NaN'))
            self.list_fit_chi2.append(float('NaN'))
            self.list_fit_dof .append(float('NaN'))            
                    
        # Optimize the Y direction
        # Update the statut
        text = (  'Statut:\nOptimizing Y')
        self.label_statut.set_text(text)
        # Note the corresponding AO
        self.AO = self.AOy
        # The center voltage will be the actual voltage
        self.V0 = self.fpga.get_AO_voltage(self.AO)
        self.Vmin = self.V0 - self.treeDic_settings['Usual/Range_Vy']/2
        self.Vmax = self.V0 + self.treeDic_settings['Usual/Range_Vy']/2
        # Trigger the scan
        self._scan_1D()
        # Process the scan only if it wasn't interrupted
        if self.is_optimizing:
            # Find the maxima
            self._find_max()
            # Update the plots
            self._update_plot_fit(self.plot_fit_y) 
            # Save info
            self.list_fit_pos .append(self. v_best)
            self.list_fit_epos.append(self.ev_best)
            self.list_fit_chi2.append(self.chi2)
            self.list_fit_dof .append(self.dof)
        else:
            # We still need to complte the arrays
            # Set a Nan
            self.list_fit_pos .append(float('NaN'))            
            self.list_fit_epos.append(float('NaN'))
            self.list_fit_chi2.append(float('NaN'))
            self.list_fit_dof .append(float('NaN'))  
            
        # Optimize the Z direction
        # Update the statut
        text = (  'Statut:\nOptimizing Z')
        self.label_statut.set_text(text)
        # Note the corresponding AO
        self.AO = self.AOz
        # The center voltage will be the actual voltage
        self.V0 = self.fpga.get_AO_voltage(self.AO)        
        self.Vmin = self.V0 - self.treeDic_settings['Usual/Range_Vz']/2
        self.Vmax = self.V0 + self.treeDic_settings['Usual/Range_Vz']/2
        # Trigger the scan
        self._scan_1D()
        # Process the scan only if it wasn't interrupted
        if self.is_optimizing:            
            # Find the maxima
            self._find_max()
            # Update the plots 
            self._update_plot_fit(self.plot_fit_z)
            # Save info
            self.list_fit_pos .append(self. v_best)
            self.list_fit_epos.append(self.ev_best)
            self.list_fit_chi2.append(self.chi2)
            self.list_fit_dof .append(self.dof)
        else:
            # We still need to complte the arrays
            # Set a Nan
            self.list_fit_pos .append(float('NaN'))            
            self.list_fit_epos.append(float('NaN'))
            self.list_fit_chi2.append(float('NaN'))
            self.list_fit_dof .append(float('NaN'))  

        if self.is_optimizing:
            # Will stop optimizing and uptage the button
            self._button_optimize_clicked()

        # Important: Remove the offsets
        self._offset_remove_them()
        # Update the plot
        self._update_databoxplot_pos()

        # Update the statut
        text = (  'Statut:\nDone.')
        self.label_statut.set_text(text)

        if _debug_enabled:
            # Verifye the voltages. 
            for i in [self.AOx,self.AOy, self.AOz]:
                V = self.fpga.get_AO_voltage(i)
                print('GUIOptimizer: _run_optimizing after removing offset V_%d'%i, V)  
        
    def _update_plot_fit(self, plot):
        """
        Plot the fit. 
        
        plot:
            "self.win_plot_fits.addPlot" object that we want to update. 
            
        """
        _debug('GUIOptimizer: _update_plot_fit') 
        
        # Remove the previous plot
        plot.clear() 
        # plot the data and the fit
        plot.addLegend() 
        plot.plot(self.Vs, self.count_array, pen=(255,255,255), name="Data")
        plot.plot(self.Vs, self.count_array, symbol='o', pen={'color': 0.8})
        
        # Error bar
        # Beam is the size of the horizontal bar
        self.obj_error = egg.pyqtgraph.ErrorBarItem(x=self.Vs, y=self.count_array, 
                                   top    = self.ecount_array, 
                                   bottom = self.ecount_array, 
                                   beam= 0.3*np.mean(np.diff(self.Vs)),
                                   pen=(255,0,255))  
        plot.addItem(self.obj_error)
        
        # Abscissa for showing the fit (more points for a smooth curve)
        x_fit = np.linspace(min(self.Vs), max(self.Vs), 100)
        # Show the fit if it worked. 
        if self.fit_worked:
            plot.plot(x_fit, func_fit(x_fit, *self.popt), pen=(255,0,255),name="Fit")
            # Show the maximum
            self.cmax = self.popt[2]
            plot.plot([self.v_best], [self.cmax], symbolBrush=(255,0,255), symbolPen='w', symbol='o', symbolSize=14)  
        else:
            # Still show where is the max
            y = np.mean(self.count_array)
            plot.plot([self.V0], [y], symbolBrush=(255,0,255), symbolPen='w',
                      symbol='o', symbolSize=14, name='Fit did not work.\nThis is the value taken.')  
        
        # Show the guess
        plot.plot(x_fit, func_fit(x_fit, *self.p0), pen=(0,255,255),name="Guess")

    def _update_databoxplot_pos(self):
        """
        Update the databox plot.
        """
        _debug('GUIOptimizer: _update_databoxplot_pos') 
        # Add headers
        for key in self.treeDic_settings.get_keys():
            # Add each element of the dictionnary three
            self.databoxplot_pos.insert_header(key , self.treeDic_settings[key])
        # Add a row. 
        self.elapsed_time = time.time() - self.t0
        row = [self.elapsed_time, 
               self.list_fit_pos[0], 
               self.list_fit_pos[1], 
               self.list_fit_pos[2],
               self.list_fit_epos[0], 
               self.list_fit_epos[1], 
               self.list_fit_epos[2],  
               self.list_fit_dof[0], 
               self.list_fit_dof[1], 
               self.list_fit_dof[2],  
               self.list_fit_chi2[0], 
               self.list_fit_chi2[1], 
               self.list_fit_chi2[2],               ] 
        self.databoxplot_pos.append_row(row, 
                                        ckeys=['Time_sec',
                                               'Vx', 'Vy', 'Vz',
                                               'eVx', 'eVy', 'eVz',
                                               'dof_x', 'dof_y', 'dof_z',
                                               'chi2_x', 'chi2_y', 'chi2_z'])
        # Show this masterpiece
        self.databoxplot_pos.plot()

    def _update_databoxplot_thresh(self):
        """
        Update the databox plot.
        """
        _debug('GUIOptimizer: _update_databoxplot_thresh') 
        # Add headers
        for key in self.treeDic_settings.get_keys():
            # Add each element of the dictionnary three
            self.databoxplot_thresh.insert_header(key , self.treeDic_settings[key])
            
        # Add a row. 
        self.elapsed_time = time.time() - self.t0
        row = [self.elapsed_time, 
               self.count_current,
               self.count_mean,
               self.count_threshold] 
        self.databoxplot_thresh.append_row(row, 
                                           ckeys=['Time_sec',
                                                  'Count_Received',
                                                  'Count_mean_since_last_opt',
                                                  'Count_threshold'])
        # Show this masterpiece
        self.databoxplot_thresh.plot()          
        

    def _update_GUI_with_fpga(self):
        """
        Update the gui such that the widgets match with the fpga. 
        That is useful for the implementation with other GUI that also 
        modifies the fpga. 
        """
        _debug('GUIOptimizer: _update_GUI_with_fpga') 
        self.is_updating_gui_with_fpga = True
        # There is no widget to match for now
        self.is_updating_gui_with_fpga = False
        return
    
    def check_threshold_opt(self, count):
        """
        Verify if we need to optimize. 
        It is based on the thershold. 

        count:
            (float) Incoming count to send for comparing.         
        
        """
        _debug('GUIOptimizer: check_threshold_opt') 
        
        # Note the actual counts and relevant info
        self.count_current = count
        r = self.treeDic_settings['Automatic/Threshold_fraction']  
        
        # Treat differently if it is the first checkup since the last optimization
        if self.n_checkup == 0:            
            # Use this as a first reference
            self.count_total_auto = self.count_current
            # Increase the number of checkup
            self.n_checkup += 1
            # Can be useuful for debugging 
            self.list_count_total_auto = [self.count_total_auto] 
            
            # Update the information
            self.count_mean = self.count_total_auto/self.n_checkup
            self.count_threshold = r *self.count_mean
            self._update_databoxplot_thresh()
            
            # Note if it did optimized
            return False
            
        else:
            # Verify if the count fall off bellow the threshold
            
            # Update the information
            self.count_mean = self.count_total_auto/self.n_checkup
            self.count_threshold = r *self.count_mean
            self._update_databoxplot_thresh()
            
            if self.count_current < self.count_threshold:
                # If it falls off
                self.button_optimize.click()
                # Restart the checkup routine just to make sure. 
                self.n_checkup  = 0
                # Note if it did optimized
                return True           
            else:
                # Update the total count 
                self.count_total_auto += count            
                # Increase the number of checkup
                self.n_checkup += 1
                # Can be useuful for debugging 
                self.list_count_total_auto.append( self.count_total_auto )
                # Note if it did optimized
                return False      
    

    def event_optimize_starts(self):
        """
        Dummy funciton to be overrid. 
        
        It is called when the optimization starts.
        """
        return

    def event_optimize_ends(self):
        """
        Dummy funciton to be overrid. 
        
        It is called when the optimization ends.
        """
        return
    
    def event_fpga_change(self):
        """
        Dummy function to be overrid. 
        
        It is called after that the value on the fpga changed.
        """      
        return

if __name__ == '__main__':
    
    import api_fpga as _fc
    
    _debug_enabled     = True
    _fc._debug_enabled = False
    
    print('Hey on es-tu bin en coton-watte')
    
    # Get the fpga paths and ressource number
    import spinmob as sm
    infos = sm.data.load('cpu_specifics.dat')
    bitfile_path = infos.headers['FPGA_bitfile_path']
    resource_num = infos.headers['FPGA_resource_number']
    # Get the fpga API
    fpga = _fc.FPGA_api(bitfile_path, resource_num) 
    fpga.open_session()
    
#     Uncomment for a fake api of the fpga
#    fpga = _fc.FPGA_fake_api(bitfile_path, resource_num) # Create the api   
#    fpga.open_session()
#    print('\nFAKE FPGA API\n')
    
    self = GUIOptimizer(fpga)
    self.show()

    





