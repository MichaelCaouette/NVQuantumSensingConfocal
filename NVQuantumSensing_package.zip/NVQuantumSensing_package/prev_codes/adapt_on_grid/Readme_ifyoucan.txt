Hello ! I hope you are doing well. 

These scripts are to be put with all the other codes. 
I put them in an isolated folder because we do not use them anymore. 

I you REALLY want to use them, copy-paste them in the same location as the other modules.
And delete the other files with the same name.

