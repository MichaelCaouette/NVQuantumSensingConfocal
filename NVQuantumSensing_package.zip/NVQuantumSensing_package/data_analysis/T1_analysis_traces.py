# -*- coding: utf-8 -*-
"""
Created on Wed Jul  8 07:57:17 2020

Example of how to load the saturation curve

@author: Childresslab
"""

import T1_process_func as _T1_f

import spinmob as sm
import numpy as np
import matplotlib.pyplot as plt

# Define the model function
def model_plus(t, gp, gm):
    return _T1_f.model_00m0(+1, t, gp, gm)
def model_minus(t, gp, gm):
    return _T1_f.model_00m0(-1, t, gp, gm) 


want_log_domain = True # If we want to plot the domaine in log scale  

# Get the data + and minus. 

d_p = sm.data.load(text='Select a single data 4pts trace +')
d_m = sm.data.load(text='Select a single data 4pts trace -')

str_time   = 'time_probed_sec'
str_PL1_t0 = 'PL1_t0'
str_PL1_tp = 'PL1_tprobed'
str_PL2_t0 = 'PL2_t0'
str_PL2_tp = 'PL2_tprobed'




# =============================================================================
# Extract the drift-independant measurement
# =============================================================================

# Check the ckeys
print(d_p.ckeys)
# CHecks the headers
print(d_m.hkeys)

#Get the structured data
(xp, yp, eyp, 
 xm, ym, eym,
 list_meas)    = _T1_f.extract_normalized_meas_4pts_trace(d_p, d_m)

# =============================================================================
# Infer the rates
# =============================================================================
out = _T1_f.rates_from_bayes_from_meas(list_meas,
                                       model_plus, model_minus,
                                       Gp_min=0.1e3, Gp_max=50e3, 
                                       Gm_min=0.1e3, Gm_max=50e3, 
                                       N_grid=200)
gp, egp, gm, egm, corr, my_bayes = out

# Get the chi2
chi2, dof = _T1_f.chi2_and_dof(xp, yp, eyp, 
                               xm, ym, eym, 
                               model_plus, model_minus,
                                gp, gm)
# =============================================================================
# Chec the duty cycle
# =============================================================================
T_decay = 0
T_total = 1
for d in [d_p, d_m]:
    # Total time elapsed
    T_total += d.headers['Time_finish'] - d.headers['Time_initial']
    # Time dedicated to the decay
    repetition = d.headers['repetition']
    iteration  = d.headers['iteration' ]
    N_readout = repetition * iteration
    # The decay time is the total time spent on waiting the decay to happen
    T_decay += N_readout*2*np.sum(d[str_time])
# The duty cycle is the fraction of time spent on waiting on the decay    
duty = T_decay / T_total

str_duty = 'Duty cycle = %.1f percent'%(duty*100)
print()
print(str_duty)

# =============================================================================
# Plot all that 
# =============================================================================
# Split the title in 2
str_t = ''
for d in [d_p, d_m]:
    ss = d.path
    str_t += ss[:len(ss)//2] + '\n' + ss[len(ss)//2:] + '\n'
#str_t = d_p.path + '\n' + d_m.path

_T1_f.plot_awesome_data_fit_from_meas(xp, yp, eyp, xm, ym, eym,
                                      model_plus, model_minus,
                                      gp, gm, egp, egm, title=str_t, 
                                      extra_info = str_duty)






