# -*- coding: utf-8 -*-
"""
Created on Wed Jun  2 11:55:19 2021

Goal:
    Compare the fitted ESR value of a couple of data files
    

@author: Childresslab
"""

import B_process_function as _B_func

import matplotlib.pyplot as plt
import spinmob as sm
import numpy as np



#Load data file into databoxes
ds = sm.data.load_multiple(text='Load one or more ESR data file')

list_files = np.arange(1, len(ds)+1)

list_list_f0  = [] # List the list of peaks per files
list_list_ef0 = [] # List the list of uncertainty peaks per files
    
# Get the frequencies and plot them
plt.figure()
for d in ds:    
    list_f0s, list_ef0s, list_popt, list_perr = _B_func.get_peaks(d)
    
    list_list_f0 .append( list_f0s  )
    list_list_ef0.append( list_ef0s )

    for i in range(len(list_f0s)):        
        popt = list_popt[i]
        f0 = list_f0s[i]
        ef0 = list_ef0s[i]
        
        fs = d[0] #Frequencies from the datafile
        
        plt.plot(fs, _B_func.lorentz(fs, *popt), '--', label='f0 = %f +- %f GHz'%(f0, ef0))

plt.xlabel("Frequency (GHz)")
plt.ylabel("Counts")
plt.title(d.path,fontsize=8)
plt.legend(loc='best')
plt.show()


# Plot the infered peaks frequencies
list_of_freq_per_file  = np.array(list_list_f0 ).T
list_of_efreq_per_file = np.array(list_list_ef0).T

plt.figure(tight_layout=True)
for i in range( len(np.array(list_list_ef0).T) ):
    plt.errorbar(list_files, 
                 list_of_freq_per_file[i], 
                 yerr=list_of_efreq_per_file[i], 
                 fmt='.')
    
plt.xlabel("Data file")
plt.ylabel("Frequency (GHz)")
title = ''
for i, d in enumerate(ds):
    title += '\n%d: '%(i+1)+d.path
plt.title(title, fontsize=9)
plt.show()







