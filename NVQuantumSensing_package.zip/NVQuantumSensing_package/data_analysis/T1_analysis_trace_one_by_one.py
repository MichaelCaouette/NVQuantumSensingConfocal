# -*- coding: utf-8 -*-
"""
Created on Wed Jul  8 07:57:17 2020

Example of how to load the saturation curve

@author: Childresslab
"""

import T1_process_func as _T1_f

import spinmob as sm
import numpy as np
import matplotlib.pyplot as plt

# Define the model function
def model_plus(t, gp, gm):
    return _T1_f.model_00m0(+1, t, gp, gm)
def model_minus(t, gp, gm):
    return _T1_f.model_00m0(-1, t, gp, gm) 


want_log_domain = True # If we want to plot the domaine in log scale  

# Get the data
N_batch = 1
ds = []
for i in range(N_batch):
    ds_batch = sm.data.load_multiple(text='Drift independant measurement;)')
    ds.extend(ds_batch)




# =============================================================================
# Extract the drift-independant measurement
# =============================================================================

# Check the ckeys
print(ds[0].ckeys)
# CHecks the headers
print(ds[0].hkeys)
N_data_file = len(ds)


(t_probe_plus_s , result_plus_s , uncertainty_plus_s , 
 t_probe_minus_s, result_minus_s, uncertainty_minus_s ) = _T1_f.extract_measurement(ds)


# =============================================================================
### Chi2 Fit the measurement for determining the rates
# =============================================================================
# Fit with chi2
out = _T1_f.rate_from_chi2(ds,
                          model_plus, model_minus)

gp_chi2, egp_chi2, gm_chi2, egm_chi2 = np.array( out[0:4] ) 
chi2, dof = (out[4], out[5])
fitterChi2 = out[6]
# Get the residuals (Watchout the units)
resi_fit_p = result_plus_s  - model_plus (t_probe_plus_s , gp_chi2, gm_chi2)
resi_fit_m = result_minus_s - model_minus(t_probe_minus_s, gp_chi2, gm_chi2)

# =============================================================================
### Bayes fit the measurement for determining the rates
# =============================================================================
out = _T1_f.rates_from_bayes_from_data(ds, model_plus,model_minus)
gp_bayes, egp_bayes, gm_bayes, egm_bayes, corr_bayes, my_bayes = out


# =============================================================================
# Check the correlation in the fit
# =============================================================================

list_key = fitterChi2.get_parameter_names()
print()
print('Correlation between parameters for Chi2')
for key in list_key:   
    print('Correlation of ',key,' -->', fitterChi2.p_fit[key].correl)
print()
# As a futur reference
corr_chi2 = fitterChi2.p_fit['gp'].correl['gm']
print('Correlation between parameters for Bayes' )  
print('Correlation bewteen gp and gm --> ', corr_bayes)
print()

# =============================================================================
### Super cool plot of the posterior and fitted stuff 
# =============================================================================
Z, mesh_gp, mesh_gm = my_bayes.get_post()
plt.figure(tight_layout=True)
plt.pcolor(mesh_gp*1e-3, mesh_gm*1e-3, Z/np.max(Z), cmap=plt.cm.jet)
plt.colorbar(label="Probability density (Unscaled)")
plt.errorbar(gp_bayes*1e-3, gm_bayes*1e-3,
             xerr=egp_bayes*1e-3,yerr=egm_bayes*1e-3,
             linestyle='', marker='.', color='k', label='Bayes; corr=%.3f'%corr_bayes, 
             markersize=20)
plt.errorbar(gp_chi2*1e-3, gm_chi2*1e-3,
             xerr=egp_chi2*1e-3,yerr=egm_chi2*1e-3,
             linestyle='', marker='.', color='green', label='Chi2; corr=%.3f'%corr_chi2, 
             markersize=20)
plt.axis("equal")#Equate the axis for a better estimate of the relative error
plt.xlabel('$\Gamma_+$ (kHz)')
plt.ylabel('$\Gamma_-$ (kHz)')
plt.title('Posterior of the rates')
plt.legend(title='Best estimate', loc='best')      


# =============================================================================
### Awesome plot of the fit
# =============================================================================
# Initiate the plot
plt.figure(tight_layout=True, figsize=(15, 8))

# Plot the plus type of measurement
ax = plt.subplot(221) # 2 rows, 2 columns, Select the first plot

# Split the title in 2
ss = ds[-1].path
str_t = ss[:len(ss)//2] + '\n' + ss[len(ss)//2:]
plt.title(str_t, fontsize=10)

# The data + 
plt.errorbar(t_probe_plus_s*1e6, result_plus_s, yerr=uncertainty_plus_s, 
             fmt='.', label='Plus')
# The fit
t_fit = sm.fun.erange(t_probe_plus_s.min(), t_probe_plus_s.max(), 300)
y_fit = model_plus(t_fit, gp_chi2, gm_chi2)
plt.plot(t_fit*1e6, y_fit, label='Chi2')
# Some enhancements
plt.legend(loc='best')
plt.xlabel('Time probed (us)')
plt.ylabel('Diff-ratio')
plt.text(0.02, .9, '(a)', transform=ax.transAxes)
if want_log_domain:
    plt.xscale('log')

# Plot the minus type of measurement
ax = plt.subplot(223) # 2 rows, 2 columns
# The data - 
plt.errorbar(t_probe_minus_s*1e6, result_minus_s, yerr=uncertainty_minus_s, 
             fmt='.', label='Minus')
# The fit
t_fit = sm.fun.erange(t_probe_minus_s.min(), t_probe_minus_s.max(), 300)
y_fit = model_minus(t_fit, gp_chi2, gm_chi2)
plt.plot(t_fit*1e6, y_fit, label='Chi2')
# Some enhancement
plt.legend(loc='best')
plt.xlabel('Time probed (us)')
plt.ylabel('Diff-ratio')
plt.text(0.02, .9, '(b)', transform=ax.transAxes)
if want_log_domain:
    plt.xscale('log')
    
# Some text
ax = plt.subplot(222) # 2 rows, 2 columns, 2nd plot
str_info = ('From Chi2 fit'+
            '\n$\Gamma_+$ = %f +- %f kHz'%(gp_chi2*1e-3, egp_chi2*1e-3) + 
            '\n$\Gamma_-$ = %f +- %f kHz'%(gm_chi2*1e-3, egm_chi2*1e-3) + 
            '\n$\chi^2_{reduced}$ = %f +- %f (%d dof)'%(chi2, (2/dof)**0.5, dof)+
            '\n\n With Bayes'+
            '\n$\Gamma_+$ = %f +- %f kHz'%(gp_bayes*1e-3, egp_bayes*1e-3) + 
            '\n$\Gamma_-$ = %f +- %f kHz'%(gm_bayes*1e-3, egm_bayes*1e-3) + 
            '\nCorrelation: %f (Bayes) and %f ($\chi^2$)'%(corr_bayes, corr_chi2)) 

plt.text(0.02, .4, str_info , transform=ax.transAxes,
         fontsize=12, color='black')
plt.axis('off')

# Put the residuals
# For the data plus
ax_res_p = plt.subplot(426)
ax_res_p.plot(t_probe_plus_s*1e6, 0*t_probe_plus_s, '--r')
ax_res_p.errorbar(t_probe_plus_s*1e6, resi_fit_p, yerr=uncertainty_plus_s, 
             fmt='.')
ax_res_p.set_ylabel('Residual +')
# For the data minus
ax_res_m = plt.subplot(428)
ax_res_m.plot(t_probe_plus_s*1e6, 0*t_probe_plus_s, '--r')
ax_res_m.errorbar(t_probe_minus_s*1e6, resi_fit_m, yerr=uncertainty_minus_s, 
             fmt='.', label='Fit -')
ax_res_m.set_ylabel('Residual -')
ax_res_m.set_xlabel('Time probed (us)')
if want_log_domain:
    ax_res_p.set_xscale('log')
    ax_res_m.set_xscale('log')




# =============================================================================
# Bonus: Resttructure the data set for having the inference VS time
# =============================================================================
    
out = _T1_f.restructure_trace(ds, N_split=50, want_print=True)
N_cum = len(out)
 
# For each accumulation, determine the inference
list_gp, list_gm, list_egp, list_egm, list_ttotal = np.zeros((5,N_cum))
for i in range(N_cum):
    t_ela = out[i][0]
    list_meas =   out[i][1] 
    
    outputs = _T1_f.rates_from_bayes_from_meas(list_meas, model_plus, model_minus)
    list_gp[i], list_egp[i], list_gm[i], list_egm[i], corr, my_bayes =  outputs
    list_ttotal[i] = t_ela 


# Plot the evolution of the inference
plt.figure(tight_layout=True)

# Check Gamma+
ax = plt.subplot(221) 
plt.errorbar(list_ttotal/3600, list_gp*1e-3, yerr=list_egp*1e-3, fmt='.')
plt.ylabel('$\Gamma_+$ (kHz)', fontsize=18)
plt.text(0.02, .9, '(a)', transform=ax.transAxes)
s = ''
for ss in ds[0].path.split(maxsplit=2):
    s += '\n' + ss
plt.title(s, fontsize=10)    

# Check Gamma-
ax = plt.subplot(223)
plt.errorbar(list_ttotal/3600, list_gm*1e-3, yerr=list_egm*1e-3, fmt='.')    
plt.ylabel('$\Gamma_-$ (kHz)', fontsize=18)
plt.text(0.02, .9, '(b)', transform=ax.transAxes)
plt.xlabel('Time elapsed (hour) ')

# Uncertainty Versus time
ax = plt.subplot(222)
plt.text(0.02, .9, '(c)', transform=ax.transAxes)
plt.plot(list_ttotal, list_egp*1e-3, '.-', label='$e\Gamma_+$')
plt.plot(list_ttotal, list_egm*1e-3, '.-', label='$e\Gamma_-$')
plt.legend(loc='best')
plt.xscale('log')
plt.yscale('log')
plt.xlabel('Time elapsed (sec) ')
plt.ylabel('Uncertainty (kHz)')
      
                
    
    
    
    
    
    
    



