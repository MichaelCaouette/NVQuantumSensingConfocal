# -*- coding: utf-8 -*-
"""
Created on Wed Jul  8 07:57:17 2020

@author: Childresslab
"""



import spinmob as sm
import numpy as np


d = sm.data.load(text='Select pulse sequence data')

# Check the ckeys
print(d.ckeys)

# Get the axis names
label_s = []
for key in d.ckeys:
    label_s.append(key)
    
#Check the name of the headers
print(d.headers)    
    


# Plot them
import matplotlib.pyplot as plt

plt.figure(tight_layout=True)


for i in range(len(d)-1):
    
    t = d[0] # x-axis
    y = d[i+1] # Count
    ey = np.sqrt(y) # Error in the counts
    # Get the count per readout
    rep = d.headers['repetition']
    nb_iter = d.headers['iteration']  
    N_readout  = rep*nb_iter
    count_per_meas  =  y/(N_readout )
    ecount_per_meas = ey/(N_readout )
    plt.errorbar(t, count_per_meas, yerr=ecount_per_meas,
                 label=label_s[i+1])

plt.legend()    
plt.xlabel(label_s[0])
plt.ylabel('Count/readout')

title = d.path+'\nN_readout = %d'%N_readout 
plt.title(title, fontsize=9)











