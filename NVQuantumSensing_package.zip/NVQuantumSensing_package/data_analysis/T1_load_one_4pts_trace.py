# -*- coding: utf-8 -*-
"""
Created on Wed Jul  8 07:57:17 2020

Example of how to load the saturation curve

@author: Childresslab
"""

import T1_process_func as _T1_f

import spinmob as sm
import numpy as np
import matplotlib.pyplot as plt

# Define the model function
def model_plus(t, gp, gm):
    return _T1_f.model_00m0(+1, t, gp, gm)
def model_minus(t, gp, gm):
    return _T1_f.model_00m0(-1, t, gp, gm) 


want_log_domain = True # If we want to plot the domaine in log scale  

# Get the data
d = sm.data.load(text='Select a single data 4pts trace')

str_time   = 'time_probed_sec'
str_PL1_t0 = 'PL1_t0'
str_PL1_tp = 'PL1_tprobed'
str_PL2_t0 = 'PL2_t0'
str_PL2_tp = 'PL2_tprobed'




# =============================================================================
# Extract the drift-independant measurement
# =============================================================================

# Check the ckeys
print(d.ckeys)
# CHecks the headers
print(d.hkeys)


array_C0_0 = d[str_PL1_t0]
array_C0_t = d[str_PL1_tp]
array_C1_0 = d[str_PL2_t0]
array_C1_t = d[str_PL2_tp]
repetition = d.headers['repetition']
iteration  = d.headers['iteration']
N_readout = repetition * iteration


y, ey = _T1_f.udiff_from_4pts_trace(array_C0_0, array_C0_t, 
                                    array_C1_0, array_C1_t,
                                    N_readout, N_readout, 
                                    N_readout, N_readout)
x = d[str_time]

plt.figure(tight_layout=True)
plt.errorbar(x*1e6, y, yerr=ey, fmt='.')
plt.xlabel('Time probed (us)')
plt.ylabel('Normalize signal')
plt.xscale('log')
    # Split the title in 2
ss = d.path
str_t = ss[:len(ss)//2] + '\n' + ss[len(ss)//2:]
plt.title(str_t, fontsize=10)


    



