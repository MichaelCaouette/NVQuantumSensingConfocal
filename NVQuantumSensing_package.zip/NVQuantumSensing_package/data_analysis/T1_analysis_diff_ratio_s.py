# -*- coding: utf-8 -*-
"""
Created on Wed Jul  8 07:57:17 2020

Example of how to load the saturation curve

@author: Childresslab
"""



import spinmob as sm
import numpy as np
import matplotlib.pyplot as plt

import T1_process_func as _f

# If True, will show the path ofd each data file. 
want_show_all_data_path = False 

ds = sm.data.load_multiple (text='Drift independant measurement;)')

## String for the headers of the data taken before 2021-05-17
#str_PL1_t0 = 'ms0_t0'
#str_PL1_tp = 'ms0_tprobed'
#str_PL2_t0 = 'ms-+1_t0'
#str_PL2_tp = 'ms-+1_tprobed'
## String for the headers of the data taken 2021-05-17 and after
str_PL1_t0 = 'PL1_t0'
str_PL1_tp = 'PL1_tprobed'
str_PL2_t0 = 'PL2_t0'
str_PL2_tp = 'PL2_tprobed'


# Check the ckeys
print(ds[0].ckeys)
# CHecks the headers
print(ds[0].hkeys)
N_data_file = len(ds)
# Initiate the array which will contain the data
t_probe   = np.zeros( N_data_file )
PL1_t0    = np.zeros( N_data_file )
PL1_tp    = np.zeros( N_data_file )
PL2_t0   = np.zeros( N_data_file )
PL2_tp   = np.zeros( N_data_file )
ref       = np.zeros( N_data_file )
N_readout = np.zeros( N_data_file )
# Corresponding uncertainty
ePL1_t0  = np.zeros( N_data_file )
ePL1_tp  = np.zeros( N_data_file )
ePL2_t0 = np.zeros( N_data_file )
ePL2_tp = np.zeros( N_data_file )
eref     = np.zeros( N_data_file )
# Combination
result      = np.zeros( N_data_file )
uncertainty = np.zeros( N_data_file )

# Extract each 
for i in range(N_data_file):
    d = ds[i]
    
    t_probe[i] = d.headers['t_probe']
  
    result[i], uncertainty[i], tuple_PL = _f.udiff_from_datafile(ds[i], 
                                                                   want_tuple_PL=True)
    (PL1_tp[i], ePL1_tp[i], PL2_tp[i], ePL2_tp[i], 
     PL1_t0[i], ePL1_t0[i], PL2_t0[i], ePL2_t0[i]) = tuple_PL    

# =============================================================================
# Verify a very rough analysis
# =============================================================================
M = (PL1_tp - PL2_tp)/(PL1_t0 - PL2_t0)
plt.figure(tight_layout=True)
plt.errorbar(t_probe, M, yerr=0, fmt='.', markersize=10)
plt.xlabel('Time probed (us)')
plt.ylabel('f(4 measurements) (uniteless)')
plt.title('Drift independent measurement')


# =============================================================================
# Verify Just the diference at t_probed
# =============================================================================
diff  = PL1_tp - PL2_tp
ediff = np.sqrt((PL1_tp + PL2_tp)/N_readout)
plt.figure(tight_layout=True)
plt.errorbar(t_probe, diff, yerr=ediff, fmt='.', markersize=10)
plt.xlabel('Time probed (us)')
plt.ylabel('Difference at t_probed')
plt.title(ds[i].path, fontsize=8)


# =============================================================================
# Plot each category of data and the drift independent measurement
# =============================================================================
plt.figure( tight_layout=True)

# First plot the raw data
ax = plt.subplot(211)
plt.errorbar(t_probe, PL1_t0, yerr=ePL1_t0, fmt='o-', markersize=10,label='PL1_t0')
plt.errorbar(t_probe, PL1_tp, yerr=ePL1_tp, fmt='*-', markersize=10,label='PL1_tp')
plt.errorbar(t_probe, PL2_t0, yerr=ePL2_t0, fmt='.-', markersize=10,label='PL2_t0')
plt.errorbar(t_probe, PL2_tp, yerr=ePL2_tp, fmt='v-', markersize=10,label='PL2_tp')
plt.errorbar(t_probe, ref, yerr=eref, fmt='x-', markersize=10,label='Reference')
plt.legend(bbox_to_anchor=(1.00, 1),loc='upper left')
plt.xlabel('Time probed (us)')
plt.ylabel('Count per readout')
plt.title('Time trace of each measurement')
plt.xlim(-min(t_probe), max(t_probe)*1.05) # View better all the data

# Plot the famous drif-independant measurement. 
ax = plt.subplot(212)
plt.errorbar(t_probe, result, yerr=uncertainty, fmt='.', markersize=10)
plt.xlabel('Time probed (us)')
plt.ylabel('f(4 measurements) (uniteless)')
    
plt.xlim(-min(t_probe), max(t_probe)*1.05) # View better all the data

if want_show_all_data_path:
    txt = ''
    for i, d in enumerate(ds):
        if i ==0:
            txt += d.path
        else:
            txt += '\n' + d.path
    plt.title(txt+'\nDrift independent measurement', fontsize=8)
else:
    plt.title(d.path+'\nDrift independent measurement', fontsize=8)
        





