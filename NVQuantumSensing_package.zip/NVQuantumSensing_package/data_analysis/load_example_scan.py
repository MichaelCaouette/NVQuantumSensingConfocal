# -*- coding: utf-8 -*-
"""
Created on Wed Jul  8 09:23:02 2020

Example of how to load a scan and extract information.

@author: Childresslab
"""

import spinmob as sm
import numpy as np
import matplotlib.pyplot as plt 

# Each column of d is a columns of the scan
d = sm.data.load(text='Select Scan')


invert_y = True

# Hardcoded scale parameters (obtained by scanning a resolution target)
convx = 9.24 #um/V
convy = 6.30 #um/V



xmin = d.headers['Vx_min']
xmax = d.headers['Vx_max']
Nx = d.headers['Nx']
ymin = d.headers['Vy_min']
ymax = d.headers['Vy_max']
Ny = d.headers['Ny']

xs = np.linspace(xmin, xmax, Nx)*convx
ys = np.linspace(ymin, ymax, Ny)*convy
if invert_y:
    # Inver the direction of y
    ys *= -1 

# Shift the zero, for convenience
xs -= min(xs)
ys -= min(ys)    

# We can look at the image by doing this:
fig = plt.figure()
ax = fig.add_subplot(111)
cs = ax.pcolor(xs, ys,np.array(d)*1e-3, cmap='cubehelix')
cb = fig.colorbar(cs, orientation='horizontal', fraction=.1)
cb.set_label('KCount/sec')
ax.set_xlabel('x (um)')
ax.set_ylabel('y (um)')
ax.set_xlim([min(xs), max(xs)])
ax.set_ylim([min(ys), max(ys)])
ax.set_aspect('equal')
plt.title(d.path, fontsize=9)
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    