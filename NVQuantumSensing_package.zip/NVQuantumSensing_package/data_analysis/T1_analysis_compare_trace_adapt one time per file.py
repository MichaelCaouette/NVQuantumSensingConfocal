# -*- coding: utf-8 -*-
"""
Created on Mon Jun 21 10:23:43 2021

Goal:
    Compare the sensitivity of adaptive and time-trace protocole

@author: Childresslab

"""

import T1_process_func as _T1_f

import spinmob as sm
import numpy as np
import matplotlib.pyplot as plt

# Define the model function
def model_plus(t, gp, gm):
    return _T1_f.model_00m0(+1, t, gp, gm)
def model_minus(t, gp, gm):
    return _T1_f.model_00m0(-1, t, gp, gm) 


# Get the data
# The adaptive data
ds_adapt = sm.data.load_multiple(text='Batch of Datas frrom adaptive measurements')
# The time trace
ds_trace = sm.data.load_multiple(text='Batch of Datas frrom time trace measurements')


# =============================================================================
### Process the time trace measurement
# =============================================================================

# Extract each the list of cumulative inference from each data file
print('Restructuring and processing the time trace...')
out = _T1_f.cum_rates_bayes_restructured_data(ds_trace, 
                                              model_plus, model_minus, 
                                              N_split=30)
list_trace_elapsed, list_trace_gp, list_trace_egp, list_trace_gm, list_trace_egm = out
print('Job done !')

# Get the total time elapsed, from the last file. 
print('Warning: we asusme that the last file is the latest')
t_in  = ds_trace[-1].headers['Time_initial']
t_end = ds_trace[-1].headers['Time_finish']
dt_trace = t_end - t_in 

# Compute the interpolated sensitivity (Fromt all the data)
tempo = list_trace_gp[-1], list_trace_egp[-1], list_trace_gm[-1], list_trace_egm[-1]
gp_trace, egp_trace, gm_trace, egm_trace = tempo
sens_trace = ( ((egp_trace/gp_trace)**2 + 
                (egm_trace/gm_trace)**2 )*(dt_trace) )**0.5

# =============================================================================
### Plot the data and fit of the time trace
# =============================================================================

_T1_f.plot_awesome_data_fit(ds_trace, model_plus, model_minus,
                            gp_trace, gm_trace, egp_trace, egm_trace)

# =============================================================================
### Process the adaptive measurement
# =============================================================================

# Extract each the list of cumulative inference from each data file
out = _T1_f.cum_rates_from_bayes(ds_adapt, model_plus, model_minus)
list_adapt_elapsed, list_adapt_gp, list_adapt_egp, list_adapt_gm, list_adapt_egm = out

# Get the total time elapsed, from the last file. 
print('Warning: we asusme that the last file is the latest')
t_in  = ds_adapt[-1].headers['Time_initial']
t_end = ds_adapt[-1].headers['Time_finish' ]
dt_adapt = t_end - t_in 

# Compute the interpolated sensitivity (Fromt all the data)
last_resuts = list_adapt_gp[-1], list_adapt_egp[-1], list_adapt_gm[-1], list_adapt_egm[-1]
gp_adapt, egp_adapt, gm_adapt, egm_adapt = last_resuts
sens_adapt = ( ((egp_adapt/gp_adapt)**2 + 
                (egm_adapt/gm_adapt)**2 )*(dt_adapt) )**0.5

# =============================================================================
### Plot the data and fit of the Adaptive
# =============================================================================
_T1_f.plot_awesome_data_fit(ds_adapt, model_plus, model_minus,
                            gp_adapt, gm_adapt, egp_adapt, egm_adapt)



# =============================================================================
# Print the comparison of the two
# =============================================================================
print('Trace: G+ = %f +- %f; G- = %f +- %f'%(gp_trace, egp_trace, gm_trace, egm_trace))
print('Adapt: G+= = %f +- %f; G- = %f +- %f'%(gp_adapt, egp_adapt, gm_adapt, egm_adapt))
print()
print('Trace: G+ = %f +- %f kHz; G- = %f +- %f'%(gp_trace*1e-3, egp_trace*1e-3, gm_trace*1e-3, egm_trace*1e-3))
print('Adapt: G+= = %f +- %f; G- = %f +- %f'%(gp_adapt*1e-3, egp_adapt*1e-3, gm_adapt*1e-3, egm_adapt*1e-3))

# Just adapt, printed in a cool way
print()
print('Adapt')
print('G+ = %.2f +- %.2f kHz\nG- = %.2f +- %.2f kHz'%(gp_adapt*1e-3, egp_adapt*1e-3, gm_adapt*1e-3, egm_adapt*1e-3) )


# =============================================================================
### Plot the comparison of the two protocol
# =============================================================================
c_trace = 'C0' # Color for the trace
c_adapt = 'C1' # Color for the adaptive


plt.figure(tight_layout=True)

# For the rate +
#ax_gp = plt.subplot(221)
ax_gp = plt.subplot(211) # Simpler for svg files

# The Time trace uncertainty (Interpolated)
rel_p_trace = egp_trace/gp_trace
sens_p_trace = rel_p_trace * dt_trace**0.5
t_interp   = np.linspace(list_trace_elapsed[0], list_trace_elapsed[-1], 10)
rel_interp = sens_p_trace / t_interp**0.5
plt.plot(t_interp, rel_interp,'-%s'%c_trace, label='Non-Adaptive')
# The Adaptive uncertainty (Interpolated)
rel_p_adapt = egp_adapt /gp_adapt 
sens_p_adapt  = rel_p_adapt  * dt_adapt **0.5
t_interp   = np.linspace(list_adapt_elapsed[0], list_adapt_elapsed[-1], 10)
rel_interp = sens_p_adapt  / t_interp**0.5
plt.plot(t_interp, rel_interp, '-%s'%c_adapt, label='Adaptive')
# The Trace uncertainty (Experimental)
list_rel = list_trace_egp / list_trace_gp
plt.plot(list_trace_elapsed, list_rel, '.%s'%c_trace)
# The Adaptive uncertainty (Experimental)
list_rel = list_adapt_egp / list_adapt_gp
plt.plot(list_adapt_elapsed, list_rel, '.%s'%c_adapt)
# Some enhancement
plt.legend(loc='best')
plt.title('Relative uncerainty', fontsize=15)
plt.ylabel('e$\Gamma_+$', fontsize=15)
plt.xscale('log')
plt.yscale('log')
ax_gp.set_xticklabels([])

# For the rate -
#ax_gm = plt.subplot(223, sharex=ax_gp)
ax_gm = plt.subplot(212, sharex=ax_gp) # Simpler for svg files
# The Time trace uncertainty (Interpolated)
rel_m_trace = egm_trace/gm_trace
sens_m_trace = rel_m_trace * dt_trace**0.5
t_interp   = np.linspace(list_trace_elapsed[0], list_trace_elapsed[-1], 10)
rel_interp = sens_m_trace / t_interp**0.5
plt.plot(t_interp, rel_interp,'-%s'%c_trace, label='Time trace')
# The Adaptive uncertainty (Interpolated)
rel_m_adapt = egm_adapt /gm_adapt 
sens_m_adapt  = rel_m_adapt  * dt_adapt **0.5
t_interp   = np.linspace(list_adapt_elapsed[0], list_adapt_elapsed[-1], 10)
rel_interp = sens_m_adapt  / t_interp**0.5
plt.plot(t_interp, rel_interp, '-%s'%c_adapt, label='Adaptive')
# The Trace uncertainty (Experimental)
list_rel = list_trace_egm / list_trace_gm
plt.plot(list_trace_elapsed, list_rel, '.%s'%c_trace)
# The Adaptive uncertainty (Experimental)
list_rel = list_adapt_egm / list_adapt_gm
plt.plot(list_adapt_elapsed, list_rel, '.%s'%c_adapt)
# Some enhancement
plt.ylabel('e$\Gamma_-$', fontsize=15)
plt.xlabel('Total elapsed time (sec)', fontsize=15)
plt.xscale('log')
plt.yscale('log')

# The combined sensitivity
ax = plt.subplot(224)
# For the time trace (interpolated)
t_interp   = np.linspace(1, dt_trace , 10)
sens = ( sens_p_trace**2 + sens_m_trace**2 )**0.5
plt.plot(t_interp, 0*t_interp+sens,'-%s'%c_trace, label='Time trace')
# For the adaptive (interpolated)
t_interp   = np.linspace(1, dt_adapt , 10)
sens = ( sens_p_adapt**2 + sens_m_adapt**2 )**0.5
plt.plot(t_interp, 0*t_interp+sens,'-%s'%c_adapt, label='Time trace')
# For the trace (experimental cumulative)
list_sens = ( ((list_trace_egm / list_trace_gm)**2 + 
               (list_trace_egp / list_trace_gp)**2 ) * list_trace_elapsed )**0.5 
plt.plot(list_trace_elapsed, list_sens, '.%s'%c_trace)
# For the adpative (experimental cumulative)
list_sens = ( ((list_adapt_egm / list_adapt_gm)**2 + 
               (list_adapt_egp / list_adapt_gp)**2 ) * list_adapt_elapsed )**0.5 
plt.plot(list_adapt_elapsed, list_sens, '.%s'%c_adapt)
plt.ylabel('Relative combined\nSensitivity')
plt.xlabel('Total elapsed time (sec)')
plt.xscale('log')

# Information on the data 
ax = plt.subplot(222)
ss = ds_adapt[-1].path
str_adapt = ss[:len(ss)//2] + '\n' + ss[len(ss)//2:]
ss = ds_trace[-1].path
str_trace = ss[:len(ss)//2] + '\n' + ss[len(ss)//2:]
str_info = ('File for adaptive: \n'+str_adapt+
            '\n\nFile for Trace: \n'+str_trace) 

plt.text(-0.2, .4, str_info , transform=ax.transAxes,
         fontsize=10, color='black')
plt.axis('off')

























