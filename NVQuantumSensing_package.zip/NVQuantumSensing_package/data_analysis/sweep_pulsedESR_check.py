# -*- coding: utf-8 -*-
"""
Created on Wed Feb 10 07:40:00 2021

Test some model on the pi-pulse data. No dephasing assumed.

@author: Childresslab
"""

import numpy as np
import matplotlib.pyplot as plt


import scipy.optimize as opt
import spinmob as sm


# =============================================================================
# Get the data    
# =============================================================================

# Load multiple pulsed ESR data
ds = sm.data.load_multiple(text='Select many pulsed ESR data')

# Set the name of the coolumns. In case this get changed 
str_setfreq = 'Frequency_(GHz)'
str_setpow  = '/sig_gen_pulsed_ESR/List/P1'
str_c0   = 'Total_counts_0'
str_c1   = 'Total_counts_1'
str_c2   = 'Total_counts_2'
str_rep  = 'repetition'
str_iter = 'iteration'
str_Nr_seq   = 'Nb_readout_per_sequence'
str_dtpulse = '/sig_gen_pulsed_ESR/dt_rf_pulse'



def plot_2D(ax, x, y, Z, cmap='jet'):
    """
    Cosy function to CORRECTLY plot a 2D map. 
    Because, from matplotlib:
        - pcolor clip the last row and column
        - Imshow is very funky
        
    ax:
        ax object for plotting
    x:
        array for the x axis.
    y:
        array for the y axis. 
    Z:
        2D matrix to plot, with the corresponding axis. 
    """
    return ax.imshow(Z, 
                      extent=[min(x), max(x), 
                              min(y), max(y)],
                      origin='lower',
                      interpolation = 'none',
                      aspect='auto',
                      cmap=cmap)    


# Create the data array
fs = []     # List of frequencies
list_P = [] # List of powers
map_c0 = [] # List is list of counts without RF
map_c1 = [] # List is list of counts with RF
signal  = [] # Difference  in count per readout
esignal = [] # Uncertainty in count per readout
# Extract the difference in count rate for each file
for d in ds:
    # Extract the data from each files
    list_P.append(d.headers[str_setpow])
    fs.append(d[str_setfreq]) # Frequency_(GHz)
    
    # Get the number of readout
    repetition = d.headers['repetition']
    iteration  = d.headers['iteration']
    nb_readout_per_seq = d.headers['Nb_readout_per_sequence']
    N_readout = repetition*iteration*nb_readout_per_seq    
    
    # Get the signal
    c0 = d[str_c0] # Count WITHOUT microwave pulses
    c1 = d[str_c1] # Count WITH    microwave pulses
    map_c0.append( c0 )
    map_c1.append( c1 )
    signal .append(  (c0 - c1)/N_readout          )
    esignal.append(  np.sqrt( c0 + c1 ) / N_readout ) # Assuming poissonian noise
    
    
# Transform into numpy array for ease of calculation if needed
signal  = np.array(signal)
esignal = np.array(esignal)
list_f = np.array( fs[0] )# Assum that each list of frequency is the same
list_P = np.array(list_P)
mesh_f, mesh_P = np.meshgrid(list_f, list_P)

# Get other data
dt_rf_pulse = d.headers[str_dtpulse]


# =============================================================================
# Plot the results
# =============================================================================

# Plot just the ms=0 counts (The one just after initiating with the laser)
fig = plt.figure(tight_layout=True)
ax = fig.add_subplot(111)
colorplot = plot_2D(ax, list_f, list_P, map_c0)
cb = fig.colorbar(colorplot, orientation='horizontal', fraction=.1)
cb.set_label('Counts without RF')
ax.set_xlabel('Frequency (GHz)')
ax.set_ylabel('Power (dBm)')
ax.axis('auto')
txt = d.path + '\nPulse duration = %f us'%dt_rf_pulse
plt.title(txt, fontsize=9)


# Plot just the dropping count (The one just after the pi-pulse)
fig = plt.figure(tight_layout=True)
ax = fig.add_subplot(111)
colorplot = plot_2D(ax, list_f, list_P, map_c1)
cb = fig.colorbar(colorplot, orientation='horizontal', fraction=.1)
cb.set_label('Counts with RF')
ax.set_xlabel('Frequency (GHz)')
ax.set_ylabel('Power (dBm)')
ax.axis('auto')
txt = d.path + '\nPulse duration = %f us'%dt_rf_pulse
plt.title(txt, fontsize=9)



fig = plt.figure(tight_layout=True)
ax = fig.add_subplot(111)
F, P = np.meshgrid(list_f, list_P)
colorplot = plot_2D(ax, list_f, list_P, signal)
cb = fig.colorbar(colorplot, orientation='horizontal', fraction=.1)
cb.set_label('Signal = (c0 - C_RF)/N_readout ')
ax.set_xlabel('Frequency (GHz)')
ax.set_ylabel('Power (dBm)')
ax.axis('auto')
txt = d.path + '\nPulse duration = %f us'%dt_rf_pulse
plt.title(txt, fontsize=9)




