# -*- coding: utf-8 -*-
"""
Created on Tuesday Nov 26


This Code is for processing several files containing each one slice. 

By this script we want to estimate the center of the slices by clicking on each spot. 


@author: Michael Caouette


"""
import matplotlib.pyplot as plt
import spinmob as sm
import numpy as np

#Load data file into databoxes
ds = sm.data.load_multiple(text="Select mutliple data files")


ncols =3 #Number of column to plot 


#These will contain the estimate position of the peak
x0s = np.array([])
y0s = np.array([])
z0s = np.array([])


for d in ds:
    
    x = d[0]
    y = d[1]
    z = d[2]
    c = d[3]
       
    plt.tripcolor(x,y,c/1000,cmap="jet")
    plt.title(d.path, fontsize=11)
    #The user click the center. 
    print("Click on the peak !")
    pts = plt.ginput(1,timeout=0) 
    x0s = np.append(x0s, pts[0][0])
    y0s = np.append(y0s, pts[0][1])
    z0s = np.append(z0s, z[0])
    
    plt.close()
   



#find the extrema for a proper plotting
cmin = 100000
cmax = 0
for d in ds:
    c = d[3]
    
    if min(c) < cmin:
        cmin = min(c)
    if max(c) > cmax:
        cmax = max(c)
    
######Plottting
#Number of row to plot according to the number of columns and the number of slice to show
nrows = int(np.ceil(len(ds)/ncols)) 

#The command int(np.ceil(len(ds)/ncols)) compute the lower number of rows regarding the total plot to do. 
fig, axes = plt.subplots(nrows,ncols ) # ,sharey=True)
plt.title(d.path, fontsize=9)
fig.subplots_adjust(wspace=0, hspace=0) #Remove spacing
axs = axes.flat #Flat the axis in order to acces them with a single index

j = -1
for d in ds:
    j+=1
    #This is the x,y,z,count arrays 
    #You may want to add your transformation
    x = d[0]
    y = d[1]
    z = d[2]
    c = d[3]
    #Plot
    tt=axs[j].tripcolor(x,y,c/1000,cmap="jet" )#, vmin = cmin/1000, vmax = cmax/1000)#"hsv")#"RdBu_r")
    #Show the peak
    axs[j].scatter(x0s[j],y0s[j], 
       marker='x', color= 'white', linewidth=6) 
    axs[j].axis("equal")
    axs[j].text(0.1,0.5,"z=%.2f"%z[0], transform=axs[j].transAxes,color='black', fontsize=20)
    
#Colorbar
fig.subplots_adjust(right=0.8)
cbar_ax = fig.add_axes([0.85, 0.15, 0.05, 0.7]) #Set the geometry of the colorbar
fig.colorbar(tt, cax=cbar_ax,label="kcounts/sec")
#Axis label
fig.text(0.5, 0.04, 'x Actuator (mm)', ha='center', va='center')
fig.text(0.1, 0.5, 'y Actuator (mm)', ha='center', va='center', rotation='vertical')






fig, axes = plt.subplots(2,2)

axes[0][0].plot(z0s,x0s,'--xg')
axes[0][0].plot(z0s[0], x0s[0], 'or')
axes[0][0].set_xlabel("z (mm)")
axes[0][0].set_ylabel("x (mm)")

axes[0][1].plot(z0s, y0s,'--xg')
axes[0][1].plot(z0s[0], y0s[0], 'or')
axes[0][1].set_xlabel("z (mm)")
axes[0][1].set_ylabel("y (mm)")

axes[1][0].plot(x0s, y0s, '--xg')
axes[1][0].plot(x0s[0], y0s[0], 'or')
axes[1][0].set_xlabel("x (mm)")
axes[1][0].set_ylabel("y (mm)")

#axes[1][1].errorbar(zs, cs/1000, xerr=ezs, yerr=ecs/1000)
#axes[1][1].plot(zs[0], cs[0]/1000, 'or')
#axes[1][1].set_xlabel("z (mm)")
#axes[1][1].set_ylabel("kcounts")

plt.suptitle(d.path,fontsize=10)
#








# Create the data box
databox_setting = sm.data.databox()

# Fill it up
databox_setting['xs'] = x0s
databox_setting['ys'] = y0s
databox_setting['zs'] = z0s

# Save it with a dialog box
databox_setting.save_file()



#
##Save the path with the counts and everything for further plotting
#a = np.asarray([ x0s, y0s, z0s])
#a= np.transpose(a)
#filename = "magPath_Click "+ d.path.split('/')[-1] 
#np.savetxt(filename, a, delimiter=",")
#
##Save a log file to know what is what
#str1 = "xs ys zs"
#filename2 = filename + "_log" 
#np.savetxt(filename2, np.zeros(1), header= str1)






