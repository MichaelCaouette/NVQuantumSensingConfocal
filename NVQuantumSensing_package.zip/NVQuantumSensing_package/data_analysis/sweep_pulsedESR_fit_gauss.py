# -*- coding: utf-8 -*-
"""
Created on Wed Feb 10 07:40:00 2021

Test some model on the pi-pulse data. No dephasing assumed.

@author: Childresslab
"""

import numpy as np
import matplotlib.pyplot as plt


import scipy.optimize as opt
import spinmob as sm


# =============================================================================
# Get the data    
# =============================================================================

# Load multiple pulsed ESR data
ds = sm.data.load_multiple(text='Select many pulsed ESR data')

# Set the name of the coolumns. In case this get changed 
str_setfreq = 'Frequency_(GHz)'
str_setpow  = '/sig_gen_pulsed_ESR/List/P1'
str_c0   = 'Total_counts_0'
str_c1   = 'Total_counts_1'
str_c2   = 'Total_counts_2'
str_rep  = 'repetition'
str_iter = 'iteration'
str_Nr_seq   = 'Nb_readout_per_sequence'
str_dtpulse = '/sig_gen_pulsed_ESR/dt_rf_pulse'

# =============================================================================
# Define the model and useful functions
# =============================================================================

def model(f, P_dBm, 
          f0, P0_dBm, wf, wp_dBm, ampl):
    """
    Model for the signal of our measurement. 
    
    Here the measurement is assumed to be proportional to the difference in 
    photoluminescence between NOT appliying a microwave pulse and applying a 
    microwave pulse.
    
    Return a function proportionnal to the Population of the ms=+-1 state when 
    the initial population is in ms=0. We assume:
        - NO DEPHASING (Fast pulse)
        - Rotating Wave Approximation 
        - At T=0, the population is ms=0
         
    Choice of input unit:
    Frequencies in GHz --> The conversion in rad/sec is in the code.
    Powers in dBm     --> The conversion in watt is in the code.
    Times in ns       --> This is such that frequency*time is uniteless 
    

    GAUSSIAN PEAK
         
    
    """
    
#    # =========================================================================
#    # The frequencies are converted in rad per sec !!!!!!!!!!!!!!!!!!!!!!!!!!!!! 
#    # =========================================================================
#    # Convert the power from dBm into watt
#    P_watt  = 10**( (P_dBm  - 30)/10 ) # Watt
#    P0_watt = 10**( (P0_dBm - 30)/10 ) # Watt
#    wp_watt = 10**( (wp_dBm - 30)/10 ) # Watt
    
    first = (f - f0) / wf
    sec   = (P_dBm - P0_dBm) / wp_dBm
    
    exponant2 = first**2 + sec**2
    
    return ampl * np.exp( - 0.5 * exponant2 )


def func_for_fit(FandP,
                 f0, P0_dBm, wf, wp_dBm, ampl):
    """
    Function used to fit the model on the data. 
    
    FandP must have the shape [f, p], where f and p are both MESGRIDDED version
    of the two first input of the function "model". 
    The other parameters are the subsequent input of the function "model". 

    The output is ravelled for using the curve_fit function. 
    To unravel it, use, for example,  reshape(np.shape(x))
    
    """
    # Unpack the input
    f = FandP[0]
    p = FandP[1]
    # Compute the function
    z = model(f, p, 
              f0, P0_dBm, wf, wp_dBm, ampl)
    # Change the shape for the curve fit function
    return z.ravel()



def plot_2D(ax, x, y, Z, cmap='jet'):
    """
    Cosy function to CORRECTLY plot a 2D map. 
    Because, from matplotlib:
        - pcolor clip the last row and column
        - Imshow is very funky
        
    ax:
        ax object for plotting
    x:
        array for the x axis.
    y:
        array for the y axis. 
    Z:
        2D matrix to plot, with the corresponding axis. 
    """
    return ax.imshow(Z, 
                      extent=[min(x), max(x), 
                              min(y), max(y)],
                      origin='lower',
                      interpolation = 'none',
                      aspect='auto',
                      cmap=cmap)    


# Create the data array
fs = []     # List of frequencies
list_P = [] # List of powers
signal  = [] # Difference  in count per readout
esignal = [] # Uncertainty in count per readout
# Extract the difference in count rate for each file
for d in ds:
    # Extract the data from each files
    list_P.append(d.headers[str_setpow])
    fs.append(d[str_setfreq]) # Frequency_(GHz)
    
    # Get the number of readout
    repetition = d.headers['repetition']
    iteration  = d.headers['iteration']
    nb_readout_per_seq = d.headers['Nb_readout_per_sequence']
    N_readout = repetition*iteration*nb_readout_per_seq    
    
    # Get the signal
    c0 = d[str_c0] # Count WITHOUT microwave pulses
    c1 = d[str_c1] # Count WITH    microwave pulses
    signal .append(  (c0 - c1)/N_readout          )
    esignal.append(  np.sqrt( c0 + c1 ) / N_readout ) # Assuming poissonian noise
    
    
# Transform into numpy array for ease of calculation if needed
signal  = np.array(signal)
esignal = np.array(esignal)
list_f = np.array( fs[0] )# Assum that each list of frequency is the same
list_P = np.array(list_P)
mesh_f, mesh_P = np.meshgrid(list_f, list_P)


# =============================================================================
# Fit the data to the model
# =============================================================================

guess_f0 = np.mean(list_f)
guess_P0 = np.mean(list_P)
guess_wf = np.max(list_f) - np.min(list_f)
guess_wp = np.max(list_P) - np.min(list_P)
guess_ampl = np.max(signal) - np.min(signal)
tuple_guess = (guess_f0, guess_P0, guess_wf, guess_wp,  guess_ampl)

# Create the fitting function with the constant
def f_fit(FandP, f0, P0_dBm, wf, wp_dBm, ampl):
    return func_for_fit(FandP, f0, P0_dBm, wf, wp_dBm, ampl)

# FIT !
popt, pcov = opt.curve_fit(f_fit, xdata = [mesh_f, mesh_P], 
                           ydata = signal.ravel(), sigma = esignal.ravel(),
                           p0=tuple_guess)

# Get the parameters of the fit
perr = np.sqrt(np.diag(pcov)) #error from the fit. 
f0_fit  = popt[0]
P0_fit  = popt[1]
wf_fit  = popt[2]
wp_fit  = popt[3]
amp_fit = popt[4]
# error
ef0_fit  = perr[0]
eP0_fit  = perr[1]
ewf_fit  = perr[2]
ewp_fit  = perr[3]
eamp_fit = perr[4]


print()
print('Fit f0   = %f +- %f GHz'%(f0_fit , ef0_fit))
print('Fit P0   = %f +- %f dBm '%(P0_fit , eP0_fit))
print('Fit wf = %f +- %f  GHz'%(wf_fit, ewf_fit))
print('Fit wp  = %f +- %f dBm'%(wp_fit, ewp_fit))
print('Fit ampl = %f +- %f  '%(amp_fit, eamp_fit))
print('Expexted ampl: ', 0.006)
print()


z_fit = f_fit([mesh_f, mesh_P], *popt).reshape(np.shape(mesh_f))
res_fit = z_fit - signal

# Compute the Chi2 ! 
dof = len(z_fit.ravel()) - len(popt) # Degree of Freedom
chi2 = np.sum( res_fit**2 / esignal**2 )/dof


# =============================================================================
# Plot the results
# =============================================================================

# Verify the fit over a long range
# Create a smoother mesh
list_x = np.linspace(f0_fit - 5*wf_fit, f0_fit + 5*wf_fit, 600)
list_y = np.linspace(P0_fit - 5*wp_fit, P0_fit + 5*wp_fit,  603)
mesh_x, mesh_y = np.meshgrid(list_x,
                             list_y)
z_smooth = f_fit([mesh_x, mesh_y], *popt).reshape(np.shape(mesh_x))

fig = plt.figure(tight_layout=True)
ax = fig.add_subplot(111)
colorplot = plot_2D(ax, list_x, list_y, z_smooth)
ax.set_xlabel('Frequency (GHz)')
ax.set_ylabel('Power (dBm)')
plt.title('Verify the fit over a long range')

plt.figure(figsize=(12, 8), tight_layout=True)

# The data
ax = plt.subplot(221) 
colorplot = plot_2D(ax, list_f, list_P, signal)
cb = plt.colorbar(colorplot, orientation='horizontal', fraction=.1)
cb.set_label('Differrence in Count/readout')
ax.set_xlabel('Frequency (GHz)')
ax.set_ylabel('Power (dBm)')
# Chop the title
dt_rf_pulse = d.headers[str_dtpulse]
sss = ''
for s in d.path .split(maxsplit=2):
    sss += s + '\n'    
plt.title(sss+ '\ndt_pulse = %f us'%dt_rf_pulse, fontsize=12)

# The fit
ax = plt.subplot(222) 
colorplot = plot_2D(ax, list_f, list_P, z_fit)
cb = plt.colorbar(colorplot, orientation='horizontal', fraction=.1)
cb.set_label('Fit')
ax.set_xlabel('Frequency (GHz)')
ax.set_ylabel('Power (dBm)')
plt.title('Chi2 = %f and %d dof'%(chi2, dof))

# The Residuals
ax = plt.subplot(223) 
colorplot = plot_2D(ax, list_f, list_P, res_fit, cmap='twilight_shifted')
cb = plt.colorbar(colorplot, orientation='horizontal', fraction=.1)
cb.set_label('Residual')
ax.set_xlabel('Frequency (GHz)')
ax.set_ylabel('Power (dBm)')

# The data with the fitted parameters
ax = plt.subplot(224) 
colorplot = plot_2D(ax, list_f, list_P, signal)
cb = plt.colorbar(colorplot, orientation='horizontal', fraction=.1)
# Contour
# Create a smoother mesh
mesh_x, mesh_y = np.meshgrid(np.linspace(np.min(mesh_f), np.max(mesh_f), 300),
                             np.linspace(np.min(mesh_P), np.max(mesh_P), 303))
z_smooth = f_fit([mesh_x, mesh_y], *popt).reshape(np.shape(mesh_x))
plt.errorbar(f0_fit, P0_fit, xerr=ef0_fit, yerr=eP0_fit, fmt='.k')
plt.contour(mesh_x, mesh_y, z_smooth, 8, colors='w')
cb.set_label('Data with fit')
ax.set_xlabel('Frequency (GHz)')
ax.set_ylabel('Power (dBm)')



