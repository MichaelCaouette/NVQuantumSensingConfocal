# -*- coding: utf-8 -*-
"""
Created on Tue Apr 20 15:56:28 2021

Goal:
    Various functions and calsses for simulating the data.

@author: Childresslab
"""


# Debuger 
_debug_enabled     = False
def _debug(*a):
    if _debug_enabled: 
        s = []
        for x in a: s.append(str(x))
        print(', '.join(s))

import numpy as np
from scipy import interpolate # for the Bayesian finder

def uinverse(A0, eA0, method = 1):
    """
    Propagate the uncertainty in f(A) = 1/A. 
    The formula is more precise than typical error propagtion with 
    linearization. 
    
    Linearization (ie, propagating the uncertainty by assuming
    linear perturbation. Therfore using derivatives of the function) works when
    A is a "gaussian variable": its noise is well defined by a gaussian 
    distribution and not chopped. 
    
    Here, we extended this to the case where:
        - A is expected to be positive
        - The noise in A can be large compared to A. Such that A can be zero or 
          negative, despite the fact that it is expected to be positive (this 
          situation happens when the noise in A is large compared to A).
    
    In order to get the propagation of the error in such a situation, we used 
    Bayesian analysis and considered the mean and standard deviation of the 
    probability density function of f(A), when A is expected to be positive, 
    but can be measured negative or zero because of noise fluctuation. 
    
    For more info on the derivation of the formula, see the notebook of 
    Michael Caouette-Mansour on 2020-11-30,
    in the subsection "Careful error propagation of inverse". 
    
    Input parameters:
        A0:
            Measured mean value of A. Can be begative or zero. 
        eA0:
            Measured uncertainty in A. If zero, the function will return 1/A0
            
        method:
            1 or 2. Which way around and in which order the algebra is made. 
            This influences some numerical round-off .
            
    return:
        z0:
            Best estimate of 1/A.
        ez0:
            Best uncertainty in z0.
    """
    if method == 1:
        """
        This method avoids division by zero if A0 = 0, 
        """
        # A ratio used many time
        ratio = A0/(eA0*eA0)
        # A product used many time
        eA02 = eA0*eA0
        # Expectation for f(A). Formula comes from careful Bayes analysis.
        z0 = 0.25*( (ratio*ratio + 8/(eA02))**0.5 - ratio)
        # Second derivative of the logarithm of the pdf of f(A)
        z02 = z0*z0 # A quantity used many time
        dL2dz2 = 2*ratio/(z02*z0) + 2/z02 - 3/(eA02*z02*z02) 
        
        #Uncertainty in f(A). Formula comes from careful Bayes analysis.
        ez0 = 1/ (-dL2dz2)**0.5
        # Here we go.
        return z0, ez0
    
    elif method == 2:
        """
        This method is more compact and may be better the deal with numerical
        round-off error. However, if A0=0, there is a division by zero. 
        """
        # A ratio used many time
        ratio = A0/(eA0*eA0) 
        relative = eA0 / A0
        
        z0 = 0.25*ratio*( ( 1 + 8*relative*relative )**0.5 - 1 )
        
        # Second derivative of the logarithm of the pdf of f(A)
        z02 = z0*z0 # A quantity used many time
        # A product used many time
        eA02 = eA0*eA0        
        dL2dz2 = 2*ratio/(z02*z0) + 2/z02 - 3/(eA02*z02*z02) 
        
        #Uncertainty in f(A). Formula comes from careful Bayes analysis.
        ez0 = 1/ (-dL2dz2)**0.5
        # Here we go.
        return z0, ez0        

    elif method == 3:
        """
        This another way to wrtie down the equation. 
        This as no 1/A0 and therefore I hope it will not have issues with 
        division by zero. 
        """
        # A ratio used many time
        ratio = A0/(eA0*eA0) 
        relative = eA0 / A0
        
        z0 = 0.25*(1/eA0)*( ( (A0/eA0)**2 + 8 )**0.5 - A0/eA0)
        
        # Second derivative of the logarithm of the pdf of f(A)
        z02 = z0*z0 # A quantity used many time
        # A product used many time
        eA02 = eA0*eA0        
        dL2dz2 = 2*ratio/(z02*z0) + 2/z02 - 3/(eA02*z02*z02) 
        
        #Uncertainty in f(A). Formula comes from careful Bayes analysis.
        ez0 = 1/ (-dL2dz2)**0.5
        # Here we go.
        return z0, ez0              
        
    

def uDiffRatio(x1, ex1, x2, ex2,
               x3, ex3, x4, ex4):
    """
    Return the differentio-Ratio measurement of 4 quantity, with the propagated
    uncertainty. 
    
    We want to evaluate z = ( x1 - x2 ) / ( x3 - x4)
    
    We linearly propagate the error in the numnerator and the denominator. 
    But we are more careful for when taking the ratio. We use a non-linear 
    error propagation for the inverse. 
    
    
    """
    # Combine the results
    Top = x1 -x2
    Bot = x3 - x4
    # Linearly propagate the error in the numerator and dominator
    eTop = ( ex1*ex1 + ex2*ex2 )**0.5   # Uncertainty in the numerator
    eBot = ( ex3*ex3 + ex4*ex4 )**0.5 # Uncertainty in the bottom
    # Non-linearly propagate the error in the inverse of the bottom
    inv_bot, einv_bot = uinverse(Bot, eBot, method=2)
    # Finnaly, the resulting best estimate and uncertainty
    z = Top*inv_bot
    
    # I comment this, because is either Top or inv_bot is zero, it leads to 
    # division by zero.
#    ez = z * ( (eTop/Top)**2 + (einv_bot/inv_bot)**2 )**0.5
    ez = ( (Top*einv_bot)**2 + (inv_bot*eTop)**2 )**0.5
    
    return z, ez


    






# =============================================================================
# Define the time evolution for the populations
# Define the differential-ratio measurement for any type of single measurement
# =============================================================================
"""
The functions ' prefact_rj ' return the two prefactors in the time evolution of
the population when the state is initiated in ms = j and we read the
state ms = r.  
"""

def g0(gp, gm):
    return ( gp*gp + gm*gm - gp*gm )**0.5

def prefact_00(gp, gm):
    b_p = 2*g0(gp, gm) + gp + gm
    b_m = 2*g0(gp, gm) - gp - gm
    return b_p, b_m
    
def prefact_p0(gp, gm):
    b_p = -g0(gp, gm) - 2*gp + gm
    b_m = -g0(gp, gm) + 2*gp - gm
    return b_p, b_m

def prefact_m0(gp, gm):
    b_p = -g0(gp, gm) + gp - 2*gm
    b_m = -g0(gp, gm) - gp + 2*gm
    return b_p, b_m   

def prefact_0p(gp, gm):
    # Symmetry
    return prefact_p0(gp, gm)

def prefact_pp(gp, gm):
    b_p = 2*g0(gp, gm) + gp - 2*gm
    b_m = 2*g0(gp, gm) - gp + 2*gm
    return b_p, b_m

def prefact_mp(gp, gm):
    b_p = -g0(gp, gm) + gp + gm
    b_m = -g0(gp, gm) - gp - gm
    return b_p, b_m

def prefact_0m(gp, gm):
    # Symmetry
    return prefact_m0(gp, gm)

def prefact_pm(gp, gm):
    # Symmetry
    return prefact_mp(gp, gm)

def prefact_mm(gp, gm):
    b_p = 2*g0(gp, gm) - 2*gp + gm
    b_m = 2*g0(gp, gm) + 2*gp - gm
    return b_p, b_m

"""
These lists will simplify the functions that output the measurement as a 
function of the type of single-measurement.
"""
# List the possible type of single measurement
list_type = ['00', '+0', '-0', '++', '-+', '--']
# List the corresponding prefactor function
list_f = [prefact_00, prefact_p0, prefact_m0,
          prefact_pp, prefact_mp, prefact_mm]
    

def prefact_type(gp, gm, str_type='00'):
    """
    Return the two prefactors depending on the choosen type of 
    single-measurement.
    """
    # Get the index of the element in the list that match the input.
    index = np.array(list_type) == str_type
    # Get the corresponding function
    function = np.array(list_f)[index][0]
    # Compute the prefactors
    b_p, b_m = function(gp, gm)
    return b_p, b_m


def pop(t, gp, gm, str_rj = '00'):
    """
    Return the population at time t of r when initiated in j. 
    """
    
    b_p, b_m = prefact_type(gp, gm, str_type=str_rj)

    djee_not = g0(gp, gm)
    beta_p = gp + gm + djee_not
    beta_m = gp + gm - djee_not

    term_p = b_p * np.exp(-beta_p*t)
    term_m = b_m * np.exp(-beta_m*t)
    
    return 1/3  + (1/(6*djee_not)) * (term_p + term_m)
    


    

def diff_ratio(t, gp, gm, type1='00', type2='++', verify_zero=False):
    """
    Model for the famous diffential-ratio measurement depending on the two choice 
    of single-measurement. 
    """
    # Get the two prefactors of each type of single measurement
    b1_p, b1_m = prefact_type(gp, gm, str_type=type1)
    b2_p, b2_m = prefact_type(gp, gm, str_type=type2)
    # Compute the ratio of the differencs
    # The effectiv rates in the exponential
    beta_p = gp + gm + g0(gp, gm)
    beta_m = gp + gm - g0(gp, gm)
    # The difference of each prefactor
    diff_p = b1_p - b2_p
    diff_m = b1_m - b2_m
    # The numerator and denominator
    top = diff_p*np.exp(-beta_p*t) + diff_m*np.exp(-beta_m*t)
    bot = diff_p + diff_m
    
    # Return a warniong string if the denominator is zero
    if verify_zero:
        try:
            if 0 in bot:
                return 'zero'
            else:
                pass
        except:
            pass
        try:
            if bot == 0:
                return 'zero'
            else:
                pass
        except:
            pass
    
    # If we pass here, it is okay to take the ratio        
    return top/bot


def PL(BG, PL0, C, t, gp, gm, str_rj = '00'):
    """
    Measured photoluminescence of a pulse sequence after initiating the 
    tatse j and reading the state r. 
    
    BG, PL0, C: 
        Experimental parameters (Background, PL0 and ocntrast)
    """
    
    rho = pop(t, gp, gm, str_rj)
    
    return BG + PL0*(1-C) + PL0*C*rho


def noisy_diff_ratio(N,BG, PL0, C, t, gp, gm, 
                               type1='00', type2='++'):
    """
    Compute the experimental noise in the diff-ratio measurement. 
    
    N:
        Number of readout. 
    """
    
    # Theoretical experimental measurement
    PL1 = PL(BG, PL0, C, t, gp, gm, str_rj = type1)
    PL2 = PL(BG, PL0, C, t, gp, gm, str_rj = type2)
    PL3 = PL(BG, PL0, C, 0, gp, gm, str_rj = type1)
    PL4 = PL(BG, PL0, C, 0, gp, gm, str_rj = type2) 
    
    # Theoretical experimental noise 
    ePL1 = ( PL1 / N )**0.5
    ePL2 = ( PL2 / N )**0.5
    ePL3 = ( PL3 / N )**0.5
    ePL4 = ( PL4 / N )**0.5
    
#    print(np.mean(ePL1 / PL1) )
    # Theoretical experimental diff-ratio with noise
    z, ez = uDiffRatio(PL1, ePL1, PL2, ePL2, 
                               PL3, ePL3, PL4, ePL4)   
    return z, ez

                 
    
class DiffRatio():
    """
    Class for convenentliy accessing the function with a signature. 
    """

    def __init__(self, type1='00', type2='++'):   
        """
        typei:
            (string) type of measurement 
        """
        self.type1 = type1
        self.type2 = type2
        
    def model(self, t, gp, gm):
        """
        This function as the correct signature for some uses.
        """
        return diff_ratio(t, gp, gm, 
                          type1=self.type1, 
                          type2=self.type2)
        
        
class DiffRatioNoise():
    """
    Class for convenentliy accessing the function with a convenient signature.
    It also provides the expected noise.
    
    This can be used for simulating a measurement.
    
    """

    def __init__(self, N, BG, PL0, C, type1='00', type2='++'):   
        """
        typei:
            (string) type of measurement 
            
        other inputs:
            Same input as the function "noisy_diff_ratio"
        """
        self.type1 = type1
        self.type2 = type2
        
        self.N   = N
        self.BG  = BG
        self.PL0 = PL0
        self.C   = C
        
    def model(self, t, gp, gm):
        """
        This function as the correct signature for some uses.
        """
        return noisy_diff_ratio(self.N, self.BG, self.PL0, self.C,
                                t, gp, gm, 
                                type1=self.type1, 
                                type2=self.type2)
        
    def model_meas(self, t, gp, gm):
        """
        This function as the correct signature for some uses.
        """
        return noisy_diff_ratio(self.N, self.BG, self.PL0, self.C,
                                t, gp, gm, 
                                type1=self.type1, 
                                type2=self.type2) [0]
        
    def model_unc(self, t, gp, gm):
        """
        This function as the correct signature for some uses.
        """
        return noisy_diff_ratio(self.N, self.BG, self.PL0, self.C,
                                t, gp, gm, 
                                type1=self.type1, 
                                type2=self.type2) [1]
        
        
        
if __name__ == '__main__':
    """
    Test the formula
    """    
    import matplotlib.pyplot as plt

    # steal spinbom._functions.erange
    def flog(start, end, steps):
        """
        Returns a numpy array over the specified range taking geometric steps.
        See also numpy.logspace()
        """
        if start == 0:
            print("Nothing you multiply zero by gives you anything but zero. Try picking something small.")
            return None
        if end == 0:
            print("It takes an infinite number of steps to get to zero. Try a small number?")
            return None
    
        # figure out our multiplication scale
        x = (1.0*end/start)**(1.0/(steps-1))
    
        # now generate the array
        ns = np.array(list(range(0,steps)))
        a =  start*np.power(x,ns)
    
        # tidy up the last element (there's often roundoff error)
        a[-1] = end
    
        return a
    
    # =============================================================================
    # Test the inverse formula and compare with the linear method
    # =============================================================================
    # We are gonna test 1/x0
    
    x0 = 1
    
    # List of relative uncertainty of each measurement
    
    #Non-linear approach
    list_relunc = flog(0.00001, 0.99, 1000)
    list_ex0  = list_relunc*x0
    list_nonlin_z, list_nonlin_ez = uinverse(x0, list_ex0, method=2)
    # Linear approach
    list_lin_z = 1/x0 + 0*list_ex0
    list_lin_ez = list_lin_z * np.abs(list_ex0 / x0)

    # Compare the linear and non-linear method
    plt.figure(tight_layout=True)
    ax = plt.subplot(211)
    plt.plot(list_relunc, list_nonlin_z, label='Non-linear')
    plt.plot(list_relunc, list_lin_z, label='Linear')
    plt.xlabel('Relative uncertainty in x')
    plt.ylabel('Estimate of 1/x')
    plt.xscale('log')
    plt.legend()
    plt.title('x = %f'%x0)
    
    ax = plt.subplot(212)
    plt.plot(list_relunc, list_nonlin_ez, label='Non-linear')
    plt.plot(list_relunc, list_lin_ez, label='Linear')
    plt.xscale('log')
    plt.xlabel('Relative uncertainty in x')
    plt.ylabel('Uncertainty of 1/x')
    
    # =========================================================================
    # Test the diff-ratio formula and compare with the linear method
    # =========================================================================
    
    x1, x2, x3, x4 = 4.1, 4.1, 2, 2.1
    # List of relative uncertainty of each measurement
#    list_relunc = np.linspace(0.01, 0.99, 100)
    list_relunc = flog(0.00001, 0.99, 1000)
    ex1 = list_relunc * x1
    ex2 = list_relunc * x2
    ex3 = list_relunc * x3
    ex4 = list_relunc * x4
    
    # Non-linear approach
    nonlin_z, nonlin_ez = uDiffRatio(x1, ex1, x2, ex2, x3, ex3, x4, ex4)  
    # Linear approach
    lin_z  = (x1 - x2) / (x3 - x4) + 0*list_relunc
    lin_ez = ( (ex1**2+ex2**2)*(x3-x4)**2 + 
                       (ex3**2+ex4**2)*(x1-x2)**2 )**0.5    
#    lin_ez = lin_z * ( (ex1**2+ex2**2)/(x1-x2)**2 + 
#                       (ex3**2+ex4**2)/(x3-x4)**2 )**0.5
    
    # Compare the linear and non-linear method
    plt.figure(tight_layout=True)
    ax = plt.subplot(211)
    plt.plot(list_relunc, list_nonlin_z, label='Non-linear')
    plt.plot(list_relunc, list_lin_z, label='Linear')
    plt.xlabel('Relative uncertaintyin \neach variable')
    plt.ylabel('Estimate of (x1 - x2) / (x3 - x4)')
    plt.xscale('log')
    plt.legend()
    plt.title('(x1 - x2) / (x3 - x4) = (%.1f - %.1f) / (%.1f - %.1f)'%(x1, x2, x3, x4))
    
    ax = plt.subplot(212)
    plt.plot(list_relunc, list_nonlin_ez, label='Non-linear')
    plt.plot(list_relunc, list_lin_ez, label='Linear')
    plt.xscale('log')
    plt.xlabel('Relative uncertaintyin \neach variable')
    plt.ylabel('Uncertainty of (x1 - x2) / (x3 - x4)')
    

    # =========================================================================
    # Sanity check the differential ratio
    # Check various combinations and the experimental version
    # =========================================================================
    # Define the parameters of the experiment
    true_gp = 5 # kHz
    true_gm = 8 # kHz
    ts = np.linspace(0, 2/true_gm, 500) # ms
    # From the apparatus
    BG  = 0.01
    PL0 = 0.02
    C   = 0.25
    N   = 4e8
    
    # Take all the possible combination
    from itertools import combinations as combibi
    comb = combibi(list_type, 2)
    list_combi= []
    for i in list(comb): 
        list_combi.append(i)    
        
    print()    
    print('There is %d possible combination'%len(list_combi))
    
    # Plot each combination    
    plt.figure(tight_layout=True)
    # Start by ploting the model
    ax_model = plt.subplot(311)
    plt.title('Check each possible diffential-ratio measurement'+
              '\nRate+ = %.1f kHz'%true_gp +
              '\nRate- = %.1f kHz'%true_gm)
    # Also verify if there is a division by zero
    list_okay_combi = []
    for duo in list_combi:
        type1 = duo[0]
        type2 = duo[1]
        # Check if there is zero
        ys_model = diff_ratio(ts, true_gp, true_gm, type1, type2, 
                              verify_zero=True)
        
        if type(ys_model) == str:
            print('Division by zero in %s'%str(duo))
        else:
            list_okay_combi.append(duo)
            # Plot the model
            plt.plot(ts, ys_model, label=str(duo))    
    plt.legend(title='Pair', 
               bbox_to_anchor=(1.00, 1),loc='upper left') 
    plt.ylabel('Diff-ratio measurement')
    
    print('Only %d combinations do not divide by zero'%len(list_okay_combi))
    print()
    
    # Plot the Ratio in population from the solution
    ax_pop_dr = plt.subplot(312)
    for duo in list_okay_combi:
        type1 = duo[0]
        type2 = duo[1]
        
        p1 = pop(ts, true_gp, true_gm, str_rj = type1)
        p2 = pop(ts, true_gp, true_gm, str_rj = type2)
        p3 = pop(0 , true_gp, true_gm, str_rj = type1)
        p4 = pop(0 , true_gp, true_gm, str_rj = type2)
        
        dr_pop = (p1 - p2) / (p3 - p4)
            
        plt.plot(ts, dr_pop)
        
    plt.ylabel('(p1 - p2) / (p3 - p4)')    
           
    
    # Plot the experimental expectation
    ax_noisy = plt.subplot(313)
    for duo in list_okay_combi:
        type1 = duo[0]
        type2 = duo[1]
        # Check if there is zero
        z, ez = noisy_diff_ratio(N, BG, PL0, C, 
                                 ts, true_gp, true_gm, type1, type2)      
        plt.errorbar(ts, z, yerr=ez, label=str(duo))
        
    plt.xlabel('Time (ms)')
    plt.ylabel('Diff-ratio measurement')    




