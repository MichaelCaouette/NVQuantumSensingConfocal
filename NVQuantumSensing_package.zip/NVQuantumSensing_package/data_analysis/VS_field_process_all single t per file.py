# -*- coding: utf-8 -*-
"""
Created on Tue Apr 13 08:56:06 2021

Goal:
    Process the data from T1 Vs field

@author: Childresslab
"""

# Load the function for computing the field. 
from B_process_function import uBperp, uBz
import T1_process_func as _T1
import VS_field_func_load_data as _load

import spinmob as sm
import numpy as np
import matplotlib.pyplot as plt 

# Define the fitting function
def model_1(t, gp, gm):
    return _T1.model_00m0(+1, t, gp, gm)
def model_2(t, gp, gm):
    return _T1.model_00m0(-1, t, gp, gm)


# Get the list of the directory of each magnet positon
str_key_mag = 'mag_pos' # comment string in the name of the magnet position
i_min = 0 # Minimum folder to check
i_max = 99 # Maximum folder to check
want_save = False # Set to true for poping a window for saving the processed data
  

# Load the data files of the ESR, Rabi, and other
out = _load.get_list_data_file(i_min=i_min, i_max=i_max)  
list_folder_mag, directory_main, (list_d_magpos, 
                                  list_d_ESR_p, list_d_Rabi_p, 
                                  list_d_ESR_m, list_d_Rabi_m) = out                 
N_field = len(list_folder_mag)
       

# Name of the folder containing pipulse minus and plus data
folder_name_minus = 'pipulse_minus' # Name of the folder containtin the pipulse minus data
folder_name_plus  = 'pipulse_plus'  # Name of the folder containtin the pipulse plus data
folder_name_T1    = 'T1'    # Folder Containing T1 data 
key_file_ESR       = 'ESR' # Key in the name of the file for the ESR data
key_file_RabiPower = 'Rabi_Power' # Key in the name of the file for the Rabi Power data
key_file_T1        = 'T1' # Key in the name of the file for the T1 data
file_mag_pos = 'magnet_position.dat'
# Set the name of the coolumns. In case this get changed 
str_setfreq = 'Frequency_(GHz)'
str_setpow  = 'Power_(dBm)'
str_c0   = 'Total_counts_0'
str_c1   = 'Total_counts_1'
str_rep  = 'repetition'
str_iter = 'iteration'
str_Nr_seq   = 'Nb_readout_per_sequence'
str_dtpulse = '/sig_gen_pulsed_ESR/dt_rf_pulse'
str_f0 = 'mean_f0'
str_ef0 = 'std_f0'
str_P0 = 'mean_P0'
str_eP0 = 'std_P0'
str_gp  = 'gamma_plus' 
str_egp = 'egamma_plus' 
str_gm  = 'gamma_minus' 
str_egm = 'egamma_minus' 
str_start_time = 'starting_time_sec'
str_time_ela = 'absolute_time_sec'
str_t_pulse_sequence = 'duration_pulse_sequence'


# For each magnet position, extract the pi-pulse
list_mag_x = np.zeros(N_field)
list_mag_y = np.zeros(N_field)
list_mag_z = np.zeros(N_field)
list_minus_f0  = np.zeros(N_field)
list_minus_ef0 = np.zeros(N_field)
list_minus_P0  = np.zeros(N_field)
list_minus_eP0 = np.zeros(N_field)
list_plus_f0  = np.zeros(N_field)
list_plus_ef0 = np.zeros(N_field)
list_plus_P0  = np.zeros(N_field)
list_plus_eP0 = np.zeros(N_field)
list_Bz     = np.zeros(N_field)
list_eBz    = np.zeros(N_field)
list_Bperp  = np.zeros(N_field)
list_eBperp = np.zeros(N_field)
list_gp  = np.zeros(N_field)
list_egp = np.zeros(N_field) 
list_gm  = np.zeros(N_field)
list_egm = np.zeros(N_field)
list_chi2 = np.zeros(N_field)
list_dof  = np.zeros(N_field)
list_time_decay = np.zeros(N_field) # Total time spend on letting the state to decay

list_t_T1_pulse_seq = np.zeros(N_field)

print()
for i, folder_mag in enumerate( list_folder_mag):
    
    print('Processing file %d / %d'%(i, len(list_folder_mag)))
        
    # =============================================================================
    # Get the magnet position
    # =============================================================================    
    databox = list_d_magpos[i]
    list_mag_x[i] = databox.headers['x_magnet'] 
    list_mag_y[i] = databox.headers['y_magnet'] 
    list_mag_z[i] = databox.headers['z_magnet'] 
    
    # =============================================================================
    #     # Get the pi-pulse minus data
    # =============================================================================
    databox_ESR = list_d_ESR_m[i]
    databox_RP  = list_d_Rabi_m[i]          
    # Extract what we want
    list_minus_f0[i]  = databox_ESR.headers[str_f0]  
    list_minus_ef0[i] = databox_ESR.headers[str_ef0] 
    list_minus_P0[i]  = databox_RP.headers[str_P0]  
    list_minus_eP0[i] = databox_RP.headers[str_eP0] 
     
    # =============================================================================
    #     # Get the pi-pulse plus data
    # =============================================================================
    databox_ESR = list_d_ESR_p[i]
    databox_RP  = list_d_Rabi_p[i]           
    # Extract what we want
    list_plus_f0[i]  = databox_ESR.headers[str_f0]  
    list_plus_ef0[i] = databox_ESR.headers[str_ef0] 
    list_plus_P0[i]  = databox_RP.headers[str_P0]  
    list_plus_eP0[i] = databox_RP.headers[str_eP0]    

    # =============================================================================
    # Get the magnetic field from the pi-pulse
    # =============================================================================    
    fp  = list_plus_f0  [i]
    efp = list_plus_ef0 [i]
    fm  = list_minus_f0 [i]
    efm = list_minus_ef0[i]      
    Bz, eBz = uBz(fp, efp, fm, efm)
    Bperp, eBperp = uBperp(fp, efp, fm, efm)
    # List that
    list_Bz[i]     = Bz     
    list_eBz[i]    = eBz    
    list_Bperp[i]  = Bperp  
    list_eBperp[i] = eBperp 

    # =========================================================================
    # Get the T1 measurement
    # ========================================================================= 
    # Get the rate data
    directory = folder_mag + '/' + folder_name_T1
    list_d = _load.get_list_data_in_one_folder(directory, key_file_T1)
                                
    # Extract what we want
    out_extract = _T1.extract_measurement(list_d)
    # Fit the rate
    out = _T1.rates_from_bayes_from_data(list_d, model_1, model_2)
    gp_fit, egp_fit, gm_fit, egm_fit, _, _ = out 
        
    # =============================================================================
    # Compute the chi2
    # =============================================================================
    tuple_meas = _T1.extract_measurement(list_d)
    chi2, dof = _T1.chi2_and_dof(*tuple_meas, 
                                 model_1, model_2, 
                                 gp_fit, gm_fit)
    
    # Get the total time
    duration_sec = 0
    for d in list_d:
        duration_sec += d.headers['duration_pulse_sequence']
        
    # List that
    list_gp[i]  = gp_fit
    list_egp[i] = egp_fit
    list_gm[i]  = gm_fit
    list_egm[i] = egm_fit  
    list_chi2[i] = chi2
    list_dof[i]     = dof
    list_t_T1_pulse_seq[i] = duration_sec

    # =============================================================================
    # Note the duty cycle    
    # =============================================================================
    time_decay = 0
    for d in list_d:
        t_probe   = d.headers['t_probe'] * 1e-6 # In sec
        N_readout = d.headers['repetition'] * d.headers['iteration'] 
        time_decay += 2 * N_readout * t_probe
    list_time_decay[i] = time_decay
    

print()
print('Processing file done !')    

# =============================================================================
# Save all that
# =============================================================================
d = sm.data.databox()
# Fill the databox with the extracted data
# The frequencies of the pi-pulse
d['f0_minus_(GHz)']  = list_minus_f0
d['ef0_minus_(GHz)'] = list_minus_ef0
d['f0_plus_(GHz)']   = list_plus_f0
d['ef0_plus_(GHz)']  = list_plus_ef0
# the powers of the pi-pulse
d['P0_minus_(dBm)']  = list_minus_P0
d['eP0_minus_(dBm)'] = list_minus_eP0
d['P0_plus_(dBm)']   = list_plus_P0
d['eP0_plus_(dBm)']  = list_plus_eP0
# The magnet position
d['mag_x_mm'] = list_mag_x
d['mag_y_mm'] = list_mag_y
d['mag_z_mm'] = list_mag_z
# The magnetic field
d['Bz_(T)']     = list_Bz
d['eBz_(T)']    = list_eBz
d['Bperp_(T)']  = list_Bperp
d['eBperp_(T)'] = list_eBperp
# The rates
d['gp_Hz']  = list_gp
d['egp_Hz'] = list_egp
d['gm_Hz']  = list_gm
d['egm_Hz'] = list_egm
# Related to the inference
d['chi2_red'] = list_chi2
d['dof']      = list_dof
# The duration
d['pulse_duration_sec'] = list_t_T1_pulse_seq
d['time_decay']         = list_time_decay
# Some headers
d.insert_header('directory', directory)

if want_save:
    # Save it
    d.save_file()


# =============================================================================
# Print how much days has elapsed
# =============================================================================
print()
print('It took %.3f days for running just the T1'%(np.sum(list_t_T1_pulse_seq)/3600/24))
    
# =============================================================================
# Plot that for fun
# =============================================================================
plt.figure(tight_layout=True, figsize=(15,8))

# The frequencies of the pi-pulse
ax = plt.subplot(321)
plt.errorbar(list_Bz*1e3, list_plus_f0 , xerr=list_eBz*1e3, yerr=list_plus_ef0, 
             fmt='.-', label='Plus')
plt.errorbar(list_Bz*1e3, list_minus_f0, xerr=list_eBz*1e3, yerr=list_minus_ef0, 
             fmt='.-', label='Minus')
plt.legend(loc='best')
plt.xlabel('Bz (mT)')
plt.ylabel('Freq (GHz)')

# The rate
ax = plt.subplot(322)
plt.errorbar(list_Bz*1e3, list_gp*1e-3, xerr=list_eBz*1e3, yerr=list_egp*1e-3, 
             fmt='.', label='$\Gamma_+$')
plt.errorbar(list_Bz*1e3, list_gm*1e-3, xerr=list_eBz*1e3, yerr=list_egm*1e-3, 
             fmt='.', label='$\Gamma_-$')
plt.legend(loc='best')
plt.xlabel('Bz (mT)')
plt.ylabel('Rate (kHz)')

# The field
ax = plt.subplot(323)
plt.errorbar(list_Bz*1e3, list_Bperp*1e3, xerr=list_eBz*1e3, yerr=list_eBperp*1e3, 
             fmt='.')
plt.xlabel('Bz (mT)')
plt.ylabel('B_perp (mT)')


# The sensitivities
ax = plt.subplot(324)
eta_p = list_egp * (list_t_T1_pulse_seq) **0.5
eta_m = list_egm * (list_t_T1_pulse_seq) **0.5
plt.errorbar(list_Bz*1e3, eta_p*1e-3, xerr=list_eBz*1e3, 
             fmt='.-', label='$\eta_+$')
plt.errorbar(list_Bz*1e3, eta_m*1e-3, xerr=list_eBz*1e3, 
             fmt='.-', label='$\eta_-$')
plt.legend(loc='best')
plt.xlabel('Bz (mT)')
plt.ylabel('Sensitivity (kHz /sqrt(Hz)')

# The Chi2
ax = plt.subplot(325)
list_echi2 = np.sqrt(2/list_dof)
plt.errorbar(list_Bz*1e3, list_chi2, yerr=list_echi2, 
             fmt='.-')
plt.xlabel('Bz (mT)')
plt.ylabel('Chi2')

# The Duty cycle
ax = plt.subplot(326)
duty = list_time_decay / list_t_T1_pulse_seq

plt.plot(list_Bz*1e3, duty*100, '.-')
plt.xlabel('Bz (mT)')
plt.ylabel('Duty cycle\n(Percent(')




























