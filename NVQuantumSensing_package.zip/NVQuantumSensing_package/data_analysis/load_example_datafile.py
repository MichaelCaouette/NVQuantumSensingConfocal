# -*- coding: utf-8 -*-
"""
Created on Thu Jul  8 07:42:01 2021

Goal: Just load a file

@author: Childresslab
"""

import spinmob as sm
import matplotlib.pyplot as plt

d = sm.data.load(text='Select a datafile')

# Check the ckeys
print(d.ckeys)

# Get the axis names
label_s = []
for key in d.ckeys:
    label_s.append(key)
    
#Check the name of the headers
print(d.headers)    
    


# Plot them
plt.figure(tight_layout=True)

for i in range(len(d)-1):
    
    t = d[0] # x-axis
    y = d[i+1] # Count
    
    plt.plot(t, y,'.-', label=label_s[i+1])

plt.legend()    
plt.xlabel(label_s[0])
plt.ylabel('Colomns')

title = d.path
plt.title(title, fontsize=9)

