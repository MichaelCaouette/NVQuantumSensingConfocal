# -*- coding: utf-8 -*-
"""
Created on Wed Jul  8 07:57:17 2020

Example of how to load the saturation curve

@author: Childresslab
"""



import spinmob as sm
import numpy as np
import matplotlib.pyplot as plt


ds = sm.data.load_multiple(text='Select one or many Rabi data')

# Check the ckeys
print(ds[0].ckeys)

# Plot each data file individually
for d in ds:
    # Get the axis names
    label_s = []
    for key in d.ckeys:
        label_s.append(key)
        
    #Check the name of the headers
    print(d.headers)    
        
    # Plot them
    plt.figure(tight_layout=True)
    for i in range(len(d)-1):
        
        t = d[0] # Time
        y = d[i+1] # Count
        ey = np.sqrt(y) # Error in the counts (assum poissonian noise)
        # Get the count rate
        dt = d.headers['dt_readout'] # count time in us
        rep = d.headers['repetition']
        nb_iter = d.headers['iteration']    
        count_rate  =  y*1e6/(dt*rep*nb_iter)
        ecount_rate = ey*1e6/(dt*rep*nb_iter)
        plt.errorbar(t,1e-3*count_rate,yerr=1e-3*ecount_rate,label=label_s[i+1])
    
    plt.legend(loc='Center Right')    
    plt.xlabel(label_s[0])
    plt.ylabel('KCount/sec')
    
    f = d.headers['Frequency']
    p = d.headers['Power']
    title = d.path+'\nPower %d dBm Freq %.4f GHz'%(p,f)
    plt.title(title, fontsize=9)

# Compare the Rabis
fig, axes = plt.subplots(len(ds), 1, tight_layout=True)
axs = axes.flat #Flat the axis in order to acces them with a single index

for i, d in enumerate( ds ):
    t = d[0] # Time
    y = d['counts'] # Count
    ey = np.sqrt(y) # Error in the counts (assum poissonian noise)
    # Get the count rate
    dt = d.headers['dt_readout'] # count time in us
    rep = d.headers['repetition']
    nb_iter = d.headers['iteration']      
    count_rate  =  y*1e6/(dt*rep*nb_iter)
    ecount_rate = ey*1e6/(dt*rep*nb_iter)
    # Normalize the count and make them prop to the contrast
    y = count_rate
    y_contrast = 100 * ( y - min(y) ) / max(y) 
    ey_contrast = ecount_rate * 100 / max(y) 
    
#    plt.errorbar(t,1e-3*count_rate,yerr=1e-3*ecount_rate, fmt='.',
#                 label=d.path.split('/')[-1])    
#    label = d.path.split('/')[-1]\
    f = d.headers['Frequency']
    p = d.headers['Power']
    label = 'Power %.1f dBm f %.4f GHz'%(p, f)
    axs[i].errorbar(t,y_contrast,yerr=ey_contrast, fmt='.', color='C%d'%i,
                 label=label)  
    axs[i].legend()
    axs[i].set_title(d.path,fontsize=9)
    
plt.xlabel(label_s[0])    
plt.ylabel('100 * ( KCount/sec - min ) / max')
#title = ''
#for i, d in enumerate(ds):
#    title += '\n' + d.path
#plt.title(title, fontsize=9)







