# -*- coding: utf-8 -*-
"""
Created on Tue Jul 20 17:28:01 2021

Goal: check the inference VS time of a 4pts trace

@author: Childresslab
"""

import spinmob as sm
import os
import T1_process_func as _T1_f
import numpy as np
import matplotlib.pyplot as plt

# Define the model function
def model_plus(t, gp, gm):
    return _T1_f.model_00m0(+1, t, gp, gm)
def model_minus(t, gp, gm):
    return _T1_f.model_00m0(-1, t, gp, gm) 

def list_pair_measurement(directory, str_key):
    """
    Pair the measurements in order of "less updated" to "most updated". 
    
    If there is more datafiles for one measurement, will will take the most
    updated and omit some measurements in the list. 
    
    """
    
    # Let's first list all the measurement of each pair
    list_p = []
    list_m = []
    list_dt_p = []
    list_dt_m = []
    
    # Search among the files in the directory. 
    for file in os.listdir(directory):
        if str_key in file:
            
            # Get the file
            path_file = os.path.join(directory, file)  
            d = sm.data.load(path_file) 
            
            # Check which type it is and which duration
            type_meas = d.headers['Type_measure']
            dt        = d.headers['Time_finish'] - d.headers['Time_initial']
            # Update the most recent file 
            if type_meas == +1:
                list_p.append( d )
                list_dt_p.append( dt )
            if type_meas == -1:
                list_m.append( d )
                list_dt_m.append( dt )    
    
    # Now pair the maximum measurements
    N_p = len(list_p)
    N_m = len(list_m)
    
    list_pair = [] 
    # Check the maximum number of pairs
    N = min(N_p, N_m)
    # Pair them
    for i in range(N):
        list_pair.append( (list_p[i], list_m[i]) )            
    # Replace the last pair by the most updated pair
    list_pair[-1] = (list_p[-1], list_m[-1])
    # We now have everything to make happy the most hard-to-satisfy phycisist. 
    return list_pair          
            

key_file_T1 = 'T1' # String key in the name of the T1 datafile


# =============================================================================
# Get the list of pair of measurement
# =============================================================================
txt = 'Select a directory containing the folder with key word %s in the name.'%key_file_T1
path = sm.dialogs.select_directory(text=txt)
list_pair = list_pair_measurement(path, key_file_T1)


# =============================================================================
# Infere the rates for each pair
# =============================================================================
N_pair = len(list_pair)
list_t_elapsed = np.zeros(N_pair)
list_gp        = np.zeros(N_pair)
list_gm        = np.zeros(N_pair)
list_egp       = np.zeros(N_pair)
list_egm       = np.zeros(N_pair)      
list_chi2      = np.zeros(N_pair)   
list_dof       = np.zeros(N_pair)  
list_duty      = np.zeros(N_pair) 

# Let's loooooooooooooop
for i in range(N_pair):
    print('Processing... %d / %d'%(i, N_pair) )
    d_p, d_m = list_pair[i]
    
    
    #Get the structured data
    (xp, yp, eyp, 
     xm, ym, eym,
     list_meas)    = _T1_f.extract_normalized_meas_4pts_trace(d_p, d_m)
    
    # Infere the rates
    out = _T1_f.rates_from_bayes_from_meas(list_meas,
                                           model_plus, model_minus,
                                           Gp_min=0.1e3, Gp_max=50e3, 
                                           Gm_min=0.1e3, Gm_max=50e3, 
                                           N_grid=200)
    gp, egp, gm, egm, corr, my_bayes = out
    list_gp[i]  = gp
    list_gm[i]  = gm
    list_egp[i] = egp
    list_egm[i] = egm    
    
    # Get the chi2
    chi2, dof = _T1_f.chi2_and_dof(xp, yp, eyp, 
                                   xm, ym, eym, 
                                   model_plus, model_minus,
                                    gp, gm)
    list_chi2[i] = chi2
    list_dof [i] = dof
    # Check the duty cycle   
    T_decay = 0
    T_total = 1
    for d in [d_p, d_m]:
        # Total time elapsed
        T_total += d.headers['Time_finish'] - d.headers['Time_initial']
        # Time dedicated to the decay
        repetition = d.headers['repetition']
        iteration  = d.headers['iteration' ]
        N_readout = repetition * iteration
        # The decay time is the total time spent on waiting the decay to happen
        T_decay += N_readout*2*np.sum(d['time_probed_sec'])
    # The duty cycle is the fraction of time spent on waiting on the decay    
    duty = T_decay / T_total    
    list_duty[i] = duty
    list_t_elapsed[i] = T_total
    
    
    
# =============================================================================
# Plot this !
# =============================================================================
plt.figure(tight_layout=True)

# For the rate +
ax_gp = plt.subplot(221)
plt.errorbar(list_t_elapsed, list_gp*1e-3, yerr=list_egp*1e-3, fmt='.' )
plt.xscale('log')
plt.ylabel('Inference $\Gamma_+$')
plt.title(path, fontsize=10)
# For the rate -
ax_gm = plt.subplot(223)
plt.errorbar(list_t_elapsed, list_gm*1e-3, yerr=list_egm*1e-3, fmt='.' )
plt.xscale('log')
plt.xlabel('Total time elapsed (sec)')
plt.ylabel('Inference $\Gamma_-$')
# uncertainty +
ax_egp = plt.subplot(222)
plt.plot(list_t_elapsed, list_egp/list_gp, '.-' )
plt.xscale('log')
plt.yscale('log')
plt.ylabel('Relative error')
# uncertainty -
ax_egm = plt.subplot(224)
plt.plot(list_t_elapsed, list_egm/list_gm, '.-' )
plt.xscale('log')
plt.yscale('log')
plt.ylabel('Relative error')
plt.xlabel('Total time elapsed (sec)')











