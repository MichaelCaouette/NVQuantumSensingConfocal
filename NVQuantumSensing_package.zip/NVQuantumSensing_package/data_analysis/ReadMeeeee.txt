The scripts here are meant to analysis/process some data generated directly by the software. 

They are example and I, a graduate student, denied any responsability for funky results :P 