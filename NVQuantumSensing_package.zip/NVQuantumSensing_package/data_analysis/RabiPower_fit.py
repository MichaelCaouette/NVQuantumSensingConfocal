# -*- coding: utf-8 -*-
"""
Created on Wed Jun 30 08:34:16 2021

@author: Childresslab
"""

import spinmob as sm
import numpy as np



d = sm.data.load(text='Load a RabiPower file')


def f_fit(x, x0, PL0, C, stretch):
    """
    Model for estimating PL0 and C
    
    Input in dBm
        
    """    
    
    phase =  10**( (stretch*(x - x0))/20 ) * np.pi /2
    pop = np.sin( phase)** 2    
    
    return PL0 * (1 - C*pop)
 
    
# =============================================================================
# Fit that
# =============================================================================


list_str_parms = ['x0', 'PL0', 'C', 'stretch']


# Define the string of the headers and columns, in case they change
str_pow   = 'Power_(dBm)'
str_count = 'Total_counts_1' # Count with the RF
str_ref   = 'Total_counts_0' # Count without RF 
str_dt_pulse  = '/sig_gen_pulsed_ESR/dt_rf_pulse'


# =============================================================================
# Get the data to fit
# =============================================================================
x = d[str_pow]
c0 = d[str_count]
c1 = d[str_ref]
# The signal is the count minus the ref
y  = c0
ey = c0**0.5 # Poissonian noise    

# =============================================================================
# FIT !!
# =============================================================================

# The guess
exp_P1 = 15 # dBm
exp_ome = 62 # MHz
exp_tau = d.headers[str_dt_pulse] # us


guess_x0   = 2*exp_P1 / ( exp_tau*exp_ome/np.pi )**2
guess_PL0  = y[0]
guess_C    = (max(y) - min(y)) / guess_PL0
guess_stretch = 1
tuple_guess   = (guess_x0,  guess_PL0, guess_C, guess_stretch)



# The fit
fitter = sm.data.fitter(autoplot = True)
# Set the two function that we simultaneuously fit
fitter.set_functions('pants(x, x0, PL0, C, stretch)', 
                     'x0, PL0, C, stretch', 
                     pants=f_fit)

# Set the data
fitter.set_data(x, y, ey)

#Set the guess
fitter.set(x0      =tuple_guess[0], 
           PL0     =tuple_guess[1],
           C       =tuple_guess[2],
           stretch =tuple_guess[3])

# Fit !
fitter.fit()


# =============================================================================
# Print out some parameters that we care about 
# =============================================================================
PL0  = fitter.results.params['PL0'].value
ePL0 = fitter.results.params['PL0'].stderr
C  = fitter.results.params['C'].value
eC = fitter.results.params['C'].stderr
# Count per readout
R = d.headers['repetition'] * d.headers['iteration'] * d.headers['Nb_readout_per_sequence']
PL0_per_R  =  PL0 / R
ePL0_per_R = ePL0 / R

print('Fitting parameters')
print('PL0_per_R = %f +- %f'%(PL0_per_R, ePL0_per_R))
print('Contrast = %f +- %f'%(C, eC))







## Extract the rates
#x0_fit  = fitter.results.params['x0'].value
#dx_fit  = fitter.results.params['dx'].value
#y0_fit  = fitter.results.params['y0'].value
#ex0_fit = fitter.results.params['x0'].stderr
#edx_fit = fitter.results.params['dx'].stderr
#ey0_fit = fitter.results.params['y0'].stderr 
#print('fit_1D_cut: Parameters extracted') 
#
#popt = [ x0_fit , dx_fit , y0_fit]
#perr = [ex0_fit, edx_fit, ey0_fit]
#
#

















