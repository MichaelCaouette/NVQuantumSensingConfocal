# -*- coding: utf-8 -*-
"""
Created on Wed Jul  8 07:57:17 2020

Goal:
    Verify the time elapsed per fpga loops

@author: Childresslab
"""


import T1_process_func as _T1_process
from T1_sensitivity import find_best_sens

import spinmob as sm

import numpy as np
import matplotlib.pyplot as plt


## String for the headers of the data taken before 2021-05-17
#str_PL1_t0 = 'ms0_t0'
#str_PL1_tp = 'ms0_tprobed'
#str_PL2_t0 = 'ms-+1_t0'
#str_PL2_tp = 'ms-+1_tprobed'
## String for the headers of the data taken 2021-05-17 and after
str_PL1_t0 = 'PL1_t0'
str_PL1_tp = 'PL1_tprobed'
str_PL2_t0 = 'PL2_t0'
str_PL2_tp = 'PL2_tprobed'
str_curent_time = 'curent_time'
       

# Note the headers keys for various stuffs
# it should prove useful if we change the headers key later. 
str_t_find_set   = 'duration_find_settings'
str_t_prep_set   = 'duration_prep_settings'
str_t_pulse_seq  = 'duration_pulse_sequence'
# =============================================================================
# Extract the drift-independant measurement
# =============================================================================

# Hardcoded information for now, because it is not included in the data file
N_FPGA_loop_per_optimization = 50

# Get the data
d = sm.data.load(text='Load a data with info on duty cycle')
# Check the ckeys
print(d.ckeys)
# CHecks the headers
print(d.hkeys)


# =============================================================================
# Plot the time per fpga loops
# =============================================================================
plt.figure(tight_layout=True, figsize=(15, 8))
    

# Total time elapsed between fpga loops
ax = plt.subplot(211)
ys = np.diff( d[str_curent_time] )
plt.plot(ys, '.-')
plt.xlabel('FPGA loop')
plt.ylabel('Time per iter\n(sec)')
s = ''
for ss in d.path.split(maxsplit=2):
    s += '\n' + ss
plt.title(s, fontsize=10)

# Subract the time spent in the decay 
ax = plt.subplot(212)
t_probe = d.headers['t_probe']*1e-6 # In sec
N_loop = d.headers['repetition'] # How many fpga loop 
t_decay = 2 * t_probe * N_loop
dt_no_decay = np.diff( d[str_curent_time] ) - t_decay
plt.plot(dt_no_decay, '.-')
plt.xlabel('FPGA loop')
plt.ylabel('Time per iter\n Wihtout decay (sec)') 
# Compute the duty cycle
T_avg_no_decay = np.mean(dt_no_decay)
duty = t_decay / (t_decay + T_avg_no_decay)
str_duty = 'Duty cycle = %.2f percent'%(duty*100)
print( str_duty)
plt.title('T_avg_no_decay = %.3f sec\n'%T_avg_no_decay +
          't_decay = %.3f sec \n'%(t_decay) + str_duty)








    



