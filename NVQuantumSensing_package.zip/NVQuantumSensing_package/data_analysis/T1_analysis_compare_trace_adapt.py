# -*- coding: utf-8 -*-
"""
Created on Mon Jun 21 10:23:43 2021

Goal:
    Compare the sensitivity of adaptive and time-trace protocole
    When the trace is a 4pts trcae

@author: Childresslab

"""


import spinmob as sm
import os
import T1_process_func as _T1_f
import numpy as np
import matplotlib.pyplot as plt

# Define the model function
def model_plus(t, gp, gm):
    return _T1_f.model_00m0(+1, t, gp, gm)
def model_minus(t, gp, gm):
    return _T1_f.model_00m0(-1, t, gp, gm) 

def list_pair_measurement(directory, str_key):
    """
    Pair the measurements in order of "less updated" to "most updated". 
    
    If there is more datafiles for one measurement, will will take the most
    updated and omit some measurements in the list. 
    
    """
    
    # Let's first list all the measurement of each pair
    list_p = []
    list_m = []
    list_dt_p = []
    list_dt_m = []
    
    # Search among the files in the directory. 
    for file in os.listdir(directory):
        if str_key in file:
            
            # Get the file
            path_file = os.path.join(directory, file)  
            d = sm.data.load(path_file) 
            
            # Check which type it is and which duration
            type_meas = d.headers['Type_measure']
            dt        = d.headers['Time_finish'] - d.headers['Time_initial']
            # Update the most recent file 
            if type_meas == +1:
                list_p.append( d )
                list_dt_p.append( dt )
            if type_meas == -1:
                list_m.append( d )
                list_dt_m.append( dt )    
    
    # Now pair the maximum measurements
    N_p = len(list_p)
    N_m = len(list_m)
    
    list_pair = [] 
    # Check the maximum number of pairs
    N = min(N_p, N_m)
    # Pair them
    for i in range(N):
        list_pair.append( (list_p[i], list_m[i]) )            
    # Replace the last pair by the most updated pair
    list_pair[-1] = (list_p[-1], list_m[-1])
    # We now have everything to make happy the most hard-to-satisfy phycisist. 
    return list_pair          
            

key_file_T1 = 'T1' # String key in the name of the T1 datafile


# =============================================================================
# Get the list of pair of measurement for the trace
# =============================================================================
txt = 'Non-Adaptive. Select a directory containing the folder with key word %s in the name.'%key_file_T1
path = sm.dialogs.select_directory(text=txt)
list_pair = list_pair_measurement(path, key_file_T1)
# Just to clarify the code later
path_trace = path

# =============================================================================
# Get the adaptive data
# =============================================================================
ds_adapt = sm.data.load_multiple(text='Batch of Datas frrom adaptive measurements')


# =============================================================================
# Non-Adaptive: Infere the rates for each pair
# =============================================================================
N_pair = len(list_pair)
list_t_elapsed = np.zeros(N_pair)
list_gp        = np.zeros(N_pair)
list_gm        = np.zeros(N_pair)
list_egp       = np.zeros(N_pair)
list_egm       = np.zeros(N_pair)      
list_chi2      = np.zeros(N_pair)   
list_dof       = np.zeros(N_pair)  
list_duty      = np.zeros(N_pair) 

# Let's loooooooooooooop
for i in range(N_pair):
    print('Processing... %d / %d'%(i, N_pair) )
    d_p, d_m = list_pair[i]
    
    
    #Get the structured data
    (xp, yp, eyp, 
     xm, ym, eym,
     list_meas)    = _T1_f.extract_normalized_meas_4pts_trace(d_p, d_m)
    
    # Infere the rates
    out = _T1_f.rates_from_bayes_from_meas(list_meas,
                                           model_plus, model_minus,
                                           Gp_min=0.1e3, Gp_max=50e3, 
                                           Gm_min=0.1e3, Gm_max=50e3, 
                                           N_grid=200)
    gp, egp, gm, egm, corr, my_bayes = out
    list_gp[i]  = gp
    list_gm[i]  = gm
    list_egp[i] = egp
    list_egm[i] = egm    
    
    # Get the chi2
    chi2, dof = _T1_f.chi2_and_dof(xp, yp, eyp, 
                                   xm, ym, eym, 
                                   model_plus, model_minus,
                                    gp, gm)
    list_chi2[i] = chi2
    list_dof [i] = dof
    # Check the duty cycle   
    T_decay = 0
    T_total = 1
    for d in [d_p, d_m]:
        # Total time elapsed
        T_total += d.headers['Time_finish'] - d.headers['Time_initial']
        # Time dedicated to the decay
        repetition = d.headers['repetition']
        iteration  = d.headers['iteration' ]
        N_readout = repetition * iteration
        # The decay time is the total time spent on waiting the decay to happen
        T_decay += N_readout*2*np.sum(d['time_probed_sec'])
    # The duty cycle is the fraction of time spent on waiting on the decay    
    duty = T_decay / T_total    
    list_duty[i] = duty
    list_t_elapsed[i] = T_total
    
# Just to clarify the code later:
gp_trace  =  gp
gm_trace  =  gm    
egp_trace = egp
egm_trace = egm     

    
# =============================================================================
### Process the adaptive measurement
# =============================================================================

# Extract each the list of cumulative inference from each data file
out = _T1_f.cum_rates_from_bayes(ds_adapt, model_plus, model_minus)
list_adapt_elapsed, list_adapt_gp, list_adapt_egp, list_adapt_gm, list_adapt_egm = out

# Get the total time elapsed, from the last file. 
print('Warning: we asusme that the last file is the latest')
t_in  = ds_adapt[-1].headers['Time_initial']
t_end = ds_adapt[-1].headers['Time_finish' ]
dt_adapt = t_end - t_in 

# Compute the interpolated sensitivity (Fromt all the data)
last_resuts = list_adapt_gp[-1], list_adapt_egp[-1], list_adapt_gm[-1], list_adapt_egm[-1]
gp_adapt, egp_adapt, gm_adapt, egm_adapt = last_resuts
sens_adapt = ( ((egp_adapt/gp_adapt)**2 + 
                (egm_adapt/gm_adapt)**2 )*(dt_adapt) )**0.5
                
               
### =============================================================================
### Plot The normalized signal for each protocole
### =============================================================================
c_trace = 'red'  # Color for the trace
c_adapt = 'blue' # Color for the adaptive

f, (ax_p, ax_m) = plt.subplots(2, 1, sharex=True, tight_layout=True)

# Adaptive
# Get the data
(xp, yp, eyp, xm, ym, eym) = _T1_f.extract_measurement(ds_adapt)
# Plot the data
ax_p.errorbar(xp*1e6, yp, yerr=eyp, fmt='.', color=c_adapt, label='Adaptive')
ax_m.errorbar(xm*1e6, ym, yerr=eym, fmt='.', color=c_adapt )

# Non-Adaptive
# Get the data
(xp, yp, eyp, 
 xm, ym, eym,
 list_meas)    = _T1_f.extract_normalized_meas_4pts_trace(d_p, d_m)
# Plot the data
ax_p.errorbar(xp*1e6, yp, yerr=eyp, fmt='.', color=c_trace,  label='Non-Adaptive')
ax_m.errorbar(xm*1e6, ym, yerr=eym, fmt='.', color=c_trace)

# PLot the fit of adaptive
x_fit  = sm.fun.erange(min(xm), max(xm), 300)
yp_fit = model_plus (x_fit, gp_adapt, gm_adapt)
ym_fit = model_minus(x_fit, gp_adapt, gm_adapt)
ax_p.plot(x_fit*1e6, yp_fit, color=c_adapt, label='Fit on Adaptive')
ax_m.plot(x_fit*1e6, ym_fit, color=c_adapt)

# Beautify the whole
ax_p.set_xscale('log')
ax_m.set_xscale('log')
ax_m.set_xlabel('$\\tau_+$ (top) and $\\tau_-$ (bottom) (us)', fontsize=15)
ax_p.set_ylabel('$S_+$', fontsize=15, rotation=0)
ax_m.set_ylabel('$S_-$', fontsize=15, rotation=0)
ax_p.legend(bbox_to_anchor=(1.00, 1),loc='upper left')

# Title
ss = ds_adapt[-1].path
str_adapt = ss[:len(ss)//2] + '\n' + ss[len(ss)//2:]
ss = path_trace
str_trace = ss[:len(ss)//2] + '\n' + ss[len(ss)//2:]

# Version 1
#str_rates_ada = '      Fit on Adaptive: $\Gamma_+$=%.2f +- %.2f kHz  $\Gamma_-$=%.2f +- %.2f kHz'%(gp_adapt*1e-3, 
#                                                                                                     egp_adapt*1e-3, 
#                                                                                                     gm_adapt*1e-3, 
#                                                                                                     egm_adapt*1e-3)
#str_rates_trac = 'Fit on non-Adaptive: $\Gamma_+$=%.2f +- %.2f kHz  $\Gamma_-$=%.2f +- %.2f kHz'%(gp_trace*1e-3, 
#                                                                                                   egp_trace*1e-3, 
#                                                                                                   gm_trace*1e-3, 
#                                                                                                   egm_trace*1e-3)    
# Version 2; With a better way to show the error; With 1 significant digit
str_rates_ada = 'Fit on Adaptive: $\Gamma_+$=%.1f (%d) kHz  $\Gamma_-$=%.1f (%d) kHz'%(gp_adapt*1e-3, 
                                                                                      10*egp_adapt*1e-3, 
                                                                                      gm_adapt*1e-3, 
                                                                                      10*egm_adapt*1e-3)
str_rates_trac = 'Fit on non-Adaptive: $\Gamma_+$=%.1f (%d) kHz  $\Gamma_-$=%.1f (%d) kHz'%(gp_trace*1e-3, 
                                                                                           10*egp_trace*1e-3, 
                                                                                           gm_trace*1e-3, 
                                                                                           10*egm_trace*1e-3)    

str_info = ('File for adaptive: \n'+str_adapt+
            '\n\nFile for Trace: \n'+str_trace+
            '\n\n'+str_rates_ada+'\n'+str_rates_trac) 
#ax_p.set_title(str_info)
ax_p.set_title('Normalized signal')

# Print the title since we are not always keeping it
print()
print(str_info)
print()

    
## =============================================================================
## Plot Inference versus Time 
## =============================================================================
fig, (ax_gp, ax_gm) = plt.subplots(nrows=2, ncols=1, sharex=True, tight_layout=True)

# For the rate +
ax_gp.errorbar(list_t_elapsed, list_gp*1e-3, yerr=list_egp*1e-3, 
             fmt='.', label='Non-Adaptive', color=c_trace)
ax_gp.errorbar(list_adapt_elapsed, list_adapt_gp*1e-3, yerr=list_adapt_egp*1e-3, 
             fmt='.' , label='Adaptive', color=c_adapt)
#ax_gp.legend(loc='best')
ax_gp.set_xscale('log')
ax_gp.set_title('Inference of the rates (kHz)', fontsize=15)
ax_gp.set_ylabel('$\Gamma_+$', fontsize=15, rotation=0)
## Split the title in 2
#str_t = ''
#for sss in [ds_adapt[-1].path, path]:
#    ss = sss
#    str_t += ss[:len(ss)//2] + '\n' + ss[len(ss)//2:] + '\n'
#ax_gp.set_title(str_t, fontsize=10)

# For the rate -
ax_gm.errorbar(list_t_elapsed, list_gm*1e-3, yerr=list_egm*1e-3, fmt='.', color=c_trace )
ax_gm.errorbar(list_adapt_elapsed, list_adapt_gm*1e-3, yerr=list_adapt_egm*1e-3, fmt='.', color=c_adapt  )
ax_gm.set_xscale('log')
ax_gm.set_xlabel('Total time elapsed (sec)', fontsize=15)
ax_gm.set_ylabel('$\Gamma_-$', fontsize=15, rotation=0)

## =============================================================================
## Plot the uncertainty versus time with the interpolated lines
## =============================================================================
fig, (ax_egp, ax_egm) = plt.subplots(nrows=2, ncols=1, sharex=True, tight_layout=True)

# uncertainty +
ax_egp.plot(list_t_elapsed, list_egp/list_gp, '.-', color=c_trace )
ax_egp.plot(list_adapt_elapsed, list_adapt_egp/list_adapt_gp, '.-', color=c_adapt  )
ax_egp.set_xscale('log')
ax_egp.set_yscale('log')
ax_egp.set_title('Relative uncertainty', fontsize=15)
ax_egp.set_ylabel('$\Gamma_+$', fontsize=15, rotation=0)


# uncertainty -
ax_egm.plot(list_t_elapsed, list_egm/list_gm, '.-', color=c_trace )
ax_egm.plot(list_adapt_elapsed, list_adapt_egm/list_adapt_gm, '.-', color=c_adapt )
ax_egm.set_xscale('log')
ax_egm.set_yscale('log')
ax_egm.set_ylabel('$\Gamma_-$', fontsize=15, rotation=0)
ax_egm.set_xlabel('Total time elapsed (sec)', fontsize=15)

# Interpolated lines
# For non-adaptive
sens_gp = list_egp[-1]/list_gp[-1] * (list_t_elapsed[-1])**0.5
ax_egp.plot(list_t_elapsed, sens_gp/(list_t_elapsed)**0.5, '--', color=c_trace )
sens_gm = list_egm[-1]/list_gm[-1] * (list_t_elapsed[-1])**0.5
ax_egm.plot(list_t_elapsed, sens_gm/(list_t_elapsed)**0.5, '--', color=c_trace )
# For adaptive
sens_adapt_gp = list_adapt_egp[-1]/list_adapt_gp[-1] * (list_adapt_elapsed[-1])**0.5
ax_egp.plot(list_adapt_elapsed, sens_adapt_gp/(list_adapt_elapsed)**0.5, '--', color=c_adapt )
sens_adapt_gm = list_adapt_egm[-1]/list_adapt_gm[-1] * (list_adapt_elapsed[-1])**0.5
ax_egm.plot(list_adapt_elapsed, sens_adapt_gm/(list_adapt_elapsed)**0.5, '--', color=c_adapt )

# =============================================================================
# Print the ratio of sensitivity and corresponding speed-up
# =============================================================================
print()
print('sens_gp/sens_adapt_gp = ', sens_gp/sens_adapt_gp)
print('sens_gm/sens_adapt_gm = ', sens_gm/sens_adapt_gm)
print('Gain in speed-up:')
print('Gamma +: %f X faster with adaptive'%(sens_gp/sens_adapt_gp)**2)
print('Gamma -: %f X faster with adaptive'%(sens_gm/sens_adapt_gm)**2)


# =============================================================================
# Print the paths
# =============================================================================

print()
print('Path for Non-Adaptive:')
print(path)
print()
print('Path for Adaptive:')
print(ds_adapt[-1].path)










































