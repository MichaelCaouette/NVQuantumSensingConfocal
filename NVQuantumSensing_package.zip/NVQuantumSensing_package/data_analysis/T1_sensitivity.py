# -*- coding: utf-8 -*-
"""
Created on Tue Apr  6 15:47:57 2021

Goal:
    - Study the sensitivity on the rates for various set of pair of measurement. 

@author: Childresslab
"""

import T1_sim_data as _m
import numpy as np

def erange(start, end, steps):
    """
    STOLEN FROM 
    https://github.com/Spinmob/spinmob/blob/master/_functions.py#L409
    Thank you, professor Jack Sankey ;) :P
    
    This function might not specifically used here, but can be imported 
    for simulation that uses this module.
    
    Returns a numpy array over the specified range taking geometric steps.
    See also numpy.logspace()
    """
    if start == 0:
        print("Nothing you multiply zero by gives you anything but zero. Try picking something small.")
        return None
    if end == 0:
        print("It takes an infinite number of steps to get to zero. Try a small number?")
        return None

    # figure out our multiplication scale
    x = (1.0*end/start)**(1.0/(steps-1))

    # now generate the array
    ns = np.array(list(range(0,steps)))
    a =  start*np.power(x,ns)

    # tidy up the last element (there's often roundoff error)
    a[-1] = end

    return a

def analytic_uncertainties(f1, f2, ef1, ef2, x0, y0, 
                         dx=0.001, dy=0.001,
                         want_variance=False):
    """
    Return an estimate of the uncertainties in the domain of a bi-dimensional
    pdf. 
    
    f1, f2:
        Two model function describing the measurement. 
        Their signature must best (x,y). ie f1 = f1(x,y) and f2 = f2(x,y)
    
    ef1, ef2:
        Absolute uncertainty in the measurement. 
    
    x0, y0:
        True or best estimate of x and y. 
        
    dx, dy:
        Infinitesimal step in x and y for taking the derivatives. 
        
    want_variance:
        (bool) If True, the function return the variances and the covariance of 
        x & y.  If False, the function return the uncertainty and the 
        correlation in x & y 
        (correlation = covariance / product of uncertainties)
    """
    
    # Compute the first derivatives, evaluated at x0, y0
    # I choose a two-point formula that should converge to h**2, according to 
    # Wikipedia: https://en.wikipedia.org/wiki/Numerical_differentiation
    df1dx = ( f1(x0 + dx, y0) - f1(x0 - dx, y0) ) / ( 2 * dx )
    df1dy = ( f1(x0, y0 + dy) - f1(x0, y0 - dy) ) / ( 2 * dy )
    df2dx = ( f2(x0 + dx, y0) - f2(x0 - dx, y0) ) / ( 2 * dx )
    df2dy = ( f2(x0, y0 + dy) - f2(x0, y0 - dy) ) / ( 2 * dy )
    
    # Compure the coefficients
    # Start with various gradients
    a1 = df1dx / ef1
    a2 = df2dx / ef2
    b1 = df1dy / ef1
    b2 = df2dy / ef2
    # Combine these gradients
    A = a1*a1 + a2*a2
    B = b1*b1 + b2*b2
    C = a1*b1 + a2*b2
    D = A*B - C*C
    # Compute the variances and covariances
    ex2 =  B / D # Variance in x
    ey2 =  A / D # Variance in y
    exy = -C / D # Covariance of x & y
    
    if want_variance:
        return ex2, ey2, exy 
    else:
        ex   = ex2**0.5
        ey   = ey2**0.5
        corr = exy / (ex * ey)
        return ex, ey, corr

def sensitivity(pair_model, 
                gp, gm,
                t1, t2, 
                N1, BG1, PL01, C1,
                N2, BG2, PL02, C2,
                type_sens='abs',
                t_overhead=0.0):
    """
    Compute the sensitivity of a measurement type at a givent time.
    
    pair_model:
        Tuples of two string with the format:
        ('ij', 'kl'), where i, j, k and l are either 0, + or -. 
        ij indicates one pair of measurement and kl the other pair. 
        The nomenclature is hte same, for example, the string input of the
        function 'pop' in the script "model_measurement.py"     
    
    gp, gm:
        Rates gamma+ and gamma-
        
    t1, t2:
        Time for measuring 'ij' and 'kl', respectively. 
        
    N, BG, PL0, C:
        Number of readout, Background, photoluminscence from ms=0 and contrast.
    
    t_overhead:
        Extra time taken by the pulse sequence, added to 
        t_total = ( t1 + t2 )*N*2    ; 
        ei, t_total = ( t1 + t2 )*N*2 + t_overhead
        Therefore, t_overhead is with all the readout included
        
        
    type_sens:
        (string) 'abs' or 'rel'. 
        Type of sensitivity to output.
            
    """
    
    # Define the diff-ratio model for each element of the pair
    duo1 = pair_model[0]
    duo2 = pair_model[1]
    # The functions model1 and model2 have trhe signature (t, gp, gm)
    class_m1 = _m.DiffRatioNoise(N1, BG1, PL01, C1, duo1[0], duo1[1])
    class_m2 = _m.DiffRatioNoise(N2, BG2, PL02, C2, duo2[0], duo2[1])
    
    # Define the function with signature (gp, gm) for a fixed time to probe
    def f1(gp, gm):
        return class_m1.model_meas(t1, gp, gm)
    def f2(gp, gm):
        return class_m2.model_meas(t2, gp, gm)
    
    # Compute the predicted uncertainty in the rates
    ef1 = class_m1.model_unc(t1, gp, gm)
    ef2 = class_m2.model_unc(t2, gp, gm)
    out = analytic_uncertainties(f1, f2, ef1, ef2, gp, gm)
    egp, egm, corr = out  

    # Get the total time to probe + overhead
    t_total = ( t1*N1 + t2*N2 )*2  + t_overhead   

    
    # Returnt he sensitivity, based on the type that we want
    if type_sens == 'abs':
        return np.sqrt( (egp*egp     + egm*egm    ) *t_total )
    elif type_sens == 'rel':
        rel_p = egp/gp
        rel_m = egm/gm
        return np.sqrt( (rel_p*rel_p + rel_m*rel_m) *t_total )
    

def find_best_sens(pair_model, 
                   gp, gm,
                   N1, BG1, PL01, C1,
                   N2, BG2, PL02, C2,
                   type_sens='abs',
                   t_overhead=0.0):
    """
    Find the minimum possible sensitivy. 
    
    Input: same as " sensitivity ", without the t1 and t2
    """
    
    # Search the minium on a grid
    N_t1 = 500
    N_t2 = 503
    list_t1 = np.linspace(0.05/gp, 1.5/gp, N_t1) # (s) Whent to probe first measurement
    list_t2 = np.linspace(0.05/gm, 1.5/gm, N_t2) # (s) Whent to probe second measurement        
    # Mesh that
    mesh_t1, mesh_t2 = np.meshgrid(list_t1, list_t2)    
    # Get the map of sensitivity for all the possible times
    map_sens = sensitivity(pair_model, gp, gm, mesh_t1, mesh_t2, 
                           N1, BG1, PL01, C1,
                           N2, BG2, PL02, C2,
                           t_overhead=t_overhead,
                           type_sens=type_sens)

    # Find the minimum
    Z  = map_sens
    ind = np.unravel_index(Z.argmin(), Z.shape)
    i = ind[0]
    j = ind[1]    
    best_sens = map_sens[i][j] 
    best_t1 = mesh_t1[i][j] 
    best_t2 = mesh_t2[i][j] 
    
    # Return all that
    return best_sens, best_t1, best_t2
     



if __name__ == '__main__':
    """
    Test the function 
    """
    true_gp = 4.7e3  # kHz
    true_gm = 6.2e3  # kHz
    # From the apparatus
    BG  = 0.01
    PL0 = 0.02
    C  = 0.25
    N  = 4e6    

    # =============================================================================
    # Test the sensitivity finder. 
    # =============================================================================
#    my_pair = [('00', '+0'), ('00', '-0')]
    my_pair = [('++', '+0'), ('--', '-0')]
    
    print('\nFinding best sens...')
    my_sens, my_t1, my_t2 = find_best_sens(my_pair, 
                                           true_gp, true_gm,
                                           N, BG, PL0, C, 
                                           type_sens='abs')    
    print('Done !\n')
    print('Best sensitivity: %.2f'%(my_sens ) +
          '\nbest_t1: %.4f / $\Gamma_+$'%(my_t1*true_gp) +
          '\nbest_t2: %.4f / $\Gamma_-$'%(my_t2*true_gm) +
          '\nPair model: ' + str(my_pair) )       
    
    
    
    










   