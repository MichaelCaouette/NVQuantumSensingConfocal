# -*- coding: utf-8 -*-
"""
Created on Thu Feb 27 00:06:06 2020

Goal:
    Compute the magnetic field from the two ESR lines. 
    We are being carful for the error propagation under the square by using a 
    precise non-linear error propagation formula for the square root. 
    This is because, in the regime that we are working, the number under the 
    square-root can be negative due to large uncertainty. Therefore we have to 
    be more careful about the best estimate and uncertainty of the square root. 
    
    
    ATTEMPT TO EXPLAIN THE ORIGIN OF THE FORMULA: 
    Thanks to Bayesian inference, we can easyly propagate the uncertainty in the 
    non-linear regime. 
    If we want to estimate y=sqrt(x), the philosophy is to use our complete 
    knowledge of x. For example, if a poor measurement provides x= -1 +- 9, 
    we cannot naively estimate y to be sqrt(x). The key is that WE ALSO KNOW
    that x should be greater than zero. Therefore, our complete knoweldge on 
    x is that x= -1 +-9 AND x>0. In this case, this results in a non-gaussian
    probability distribute for x. P(x) is non-gaussian in this case, because 
    it is severely chopped at x=0. 
    
    For a clear explanation:
    See the book
    Data Analysis A Bayesian Tutorial, Second Edition, Sivia
    Chapter
    3.6.2 Taking the square root of a number
    

@author: Childresslab
"""

from uncertainties import ufloat#, unumpy

# Set the best guess for the constant. Note that, when using the function, 
# the user can still set them as he/she wants. 
# D: Zero field splitting (GHz)
# gamma: Zeeman shift constant (GHz/T)
D_best_guess     = ufloat(2.8707565, 71e-6)
gamma_best_guess = ufloat(28.025, 0)


def usqrt(x, ex):
    """
    Best estimate of the square root of x, with uncertainty x. 
    We use a non-linear error propagation, based on Bayesian inference. 
    
    It can be shown that, when ex is very small compared to x, the formula 
    reduces to the one obtained with linear error propagation. 
    
    Return y, ey:
        y:
            Best estimate of sqrt(x)
        ey:
            Best estimate the uncertainty in sqrt(x)
    """
    # Best estimate of sqrt(x)
    y  = ( 0.5*( x + (x**2 + 2*ex**2)**0.5 ) )**0.5
    
    # Best estimate of the uncertainty in sqrt(x)
    inve_sig2 = 1/y**2 + 2*(3*y**2 - x)/ex**2
    ey = 1/inve_sig2**0.5
    
    
    return y, ey
    
    

def uBz(fp, efp,  fm, efm, 
       D = D_best_guess.nominal_value, eD = D_best_guess.std_dev,
       gamma = gamma_best_guess.nominal_value, egamma = gamma_best_guess.std_dev):
    """
    Returns the measured B_parallel (along NV_z)
    
    Input:
        fp, efp:
            Best estimate and uncertainty in the frequency +
        fm, efm:
            Best estimate and uncertainty in the frequency +
        D, eD:
            Best estimate and uncertainty in the Zero-field splitting. 
            Default value: D, eD = %f, %f GHz
        gamma, egamma:
            Best estimate and uncertainty in the zeeman gyro-mag ratio.
            Default value: gamma, egamma = %f, %f GHz/T
    
    OutputL
        Bz, eBz:
            Best esstimate and uncertainty of the field along NV z axis.
            
    Choice of unit:
        The frequencies and zero field splitting must have the same.
        And gamma must be in the same unit of frequency divided by a unit 
        of the field. 
        This will output B in unit of the unit of the field in gamma. 
        Lol This is not clear. 
        Example: 
            All frequencies in GHz and gamma in GHz/T. This will output
            a field in unit of T.  
        
    It uses the package "uncertainties" for the linear error propagation. 
    For the non-linear part, it uses a formula for non-linear error propagation
    in the square root. 
    
    """%(D_best_guess.nominal_value, D_best_guess.std_dev,
         gamma_best_guess.nominal_value, gamma_best_guess.std_dev)
    # Transform the inputs in ufloat. The package will propagate for us. 
    ufp = ufloat(fp, efp)
    ufm = ufloat(fm, efm)
    uD  = ufloat(D, eD)
    ugamma = ufloat(gamma, egamma)
    # Linearly propagate the error before taking the square root. 
    linear_part = -(uD+ufp-2*ufm)*(uD+ufm-2*ufp)*(uD+ufp+ufm)/27/ugamma**2/uD
    
    # Non-linearly propagate the error in the estimation of the square root. 
    Bz, eBz = usqrt(linear_part.nominal_value, 
                    linear_part.std_dev)
    
    return Bz, eBz

def uBperp(fp, efp,  fm, efm, 
          D = D_best_guess.nominal_value, eD = D_best_guess.std_dev,
          gamma = gamma_best_guess.nominal_value, egamma = gamma_best_guess.std_dev):
    """
    Returns the measured B_perpendicular (orthogonal to NV_z)

    Input:
        fp, efp:
            Best estimate and uncertainty in the frequency +
        fm, efm:
            Best estimate and uncertainty in the frequency +
        D, eD:
            Best estimate and uncertainty in the Zero-field splitting
        gamma, egamma:
            Best estimate and uncertainty in the zeeman gyro-mag ratio
    
    OutputL
        Bperp, eBperp:
            Best esstimate and uncertainty of the field perpendicular to the 
            NV z axis. 
            
    Choice of unit:
        The frequencies and zero field splitting must have the same.
        And gamma must be in the same unit of frequency divided by a unit 
        of the field. 
        This will output B in unit of the unit of the field in gamma. 
        Lol This is not clear. 
        Example: 
            All frequencies in GHz and gamma in GHz/T. This will output
            a field in unit of T.  
        
    It uses the package "uncertainties" for the linear error propagation. 
    For the non-linear part, it uses a formula for non-linear error propagation
    in the square root. 
    """

    # Transform the inputs in ufloat. The package will propagate for us. 
    ufp = ufloat(fp, efp)
    ufm = ufloat(fm, efm)
    uD  = ufloat(D, eD)
    ugamma = ufloat(gamma, egamma)
    
    # Linearly propagate the error before taking the square root. 
    linear_part = -((2*uD-ufp-ufm)*(2*uD+2*ufm-ufp)*(2*uD+2*ufp-ufm)/27/ugamma**2/uD)
    
    # Non-linearly propagate the error in the estimation of the square root. 
    Bperp, eBperp = usqrt(linear_part.nominal_value, 
                          linear_part.std_dev)
    
    return Bperp, eBperp


# =============================================================================
# Previous function for comparision
# =============================================================================
def prev_Bz(fp, fm, D = D_best_guess, gamma = gamma_best_guess):
    """
    Returns the measured B_parallel (along NV_z)
    """
    
    Bz = (-(D+fp-2*fm)*(D+fm-2*fp)*(D+fp+fm)/27/gamma**2/D)**0.5
    
    return Bz

def prev_Bperp(fp, fm, D = D_best_guess, gamma = gamma_best_guess):
    """
    Returns the measured B_perpendicular (orthogonal to NV_z)
    """
    
    try:
        Bp = (-((2*D-fp-fm)*(2*D+2*fm-fp)*(2*D+2*fp-fm)/27/gamma**2/D))**0.5
    except:
        Bp = (abs((2*D-fp-fm)*(2*D+2*fm-fp)*(2*D+2*fp-fm)/27/gamma**2/D))**0.5
#        raise ValueError("Imaginary Bperp")
        print("Bperp is imaginary")
        
    return Bp

import numpy as np
import scipy.optimize as opt
from scipy.signal import find_peaks

#Lorentz function for the fits
def lorentz(f, f0, BG, amplitude, width):
    """
    Lorentzian function
    """
    return BG - amplitude/(1 + ((f-f0)/width)**2 )

def get_peaks(d, nbPointsBetweenPeak=5, df=0.4, index_ref=3, index_sig=2):
    """
    
    
    index_sig:
        Index of the singal counts):
    index_ref:
        Index of the reference counts
    df:
        (GHz) Width of the range over with the single lorentzian if fitted
    nbPointsBetweenPeak:
        Minimum number of point between peaks
    d:
        ESR data file
    
    """
    #Extract usefull data (un-usefull data are not extracted lol !!!!!)
    fs = d[0] #Frequencies 
    sig = d[index_sig]  #PhotoLuminescence
    ref = d[index_ref]
    
    PL = sig - ref
    
    #Get the peaks !
    f0s = np.array([]) #Containt the  peaking frequencies
    ef0s = np.array([]) #Containt the error in peaking frequency
    list_popt, list_perr = [], []
    
    #Estimate the peaks
    y = -PL + max(PL) #Invert the peak such that they point up and make them positive
    minPeak = (max(y)-min(y))/2 + y*0 #Minimum Height of the peak
    maxPeak =  (max(y)-min(y))*1.2 + y*0 #Maximum height for the peak
    peak_indices, _ = find_peaks(y, height=(minPeak,maxPeak), width=nbPointsBetweenPeak)

    for peak_index in peak_indices:    
        f0_guess = fs[peak_index]
        index = (fs<(f0_guess+df/2) )*(fs>(f0_guess-df/2) )
        f_fit = fs[index]
        c_fit = PL[index]
        #guesses for the parameters
        BG_guess = max(c_fit)
        amplitude_guess =  BG_guess - min(c_fit)
        width_guess = 0.01
        initial_guess = (f0_guess, BG_guess, amplitude_guess, width_guess)
        popt, pcov = opt.curve_fit(lorentz, f_fit, c_fit, p0=initial_guess)
        perr = np.sqrt(np.diag(pcov)) #error from the fit. 
        #Extract the resonance frequency and the error
        f0 = popt[0]
        ef0 = perr[0]
        f0s = np.append(f0s, f0)
        ef0s = np.append(ef0s, ef0)
        # Record also the fit stuffs
        list_popt.append(popt)
        list_perr.append(perr)
    
    return f0s, ef0s, list_popt, list_perr


if __name__ == '__main__':
    
    # =========================================================================
    # Test the sqrt formula
    # =========================================================================
    import numpy as np
    import matplotlib.pyplot as plt
    N = 100
    # Generate xwith uncertainty
    x0 = 1 
    list_ex = np.linspace(0.01, 20, N)
    # Get the linear ufloat
    list_ux = []
    for ex in list_ex:
        list_ux.append( ufloat(x0, ex) )
        
    # Compute the best estimate of sqrt(x)
    # Nonlinear method
    nonlin_y, nonlin_ey = usqrt(x0, list_ex)
    # Linear method
    lin_y, lin_ey = [], []
    lin_x_axis = []
    for i in range(N):
        ux = list_ux[i]
        try:
            uy = ux**0.5
            lin_y.append(uy.nominal_value)
            lin_ey.append(uy.std_dev)
            lin_x_axis.append(ux.std_dev)
        except:
            pass
    
    # Compare the linear and non-linear method
    plt.figure(tight_layout=True)
    ax = plt.subplot(211)
    plt.plot(list_ex, nonlin_y, label='Non-linear')
    plt.plot(lin_x_axis, lin_y, label='Linear')
    plt.xlabel('Uncertainty in x')
    plt.ylabel('Etsimate of sqrt(x)')
    plt.legend()
    plt.title('x0 = %f'%x0)
    
    ax = plt.subplot(212)
    plt.plot(list_ex, nonlin_ey, label='Non-linear')
    plt.plot(lin_x_axis, lin_ey, label='Linear')
    plt.xlabel('Uncertainty in x')
    plt.ylabel('Uncertainty of sqrt(x)')
    

    # =========================================================================
    # Test the Field formula
    # ========================================================================= 
    
    # Create a set of NV ESR lines
    # From data in 
    # "X:\DiamondCloud\Magnetometry\Data\2021\03\04\pi_pulse_vs_field_v3"
    # data 1, 4, 5
    # In GHz
    list_fm  = [2.0672880945897583, 1.621482304309164, 1.704023125775099, 2.0674149732347513]
    list_efm = [7.903175957148593e-05, 0.00013970779208398107, 0.00014872948113550487, 0.00013899725627611697]
    list_fp  = [3.6792710113095777, 4.120160273025669, 4.038612073151254, 3.761408727798883]
    list_efp = [0.00010567450511123647, 0.00022487798771478917, 0.00012965263964464697, 0.3980373105917349]    
    
    # Compute the field with the non-linear error propagation
    list_Bz  = []
    list_eBz = []
    list_Bperp  = []
    list_eBperp = []
    Ndata = len(list_fm)
    for i in range(Ndata):
        fp  = list_fp[i]
        efp = list_efp[i]
        fm  = list_fm[i]
        efm = list_efm[i]
        # Compute the best estimate of the field with uncertainty
        Bz, eBz      = uBz(fp, efp, fm, efm)
        Bperp, eBperp = uBperp(fp, efp, fm, efm)
        # Append all that
        list_Bz.append(Bz)
        list_eBz.append(eBz)
        list_Bperp.append(Bperp)
        list_eBperp.append(eBperp)
    # Convert into numpy array for manipulation
    list_Bz  = np.array(list_Bz)
    list_eBz = np.array(list_eBz)
    list_Bperp  = np.array(list_Bperp)
    list_eBperp = np.array(list_eBperp)    

    # Compute the field with the linear error propagation
    list_lin_Bz  = []
    list_lin_eBz = []
    list_lin_Bperp  = []
    list_lin_eBperp = []
    Ndata = len(list_fm)
    for i in range(Ndata):
        ufp = ufloat( list_fp[i], list_efp[i] )
        ufm = ufloat( list_fm[i], list_efm[i] )
        # Compute the best estimate of the field with uncertainty
        uBz       = prev_Bz(ufp, ufm)
        Bz, eBz = uBz.nominal_value, uBz.std_dev
        uBperp = prev_Bperp(ufp, ufm)
        Bperp, eBperp = uBperp.nominal_value, uBperp.std_dev
        # Append all that
        list_lin_Bz.append(Bz)
        list_lin_eBz.append(eBz)
        list_lin_Bperp.append(Bperp)
        list_lin_eBperp.append(eBperp)    
    # Convert into numpy array for manipulation
    list_lin_Bz  = np.array(list_lin_Bz)
    list_lin_eBz = np.array(list_lin_eBz)
    list_lin_Bperp  = np.array(list_lin_Bperp)
    list_lin_eBperp = np.array(list_lin_eBperp)        
        
    # Plot all that
    x_axis = np.arange(0, Ndata)
    plt.figure(tight_layout=True)
    ax = plt.subplot(311)
    plt.errorbar(x_axis, list_fm, yerr=list_efm, fmt='.', label='Minus')
    plt.errorbar(x_axis, list_fp, yerr=list_efp, fmt='.', label='Plus')    
    plt.xlabel('Data index')
    plt.ylabel('ESR frequency (GHz)')
    plt.legend(title='Line', 
               bbox_to_anchor=(1.00, 1),loc='upper left')
    plt.xlim([x_axis[0]-0.5, x_axis[-1]+0.5])
    
    ax = plt.subplot(312)
    plt.errorbar(x_axis, list_Bz*1e3, yerr=list_eBz*1e3, fmt='.', label='Non-linear')
    plt.errorbar(x_axis+0.1, list_lin_Bz*1e3, yerr=list_lin_eBz*1e3, fmt='.', label='Linear')
    plt.xlabel('Data index')
    plt.ylabel('B parallele (mT)')    
    plt.legend(title='Estimate propagation', 
               bbox_to_anchor=(1.00, 1),loc='upper left')
    plt.xlim([x_axis[0]-0.5, x_axis[-1]+0.5])
    
    ax = plt.subplot(313)
    plt.errorbar(x_axis, list_Bperp*1e3, yerr=list_eBperp*1e3, fmt='.', label='Non-linear')
    plt.errorbar(x_axis+0.1, list_lin_Bperp*1e3, yerr=list_lin_eBperp*1e3, fmt='.', label='Linear')
    plt.xlabel('Data index')
    plt.ylabel('B perpendicular (mT)')   
    plt.xlim([x_axis[0]-0.5, x_axis[-1]+0.5])     
    
    
    










