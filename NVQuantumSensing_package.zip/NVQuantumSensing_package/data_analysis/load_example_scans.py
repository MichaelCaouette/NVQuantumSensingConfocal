# -*- coding: utf-8 -*-
"""
Created on Wed Jul  8 09:23:02 2020

Load few scans and compare
@author: Childresslab
"""

import spinmob as sm
import numpy as np
import matplotlib.pyplot as plt 

ds = sm.data.load_multiple(text='Select one or more scan')

invert_y = True

if len(ds) > 1:
    have_more_than_one_scan = True
else:
    have_more_than_one_scan = False


ncols = 1
nrows = int(np.ceil(len(ds)/ncols)) 


# Hardcoded scale parameters (obtained by scanning a resolution target)
convx = 9.24 #um/V
convy = 6.30 #um/V


#The command int(np.ceil(len(ds)/ncols)) compute the lower number of rows regarding the total plot to do. 
fig, axes = plt.subplots(nrows, ncols ) # ,sharey=True)
#fig.subplots_adjust(wspace=0, hspace=0) #Remove spacing
if have_more_than_one_scan:
    # Create an array with the axes if we have more than one plot to make
    axs = axes.flat #Flat the axis in order to acces them with a single index
else:
    axs = axes
    
for j, d in enumerate( ds):
    # Define the domain
    xmin = d.headers['Vx_min']
    xmax = d.headers['Vx_max']
    Nx = d.headers['Nx']
    ymin = d.headers['Vy_min']
    ymax = d.headers['Vy_max']
    Ny = d.headers['Ny']
    xs = np.linspace(xmin, xmax, Nx)*convx
    ys = np.linspace(ymin, ymax, Ny)*convy
    if invert_y:
        # Inver the direction of y
        ys *= -1     
        
    if have_more_than_one_scan:
        my_ax = axs[j]
    else:
        my_ax = axs
    
    
    cs = my_ax.pcolor(xs, ys,np.array(d)*1e-3)
    my_ax.set_title(d.path, fontsize=9)
    my_ax.set_xlabel('x (um)')
    my_ax.set_ylabel('y (um)')
    
    my_ax.set_xlim([min(xs), max(xs)])
    my_ax.set_ylim([min(ys), max(ys)])
    my_ax.set_aspect('equal')
    
#    cb = fig.colorbar(cs, orientation='horizontal', fraction=.1)
#    cb.set_label('KCount/sec')    
#    
    
    
    
    
    
    
    
    
    
    
    
    
    
    