# -*- coding: utf-8 -*-
"""
Created on Fri Jun  4 13:08:07 2021

Goal: Load a trajecotry file and interpolate and/or extrapolate

@author: Childresslab
"""


import scipy.optimize as opt
import spinmob as sm
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D # Used implicitly for the 3D plot

# Set the points that we would like
z_desired = np.linspace(1.25, 7, 10 )
want_save = True # If true, will ask to the user to save the data

# =============================================================================
### Get the points to interpolate
# =============================================================================
d = sm.data.load(text='Load the trajectory file')
xs = d['xs']
ys = d['ys']
zs = d['zs']


# =============================================================================
### Look at the data to see what is the best way to fit them. 
# =============================================================================
fig = plt.figure(tight_layout=True, figsize=(10, 10))
fig.add_subplot(2, 2, 1)
plt.plot(zs,xs,'-xg')
plt.plot(zs[0], xs[0], 'or')
plt.xlabel("z (mm)")
plt.ylabel("x (mm)")

fig.add_subplot(2, 2, 2)
plt.plot(zs, ys,'-xg')
plt.plot(zs[0], ys[0], 'or')
plt.xlabel("z (mm)")
plt.ylabel("y (mm)")

fig.add_subplot(2, 2, 3)
plt.plot(xs, ys, '-xg')
plt.plot(xs[0], ys[0], 'or')
plt.xlabel("x (mm)")
plt.ylabel("y (mm)")

fig.add_subplot(2, 2, 4, projection='3d')
plt.plot(xs, ys, zs, '--x')
plt.plot([xs[0]], [ys[0]], [zs[0]], 'or')
plt.xlabel("z (mm)")
plt.ylabel("x (mm)")

# =============================================================================
### Define the fitter
# =============================================================================

def model_x(z, x0, a1x, ):
    """
    Model for fitting the line fpr x(z)
    
    """
    return x0 + a1x*z

def model_y(z, y0, a1y, a2y):
    """
    Model for fitting the line fpr x(z)
    
    """
    return y0 + a1y*z + a2y*z*z



# Prepare the guess
# guess for x(z)
#guess_a1x = ( zs[0] - zs[-1] ) / ( xs[0] - xs[-1] ) # Rough Partial derivative
#guess_x0  = xs[0] - guess_a1x*zs[0]
guess_a1x = np.mean( np.diff(zs) /  np.diff(xs) ) # Rough Partial derivative
guess_x0  = np.mean( xs - guess_a1x*zs )
tuple_guess_x = [guess_x0, guess_a1x]
# guess for y(z)
guess_a1y = ( zs[0] - zs[-1] ) / ( ys[0] - ys[-1] ) # Rough Partial derivative
guess_a2y = 0
guess_y0  = ys[0] - guess_a1y*zs[0]
tuple_guess_y = [guess_y0, guess_a1y, guess_a2y]


# Fit x(z) ! 
popt_x, pcov_x = opt.curve_fit(model_x, xdata = zs, 
                           ydata = xs,
                           p0=tuple_guess_x)
perr_x = np.sqrt(np.diag(pcov_x)) #error from the fit. (Maybe irrelevant)
# Fit y(z) ! 
popt_y, pcov_y = opt.curve_fit(model_y, xdata = zs, 
                           ydata = ys,
                           p0=tuple_guess_y)
perr_y = np.sqrt(np.diag(pcov_y)) #error from the fit. (Maybe irrelevant)


# Get the desired extrapolated data
x_desired = model_x(z_desired, *popt_x)
y_desired = model_y(z_desired, *popt_y)

# =============================================================================
# Save the data
# =============================================================================
if want_save:
    d_save = sm.data.databox()
    d_save['xs']  = x_desired
    d_save['ys']  = y_desired
    d_save['zs']  = z_desired
    d_save.insert_header('original_file', d.path)
    # Save it
    d_save.save_file()
    
# =============================================================================
### Check that out
# =============================================================================

# The fitted points
z_fit = np.linspace(0.8*min(zs), 2*max(zs), 300)
x_fit = model_x(z_fit, *popt_x)
y_fit = model_y(z_fit, *popt_y)
# The guess
x_guess = model_x(z_fit, *tuple_guess_x)
y_guess = model_y(z_fit, *tuple_guess_y)
# 


fig = plt.figure(tight_layout=True, figsize=(10, 10))
plt.axis('off')

plt.title(('Original file: ' + d.path + '\n'+
           'Interpolate file: ' + d_save.path )
          , fontsize=10)

fig.add_subplot(2, 2, 1)
plt.plot(zs, xs,'.', label='Original pts')
plt.plot(z_fit, x_fit, label='Fit')
plt.plot(z_fit, x_guess, '--k', label='Guess')
plt.plot(z_desired, x_desired, '.r', label='Desired')
plt.xlabel("z (mm)")
plt.ylabel("x (mm)")
plt.legend(loc='best')
plt.axis('equal')

fig.add_subplot(2, 2, 2)
plt.plot(zs, ys,'.')
plt.plot(z_fit, y_fit)
plt.plot(z_fit, y_guess, '--k')
plt.plot(z_desired, y_desired, '.r')
plt.xlabel("z (mm)")
plt.ylabel("y (mm)")
plt.axis('equal')

fig.add_subplot(2, 2, 3)
plt.plot(xs, ys, '.')
plt.plot(x_fit, y_fit)
plt.plot(x_guess, y_guess, '--k')
plt.plot(x_desired, y_desired, '.r')
plt.xlabel("x (mm)")
plt.ylabel("y (mm)")
plt.axis('equal')

ax = fig.add_subplot(2, 2, 4, projection='3d')
plt.plot(xs, ys, zs, '.')
plt.plot(x_fit, y_fit, z_fit)
plt.plot(x_fit, y_guess, z_fit, '--k')
plt.plot(x_desired, y_desired, z_desired, '.r')
plt.xlabel("x (mm)")
plt.ylabel("y (mm)")
ax.set_zlabel('z (mm)')
# Set equal aspect on the 3D plot.
# For this we need the extremum of all the pts
allpts = np.concatenate((xs, ys, zs))
max_all = np.max(allpts)
min_all = np.min(allpts)
radius = 0.5*(max_all - min_all)
# Get the central position
xmean = np.mean(xs)
ymean = np.mean(ys)
zmean = np.mean(zs)
# Set the axe such that it span the same amount in each direction
ax.set_xlim3d(xmean-radius, xmean+radius)
ax.set_ylim3d(ymean-radius, ymean+radius)
ax.set_zlim3d(zmean-radius, zmean+radius)




































