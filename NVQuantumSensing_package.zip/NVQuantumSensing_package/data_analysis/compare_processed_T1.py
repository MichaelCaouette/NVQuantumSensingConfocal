# -*- coding: utf-8 -*-
"""
Created on Wed Apr 14 12:59:19 2021

Goal:
    Compare the data from various runs of T1

@author: Childresslab
"""

import spinmob as sm
import numpy as np
import matplotlib.pyplot as plt 


ds = sm.data.load_multiple(text='Select many processed T1 runs')

# Set true for a comparison of the rates on the same plot. 
want_list_perso_label = True # If we want more clarity

# Useful only if want_list_perso_label = True 
#list_label = ['Non-Adaptive', 'Adaptive']
list_label = ['2021-07-07', '2021-08-12']

# =============================================================================
###  Plot each rate on the same plot for all data file.
# =============================================================================

plt.figure(tight_layout=True, figsize=(15,8))

ax_p = plt.subplot(211)
ax_m = plt.subplot(212)

# Plot each data set
for i, d in enumerate(ds):
    # Extract what we want
    list_Bz  = d['Bz_(T)'] * 1e3
    list_eBz = d['eBz_(T)']* 1e3
    list_gp  = d['gp_Hz']  * 1e-3
    list_egp = d['egp_Hz'] * 1e-3
    list_gm  = d['gm_Hz']  * 1e-3
    list_egm = d['egm_Hz'] * 1e-3
    directory = d.headers['directory']  
    
    ax_p.errorbar(list_Bz, list_gp, xerr=list_eBz, yerr=list_egp, 
                 fmt='.-', label=directory.split('/')[-3])
    ax_m.errorbar(list_Bz, list_gm, xerr=list_eBz, yerr=list_egm, 
                 fmt='.-')
ax_p.set_title('Rates')
ax_p.legend(bbox_to_anchor=(1.00, 1),loc='upper left')  
ax_m.set_xlabel('Bz (mT)')
ax_p.set_ylabel('$\Gamma_+$ (kHz)', fontsize=20)
ax_m.set_ylabel('$\Gamma_-$ (kHz)', fontsize=20)

title = ''
for d in ds:
    title += '\n'+ d.headers['directory']  
plt.title(title, fontsize=9)

# =============================================================================
# ##Plot each data set on a separate plot
# =============================================================================
N_data = len(ds)
fig, axes = plt.subplots(N_data, 1, 
                         tight_layout=True, 
                         figsize=(15,8),
                         sharex=True)
#    fig.subplots_adjust(wspace=0, hspace=0) #Remove spacing
axs = axes.flat #Flat the axis in order to acces them with a single index    

# Plot each 
for i, d in enumerate(ds):
    ax = axs[i]
    # Extract what we want
    list_Bz  = d['Bz_(T)'] * 1e3
    list_eBz = d['eBz_(T)']* 1e3
    list_gp  = d['gp_Hz']  * 1e-3
    list_egp = d['egp_Hz'] * 1e-3
    list_gm  = d['gm_Hz']  * 1e-3
    list_egm = d['egm_Hz'] * 1e-3
    directory = d.headers['directory']  
    # How long for acquiring the data
    days = np.sum(d['pulse_duration_sec'])/3600/24
    
    
    # The points
    ax.errorbar(list_Bz, list_gp, xerr=list_eBz, yerr=list_egp, 
                 fmt='.-', color='C0')
    ax.errorbar(list_Bz, list_gm, xerr=list_eBz, yerr=list_egm, 
                 fmt='.-', color='C1')
    # Some cool filling
    ax.fill_between(list_Bz, 
                     list_gp-list_egp, list_gp+list_egp,
                     alpha=0.5,  color='C0', label='$\Gamma_+$')
    # Some cool filling
    ax.fill_between(list_Bz, 
                     list_gm-list_egm, list_gm+list_egm,
                     alpha=0.5, color='C1', label='$\Gamma_-$')
    
    if want_list_perso_label:
        
        # Total time elapsed
        s_time = '%.2f days\n'%days 
        ax.text(0.2, 0.05, s_time,
                horizontalalignment='center',
                verticalalignment='center',
                transform = ax.transAxes)
        # duty cycle
        T_total = np.sum( d['pulse_duration_sec'] )
        T_decay = np.sum( d['time_decay'] )
        duty = T_decay / T_total
        s_duty= 'Duty Cycle %.1f percent\n'%(duty*100)         
        ax.set_ylabel(s_duty+list_label[i], fontsize=14) 
        
        
    else:
        ax.set_ylabel(directory.split('/')[-3], fontsize=14)        
    
axs[0].set_title('Rates (kHz)', fontsize=20)

#    axs[0] .legend(bbox_to_anchor=(1.00, 1),loc='upper left')  
axs[-1].legend(loc='best')  
axs[-1].set_xlabel('External DC field (mT)', fontsize=14)
    
 


# =============================================================================
### Plot the sensitivity
# =============================================================================
plt.figure(tight_layout=True, figsize=(15,8))

ax_p   = plt.subplot(311) # Sensitivity on Gamma+
ax_m   = plt.subplot(312) # Sensitivity on Gamma-
ax_mix = plt.subplot(313) # Relative sensitivity on both rates
# Plot each data sets
for i, d in enumerate(ds):
    # Extract the data
    list_Bz  = d['Bz_(T)'] * 1e3
    list_eBz = d['eBz_(T)']* 1e3
    list_gp  = d['gp_Hz']  * 1e-3
    list_egp = d['egp_Hz'] * 1e-3
    list_gm  = d['gm_Hz']  * 1e-3
    list_egm = d['egm_Hz'] * 1e-3
    list_t   = d['pulse_duration_sec'] 
    directory = d.headers['directory']  
    # Compute the sensitivities
    sens_p = list_egp * np.sqrt( list_t )
    sens_m = list_egm * np.sqrt( list_t )
    sens_mix = np.sqrt( (list_egp/list_gp)**2 + 
                        (list_egm/list_gm)**2 ) * np.sqrt( list_t )
    
    ax_p.errorbar(list_Bz, sens_p, xerr=list_eBz, 
                 fmt='.-', label=directory.split('/')[-3])
    ax_m.errorbar(list_Bz, sens_m , xerr=list_eBz,  
                 fmt='.-')
    ax_mix.errorbar(list_Bz, sens_mix , xerr=list_eBz,  
                 fmt='.-')   
ax_p.set_title('Sensitivities')    
ax_p.legend(bbox_to_anchor=(1.00, 1),loc='upper left')  
ax_mix.set_xlabel('Bz (mT)')
ax_p.set_ylabel('$\eta_+$ (kHz / $Hz^{1/2}$)', fontsize=20)
ax_m.set_ylabel('$\eta_-$ (kHz / $Hz^{1/2}$)', fontsize=20)

str_mix = '$ \sqrt{ (\\frac{e\Gamma_+}{\Gamma_+})^2 + (\\frac{e\Gamma_-}{\Gamma_-})^2 } \sqrt{ T_{total} } $'
ax_mix.set_ylabel(str_mix+'\n (1 / $Hz^{1/2}$)', fontsize=15)

















