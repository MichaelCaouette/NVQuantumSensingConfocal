# -*- coding: utf-8 -*-
"""
Created on Sat Feb 20 10:47:14 2021

@author: Childresslab
"""

import spinmob as sm
import numpy as np
import matplotlib.pyplot as plt 





# Load multiple pulsed ESR data
ds = sm.data.load_multiple(text='Select many adaptive pipulse results')
N_exp = len(ds)

# Set the name of the coolumns. In case this get changed 
str_setfreq = 'Frequency_(GHz)'
str_setpow  = 'Power_(dBm)'
str_c0   = 'Total_counts_0'
str_c1   = 'Total_counts_1'
str_rep  = 'repetition'
str_iter = 'iteration'
str_Nr_seq   = 'Nb_readout_per_sequence'
str_dtpulse = '/sig_gen_pulsed_ESR/dt_rf_pulse'
str_f0  = 'mean_f0_(GHz)'
str_ef0 = 'std_f0_(GHz)'
str_P0  = 'mean_P0_(dBm)'
str_eP0 = 'std_P0_(dBm)'
str_start_time = 'starting_time_sec'
str_time_ela = 'absolute_time_sec'
str_threshold_P0 = 'threshold_P0'
str_threshold_f0 = 'threshold_f0'
str_t_find_set  = 'duration_find_settings_sec'
str_t_prep_set  = 'duration_set_sig_gen_sec'
str_t_pulse_seq = 'duration_pulse_sequence_sec'


def gaussian(f, P_dBm,
             f0, P0_dBm, wf, wp_dBm, ampl):
    """
    Model for the signal of our measurement. 
    
    Here the measurement is assumed to be proportional to the difference in 
    photoluminescence between NOT appliying a microwave pulse and applying a 
    microwave pulse.
         
    Choice of input unit:
        Power in dBm
        Frequency: as long as they are all the same
        
    Input parameters:
        PLEASE EXPLAIN. It is a 2D gaussian with no offset and not skewed. 
         
    
    """
    
    first = (f - f0) / wf
    sec   = (P_dBm - P0_dBm) / wp_dBm
    
    exponant2 = first**2 + sec**2
    
    return ampl * np.exp( - 0.5 * exponant2 )    

#Append all the data together
list_setf = []
list_setP = []
list_z = [] # The measurement
# For the parameters
list_ef0 = []
list_eP0 = []
# For studying the duty cycle
list_t_find_set  = np.zeros(N_exp)
list_t_prep_set  = np.zeros(N_exp)
list_t_pulse_seq  = np.zeros(N_exp)

# Other
list_time_elapsed = [] 

for i in range(N_exp):
    d = ds[i] # Get the data folder
    # About the parameters
    ef0 = d.headers[str_ef0]
    eP0 = d.headers[str_eP0]
    # Get all the infor that we care
    fs = d[str_setfreq]
    ps = d[str_setpow]
    c0 = d[str_c0]
    c1 = d[str_c1]
    # Compute the data that we want: the difference in counts per readout
    rep = d.headers[str_rep]
    Niter = d.headers[str_iter]
    Nr_seq = d.headers[str_Nr_seq]
    N_readout = Nr_seq * Niter * rep  # Get the total readout
    z = ( c0 - c1 ) / N_readout
    # Append all that
    list_setf.extend( fs )
    list_setP.extend( ps )
    list_z.extend( z )
    list_ef0.append(ef0)
    list_eP0.append(eP0)   
    # Check the elapsed time
    list_time_elapsed.append( d.headers[str_time_ela] )
    # For the duty cycle
    list_t_find_set[i]   = d.headers[ str_t_find_set   ] 
    list_t_prep_set[i]   = d.headers[ str_t_prep_set   ]
    list_t_pulse_seq[i]  = d.headers[ str_t_pulse_seq  ]

list_z = np.array(list_z)
# Compute the time elapsed since the first data
# Future data files should contain the starting time. For now, we cheat a 
# little bit by estimating the starting time with the mean difference in 
# elapsed time
print('We cheat for the starting time. Check the comments')
t_abs = np.array( list_time_elapsed) 
t_ela = t_abs - t_abs[0] + np.mean( np.diff(t_abs) )

# Get the best estimated parameters
label_parms = ['f0_(GHz)', 'P0_(dBm)', 'Width_f_(GHz)', 'Width_P_(dBm)', 'Ampl']
parms_inf = []

str_print = 'N_readout per point= %d\n'%N_readout
for label in label_parms:
    key_mean = 'mean_' + label
    mean = d.headers[key_mean]
    parms_inf.append( mean )
    key_std = 'std_' + label
    std = d.headers[key_std]
    str_print += '\n' + label + ' = %f +- %f'%(mean, std) 
print(str_print)

# Expected map
inf_f0 = parms_inf[0]
#inf_p0 = parms_inf[1]
inf_wf = parms_inf[2]
#inf_wp = parms_inf[3]
xs = np.linspace(inf_f0 - 3*inf_wf, inf_f0 + 3*inf_wf, 250)
ys = np.linspace(min(list_setP), max(list_setP), 247)
#xs = np.linspace(min(list_setf), max(list_setf), 537)
#ys = np.linspace(min(list_setP), max(list_setP), 587)
x_mesh, y_mesh = np.meshgrid(xs, ys)
z_fit = gaussian(x_mesh, y_mesh, *parms_inf)

# Get other stuff
dt_rf_pulse = d.headers[str_dtpulse]
threshold_P0 = d.headers[str_threshold_P0]
threshold_f0 = d.headers[str_threshold_f0]


# =============================================================================
### Plot the duty cycle 
# =============================================================================
plt.figure(tight_layout=True, figsize=(15, 8))

Nbins = 3 
plt.hist(list_t_find_set , bins=Nbins, label= 'Finding best settings',linewidth=0)
plt.hist(list_t_prep_set , bins=Nbins, label= 'Prepare settings' ,linewidth=0)
plt.hist(list_t_pulse_seq, bins=Nbins, label= 'Run pulse_sequence' ,linewidth=0)
plt.legend()#loc='center') #bbox_to_anchor=(1.00, 1),loc='upper left') 
#plt.xscale('log')
plt.xlabel('Time (sec)')
plt.ylabel('Occurence')
plt.title(d.path, fontsize=8)  

# =============================================================================
### Awesome plotting
# =============================================================================

# Initiate the plot
plt.figure(tight_layout=False, figsize=(15, 8))

# Plot the probed freq and power
ax = plt.subplot(221) # 2 rows, 2 columns, Select the first plot
# The best estimate
pc = plt.pcolor(x_mesh, y_mesh, 1e3*z_fit, cmap='jet') #'cubehelix_r'
cb = plt.colorbar(pc, orientation='horizontal', fraction=.1)
cb.set_label('Inference (*10^-3)')
# The probed positions
plt.plot(list_setf, list_setP, '.r', alpha=0.7)
plt.xlabel('Frequency probed (GHz)')
plt.ylabel('Power probed (dBm)')
plt.text(0.02, .9, '(a)', transform=ax.transAxes)
# Chop the title
sss = ''
for s in d.path .split(maxsplit=2):
    sss += '\n' + s
plt.title(sss, fontsize=11)

# Plot the evolution of the uncertainty
ax = plt.subplot(222) # 2 rows, 2 columns, 2nd plot
# Frequency
ax.loglog(t_ela, list_ef0, '.-', color='C0')
ax.plot(t_ela, 0*t_ela + threshold_f0, '--', color='C0', label='Aimed threshold') 
ax.set_ylabel("Uncertainty Freq (GHz)" ,color='C0')
ax.tick_params(axis='y', colors='C0')
ax.set_xlabel('Time elapsed (s)')
plt.legend()
# Power
ax2 = ax.twinx()
ax2.loglog(t_ela, list_eP0, '.-', color='C1')
ax2.plot(t_ela, 0*t_ela + threshold_P0, '--', color='C1') 
ax2.set_ylabel("Uncertainty Pow (dBm)", color='C1')
ax2.tick_params(axis='y', colors='C1')
ax2.spines['right'].set_color('C1')
ax2.spines['left'].set_color('C0')
plt.xlabel("Time elapsec (sec)")
plt.text(0.02, .8, '(b)', transform=ax.transAxes)
plt.text(0.02, .1, str_print, transform=ax.transAxes,
         fontsize=11, color='black')
# Set the title
n_measure = len(list_setf)
txt_title = ('dt_pulse = %f us'%dt_rf_pulse +
             '\n# Inference: %d'%N_exp +
             '\n# pts probed per inference: %d'%(int( n_measure/N_exp )))
plt.title( txt_title)


# Plot the measurements
ax = plt.subplot(223)
tr = plt.tripcolor(list_setf, list_setP, 1e3*list_z)
cb = plt.colorbar(tr, orientation='horizontal', fraction=.1)
cb.set_label('Measured (*10^-3) ')
plt.xlabel('Frequency probed (GHz)')
plt.ylabel('Power probed (dBm)')
plt.text(0.02, .9, '(c)', transform=ax.transAxes)

# PLot the measured position
ax = plt.subplot(224) # 2 rows, 2 columns, 4th plot
plt.semilogx(np.arange(n_measure) + 1, list_setf, 'k.', alpha=.2)
plt.plot()
plt.ylabel("Frequency probed")
plt.xlabel("No. of measurements")
plt.text(0.02, .9, '(d)', transform=ax.transAxes)  





