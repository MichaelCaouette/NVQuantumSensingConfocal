# -*- coding: utf-8 -*-
"""
Created on Wed Jun  2 11:08:00 2021

Goal:
    Load ESr data and find the B field

@author: Childresslab
"""

import B_process_function as _B_func

import matplotlib.pyplot as plt
import spinmob as sm
import numpy as np


#TODO The other mode
mode = '1 peak per file' # Weither we have the two peaks per file or not.

# We will list the resonance frequencies
list_f0_p = []
list_f0_m = []
list_ef0_p = []
list_ef0_m = []


if mode == '1 peak per file':
    list_data_plus  = sm.data.load_multiple(text='Load ESR data fro the PLUS' )
    list_data_minus = sm.data.load_multiple(text='Load ESR data fro the MINUS')
    
    for i in range( len(list_data_plus) ):
        # Get the freqiencies plus        
        data_p = list_data_plus[i]
        fps, efps, _, _ = _B_func.get_peaks(data_p)
        list_f0_p .append( fps[0])
        list_ef0_p.append(efps[0])
        
        # Get the freqiencies minus        
        data_m = list_data_minus[i]
        fms, efms, _, _ = _B_func.get_peaks(data_m)
        list_f0_m .append( fms[0])
        list_ef0_m.append(efms[0])        

list_f0_p  = np.array(list_f0_p )
list_ef0_p = np.array(list_ef0_p)
list_f0_m  = np.array(list_f0_m )
list_ef0_m = np.array(list_ef0_m)
   

# =============================================================================
# Determine the field from each pair of frequency.
# =============================================================================
N_data = len(list_f0_p)

list_Bz = np.zeros(N_data)
list_Bperp = np.zeros(N_data)
list_eBz = np.zeros(N_data)
list_eBperp = np.zeros(N_data)

for i in range(N_data):
    list_Bz[i], list_eBz[i] =  _B_func.uBz(list_f0_p[i], list_ef0_p[i], 
                                           list_f0_m[i], list_ef0_m[i] )        
    list_Bperp[i], list_eBperp[i] =  _B_func.uBperp(list_f0_p[i], list_ef0_p[i], 
                                                    list_f0_m[i], list_ef0_m[i] )
 
       

# =============================================================================
# # Plot the fields
# =============================================================================
list_files = np.arange(1, N_data+1)


fig, axs = plt.subplots(nrows=4, ncols=1, 
                        sharex=True,tight_layout=True)
#fig.subplots_adjust(hspace=0)
title = ''
for i, d in enumerate(list_data_plus):
    title += '\n%d: '%(i+1)+d.path
axs[0].set_title(title, fontsize=9)
# Frequency +
axs[0].errorbar(list_files, list_f0_p, yerr=list_ef0_p, fmt='.')
axs[0].set_ylabel("Freq + (GHz)")
# Frequency -
axs[1].errorbar(list_files, list_f0_m, yerr=list_ef0_m, fmt='.')
axs[1].set_ylabel("Freq - (GHz)")
# B field parallele
axs[2].errorbar(list_files, list_Bz*1e3, yerr=list_eBz*1e3, fmt='.')
axs[2].set_ylabel("Field || (mT)")
# B field perpendicular
axs[3].errorbar(list_files, list_Bperp*1e3, yerr=list_eBperp*1e3, fmt='.')
axs[3].set_ylabel("Field perp (mT)")
 
axs[3].set_xlabel("Data file")







        
        
        
        



            
        
        
        



    
    
    


