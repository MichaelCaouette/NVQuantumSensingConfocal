# -*- coding: utf-8 -*-
"""
Created on Thu Oct 31 15:53:35 2019

GOAL: Fit a lorentz on each individual peak. 


    
    
"""

import matplotlib.pyplot as plt
import spinmob as sm
import numpy as np
import scipy.optimize as opt
from scipy.signal import find_peaks

#Lorentz function for the fits
def lorentz(f, f0, BG, amplitude, width):
    """
    Lorentzian function
    """
    return BG - amplitude/(1 + ((f-f0)/width)**2 )

#Load data file into databoxes
d = sm.data.load(text="Select a Single ESR data file")

str_count = 'Total_counts_0' # Count with the RF
str_ref   = 'Total_counts_1' # Count without RF 
str_dt_read = 'dt_on' # count time


nbPointsBetweenPeak = 5 #Minimum number of point between peaks
df = 0.4 #Width of the range over with the single lorentzian if fitted


#Extract usefull data (un-usefull data are not extracted lol !!!!!)
fs = d[0] #Frequencies 

total_counts = d[str_count]# Total counts
etotal_counts = np.sqrt(total_counts) # uncertainty in the count. Assuming poisson
total_ref = d[str_ref]# Total counts
etotal_ref= np.sqrt(total_ref) # uncertainty in the count. Assuming poisson
#Get the count rate in count/sec
dt = d.headers[str_dt_read] # count time in us
rep = d.headers['repetition']
nb_iter = d.headers['iteration']
count_rate  = total_counts*1e6/(nb_iter*rep*dt) 
ecount_rate = etotal_counts*1e6/(nb_iter*rep*dt) 
ref_rate  = total_ref*1e6/(nb_iter*rep*dt) 
eref_rate = etotal_ref*1e6/(nb_iter*rep*dt) 

# Get the signal 
signal_tot  = total_counts - total_ref
esignal_tot = np.sqrt(total_counts + total_ref ) # Poissonian noise
sig  = signal_tot  *1e6/(nb_iter*rep*dt) 
esig = esignal_tot *1e6/(nb_iter*rep*dt) 


#Get the peaks !
f0s = np.array([]) #Containt the  peaking frequencies
ef0s = np.array([]) #Containt the error in peaking frequency

#Estimate the peaks

y = -sig + max(sig) #Invert the peak such that they point up and make them positive
minPeak = (max(y)-min(y))/2 + y*0 #Minimum Height of the peak
maxPeak =  (max(y)-min(y))*1.2 + y*0 #Maximum height for the peak
peak_indices, _ = find_peaks(y, height=(minPeak,maxPeak), width=nbPointsBetweenPeak)
#Check what I got 
plt.figure()
plt.plot(fs,y)
plt.plot(fs[peak_indices], y[peak_indices], "x", label='peak guess')   
plt.plot(fs, minPeak, "--", color="gray", label="Minimum")
plt.plot(fs, maxPeak, ":", color="gray", label="Maximum")
plt.legend()
plt.title("Check the peaks detected")


#Fit on each peak
plt.figure()
plt.errorbar(fs, sig, yerr=esig, fmt='.')
for peak_index in peak_indices:
    
    f0_guess = fs[peak_index]
    index = (fs<(f0_guess+df/2) )*(fs>(f0_guess-df/2) )
    f_fit = fs[index]
    c_fit  =  sig[index]
    ec_fit = esig[index]
    #guesses for the parameters
    BG_guess = max(c_fit)
    amplitude_guess =  BG_guess - min(c_fit)
    width_guess = 0.01
    initial_guess = (f0_guess, BG_guess, amplitude_guess, width_guess)
    popt, pcov = opt.curve_fit(lorentz, f_fit, c_fit, sigma=ec_fit,
                               p0=initial_guess)
    perr = np.sqrt(np.diag(pcov)) #error from the fit. 
    #Extract the resonance frequency and the error
    f0 = popt[0]
    ef0 = perr[0]
    f0s = np.append(f0s, f0)
    ef0s = np.append(ef0s, ef0)
    
    plt.plot(f_fit, lorentz(f_fit, *popt), '--', label='f0 = %f +- %f GHz'%(f0, ef0))

plt.xlabel("Frequency (GHz)")
plt.ylabel("Counts")
plt.title(d.path,fontsize=8)
plt.legend(loc='best')
plt.show()


    
    
    











    
    
    
    
    
    
    
    
#    



#Grave Yaaaard

#BzMesh, fmesh = np.meshgrid(np.append(Bzs,99999), np.append(fs,9999)) #Meshgrif for 2D plot        
#BzMesh, fmesh = np.meshgrid(Bzs, fs) #Meshgrif for 2D plot          
#        
##Plot what we got with the field
#plt.figure()
#plt.pcolor(BzMesh,fmesh,PL,cmap="viridis")
#plt.xlabel('Bz (mT)')
#plt.ylabel('frequency (GHz)')
#str1 = d.path
#str2 = "\nTrajectory = " + trajectoryFile.split('\\')[-1]
#plt.title(str1+str2, fontsize=8)
#plt.colorbar(label="counts/sec")







#fmin = h.h('Start frequency1 (GHz)') #Minimum frequency
#fmax = h.h('Stop frequency1 (GHz)') #Maximum frequency
#I manually input the frequency because Labview doesn't succed to saved them well with List Sweep... :/
#fs = np.linspace(0.5, 5, 601) #Frequency array, assuming same spacing everywhere













#def getfm(i):
#    """
#    Extract the minimumresonance frequency of the i'th dataset
#    
#    """
#    #First estimate the peak position
#    y = -d[i] + max(d[i]) #Invert the peak such that they point up/ 
#    minPeak = (max(y)-min(y))/2 + y*0 #Minimum Height of the peak
#    maxPeak =  (max(y)-min(y))*1.2 + y*0 #Maximum height for the peak
#    peaks, _ = find_peaks(y, height=(minPeak,maxPeak))
#    df = 1 #Width of the range on which we fit the Lorentzian
#    #For the plus
#    #take data around the peak
#    f0_guess = min(fs[peaks])
#    index = (fs<(f0_guess+df/2) )*(fs>(f0_guess-df/2) )
#    f_fit = fs[index]
#    c_fit = y[index]
#    #guesses for the parameters
#    BG_guess = min(c_fit)
#    amplitude_guess = max(c_fit) - BG_guess
#    width_guess = 0.01
#    initial_guess = (f0_guess, BG_guess, amplitude_guess, width_guess)
#    popt, pcov = opt.curve_fit(lorentz, f_fit, c_fit, p0=initial_guess)
#    perr = np.sqrt(np.diag(pcov)) #error from the fit. 
#    #Extract the resonance frequency and the error
#    fm = popt[0]
#    efm = perr[0]
#    
#    return fm, efm



#    
#    
#    
#    
#    
#    
#
#for i in range(0,Ntraj):
#    
#    #Exctract the two extrem frequency and there errors
#    fp, efp = getfp(i)
#    fm, efm = getfm(i)
#    
#    fps = np.append(fps, fp)
#    fms = np.append(fms, fm)
#    efps = np.append(efps, efp)
#    efms = np.append(efms, efm)    
#    
#
##Plot what we got
#plt.figure()
#plt.pcolor(trajMesh,fmesh,PL,cmap="viridis")
#plt.plot(trajs+0.5, fps, '--o')
#plt.plot(trajs+0.5, fms, '--o')
#plt.xlabel('Trajectory label')
#plt.ylabel('frequency (GHz)')
#str1 = d.path
#str2 = "\nTrajectory = " + trajectoryFile.split('\\')[-1]
#plt.title(str1+str2, fontsize=8)
#plt.colorbar(label="counts/sec")
#
#
#
#
#
#
#
#
#
#
##Compute the field
#D = 2.8707 #GHz
#gamma = 2.8025*1e-3*10 #GHz/mT
#
#Bzs = 0*fps #Initialize the field along z
#
#for i in range(0,Ntraj):
#    
#    wp = fps[i]
#    wm = fms[i]
#
#    print("\nThis is Yacobi's formula for %d"%i)
#    #Field parallele squared
#    Bz2 = -(D+wp-2*wm)*(D+wm-2*wp)*(D+wm+wp)/(3*gamma*np.sqrt(3*D))**2
#    #Field perpendicular squared
#    Bper2 = -(2*D-wp-wm)*(2*D+2*wm-wp)*(2*D-wm+2*wp)/(3*gamma*np.sqrt(3*D))**2
#    
#    
#    print(Bz2)
#    print(Bper2)
#    
#    if Bz2>= 0:
#        print("Bz = %f mT"%np.sqrt(Bz2))
#        Bzs[i] = np.sqrt(Bz2)
#    else:
#        print("Bz^2 is negative")
#        Bzs[i] = -11111 #An absurd value to make sure I notice. 
#    if Bper2>= 0:
#        print("Bper = %f mT"%np.sqrt(Bper2))
#    else:
#        print("Bper^2 is negative")
#    
#
#
#
#
#
##Plot this 
#plt.figure()
#plt.plot(Bzs, fps, "-x", label="Top Splitting")
#plt.plot(Bzs, fms, "-x", label="Bottom Splitting")
#plt.legend()
#plt.xlabel("Field along NV axis (mT)")
#plt.ylabel("Frequency (GHz)")
#str1 = d.path
#str2 = "\nTrajectory = " + trajectoryFile.split('\\')[-1]
#plt.title(str1+str2, fontsize=8)
#
#
#
##For fun, plot the energies !!
#E0 = 2*D/3 - (fps + fms)/3
#E1 = E0 + fms
#E2 = E0 + fps
#plt.figure()
#plt.plot(Bzs, E0, "-x", label="E0")
#plt.plot(Bzs, E1, "-x", label="E1")
#plt.plot(Bzs, E2, "-x", label="E2")
#plt.legend()
#plt.xlabel("Field along NV axis (mT)")
#plt.ylabel("Energies (GHz)")
#str1 = d.path
#str2 = "\nTrajectory = " + trajectoryFile.split('\\')[-1]
#plt.title(str1+str2, fontsize=8)
#
#
#
#
#
#
#
##For debuging, select the i value on which you want to see the peak
#i = 1
#y = -d[i] + max(d[i]) #Invert the peak such that they point up/ 
#minPeak = (max(y)-min(y))/2 + y*0 #Minimum Height of the peak
#maxPeak =  (max(y)-min(y))*1.2 + y*0 #Maximum height for the peak
#peaks, _ = find_peaks(y, height=(minPeak,maxPeak))
#
#
##Fit a lorentzian around each peak
#
#    
#
#
#plt.figure()
#plt.plot(fs,y)
#plt.plot(fs[peaks], y[peaks], "x", label='peak guess')   
#
#df = 1 #Width of the range on which we fit the Lorentzian
##For the plus
##take data around the peak
#f0_guess = max(fs[peaks])
#index = (fs<(f0_guess+df/2) )*(fs>(f0_guess-df/2) )
#f_fit = fs[index]
#c_fit = y[index]
##guesses for the parameters
#BG_guess = min(c_fit)
#amplitude_guess = max(c_fit) - BG_guess
#width_guess = 0.01
#initial_guess = (f0_guess, BG_guess, amplitude_guess, width_guess)
#popt, pcov = opt.curve_fit(lorentz, f_fit, c_fit, p0=initial_guess)
#perr = np.sqrt(np.diag(pcov)) #error from the fit. 
##Extract the resonance frequency and the error
#fp = popt[0]
#efp = perr[0]
##Compute the fit over the fitted range, for checking
#c_fitted = lorentz(f_fit, *popt)
#
#plt.plot(f_fit, c_fitted, '--', color='limegreen', label='Lorentz fit = %.3f +- %.3f GHz'%(fp, efp))
#
#
#df = 1 #Width of the range on which we fit the Lorentzian
##For the plus
##take data around the peak
#f0_guess = min(fs[peaks])
#index = (fs<(f0_guess+df/2) )*(fs>(f0_guess-df/2) )
#f_fit = fs[index]
#c_fit = y[index]
##guesses for the parameters
#BG_guess = min(c_fit)
#amplitude_guess = max(c_fit) - BG_guess
#width_guess = 0.01
#initial_guess = (f0_guess, BG_guess, amplitude_guess, width_guess)
#popt, pcov = opt.curve_fit(lorentz, f_fit, c_fit, p0=initial_guess)
#perr = np.sqrt(np.diag(pcov)) #error from the fit. 
##Extract the resonance frequency and the error
#fm = popt[0]
#efm = perr[0]
##Compute the fit over the fitted range, for checking
#c_fitted = lorentz(f_fit, *popt)
#
#plt.plot(f_fit, c_fitted, '--', color='orangered', label='Lorentz fit = %.3f +- %.3f GHz'%(fm, efm))
#
#
#plt.plot(fs, minPeak, "--", color="gray", label="Minimum")
#plt.plot(fs, maxPeak, ":", color="gray", label="Maximum")
#plt.xlabel("Frequency (GHz)")
#plt.ylabel("Counts")
#plt.legend(loc='best')
#plt.show()
#
##plt.plot(f_fit, lorentz(f_fit, *initial_guess), '--g', label="Top frequency lorentz fit")
##plt.plot([fm-efm, fm-efm], [minPeak[0], maxPeak[0]], '-', color='blue', label='Bottom frequency = %.3f +- %.3f GHz'%(fm, efm))
##plt.plot([fm+efm, fm+efm], [minPeak[0], maxPeak[0]], '-', color='blue')
##plt.plot([fp-efp, fp-efp], [minPeak[0], maxPeak[0]], '-', color='blue', label='Top frequency = %.3f +- %.3f GHz'%(fp, efp))
##plt.plot([fp+efp, fp+efp], [minPeak[0], maxPeak[0]], '-', color='blue')
#
#
#
#
#
#




