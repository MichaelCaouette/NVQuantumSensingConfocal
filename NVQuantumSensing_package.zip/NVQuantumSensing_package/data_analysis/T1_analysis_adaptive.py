# -*- coding: utf-8 -*-
"""
Created on Wed Jul  8 07:57:17 2020

Example of how to load the saturation curve

@author: Childresslab
"""

import T1_process_func as _T1_process

# Define the model function
def model_plus(t, gp, gm):
    return _T1_process.model_00m0(+1, t, gp, gm)
def model_minus(t, gp, gm):
    return _T1_process.model_00m0(-1, t, gp, gm)  

import spinmob as sm

import numpy as np
import matplotlib.pyplot as plt


## String for the headers of the data taken before 2021-05-17
#str_PL1_t0 = 'ms0_t0'
#str_PL1_tp = 'ms0_tprobed'
#str_PL2_t0 = 'ms-+1_t0'
#str_PL2_tp = 'ms-+1_tprobed'
## String for the headers of the data taken 2021-05-17 and after
str_PL1_t0 = 'PL1_t0'
str_PL1_tp = 'PL1_tprobed'
str_PL2_t0 = 'PL2_t0'
str_PL2_tp = 'PL2_tprobed'
       
# Weither or not to plot the fitting details
want_plot_fitter = False
# If we want to plot the domaine in log scale  
want_log_domain = True 

# Hardcoded information for now, because it is not included in the data file
N_FPGA_loop_per_optimization = 50
dt_optimization = 10  # (sec) How long it takes to optimize.
dt_no_decay = 20*1e-6 # (sec) Amount of time spent wihtout decay time in the single FPGA pulse sequence. 



# Get the data
ds = sm.data.load_multiple(text='Drift independant measurement;)')

# Note the headers keys for various stuffs
# it should prove useful if we change the headers key later. 
str_t_find_set   = 'duration_find_settings'
str_t_prep_set   = 'duration_prep_settings'
str_t_pulse_seq  = 'duration_pulse_sequence'
str_t_update_inf = 'duration_update_inference'
str_T_overhead   = 'Estimate_T_overhead'
# =============================================================================
# Extract the drift-independant measurement
# =============================================================================

# Check the ckeys
print(ds[0].ckeys)
# CHecks the headers
print(ds[0].hkeys)
N_data_file = len(ds)



# Store the drift independent measurement for each type of experiment
out = _T1_process.extract_measurement(ds)
(t_probe_plus_s, result_plus_s,  uncertainty_plus_s,
 t_probe_minus_s, result_minus_s, uncertainty_minus_s ) = out
 



# For studying the sensitivity
list_N_readout_p = []
list_N_readout_m = []
list_t_pulse_seq_p = []
list_t_pulse_seq_m = []
# For studying the duty cycle and ovehread times
list_t_find_set  = np.zeros(N_data_file)
list_t_prep_set  = np.zeros(N_data_file)
list_t_pulse_seq  = np.zeros(N_data_file)
list_t_update_inf = np.zeros(N_data_file)
list_T_overhead   = np.zeros(N_data_file)
list_iterations   = np.zeros(N_data_file)
list_N_readout    = np.zeros(N_data_file)


# Extract each the measurement from each data file
for i in range(N_data_file):
    # Get the data file
    d = ds[i]
    # Extract stuffs
    N_readout = d.headers['repetition']*d.headers['iteration']
    
    # Extract the time probed 
    t_probe = d.headers['t_probe']
    # Extract the drift_independent measurement from the file. 
    result, uncertainty = _T1_process.udiff_from_datafile(d)
    # Append the result depending on the type of measurement
    type_measurement = d.headers['Type_measure']    
    if type_measurement == +1:
        list_N_readout_p.append( N_readout )
        list_t_pulse_seq_p.append( d.headers[ str_t_pulse_seq  ] )
    elif type_measurement == -1:
        list_N_readout_m.append( N_readout )
        list_t_pulse_seq_m.append( d.headers[ str_t_pulse_seq  ] )
    
    # For the duty cycle
    list_t_find_set[i]   = d.headers[ str_t_find_set   ] 
    list_t_prep_set[i]   = d.headers[ str_t_prep_set   ]
    list_t_pulse_seq[i]  = d.headers[ str_t_pulse_seq  ]
    list_t_update_inf[i] = d.headers[ str_t_update_inf ]
    list_T_overhead  [i] = d.headers[ str_T_overhead   ]
    list_iterations  [i] = d.headers['iteration']
    list_N_readout[i] = N_readout
    
# Get into numpy array
list_N_readout_p = np.array(list_N_readout_p)
list_N_readout_m = np.array(list_N_readout_m)
list_t_pulse_seq_p = np.array(list_t_pulse_seq_p)
list_t_pulse_seq_m = np.array(list_t_pulse_seq_m)

# The overhead time is duplicated for alternative measurements
# Because T_overhead includes the two type of measurement in the acquisition code
list_T_overhead = list_T_overhead[1::2]
# Add up the pair of iterations (both type of measurement)
list_iterations = list_iterations[0::2] + list_iterations[1::2]
list_N_readout  = list_N_readout [0::2] + list_N_readout [1::2]

# Get extra infor for the inference
Gp_min = d.headers['Rate_+_min']*1e3 # In Hz please !!
Gp_max = d.headers['Rate_+_max']*1e3 # In Hz please !!
Gm_min = d.headers['Rate_-_min']*1e3 # In Hz please !!
Gm_max = d.headers['Rate_-_max']*1e3 # In Hz please !!
N_grid = d.headers['N_grid'] 




# =============================================================================
# Infere the rate with Bayes
# =============================================================================
# Inference at the end (with all the data)
out = _T1_process.rates_from_bayes_from_data(ds, model_plus, model_minus,
                                             Gp_min, Gp_max, 
                                             Gm_min, Gm_max, 
                                             N_grid)
gp_bayes, egp_bayes, gm_bayes, egm_bayes, corr, my_bayes = out

# Cummulative inference 
out = _T1_process.cum_rates_from_bayes(ds, model_plus, model_minus,
                                   Gp_min, Gp_max, 
                                   Gm_min, Gm_max, 
                                   N_grid)
t_elapsed, gp_protocole, egp_protocole, gm_protocole, egm_protocole = out

    
# =============================================================================
# Infer the rate with chi2
# =============================================================================
out = _T1_process.rate_from_chi2(ds, 
                                 model_plus, model_minus, 
                                 want_plot_fitter=want_plot_fitter)
gp_fit, egp_fit, gm_fit, egm_fit, chi2, dof, fitter = out


# =============================================================================
### Plot the sensitivity
# =============================================================================
plt.figure(figsize=(15, 8), tight_layout=True)  

# First show the uncertainty in loglog scale
ax = plt.subplot(311)
plt.loglog(t_elapsed/60, egp_protocole*1e-3, '.', label='eGamma+ from adaptive')
plt.loglog(t_elapsed/60, egm_protocole*1e-3, '.', label='eGamma- from adaptive')
# Beautify the plot
plt.legend(bbox_to_anchor=(1.00, 1),loc='upper left')
plt.ylabel('Uncertainty in rates (kHz)')    
plt.title(d.path, fontsize=8)

# Then plot the sensitivity
ax = plt.subplot(312)
eta_gp_adaptive = egp_protocole*np.sqrt(t_elapsed)
eta_gm_adaptive = egm_protocole*np.sqrt(t_elapsed)    

plt.plot(t_elapsed/60, eta_gp_adaptive*1e-3, label='eta+ from adaptive')
plt.plot(t_elapsed/60, eta_gm_adaptive*1e-3, label='eta- from adaptive')
# Beautify the plot
plt.legend(bbox_to_anchor=(1.00, 1),loc='upper left')
plt.ylabel('Sensitivity ( kHz*sqrt(sec) )')       

# Then plot the combined relative sensitivie and compare the prediction
ax = plt.subplot(313)
# Compute the expected sensitivity
from T1_sensitivity import find_best_sens

#T_overhead_per_seq = list_T_overhead[-1] / list_N_readout[-1]
N_mean_p = np.mean( list_N_readout_p[-5:] )
N_mean_m = np.mean( list_N_readout_m[-5:] )
best_sens, best_t1, best_t2 = find_best_sens((('00', '+0'), ('00', '-0')), 
                                             gp_bayes, gm_bayes, # In Hz !
                                             N1=N_mean_p, BG1=0, PL01=0.015, C1=0.1952,
                                             N2=N_mean_m, BG2=0, PL02=0.017, C2=0.136,
                                             type_sens='rel',
                                             t_overhead=np.mean(list_T_overhead[-5:]) ) # Just take the last five

# Experimental combined relative sensitivity         
rel_p = egp_protocole / gp_protocole
rel_m = egm_protocole / gm_protocole                                
sens_rel_exp =  ( (rel_p**2 + rel_m**2)*t_elapsed )**0.5

plt.plot(t_elapsed/60, 100*sens_rel_exp  ,'.-', label='Experimental')
plt.plot(t_elapsed/60, 0*t_elapsed+100*best_sens, label='Theoretical best')
# Beautify the plot
plt.legend(bbox_to_anchor=(1.00, 1),loc='upper left')
plt.xlabel('Elapsed time (min)')
plt.ylabel('Relative sensitivie\n( Percent/sqrt(Hz) )')   

# =============================================================================
### Plot the duty cycle 
# =============================================================================
plt.figure(tight_layout=True, figsize=(15, 8))

# Histograms 
ax = plt.subplot(311)
plt.hist(list_t_find_set, label='Finding best settings')
plt.hist(list_t_prep_set, label= 'Prepare settings' )
plt.hist(list_t_pulse_seq, label= 'Run pulse_sequence' )
plt.hist(list_t_update_inf, label= 'Update inference' )
plt.legend(bbox_to_anchor=(1.00, 1),loc='upper left')  
plt.xscale('log')
plt.xlabel('Time (sec)')
plt.ylabel('Occurence')
plt.title(d.path, fontsize=8)  


# Verify the overhead time
ax = plt.subplot(312)
# Estimate the time not to probe
# Make sure that the times are in second !
list_t_meas = 2 * ( list_N_readout_p*t_probe_plus_s + list_N_readout_m*t_probe_minus_s )
time_seq_no_probing =  list_t_pulse_seq_p + list_t_pulse_seq_m - list_t_meas

# Estimate the time spent to optimize
N_total_optimization = np.ceil( list_iterations/N_FPGA_loop_per_optimization )
time_optimizing = N_total_optimization * dt_optimization
time_seq_not_decay = dt_no_decay*list_N_readout


x_axis = np.arange(1, len(list_T_overhead)+1)
plt.plot(x_axis, list_T_overhead, '.-', label='Estimated T_overhead\nBy software')
plt.plot(x_axis, time_seq_no_probing, '.-', label='Whole pulse sequence\nWithout decay time. ')
plt.plot(x_axis, time_optimizing, '.-', label='Refocusing only')
plt.plot(x_axis, time_seq_not_decay+time_optimizing, '.-', label='Refocusing +\nDwell Times in pulse seq.')


plt.xlabel('Iteration of \nthe two pulse sequence')
plt.ylabel('Time (sec)')
plt.legend(bbox_to_anchor=(1.00, 1),loc='upper left')  


# Just a quantity that I do not use yet. 
sum_ovehead_times = list_t_find_set + list_t_prep_set + list_t_update_inf

# Plot the times probed and the supposely best times
ax = plt.subplot(313)
plt.plot(t_probe_plus_s*1e6 , '.-', color='C0', label='Plus')
plt.plot(t_probe_minus_s*1e6, '.-', color='C1', label='Minus')
plt.plot(0*x_axis + best_t1*1e6, '-', color='C0', label='Theoretcal best plus')
plt.plot(0*x_axis + best_t2*1e6, '-', color='C1', label='Theoretcal best minus')
plt.xlabel('Iteration of \nthe two pulse sequence')
plt.ylabel('Time (us)')
plt.legend(bbox_to_anchor=(1.00, 1),loc='upper left')

# =============================================================================
### Awesome plotting
# =============================================================================

# Initiate the plot
plt.figure(tight_layout=True, figsize=(15, 8))

# Plot the plus type of measurement
ax = plt.subplot(221) # 2 rows, 2 columns, Select the first plot
t_fit = np.linspace(t_probe_plus_s.min(), t_probe_plus_s.max(), 300) # sec
y_fit = model_plus(t_fit, gp_fit, gm_fit)
plt.errorbar(t_probe_plus_s*1e6, result_plus_s, yerr=uncertainty_plus_s, 
             fmt='.', label='Plus')
plt.plot(t_fit*1e6, y_fit, label='Chi2 Fit')
plt.legend()
plt.xlabel('Time probed (us)')
plt.ylabel('Diff-ratio')
plt.title(d.path, fontsize=8)
plt.text(0.02, .9, '(a)', transform=ax.transAxes)
if want_log_domain:
    plt.xscale('log')

# Plot the minus type of measurement
ax = plt.subplot(223) # 2 rows, 2 columns
t_fit = np.linspace(t_probe_minus_s.min(), t_probe_minus_s.max(), 300) # sec
y_fit = model_minus(t_fit, gp_fit, gm_fit)
plt.errorbar(t_probe_minus_s*1e6, result_minus_s, yerr=uncertainty_minus_s, 
             fmt='.', label='Minus')
plt.plot(t_fit*1e6, y_fit, label='Chi2 Fit')
plt.legend()
plt.xlabel('Time probed (us)')
plt.ylabel('Diff-ratio')
plt.text(0.02, .9, '(b)', transform=ax.transAxes)
if want_log_domain:
    plt.xscale('log')

# Plot the evolution of the uncertainties
ax = plt.subplot(222) # 2 rows, 2 columns, 2nd plot
# Gamma +
ax.loglog(t_elapsed, egp_protocole*1e-3, '.-', color='C0')
ax.set_ylabel("e$\Gamma_+$ (kHz)" ,color='C0')
ax.tick_params(axis='y', colors='C0')
ax.set_xlabel('Elapsed time (sec)')
# Gamma - 
ax2 = ax.twinx()
ax2.loglog(t_elapsed, egm_protocole*1e-3, '.-', color='C1')
ax2.set_ylabel("e$\Gamma_-$ (kHz)", color='C1')
ax2.tick_params(axis='y', colors='C1')
ax2.spines['right'].set_color('C1')
ax2.spines['left'].set_color('C0')
plt.text(0.02, .9, '(c)', transform=ax.transAxes)
plt.title('Uncertainties in the rates')


# Plot the Inference of the rates
ax = plt.subplot(224)
Z, mesh_gp, mesh_gm = my_bayes.get_post()
plt.pcolor(mesh_gp*1e-3, mesh_gm*1e-3, Z, cmap=plt.cm.jet)
plt.colorbar(label="Probability density")
plt.errorbar(gp_bayes*1e-3, gm_bayes*1e-3, 
                     xerr=egp_bayes*1e-3, yerr=egm_bayes*1e-3,
                     fmt='.', color='red', label='Bayes') 
plt.errorbar(gp_fit*1e-3, gm_fit*1e-3, 
                     xerr=egp_fit*1e-3, yerr=egm_fit*1e-3,
                     fmt='.', color='blue', label='chi2 fit') 
plt.text(0.02, .9, '(d)', transform=ax.transAxes)
plt.axis("equal")#Equate the axis for a better estimate of the relative error
plt.xlabel('$\Gamma_+$ (kHz)')
plt.ylabel('$\Gamma_-$ (kHz)')
plt.title('Posterior of the rates'+
          '\n$\chi^2_{reduced}$ = %f +- %f (%d dof)'%(chi2, (2/dof)**0.5, dof) )
plt.legend()              


# =============================================================================
# Check the duty cycle
# =============================================================================
t_total  = t_elapsed[-1] # Total time
# Time dedicated to the decay
t_decay = 2*(np.sum(list_N_readout_p*t_probe_plus_s) + 
             np.sum(list_N_readout_m*t_probe_minus_s))
duty_cycle = t_decay/t_total 
print('Total duty cycle: %.2f percent'%(duty_cycle*100))






