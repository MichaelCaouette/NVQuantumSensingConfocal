# -*- coding: utf-8 -*-
"""
Created on Sat May 29 09:12:24 2021

Goal: Load and plot the optimization data

@author: Childresslab
"""

import spinmob as sm
import numpy as np
import matplotlib.pyplot as plt


d = sm.data.load(text='Load a data files')

# Check the ckeys
print(d.ckeys)

# Get the axis names
label_s = []
for key in d.ckeys:
    label_s.append(key)
    
#Check the name of the headers
print(d.headers)    

# =============================================================================
# Elapsed time between optimization
# =============================================================================
plt.figure(tight_layout=True)
x = d[0][0:-1]
y = np.diff(d[0])
plt.plot(x/3600, y, '.-')
plt.ylabel('Time between\nOptimization (sec)')
plt.xlabel('Elapsed Time (hour)' )
# Check the average
avg = np.mean(y)
ss = d.path
str_t = ss[:len(ss)//2] + '\n' + ss[len(ss)//2:]
plt.title(str_t+'\nMean= %.1f sec'%avg, fontsize=10)

# =============================================================================
# Awesome plot
# =============================================================================
fig, ax_s = plt.subplots(2, 1, sharex=True, tight_layout=True)
ax_vx = ax_s[0]
ax_vy = ax_vx.twinx()
ax_vz = ax_vx.twinx()
list_ax = [ax_vx, ax_vy, ax_vz]
for i in range(3):
    ax = list_ax[i]
    x = d[0] /3600 # x-axis
    y = d[i+1] # Count
    ey = d[i+4]
    # Bring the count relative to the minimum
    y -= np.min(y)
    
    ax.errorbar(x, y, yerr=ey, color='C%d'%i,
                 label=label_s[i+1])
    ax.legend( bbox_to_anchor=(1.00, 1-i/3), loc='upper left') 
    
#ax_vx.set_xlabel(label_s[0])
ax_vx.set_ylabel('Relative voltage')
# Split the title in 2
ss = d.path
str_t = ss[:len(ss)//2] + '\n' + ss[len(ss)//2:]
ax.set_title(str_t, fontsize=10)

# Plot the chi2 of each position
# No need to twin the axis
#plt.figure(tight_layout=True)
for i in range(3):
    x = d[0] /3600# x-axis
    y = d[i+10] 
    dof = d[i+7]
    ey = np.sqrt(2/dof) # Standard deviation of a chi2
    
    ax_s[1].errorbar(x, y, yerr=ey, 
                 label=label_s[i+10])
ax_s[1].legend(loc='best')    
ax_s[1].set_xlabel(label_s[0]+'( Hours)')
ax_s[1].set_ylabel('Chi2')

