# -*- coding: utf-8 -*-
"""
Created on Fri Feb 12 11:27:39 2021

Goal:
    Load and plot time trace of counts

@author: Childresslab
"""

import numpy as np
import spinmob as sm
import matplotlib.pyplot as plt 

ds = sm.data.load_multiple(text='Please select a time trace of the counts')

# Check the time trace
for d in ds:
    # Get the count time in second
    str_dt_sec = 'count_duration_sec'
    count_time = d.headers[str_dt_sec] # Second
    
    # Make the time start at zero
    t = d[0] - d[0][0]
    # Get the count rate and shot-noise
    count_rate  = d[1]*1e-3 # Kcount/sec
    ecount_rate = 1e-3 * np.sqrt(d[1]*count_time ) / count_time
    
    
    plt.figure(tight_layout=True)
    ax = plt.subplot(211)
    plt.errorbar(t, count_rate, yerr=ecount_rate, fmt='.')
    #plt.plot(t, count_rate, '.')
    plt.xlabel('time (sec)')
    plt.ylabel('Kcount/sec')
    plt.title(d.path, fontsize=9)
    
    
    # CHeck the PSD
    out = sm.fun.psd(t, count_rate)
    ax = plt.subplot(212)
    plt.plot(out[0], out[1], '.')
    plt.xlabel('Frequency (Hz)')
    plt.ylabel('PSD')
    plt.xscale('log')
    plt.yscale('log')


# Compare the time traces if more than one data is selected
if len(ds) > 1:
    fig, axes = plt.subplots(len(ds), 1 ,tight_layout=True) # ,sharey=True)
    axs = axes.flat
    
    for i, d in enumerate( ds ):
        # Make the time start at zero
        t = d[0] - d[0][0]
        # Get the count rate and shot-noise
        count_rate  = d[1]*1e-3 # Kcount/sec
        ecount_rate = 1e-3 * np.sqrt(d[1]*count_time ) / count_time
        # plot the time trace
        my_ax = axs[i]
        my_ax.errorbar(t, count_rate, yerr=ecount_rate, fmt='.')
        my_ax.set_title(d.path, fontsize=9) 
        my_ax.set_ylabel('Kcount/sec')

    plt.xlabel('time (sec)')
#    plt.ylabel('Kcount/sec')
#    title = ''
#    for i, d in enumerate(ds):
#        title += '\n' + d.path
#    plt.title(title, fontsize=9)       
    

# Plot an histogram and compare with poissonian noise (shot noise)
Nbins = 44
plt.figure(tight_layout=True)
# Superimpose in the same plot each data
for i, d in enumerate(ds):
    # Make the time start at zero
    t = d[0] - d[0][0]
    count_rate  = d[1]*1e-3 # Kcount/sec
    ecount_rate = 1e-3 * np.sqrt(d[1]*count_time ) / count_time
    # Size of the bin
    dx = ( max(count_rate) - min(count_rate) ) /Nbins
    
    # Poissonian noise is the sqrt of the total count
    mean_total_count = np.mean(count_rate) * count_time * 1e3
    poiss_ecount = np.sqrt(mean_total_count)
    poiss_erate = poiss_ecount / ( count_time * 1e3 ) # Expected shot noise rate in kCount/sec
    # Expected distribution (Gaussian with shot-noise)
    x = np.linspace(min(count_rate), max(count_rate), 500)
    exp_y = dx * len(count_rate) * np.exp( -(x-np.mean(count_rate))**2/(2*poiss_erate**2) ) / (2*3.14159 * poiss_erate**2)**0.5
    

    # Plot the histogram and expectation
    plt.hist(count_rate, bins=Nbins, label=d.path.split('/')[-1])
    plt.plot(x, exp_y, label='Expected from shot-noise', color='cyan', linewidth=5)

plt.xlabel('Kcount/sec')
plt.ylabel('Occurence')
plt.legend() #loc='upper center')
title = ''
for i, d in enumerate(ds):
    title += '\n' + d.path
plt.title(title, fontsize=9)





