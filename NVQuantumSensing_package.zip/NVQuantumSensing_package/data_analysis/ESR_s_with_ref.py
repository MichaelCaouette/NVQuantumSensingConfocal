# -*- coding: utf-8 -*-
"""
Created on Wed Jul  8 07:57:17 2020

Example of how to load the saturation curve

@author: Childresslab
"""



import spinmob as sm
import numpy as np


#d = sm.data.load(text='Select saturation curve ;)')


ds = sm.data.load_multiple(text='ESR data')
# Define the string of the headers and columns, in case they change
str_count = 'Total_counts_0' # Count with the RF
str_ref   = 'Total_counts_1' # Count without RF 
str_dt_read = 'dt_on' # count time

want_estimate_contrast = False # Set to true for showing the contrast
want_waterfall = False # Set to true for having a water fall plot
show_map = True # Show a map with the domain f & file
want_plot_ref = True

# Check the ckeys
print(ds[-1].ckeys)

# Get the axis names
label_s = []
for key in ds[-1].ckeys:
    label_s.append(key)

# Plot them
import matplotlib.pyplot as plt

plt.figure(tight_layout=True)

Z  = [] # This will serve for a color plot
eZ = [] # This will serve for a color plote
delta_y = 0 # This will be to split the 
max_prev = 0
for i, d in enumerate(ds):
    fs = d[0] # Frequency in GHz
    total_counts = d[str_count]# Total counts
    etotal_counts = np.sqrt(total_counts) # uncertainty in the count. Assuming poisson
    total_ref = d[str_ref]# Total counts
    etotal_ref= np.sqrt(total_ref) # uncertainty in the count. Assuming poisson
    
    #Get the count rate in count/sec
    dt = d.headers[str_dt_read] # count time in us
    rep = d.headers['repetition']
    nb_iter = d.headers['iteration']
    count_rate  = total_counts*1e6/(nb_iter*rep*dt) 
    ecount_rate = etotal_counts*1e6/(nb_iter*rep*dt) 
    ref_rate  = total_ref*1e6/(nb_iter*rep*dt) 
    eref_rate = etotal_ref*1e6/(nb_iter*rep*dt) 
    
    txt = '' # Test for the label
    
    if want_estimate_contrast:
        # Estimate the contrast
        c = 100*(np.max(count_rate) - np.min(count_rate))/np.max(count_rate)
        txt += (d.path.split('/')[-1] + '\nPower %.2f dBm'%d.headers['Power']+
               '\n(Max-Min)/Max %.2f percent'%c)
    
    # Note the position of the field
    try:
        #Only if the info is there
        x = d.headers['x_magnet']
        y = d.headers['y_magnet']
        z = d.headers['z_magnet']
        txt += '%.2f, %.2f, %.2f'%(x, y, z)
    except:
        pass
    
    if want_waterfall:
        y = count_rate*1e-3
        y += delta_y + max_prev - min(y)
        plt.errorbar(fs,y,yerr=ecount_rate*1e-3,
                     label =txt)
        delta_y += 0.2*(max(y) - min(y))
        max_prev = max(y)
    else:
        plt.errorbar(fs,count_rate*1e-3,yerr=ecount_rate*1e-3, #color='C%d'%i,
                     label =txt)        
        plt.errorbar(fs,ref_rate*1e-3,yerr=eref_rate*1e-3,
                     label ='Ref')             
    
#     For the color plot
#     Compute the signal (RF ON minus RF off)
    signal_tot  = total_counts - total_ref
    esignal_tot = np.sqrt(total_counts + total_ref )
    signal  = signal_tot  *1e6/(nb_iter*rep*dt) 
    esignal = esignal_tot *1e6/(nb_iter*rep*dt) 
    
    Z .append(signal)
    eZ.append(esignal)

Z = np.array( Z )

# Make the legend oustide of the plot
plt.legend(title='Magnet x,y,z', 
           bbox_to_anchor=(1.00, 1),loc='upper left')
plt.ylabel("Kcount/sec")
plt.xlabel(label_s[0])

title = ''
for d in ds:
    title += '\n'+d.path
plt.title(title, fontsize=9)


# Show the signal (RF ON minus RF off)
plt.figure(tight_layout=True)
for i, d in enumerate(ds):
    y  = Z[i]
    ey = eZ[i]
    fs = d[0]
    plt.errorbar(fs, y*1e-3,yerr=ey*1e-3, label=d.path.split('/')[-1]  )    
plt.ylabel('Count - Ref ( Kcount/sec )')
plt.xlabel(label_s[0])
plt.legend(bbox_to_anchor=(1.00, 1),loc='upper left')
title = ''
for d in ds:
    title += '\n'+d.path
plt.title(title, fontsize=9)



def plot_2D(ax, x, y, Z):
    """
    Function to CORRECTLY plot the data. 
    Because:
        - pcolor clip the last row and column
        - Imshow is very funky
        
    ax:
        ax object for plotting
    x:
        array for the x axis.
    y:
        array for the y axis. 
    Z:
        2D matrix to plot, with the corresponding axis. 
    """
    return ax.imshow(Z, 
                      extent=[min(x), max(x), 
                              min(y), max(y)],
                      origin='lower',
                      interpolation = 'none',
                      aspect='auto')    
    

if show_map:
    fig = plt.figure(tight_layout=True)
    ax = fig.add_subplot(111)
    yi = np.arange(0, len(ds)) + 1
    colorplot = plot_2D(ax, d[0], yi, Z*1e-3)
    cb = fig.colorbar(colorplot, orientation='horizontal', fraction=.1)
    cb.set_label('KCounts/sec')
    ax.set_xlabel('Frequency (GHz)')
    ax.set_ylabel('Sweep #')
    plt.title(title, fontsize=9)


