# -*- coding: utf-8 -*-
"""
Created on Thu Feb  4 11:16:29 2021

Goal:
    Take ESR at various magnet position

@author: Childresslab
"""


# Also import nice stuff
import traceback
_p = traceback.print_last #Very usefull command to use for getting the last-not-printed error

# =============================================================================
# Import the modules that we will use and the FPGA
# =============================================================================
# Add the folder of the software package that we are using. 
import sys
path_softwares = 'X:\\DiamondCloud\\Magnetometry\\Data\\2021\\04\\01\\NVQuantumSensing_package\\software_packages'
#sys.path.insert(0, pa)
sys.path.append(path_softwares)
path_base_modules = path_softwares + '\\base_modules'
sys.path.append(path_base_modules)
# Import
from confocal import GUIMainConfocal
from magnet_positions import GUIMagnetPositions
from pulse_sequences import GUIPulseSequences

# =============================================================================
# Open the fpga
# =============================================================================
# Get the ressource and bitfile
import spinmob as sm
dir_specifics = path_base_modules + '\\cpu_specifics.dat'
cpu_specific_infos = sm.data.load(dir_specifics)
# cpu_specific_infos is defined in the import of the base modules
bitfile_path = cpu_specific_infos.headers['FPGA_bitfile_path']
resource_num = cpu_specific_infos.headers['FPGA_resource_number']
# Open the fpga
import base_modules.api_fpga as _fc
fpga = _fc.FPGA_api(bitfile_path, resource_num) 
fpga.open_session()




class APIMagnetESR():
    """
    Class for taking ESRs at various magnet positions.
    It should pop up the relevant gui. 
    """
    
    def __init__(self):
        """
        Init... INIT !!! I said.... INIT !!
        """
        # =====================================================================
        # Open each application that we need
        # =====================================================================
        # The confocal microscope
        self.confo = GUIMainConfocal(fpga)
        self.confo.show()
        # The pulse sequence, that we add to the confocal for avoiding too many 
        # openned window
        self.pulser = GUIPulseSequences(fpga)
        tab_pulse = self.confo.tabs1.add_tab('Pulse Sequence')
        tab_pulse.place_object(self.pulser )  
        # The magnet positionner
        self.magnet = GUIMagnetPositions()
        self.magnet.show()     

        # =====================================================================
        # Connect the signal for optimizing
        # =====================================================================
        self.optimizer = self.confo.gui_optimizer
        f_optimize = self.optimizer.button_optimize.click
        self.pulser.set_optimization_function(f_optimize)    
        
        # =====================================================================
        # Connect the task to perform
        # =====================================================================
        self.magnet.dummy_before_starting = self.task_before
        self.magnet.dummy_task = self.task_to_perform

    def task_before(self):
        """
        Define the task to perform just before we start to loop over the magnet 
        positions
        """
        # We assum that, already:
        # - The signal generator is connected and the RF are ON
        # - The confocal microscope is focused on the NV. And the offset of the 
        #   optimzer is set. 
        # - The settings of the loop are set (N fpga loop, sequence per fpga loop,
        #   N loop before optimization, etc)
        
        self.magnet.label_info_update('Setting the pulser.')

        # Specifically extract the ESR pulser
        self.gui_ESR = self.pulser.list_gui_exp[1]
        
        # Prepare the ESR 
        self.magnet.label_info_update('Preparing the ESR sequence.')
        self.gui_ESR.button_prepare_experiment.click()
        
        # Prepare the FPGA data
        self.gui_ESR.gui_pulse_runner.pulser.button_convert_sequence.click()
        
    
        # Ask the user the repository for saving the files
        txt = 'Select a directory for saving the data of each ESR.'
        self.path_folder_save = sm.dialogs.select_directory(txt)
    

    def task_to_perform(self):
        """
        Define the task that we want to perform at each magnet position. 
        """
        # We assum that, already:
        # - The gui for the pulse sequence is set (the number of FPGA loop before 
        #   optimzation is set, the number of sequence per FPGA loop also, etc.)
        
        # =========================================================================
        # Step 1 Optimize the confocal spot on the NV
        # =========================================================================  
        self.magnet.label_info_update('Optimizing before taking the ESR')
        self.optimizer.button_optimize.click()
        
        # =========================================================================
        # Step 2 take an ESR
        # =========================================================================
        # Reset the FPGA
        self.gui_ESR.gui_pulse_runner.button_reset.click()
        # Launch the pulse sequence
        self.magnet.label_info_update('Taking the ESR.')
        self.gui_ESR.gui_pulse_runner.button_start.click()
        
        # =========================================================================
        # Step 3 Save the ESR data
        # =========================================================================
        # Get the databox
        self.databox = self.gui_ESR.databoxplot
        # Add some info in the databox
        x, y, z = self.magnet.gui_magnet3.get_positions()
        self.databox.insert_header('x_magnet' , x)  
        self.databox.insert_header('y_magnet' , y)  
        self.databox.insert_header('z_magnet' , z)  
        # Save
        iteration = self.magnet.iter
        dir_save = self.path_folder_save + '\\ESR %.3d'%iteration + '.dat'
        self.databox.save_file(path=dir_save )
        self.magnet.label_info_update('ESR done and saved')
    
        return 
    
 
# Launch the experiment
self  =  APIMagnetESR()











