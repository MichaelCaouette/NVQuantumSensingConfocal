# -*- coding: utf-8 -*-
"""
Created on Tue Jun 22 12:26:50 2021

Goal:
    Help to spatially interpolate the eigenfrequencies of the NV,
    When we know two set of eignefrequencies at two given position. 

@author: Childresslab
"""




# D: Zero field splitting (GHz)
# gamma: Zeeman shift constant (GHz/T)
D     = 2.8707565
gamma = 28.025 # Note: this gamma effectivaly cancels in the process. 


def B_from_fs(fp, fm):
    """
    Get the field given two eigenfrequencyy. 
    ASSUM On-axis field ! 
    
    fp and fm:
        (GHz)
        
    Return the on axis field (in T)
    """
    
    return (fp-fm) / (2*gamma)

def B_interp(r, 
             B1, r1, 
             B2, r2, 
             want_to_print_ab=False):
    """
    Get the field at a distance r, given that the field is 
    B1 at a distance r1 and B2 at a distance r2. 
    
    This is assumming that the field at a distance r is given by the 
    phenomengical law: B(r) = a/r^3 + b
    """
    # Infer the constants from the two known field
    r1_cube, r2_cube = r1**3, r2**3
    a = (B2 - B1) / (1/r2_cube - 1/r1_cube)   
    b = (r2_cube*B2 - r1_cube*B1) / (r2_cube - r1_cube) 
    
    # By curiosity
    if want_to_print_ab:
        print('a, b = ', a, b)
    
    return a / r**3 + b


def fs_from_known_fs(r, 
                     f1p, f1m, r1,
                     f2p, f2m, r2, 
                     want_to_print_ab=False):
    """
    Get the interpolated eigengrencies based on the knowldged of two other 
    eignefrequencies at an other position. 
    """
    
    B1 = B_from_fs(f1p, f1m)
    B2 = B_from_fs(f2p, f2m)
    
    B3 = B_interp(r, B1, r1, B2, r2, want_to_print_ab)
    
    # Assum on-axis field
    f3p = D + gamma*B3
    f3m = D - gamma*B3
    
    return f3p, f3m
    
if __name__ == '__main__':
    """
    Test the formula
    """
    import numpy as np
    import matplotlib.pyplot as plt
    
    # If we want to load a data file
    # If False, we will use hard-coded data
    want_load_data = True 

    
    
    if want_load_data:
        # Load the data
        import spinmob as sm
        d = sm.data.load(text='Load a file containing the frequencies and magnet position')
        # Get the frequencies and magnet position
        list_fp, list_efp = d['f0_plus_(GHz)'] , d['ef0_plus_(GHz)' ]
        list_fm, list_efm = d['f0_minus_(GHz)'], d['ef0_minus_(GHz)']        		
        list_r = np.sqrt( d['mag_y_mm']**2	+ d['mag_z_mm']**2 )

         # Set the reference eigenfrequency and corresponding position. 
        f1p, f1m = list_fp[0 ], list_fm[0 ]
        f2p, f2m = list_fp[-1], list_fm[-1]
        # We are gonna assume x to be constant and to play no role in the position
        r1 = list_r[0 ]
        r2 = list_r[-1]

    
        # Interpolate the eigenfrequency
        list_interp_fp, list_interp_fm = fs_from_known_fs(list_r,
                                                          f1p, f1m, r1, 
                                                          f2p, f2m, r2, 
                                                          want_to_print_ab=True)
        
        # Check the result
        plt.figure(tight_layout=True)
        # A linear interpolation, for a guide to the eye. 
        plt.plot([r1, r2], [f1p, f2p], '--k', alpha=0.5)
        plt.plot([r1, r2], [f1m, f2m], '--k', alpha=0.5)        
        # The interpolation
        plt.plot(list_r, list_interp_fp, '.-g', label='Inteprolation')
        plt.plot(list_r, list_interp_fm, '.-g')
        # The data points
        plt.errorbar(list_r, list_fp, yerr=list_efp, fmt='.C4', label='Data')
        plt.errorbar(list_r, list_fm, yerr=list_efm, fmt='.C4')
        # The input data
        plt.plot([r1, r2], [f1p, f2p], '.r', markersize=12)
        plt.plot([r1, r2], [f1m, f2m], '.r', markersize=12)
        plt.ylabel('Freq (GHz)')
        plt.xlabel('r (mm)')
        plt.legend(loc='best')
        
            
        
        
    else:
        # Hard code the data
         # Set the reference eigenfrequency and corresponding position. 
        f1p, f1m = 3.344, 2.3995
        f2p, f2m = 4.25, 1.5
        # We are gonna assume x to be constant and to play no role in the position
        r1 = np.sqrt( 9.3**2 + 1.25**2)
        r2 = np.sqrt( 6.7**2 + 5**2   )
        
        list_z = np.array( [1.25, 1.6666666666666667, 2.0833333333333335,2.5, 
                            2.916666666666667, 3.3333333333333335, 3.75, 
                            4.166666666666667,4.583333333333334, 5.0] )
        list_y = np.array( [9.313631216804138, 9.059271644782022,8.795818669271435, 
                            8.523272290272379	, 8.24163250778485, 
                            7.95089932180885,  7.651072732344382, 7.342152739391441, 
                            7.024139342950028, 6.697032543020146] )
        
        list_r = np.sqrt( list_z**2 + list_y**2 )
        
        list_fp, list_fm = fs_from_known_fs(list_r,
                                            f1p, f1m, r1,
                                            f2p, f2m, r2,
                                            want_to_print_ab=True)
        
        # Check the result
        plt.figure(tight_layout=True)
        # A linear interpolation, for a guide to the eye. 
        plt.plot([r1, r2], [f1p, f2p], '--k', alpha=0.5)
        plt.plot([r1, r2], [f1m, f2m], '--k', alpha=0.5)        
        # The interpolation
        plt.plot(list_r, list_fp, '.-g')
        plt.plot(list_r, list_fm, '.-b')
        # The input data
        plt.plot([r1, r2], [f1p, f2p], '.r')
        plt.plot([r1, r2], [f1m, f2m], '.r')
        plt.ylabel('Freq (GHz)')
        plt.xlabel('r (mm)')
        
    
    
    
    



