# -*- coding: utf-8 -*-
"""
Created on Thu Feb  4 11:16:29 2021

Goal:
    Take measurements at various magnet position

@author: Childresslab
"""


# Also import nice stuff
import time
import os # For creating new folders
import traceback
_p = traceback.print_last #Very usefull command to use for getting the last-not-printed error


# =============================================================================
# Import the modules that we will use and the FPGA
# =============================================================================
# Add the folder of the software package that we are using. 
import sys
path_softwares = 'X:\\DiamondCloud\\Magnetometry\\Data\\2021\\07\\16\\NVQuantumSensing_package\\software_packages'
#sys.path.insert(0, pa)
sys.path.append(path_softwares)
path_base_modules = path_softwares + '\\base_modules'
sys.path.append(path_base_modules)
# Import the relevant module for the experiment
from confocal import GUIMainConfocal
from magnet_positions import GUIMagnetPositions
from pulse_sequences import GUIPulseSequences
from pipulse_find_auto import GUIPiPulseFinderAuto
# For an unknown reason I can import this only if I copy the script with an other name... 
from base_modules.gui_pulse_perso_decay_trace   import GUI4ptsTrace

# =============================================================================
# Open the fpga
# =============================================================================
# Get the ressource and bitfile
import spinmob as sm
dir_specifics = path_base_modules + '\\cpu_specifics.dat'
cpu_specific_infos = sm.data.load(dir_specifics)
# cpu_specific_infos is defined in the import of the base modules
bitfile_path = cpu_specific_infos.headers['FPGA_bitfile_path']
resource_num = cpu_specific_infos.headers['FPGA_resource_number']
# Open the fpga
import base_modules.api_fpga as _fc
fpga = _fc.FPGA_api(bitfile_path, resource_num) 
fpga.open_session()



# =============================================================================
# HARD WAY TO CODE THE BEST GUESS FOR THE PIPULSE
# =============================================================================
#list_f_minus_min = [1.4, 1.70, 2.05]
#list_f_minus_max = [1.7, 2.00, 2.30]
#list_f_plus_min  = [3.9, 3.75, 3.45]
#list_f_plus_max  = [4.2, 4.10, 3.75]

#import numpy as np
## For the pi-pulse minus
#list_f_minus_min = 1.5 + np.zeros(12)
#list_f_minus_max = 2.3 + np.zeros(12)
#list_p_minus_min = 15  + np.zeros(12)
#list_p_minus_max = 25  + np.zeros(12)
#
## For the pi-pulse plus
#list_f_plus_min = 3.4 + np.zeros(12)
#list_f_plus_max = 4.2 + np.zeros(12)
#list_p_plus_min = 15  + np.zeros(12)
#list_p_plus_max = 25  + np.zeros(12)

## For the pi-pulse minus
#fm_center = np.linspace(1.61,  1.88, 3)
#list_f_minus_min = fm_center - 0.20
#list_f_minus_max = fm_center + 0.20
#list_p_minus_min = 0  + 0*fm_center
#list_p_minus_max = 25  + 0*fm_center
#
## For the pi-pulse plus
#fp_center = np.linspace(4.13,  3.86, 3)
#list_f_plus_min = fp_center - 0.20
#list_f_plus_max = fp_center + 0.20
#list_p_plus_min = 0  + 0*fm_center
#list_p_plus_max = 25  + 0*fm_center

## For the pi-pulse minus
#fm_center = np.linspace(1.61,  1.98, 7)
#list_f_minus_min = fm_center - 0.20
#list_f_minus_max = fm_center + 0.20
#list_p_minus_min = 0  + 0*fm_center
#list_p_minus_max = 25  + 0*fm_center
#
## For the pi-pulse plus
#fp_center = np.linspace(4.13,  3.77, 7)
#list_f_plus_min = fp_center - 0.20
#list_f_plus_max = fp_center + 0.20
#list_p_plus_min = 0  + 0*fm_center
#list_p_plus_max = 25  + 0*fm_center

## For the pi-pulse minus
#fm_center = np.linspace(1.51, 1.941, 12)
#list_f_minus_min = fm_center - 0.10
#list_f_minus_max = fm_center + 0.10
#list_p_minus_min = 0  + 0*fm_center
#list_p_minus_max = 25  + 0*fm_center
#duration_RF_minus = 0.080 # (us) Duration of the pi-pulse -
#
## For the pi-pulse plus
#fp_center = np.linspace(4.23, 3.808, 12)
#list_f_plus_min = fp_center - 0.10
#list_f_plus_max = fp_center + 0.10
#list_p_plus_min = 2  + 0*fm_center
#list_p_plus_max = 25  + 0*fm_center
#duration_RF_plus = 0.08 # (us)Duration of the pi-pulse +

## For the pi-pulse minus
#fm_center = np.linspace(2.171, 1.515, 5)
#list_f_minus_min = fm_center - 0.15
#list_f_minus_max = fm_center + 0.15
#list_p_minus_min = 0  + 0*fm_center
#list_p_minus_max = 25  + 0*fm_center
#duration_RF_minus = 0.080 # (us) Duration of the pi-pulse -
#
## For the pi-pulse plus
#fp_center = np.linspace(3.566, 4.22, 5)
#list_f_plus_min = fp_center - 0.15
#list_f_plus_max = fp_center + 0.15
#list_p_plus_min = 0  + 0*fm_center
#list_p_plus_max = 25  + 0*fm_center
#duration_RF_plus = 0.08 # (us)Duration of the pi-pulse +

# =============================================================================
# Non-linearly interpolate the frequencies
# =============================================================================
from eigenfreq_interpolate import get_fs_from_r
import numpy as np
list_z = np.array( [1.25, 1.6666666666666667, 2.0833333333333335,2.5, 
                    2.916666666666667, 3.3333333333333335, 3.75, 
                    4.166666666666667,4.583333333333334, 5.0] )
tuple_parms = [34.12474791148252, 7.647660230661493, 3.141574704851089]
list_interp_fp, list_interp_fm = get_fs_from_r(list_z, *tuple_parms)
print()
print('List of frequencies: ')
print(list_interp_fp)
print(list_interp_fm)
print()    


#fm_center = np.linspace(1.5, 2.3995, 10)
fm_center = list_interp_fm
list_f_minus_min = fm_center - 0.15
list_f_minus_max = fm_center + 0.15
list_p_minus_min = 0  + 0*fm_center
list_p_minus_max = 25  + 0*fm_center
duration_RF_minus = 0.080 # (us) Duration of the pi-pulse -

# For the pi-pulse plus
#fp_center = np.linspace(4.25, 3.344, 10)
fp_center = list_interp_fp
list_f_plus_min = fp_center - 0.15
list_f_plus_max = fp_center + 0.15
list_p_plus_min = 0  + 0*fm_center
list_p_plus_max = 25  + 0*fm_center
duration_RF_plus = 0.120 # (us)Duration of the pi-pulse +

# Other settings
N_readout_goal = 1e6# Aimed number of readout
T_per_fpga_loop = 5 # sec; Aimed time per fpga loop
T_before_auto_save = 5 # min; Aimed time in the trace loop before autosaving the data
str_T1_name_save = 'T1_leper_messiah' # Name in front of the save

print()
print('Settings')
print('N_readout_goal ', N_readout_goal)
print('T_per_fpga_loop ', T_per_fpga_loop)
print('T_before_auto_save ', T_before_auto_save)
print()

# =============================================================================
# Define a class that will connect all the modules together
# =============================================================================

class APIMagnetT1():
    """
    Class for taking T1 at various magnet positions.
    It should pop up the relevant guis.
    
    The experiment is the following:
        - Set the magnet position
        - Calibrate the one pipulse
        - Run a T1 measurement for this pi-pulse
        - 
    """
    
    def __init__(self):
        """
        Init... INIT !!! I said.... INIT !!
        """
        # =====================================================================
        # Open each application that we need
        # =====================================================================
        # The confocal microscope
        self.confo = GUIMainConfocal(fpga)
        self.confo.show()
        
        # The pulse sequence, that we add to the confocal for avoiding too many 
        # openned window
        self.pulser = GUIPulseSequences(fpga)
        tab_pulse = self.confo.tabs1.add_tab('Pulse Sequence')
        tab_pulse.place_object(self.pulser )  
        # The pi pulse finder
        self.pipulse = GUIPiPulseFinderAuto(fpga)
        self.pipulse.show()
        
        # The T1 finder
        self.T1tracer  = GUI4ptsTrace(fpga)
        self.T1tracer.show()
                
        # The magnet positionner, for performing a task at each position
        self.magnet = GUIMagnetPositions()
        self.magnet.show()     
        
        # =====================================================================
        # Connect the signal for optimizing
        # =====================================================================
        # We have to connect the optimization to each gui that uses pulse sequences
        # First get the optimizer and its optimization function
        self.optimizer = self.confo.gui_optimizer
        self.f_optimize = self.optimizer.button_optimize.click
        # Now connect it to the various GUI that uses it.
        self.pulser.set_optimization_function(self.f_optimize)   
        self.pipulse.connect_optimization(self.f_optimize)
        self.T1tracer.dummy_please_optimize = self.f_optimize        
        self.T1tracer.gui_pulse_runner.connect_opt_method(self.confo.gui_optimizer)   
        
        # =====================================================================
        # Connect the task to perform by overiding
        # =====================================================================
        self.magnet.dummy_before_starting = self.task_before
        self.magnet.dummy_task = self.task_to_perform
        
        self.T1tracer.dummy_signal_loop_completed = self.autosave_T1_data
        
    def _run_4pts_trace(self, f0, power, dt_pulse, type_measurement):
        """
        Prepare and run the T1 trace
        """
        # Note this for a reference
        self.type_of_measurement = type_measurement
        # =============================================================================
        # Prepare the signal generator        
        # =============================================================================
        # Disconnect the signal generator from the pipulse and connect it to 
        # the T1, becuase it is shared between the two. 
        # Disconnect the pipulse if it is connected
        self.pipulse.disconnect_sig_gen() 
        # Connect the T1 if it is not connected
        if not( self.T1tracer.sig_gen.button_connect.is_checked() ):
            self.T1tracer.sig_gen.button_connect.click()
            self.T1tracer.sig_gen.button_reset.click()        

        # =============================================================================
        # Set the parameter of the trace
        # =============================================================================
        # The pi-pulse
        self.T1tracer.treeDic_settings['dt_pi_pulse'] = dt_pulse
        self.T1tracer.treeDic_settings['Frequency']   = f0
        self.T1tracer.treeDic_settings['Power']       = power         
        
        # Adjust the proper number of readout
        # Estimate the time of a single pulse sequence In second !
        self.sum_tprobe = self.T1tracer.get_sum_list_t_probe()*1e-6
        
        # We roughly want the fpga_loop to last less than few second. This is in
        # order to avoid freeze out of the GUI
        self.estimate_time_per_readout = 2*self.sum_tprobe + 20*1e-6 # (second) Roughly the time elapsed by readout
        self.N_readout_per_FPGA_loop = int(np.ceil(T_per_fpga_loop/(self.estimate_time_per_readout) ))  
        # Determine how many FPGA loop to perfom. 
        # We take the ceil, such that we have at least 1 loop. 
        self.N_FPGA_loop = int( np.ceil(N_readout_goal/self.N_readout_per_FPGA_loop ) )
        # The true number of readout that should happen
        self.N_readout_gonna_happend = self.N_readout_per_FPGA_loop*self.N_FPGA_loop
        
        # =============================================================================
        # Prepare the pulse sequence        
        # =============================================================================
        self.T1tracer.button_prepare_experiment.click()        
        # Set the number of readout
        self.T1tracer.gui_pulse_runner.NumberBox_repetition.set_value(self.N_readout_per_FPGA_loop) 
        # Set the number of FPGA loop to have. 
        self.T1tracer.gui_pulse_runner.NumberBox_N_loopFPGA.set_value(self.N_FPGA_loop)
        # Convert the pulse sequence
        # The button reset is automatically clicked in the method for converting
        self.T1tracer.gui_pulse_runner.button_convert_sequence.click()
        self.T1tracer.gui_pulse_runner.button_reset.click()
               
        # Create a folder for saving the data
        self.path_save_T1 = self.path_save + '/' + 'T1'
        if not os.path.exists(self.path_save_T1):
            os.makedirs(self.path_save_T1)
            
        # =============================================================================
        #         # Run the T1          
        # =============================================================================
        self.iter_save = 0 # For the autosave
        self.t0_run4pts_trace = time.time()
        self.t0_checkup = self.t0_run4pts_trace # This will change. It is for the autosave
        self.T1tracer.gui_pulse_runner.button_start.click()
        self.t_run4pts_trace = time.time() - self.t0_run4pts_trace    
        
        # =============================================================================
        #         # Save the data       
        # =============================================================================
        self.autosave_T1_data(save_anyway=True)
                
    def autosave_T1_data(self, save_anyway=False):
        """
        We will save the data after each certaion amount of elapsed time. 
        
        save_anyway:
            (bool) If true, will save the data, irrespect of the condition. 
        """
        
        # Check the various condition under which we would save
        condition1 = time.time() - self.t0_checkup > T_before_auto_save*60 # In sec
        condition2 = save_anyway
        condition  = condition1 or condition2
        
        # Save when the conditions are met
        if condition:
            # =====================================================================
            # SAVE THE DATA
            # =====================================================================  
            # Add some stuff in the data boxe
            self.T1tracer.databoxplot.insert_header('Type_measure', self.type_of_measurement)
            self.T1tracer.databoxplot.insert_header('Time_initial', self.t0_run4pts_trace)
            self.T1tracer.databoxplot.insert_header('Time_finish' , time.time())
            # Related to various elapsed time for the stats
            self.T1tracer.databoxplot.insert_header('duration_elapsed_total', time.time()-self.t0_run4pts_trace)    
            
            # Give a unique name to the file and save it. 
            
            self.total_name = (str_T1_name_save +
                               '_type'+str(int(self.type_of_measurement)) +
                               '_%.3d.dat'%self.iter_save)
            path = self.path_save_T1 + '/' + self.total_name
            self.T1tracer.databoxplot.save_file(path)      
            
            # Update the iterator
            self.iter_save += 1
            # Update the checkup time
            self.t0_checkup = time.time()        
            
        # Job done
        return             
        
    def task_before(self):
        """
        Define the task to perform just before we start to loop over the magnet 
        positions
        """
        # We assum that, already:
        # - The signal generator is connected and the RF are ON
        # - The confocal microscope is focused on the NV. And the offset of the 
        #   optimzer is set. 
        # - The settings of PiPulse finder are set, BUT the window for findind f0 and P0
        # - The setting of the T1 finder are set
        
        self.magnet.label_info_update('Initiating all the settings')

        # =====================================================================
        # Set the saving path
        # =====================================================================   
        
        # Ask the user the repository for saving the files
        txt = 'Select a directory for saving the data at each field.'
        self.path_main_dir_save = sm.dialogs.select_directory(txt)
    

    def task_to_perform(self):
        """
        Define the task that we want to perform at each magnet position. 
        
        - Create folders
        - Find the pi-pulse -
        - Measure the whole T1 trace -
        - Find the pi-pulse +
        - Measure the whole T1 trace +
        
        """
        # We assum that, already:
        # - 

        # =========================================================================
        # Create a new folder, because we are gonna save many things.
        # And save the magnet position
        # =========================================================================         
        self.mag_iter = self.magnet.get_iter()
        self.path_save = self.path_main_dir_save + '/' + 'mag_pos_%.3d'%self.mag_iter
        # This creates the directory if it doesn't exist
        if not os.path.exists(self.path_save):
            os.makedirs(self.path_save)
        # Now the magnet position
        self.databox_magnet = sm.data.databox()
        x, y, z = self.magnet.gui_magnet3.get_positions()
        self.databox_magnet.insert_header('date' , time.ctime(time.time()))  
        self.databox_magnet.insert_header('time_sec' , time.time())  
        self.databox_magnet.insert_header('x_magnet' , x)  
        self.databox_magnet.insert_header('y_magnet' , y)  
        self.databox_magnet.insert_header('z_magnet' , z)    
        # Save it 
        save_name = self.path_save + '/magnet_position.dat'
        self.databox_magnet.save_file(save_name)
        
        # =========================================================================
        # Step 1 Optimize the confocal spot on the NV
        # =========================================================================  
        self.magnet.label_info_update('Optimizing before finding the pipulse')
        self.optimizer.button_optimize.click()
        
        # =========================================================================
        # Step 2 Find the pipulse MINUS
        # =========================================================================
        
        # Disconnect the signal generator from the T1 and connect it to the 
        # pi-pulse, becuase it is shared between the two. 
        # Disconnect the T1 if it is connected
        if self.T1tracer.sig_gen.button_connect.is_checked():
            self.T1tracer.sig_gen.button_connect.click()           
        
        # Start with the minus pipulse
        self.magnet.label_info_update('Finding the first (minus) pipulse ...')
        # Set the best guess 
        self.pipulse.treeDic_settings['f_min'] = list_f_minus_min[self.mag_iter]
        self.pipulse.treeDic_settings['f_max'] = list_f_minus_max[self.mag_iter]
        self.pipulse.treeDic_settings['P_min'] = list_p_minus_min[self.mag_iter]
        self.pipulse.treeDic_settings['P_max'] = list_p_minus_max[self.mag_iter]
        self.pipulse.treeDic_settings['dt_pipulse'] = duration_RF_minus
        # Create a folder for saving the data
        self.path_save_pi_minus = self.path_save + '/' + 'pipulse_minus'
        if not os.path.exists(self.path_save_pi_minus):
            os.makedirs(self.path_save_pi_minus)
        # Run the pipulse
        self.pipulse.button_reset.click()
        self.pipulse._button_run_clicked(dir_save=self.path_save_pi_minus)
        # Note the pi-pulse parameter
        output = self.pipulse.get_pipulse()
        self.pi_minus_T  = output[0] # Should be in us
        self.pi_minus_f0 = output[1]
        self.pi_minus_P0 = output[2]

        print('Pi pulse minus:')
        print(self.pi_minus_T)
        print(self.pi_minus_f0)
        print(self.pi_minus_P0)
        
        # =============================================================================
        # Step 3 Measure the full trace MINUS        
        # =============================================================================
        self.magnet.label_info_update('Measuring the time trace for the measurement MINUS ...')    
        # Let's go
        self._run_4pts_trace(self.pi_minus_f0,
                             self.pi_minus_P0, 
                             self.pi_minus_T,
                             type_measurement = -1)

        # =========================================================================
        # Step 4 Find the pipulse PLUS
        # =========================================================================    
        
        # Then the plus pipulse
        self.magnet.label_info_update('Finding the second (plus) pipulse ...')
        # Set the best guess 
        self.pipulse.treeDic_settings['f_min'] = list_f_plus_min[self.mag_iter]
        self.pipulse.treeDic_settings['f_max'] = list_f_plus_max[self.mag_iter]
        self.pipulse.treeDic_settings['P_min'] = list_p_plus_min[self.mag_iter]
        self.pipulse.treeDic_settings['P_max'] = list_p_plus_max[self.mag_iter]
        self.pipulse.treeDic_settings['dt_pipulse'] = duration_RF_plus
        # Create a folder for saving the data
        self.path_save_pi_plus = self.path_save + '/' + 'pipulse_plus'
        if not os.path.exists(self.path_save_pi_plus):
            os.makedirs(self.path_save_pi_plus)
        # Run the pipulse
        self.pipulse.button_reset.click()
        self.pipulse._button_run_clicked(dir_save=self.path_save_pi_plus)
        # Note the pi-pulse parameter
        output = self.pipulse.get_pipulse()
        self.pi_plus_T  = output[0] # Should be in us
        self.pi_plus_f0 = output[1]
        self.pi_plus_P0 = output[2]

        # =============================================================================
        # Step 5 Measure the full trace MINUS        
        # =============================================================================
        self.magnet.label_info_update('Measuring the time trace for the measurement PLUS ...')    
        # Let's go
        self._run_4pts_trace(self.pi_plus_f0,
                             self.pi_plus_P0, 
                             self.pi_plus_T,
                             type_measurement = +1)                
        
        # Jove done for this field.
        return 
    
 
# Launch the experiment
self  =  APIMagnetT1()


#
## Bonus, aslo import the sweeper
#from sweep_pulsedESR import GUISweepPulsedESR
#sweepy = GUISweepPulsedESR(fpga)
#sweepy.gui_pulsed_ESR.gui_pulse_runner.dummy_please_optimize = self.f_optimize
#sweepy.show()
#








