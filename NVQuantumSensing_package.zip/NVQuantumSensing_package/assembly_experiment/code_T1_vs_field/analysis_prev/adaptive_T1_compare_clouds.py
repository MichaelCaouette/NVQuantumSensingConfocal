# -*- coding: utf-8 -*-
"""
Created on Wed Jul  8 07:57:17 2020

Example of how to load the saturation curve

@author: Childresslab
"""

import func_T1_data as f_T1

import spinmob as sm
import numpy as np
import matplotlib.pyplot as plt

import os
import tkinter.filedialog as fd

# Get the list of the directory of each magnet positon
str_key_mag = 'mag_pos' # comment string in the name of the magnet position
folder_name_T1    = 'T1_sequence'
key_file_T1 = 'T1'
i_min = 0 # Minimum folder to check
i_max = 3 # Maximum folder to check

# Get the path of the folders of each magnet position 
path_folder_mags = fd.askdirectory(title='Select the folder containing the %s files'%str_key_mag)
list_folder_mag = []

for file in os.listdir(path_folder_mags):
    # List the folders that contains the key for the magnet position 
    if str_key_mag in file:
        path_file = os.path.join(path_folder_mags, file)
        list_folder_mag.append(path_file)
# Number of magnet position    
#N_field = len(list_folder_mag)
N_data_set = 1 + i_max - i_min     
    


# =============================================================================
# Prepare the plot
# =============================================================================
plt.figure(figsize=(15, 8), tight_layout=True)  

# The first is the cloud of points. 
ax = plt.subplot(211)

# Process each set of data
list_gp = []
list_gm = []
list_egp = []
list_egm = []



for kkk, folder_mag in enumerate( list_folder_mag ):
    
    if ( kkk >= i_min ) and ( kkk <= i_max ):
        
        # =============================================================================
        # Get the data
        # =============================================================================
        # Get the list of datafile
        ds = []
        directory = folder_mag + '/' + folder_name_T1
        for file in os.listdir(directory):
            if key_file_T1 in file:
                path_file = os.path.join(directory, file)  
                ds.append( sm.data.load(path_file) )
                  
        print('Taking care of data set %d'%kkk)
        
        # =============================================================================
        # Extract the drift-independant measurement
        # =============================================================================
        
        gp_bayes, egp_bayes, gm_bayes, egm_bayes, my_bayes = f_T1.rates_from_brayes(ds)
        # List them
        list_gp .append( gp_bayes )
        list_gm .append( gm_bayes )
        list_egp.append( egp_bayes)
        list_egm.append( egm_bayes)
    
        # =============================================================================
        # Plot the Bayes inference 
        # =============================================================================
        parms = my_bayes.my_obe.parameters # This contains the arrays of each parameter
#        txt_label = ds[-1].path.split('/')[-3] # Have a meaningfull label
        txt_label = ds[-1].path.split('/')[-2].split('\\')[-1]
        plt.scatter(parms[0]*1e-3, parms[1]*1e-3, color='C%d'%kkk, 
                    alpha=0.1)
        # Plot a single point with alpha=1 for having the label clearer
        plt.scatter(parms[0][0]*1e-3, parms[1][0]*1e-3, color='C%d'%kkk, 
                    alpha=1, label=txt_label)    
        
        # # Shown the inference
        plt.errorbar(gp_bayes*1e-3, gm_bayes*1e-3, 
                     xerr=egp_bayes*1e-3,yerr=egm_bayes*1e-3, color='k')
    
# Enhance the plot
plt.legend()
plt.xlabel('Rate+ (kHz)')
plt.ylabel('Rate- (kHz)')    
plt.title(ds[-1].path, fontsize=8)

print('Done')



list_gp  = np.array(list_gp)
list_gm  = np.array(list_gm)
list_egp = np.array(list_egp)
list_egm = np.array(list_egm)
    
# The second is the value of the rates for each magnetpositon
ax = plt.subplot(212)
x_axis = np.arange(0, N_data_set)
plt.errorbar(x_axis, list_gp*1e-3, yerr=list_egp*1e-3, fmt='.-', label='$\Gamma_+$')
plt.errorbar(x_axis, list_gm*1e-3, yerr=list_egm*1e-3, fmt='.-', label='$\Gamma_-$')
plt.legend()
plt.ylabel('Rates (kHz)') 










