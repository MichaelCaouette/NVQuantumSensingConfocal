# -*- coding: utf-8 -*-
"""
Created on Wed Apr 14 10:51:01 2021

Goal:
    Useful function for analysing the T1 measurements.

@author: Childresslab
"""
import T1_finder as _T1_find
import numpy as np
import spinmob as sm
import matplotlib.pyplot as plt

# Debuger 
_debug_enabled     = False
def _debug(*a):
    if _debug_enabled: 
        s = []
        for x in a: s.append(str(x))
        print(', '.join(s))

## String for the headers of the data taken before 2021-05-17
#str_PL1_t0 = 'ms0_t0'
#str_PL1_tp = 'ms0_tprobed'
#str_PL2_t0 = 'ms-+1_t0'
#str_PL2_tp = 'ms-+1_tprobed'
## String for the headers of the data taken 2021-05-17 and after
str_PL1_t0 = 'PL1_t0'
str_PL1_tp = 'PL1_tprobed'
str_PL2_t0 = 'PL2_t0'
str_PL2_tp = 'PL2_tprobed'
    
    
def uinverse(A0, eA0, method = 1):
    """
    Propagate the uncertainty in f(A) = 1/A. 
    The formula is more precise than typical error propagtion with 
    linearization. 
    
    Linearization (ie, propagating the uncertainty by assuming
    linear perturbation. Therfore using derivatives of the function) works when
    A is a "gaussian variable": its noise is well defined by a gaussian 
    distribution and not chopped. 
    
    Here, we extended this to the case where:
        - A is expected to be positive
        - The noise in A can be large compared to A. Such that A can be zero or 
          negative, despite the fact that it is expected to be positive (this 
          situation happens when the noise in A is large compared to A).
    
    In order to get the propagation of the error in such a situation, we used 
    Bayesian analysis and considered the mean and standard deviation of the 
    probability density function of f(A), when A is expected to be positive, 
    but can be measured negative or zero because of noise fluctuation. 
    
    For more info on the derivation of the formula, see the notebook of 
    Michael Caouette-Mansour on 2020-11-30,
    in the subsection "Careful error propagation of inverse". 
    
    Input parameters:
        A0:
            Measured mean value of A. Can be begative or zero. 
        eA0:
            Measured uncertainty in A. If zero, the function will return 1/A0
            
        method:
            1 or 2. Which way around and in which order the algebra is made. 
            This influences some numerical round-off .
            
    return:
        z0:
            Best estimate of 1/A.
        ez0:
            Best uncertainty in z0.
    """
    if method == 1:
        """
        This method avoids division by zero if A0 = 0, 
        """
        # A ratio used many time
        ratio = A0/(eA0*eA0)
        # A product used many time
        eA02 = eA0*eA0
        # Expectation for f(A). Formula comes from careful Bayes analysis.
        z0 = 0.25*( (ratio*ratio + 8/(eA02))**0.5 - ratio)
        # Second derivative of the logarithm of the pdf of f(A)
        z02 = z0*z0 # A quantity used many time
        dL2dz2 = 2*ratio/(z02*z0) + 2/z02 - 3/(eA02*z02*z02) 
        
        #Uncertainty in f(A). Formula comes from careful Bayes analysis.
        ez0 = 1/ (-dL2dz2)**0.5
        # Here we go.
        return z0, ez0
    
    elif method == 2:
        """
        This method is more compact and may be better the deal with numerical
        round-off error. However, if A0=0, there is a division by zero. 
        """
        # A ratio used many time
        ratio = A0/(eA0*eA0) 
        relative = eA0 / A0
        
        z0 = 0.25*ratio*( ( 1 + 8*relative*relative )**0.5 - 1 )
        
        # Second derivative of the logarithm of the pdf of f(A)
        z02 = z0*z0 # A quantity used many time
        # A product used many time
        eA02 = eA0*eA0        
        dL2dz2 = 2*ratio/(z02*z0) + 2/z02 - 3/(eA02*z02*z02) 
        
        #Uncertainty in f(A). Formula comes from careful Bayes analysis.
        ez0 = 1/ (-dL2dz2)**0.5
        # Here we go.
        return z0, ez0        

    elif method == 3:
        """
        This another way to wrtie down the equation. 
        This as no 1/A0 and therefore I hope it will not have issues with 
        division by zero. 
        """
        # A ratio used many time
        ratio = A0/(eA0*eA0) 
        relative = eA0 / A0
        
        z0 = 0.25*(1/eA0)*( ( (A0/eA0)**2 + 8 )**0.5 - A0/eA0)
        
        # Second derivative of the logarithm of the pdf of f(A)
        z02 = z0*z0 # A quantity used many time
        # A product used many time
        eA02 = eA0*eA0        
        dL2dz2 = 2*ratio/(z02*z0) + 2/z02 - 3/(eA02*z02*z02) 
        
        #Uncertainty in f(A). Formula comes from careful Bayes analysis.
        ez0 = 1/ (-dL2dz2)**0.5
        # Here we go.
        return z0, ez0              
        
    

def uDiffRatio(x1, ex1, x2, ex2,
               x3, ex3, x4, ex4):
    """
    Return the differentio-Ratio measurement of 4 quantity, with the propagated
    uncertainty. 
    
    We want to evaluate z = ( x1 - x2 ) / ( x3 - x4)
    
    We linearly propagate the error in the numnerator and the denominator. 
    But we are more careful for when taking the ratio. We use a non-linear 
    error propagation for the inverse. 
    
    
    """
    # Combine the results
    Top = x1 -x2
    Bot = x3 - x4
    # Linearly propagate the error in the numerator and dominator
    eTop = ( ex1*ex1 + ex2*ex2 )**0.5   # Uncertainty in the numerator
    eBot = ( ex3*ex3 + ex4*ex4 )**0.5 # Uncertainty in the bottom
    # Non-linearly propagate the error in the inverse of the bottom
    inv_bot, einv_bot = uinverse(Bot, eBot, method=2)
    # Finnaly, the resulting best estimate and uncertainty
    z = Top*inv_bot
    
    # I comment this, because is either Top or inv_bot is zero, it leads to 
    # division by zero.
#    ez = z * ( (eTop/Top)**2 + (einv_bot/inv_bot)**2 )**0.5
    ez = ( (Top*einv_bot)**2 + (inv_bot*eTop)**2 )**0.5
    
    return z, ez

        
# Defines the models function        
def model_00m0(m, t, gp, gm):
    """
    
    Model for the behavior of the experimental measurement. 
    It of the type 00m0; where m is either +1 or -1. 
    
    m:
        +1 or -1 
        (Depending on the tuype of the pulse sequence to use)   
    t:
        Time    
    gp, gm:
        Rates
        
    Choice of unit: 
        As long as the time multiplied by the rate is unitless.
        
    """    
    g0 = ( gp*gp + gm*gm - gp*gm )**0.5
    beta_p = gp + gm + g0
    beta_m = gp + gm - g0   
    
    # This trick outputs gp is m=+1 and gm if m=-1
    gamma = 0.5*(1+m)*gp + 0.5*(1-m)*gm 
    
    term1 = (g0 + gamma) *np.exp(-beta_p * t)
    term2 = (g0 - gamma)*np.exp(-beta_m * t)
    
    return (term1 + term2 ) / (2*g0)  

def model_m0mm(m, t, gp, gm):
    """
    
    Model for the behavior of the experimental measurement. 
    It of the type m0mm; where m is either +1 or -1. 
    
    m:
        +1 or -1 
        (Depending on the tuype of the pulse sequence to use)   
    t:
        Time    
    gp, gm:
        Rates
        
    Choice of unit: 
        As long as the time multiplied by the rate is unitless.
        
    """    
    g0 = ( gp*gp + gm*gm - gp*gm )**0.5
    beta_p = gp + gm + g0
    beta_m = gp + gm - g0   
    
    term1 = (g0 + m*(gp-gm))*np.exp(-beta_p * t)
    term2 = (g0 + m*(gm-gp))*np.exp(-beta_m * t)
    
    return (term1 + term2 ) / (2*g0)  

def udiff_from_array_counts(array_C0_0, array_C0_t, 
                            array_C1_0, array_C1_t,
                            repetition_0_0, repetition_0_t,
                            repetition_1_0, repetition_1_t,
                            want_tuple_PL=False):
    """
    Take arrays of counts for each signal and compute the diff-ratio of this. 
    
    Array Inputs:
        Each array is an array of equivalent counts. 
        Equivalent counts means that it is counts under the same condition. 
        Just repeated over and over. They are meant to be summed up. 
    
    repetition:
        Number of repetition that was done for accumulation each counts in the
        arrays. 
        It is important because it is used for determining the count per 
        readout. 
    want_tuple_PL:
        (bool) if True, will also return a tuple of the 4 PLs and the 
        uncertainties        
    
    """
    
    
    # ms=0 at t=0
    iteration = len(array_C0_0)
    N_readout = iteration * repetition_0_0
    counts = np.sum(array_C0_0)
    PL0_0  = counts/N_readout
    ePL0_0 = np.sqrt(PL0_0/N_readout)

    # ms=0 at t=t_probed
    iteration = len(array_C0_t)
    counts = np.sum(array_C0_t)
    N_readout = iteration * repetition_0_t
    PL0_t   = counts/N_readout
    ePL0_t  = np.sqrt(PL0_t /N_readout)  
    
    # ms=+-1 at t=0
    iteration = len(array_C1_0)
    N_readout = iteration * repetition_1_0
    counts = np.sum(array_C1_0)
    PL1_0  = counts/N_readout
    ePL1_0 = np.sqrt(PL1_0/N_readout) 
    
    # ms=+-1 at t=t_probed
    iteration = len(array_C1_t)
    N_readout = iteration * repetition_1_t
    counts = np.sum(array_C1_t)
    PL1_t  = counts/N_readout
    ePL1_t = np.sqrt(PL1_t/N_readout) 

    # =========================================================================
    # Compute the drift_independant measurement
    # =========================================================================  
    tuple_PL = (PL0_t, ePL0_t, PL1_t, ePL1_t, PL0_0, ePL0_0, PL1_0, ePL1_0)
    result, uncertainty = uDiffRatio(*tuple_PL)   
    
    if want_tuple_PL:        
        return result, uncertainty, tuple_PL 
    else:
        return result, uncertainty

def udiff_from_datafile(data_file, want_tuple_PL=False):
    """
    Compute the drift independent measurement from the 4 data points. 
    
    data_file:
        (databox from spinmob) File of a single drift independent measurement
        
    want_tuple_PL:
        (bool) if True, will also return a tuple of the 4 PLs and the 
        uncertainties
    """
    
    # Same number of repetition for each files. 
    rep = data_file.headers['repetition']
    # Compute the differential ratiot for all the files
    return udiff_from_array_counts(data_file[str_PL1_t0], data_file[str_PL1_tp],
                                   data_file[str_PL2_t0], data_file[str_PL2_tp],
                                   rep, rep, rep, rep, 
                                   want_tuple_PL)
    
def extract_list_diff_ratio(ds):
    """
    Return a list of differential ratio measurement
    
    ds:
        List of T1 datafile    
    """    
    
    list_meas = []
    N_data_file = len(ds)
    
    # Extract each the measurement from each data file
    for i in range(N_data_file):
        # Get the data file
        d = ds[i]
        # Extract the time probed 
        t_probe = d.headers['t_probe']*1e-6 # In sec
        # Extract the drift_independent measurement from the file. 
        result, uncertainty = udiff_from_datafile(d)
        # Append the result depending on the type of measurement
        type_measurement = d.headers['Type_measure']    
        
        list_meas.append( (t_probe, type_measurement,
                           result, uncertainty) )
    
    return list_meas
    

def extract_measurement(ds):
    """
    ds:
        List of T1 datafile
        
    We will convert into second !!
    
    """
    
    N_data_file = len(ds)
    # Store the drift independent measurement for each type of experiment
    result_plus_s  = []
    result_minus_s = []
    uncertainty_plus_s  = []
    uncertainty_minus_s = []
    t_probe_plus_s  = []
    t_probe_minus_s = []
    
    # Extract each the measurement from each data file
    for i in range(N_data_file):
        # Get the data file
        d = ds[i]
        # Extract the time probed 
        t_probe = d.headers['t_probe'] * 1e-6 # CONVERT INTO SECOND
        # Extract the drift_independent measurement from the file. 
        result, uncertainty = udiff_from_datafile(d)
        # Append the result depending on the type of measurement
        type_measurement = d.headers['Type_measure']    
        if type_measurement == +1:
            result_plus_s.append(result)
            uncertainty_plus_s.append(uncertainty)
            t_probe_plus_s.append(t_probe)
        elif type_measurement == -1:
            result_minus_s.append(result)
            uncertainty_minus_s.append(uncertainty)     
            t_probe_minus_s.append(t_probe)

    # Get into numpy array
    result_plus_s       = np.array(result_plus_s)
    uncertainty_plus_s  = np.array(uncertainty_plus_s)
    result_minus_s      = np.array(result_minus_s)
    uncertainty_minus_s = np.array(uncertainty_minus_s) 
    t_probe_plus_s = np.array(t_probe_plus_s)   
    t_probe_minus_s = np.array(t_probe_minus_s)
    
    # Make the output to matche the input of other processinf function
    return (t_probe_plus_s , result_plus_s , uncertainty_plus_s, 
            t_probe_minus_s, result_minus_s, uncertainty_minus_s)


def rates_from_bayes_from_meas(list_meas,
                               model_1, model_2,
                               Gp_min=0.01e3, Gp_max=100e3, 
                               Gm_min=0.01e3, Gm_max=100e3, 
                               N_grid=200):
    """
    Fit the model on the data with stochastic bayesian fitting. 
    Get the rates from this
    
    list_meas:
        List of tuple that describes the measurment. The form of each tuple is:
        (t_probe, type_measurement, result, uncertainty)

    model_1, model_2:
        Function with signature (t, gp, gm) that describes the model of the 
        data. 
    other inputs:
        bounds and size of the (assuming flat) prior knowledge. 
        (Rates in Hz) 
    
        
    """
    
    # Initiate the object    
    mesh_gp, mesh_gm = np.meshgrid(np.linspace(Gp_min, Gp_max, N_grid),
                                   np.linspace(Gm_min, Gm_max, N_grid) )
    prior = 1 + 0*mesh_gp  
    my_bayes = _T1_find.Bayes2DInference(mesh_gp, mesh_gm, prior, model_1, model_2)  
    
    my_bayes.give_measurement(list_meas, 
                              want_refine_grid=True)
    # Check the rates
    out = my_bayes.get_parameters(want_corr=True)
    gp, gm, egp, egm, corr = out
    
    # Watchout the order of the outputs 
    return gp, egp, gm, egm, corr, my_bayes


def rates_from_bayes_from_data(ds, model_1, model_2,
                               Gp_min=0.01e3, Gp_max=100e3, 
                               Gm_min=0.01e3, Gm_max=100e3, 
                               N_grid=200):
    """
    Fit the model on the data with stochastic bayesian fitting. 
    Get the rates from this
    
    ds:
        list of data file 
    model_1, model_2:
        Function with signature (t, gp, gm) that describes the model of the 
        data. 
    other inputs:
        bounds and size of the (assuming flat) prior knowledge. 
        (Rates in Hz) 
    
        
    """   
    # Get the list of measurement
    list_meas = extract_list_diff_ratio(ds)
    # Make the inference
    return rates_from_bayes_from_meas(list_meas,
                                      model_1, model_2,
                                      Gp_min=Gp_min, Gp_max=Gp_max, 
                                      Gm_min=Gm_min, Gm_max=Gm_max, 
                                      N_grid=N_grid)
    

def cum_rates_from_bayes(ds, model_1, model_2,
                         Gp_min=0.01e3, Gp_max=100e3, 
                         Gm_min=0.01e3, Gm_max=100e3, 
                         N_grid=200):
    """
    Get the cumulative inference of the rates with Bayes. 
    This for seeing how the inference evolve with the data.
    ds:
        list of data file 
        
    """
    
    # Initiate the object
    mesh_gp, mesh_gm = np.meshgrid(np.linspace(Gp_min, Gp_max, N_grid),
                                   np.linspace(Gm_min, Gm_max, N_grid))
    prior = 1 + 0*mesh_gp  
    my_bayes = _T1_find.Bayes2DInference(mesh_gp, mesh_gm, prior, model_1, model_2)   
    
    # Cumulitivaly provide the data and monitor the inference
    list_meas = extract_list_diff_ratio(ds)
    N_data = len(ds)
    list_t_elapsed = np.zeros(N_data)
    list_gp = np.zeros(N_data)
    list_gm = np.zeros(N_data)
    list_egp = np.zeros(N_data)
    list_egm = np.zeros(N_data)    
    for i in range(N_data):
        # Make the inference
        my_bayes.give_measurement([ list_meas[i] ], 
                                  want_refine_grid=True)
        # Check the rates
        out = my_bayes.get_parameters(want_corr=True)
        list_gp[i], list_gm[i], list_egp[i], list_egm[i], _ = out        
        # Also get the elapsed time
        d = ds[i]
        list_t_elapsed[i] = d.headers['Time_finish'] - d.headers['Time_initial']
    
    # Watchout the order of the outputs 
    return list_t_elapsed, list_gp, list_egp, list_gm, list_egm
    

def rate_from_chi2(ds, model_1, model_2, want_plot_fitter=False):
    """
    Fit the model on the data with chi2 fitting. 
    Get the rates from this

    """
    # Create the fitter object
    fitter = sm.data.fitter(autoplot = want_plot_fitter)
    # Set the two function that we simultaneuously fit
    fitter.set_functions(['fp(x, gp, gm)', 'fm(x, gp, gm)'], 
                          p='gp,gm', fp=model_1, fm=model_2)
    
    tp, yp, eyp, tm, ym, eym = extract_measurement(ds)
    
    # Help to debug
    print('tp, yp, eyp, tm, ym, eym = ',tp, yp, eyp, tm, ym, eym)
    
    # Set the data
    fitter.set_data([tp, tm], 
                    [yp, ym], [eyp, eym])
    #Set the guess
#    guess_gp = np.mean(0.5/tp)
#    guess_gm = np.mean(0.5/tm) 
    # Apparently the fit fails if the guess are too much wrong.
    guess_gp = 1e3
    guess_gm = 1e3
    
    # Help to debug
    print('guess_gp, guess_gm = ', guess_gp, guess_gm)    
    
    fitter.set(gp=guess_gp, gm=guess_gm)
    # Fit !
    fitter.fit()
    # Extract the rates
    gp_fit  = fitter.results.params['gp'].value
    egp_fit = fitter.results.params['gp'].stderr
    gm_fit  = fitter.results.params['gm'].value
    egm_fit = fitter.results.params['gm'].stderr   
    
    # Get extrac info
    chi2 = fitter.get_reduced_chi_squared()
    dof  = fitter.get_degrees_of_freedom()
    
    return gp_fit, egp_fit, gm_fit, egm_fit, chi2, dof, fitter
    

def plot_awesome_data_fit(ds, model_plus, model_minus,
                          gp, gm, egp, egm):
    """
    Create a wonderful plot of the data and the fit.
    """
    

    (t_probe_plus_s , result_plus_s , uncertainty_plus_s , 
     t_probe_minus_s, result_minus_s, uncertainty_minus_s ) = extract_measurement(ds)
    
    # Compute the chi2
    res_p = result_plus_s  - model_plus (t_probe_plus_s ,gp, gm)
    res_m = result_minus_s - model_minus(t_probe_minus_s,gp, gm)
    dof = len(ds) - 2
    chi2 = ( np.sum( (res_p/uncertainty_plus_s )**2 ) + 
             np.sum( (res_m/uncertainty_minus_s)**2 )   ) / dof
    
    # Initiate the plot
    plt.figure(tight_layout=True, figsize=(15, 8))
    
    # Plot the plus type of measurement
    ax = plt.subplot(221) # 2 rows, 2 columns, Select the first plot
    
    # Split the title in 2
    ss = ds[-1].path
    str_t = ss[:len(ss)//2] + '\n' + ss[len(ss)//2:]
    plt.title(str_t, fontsize=10)
    
    # The data + 
    plt.errorbar(t_probe_plus_s*1e6, result_plus_s, yerr=uncertainty_plus_s, 
                 fmt='.', label='Plus')
    # The fit
    t_fit = sm.fun.erange(t_probe_plus_s.min(), t_probe_plus_s.max(), 300)
    y_fit = model_plus(t_fit, gp, gm)
    plt.plot(t_fit*1e6, y_fit, label='Chi2')
    # Some enhancements
    plt.legend(loc='best')
    plt.xlabel('Time probed (us)')
    plt.ylabel('Diff-ratio')
    plt.text(0.02, .9, '(a)', transform=ax.transAxes)
    plt.xscale('log')
    
    # Plot the minus type of measurement
    ax = plt.subplot(223) # 2 rows, 2 columns
    # The data - 
    plt.errorbar(t_probe_minus_s*1e6, result_minus_s, yerr=uncertainty_minus_s, 
                 fmt='.', label='Minus')
    # The fit
    t_fit = sm.fun.erange(t_probe_minus_s.min(), t_probe_minus_s.max(), 300)
    y_fit = model_minus(t_fit, gp, gm)
    plt.plot(t_fit*1e6, y_fit, label='Chi2')
    # Some enhancement
    plt.legend(loc='best')
    plt.xlabel('Time probed (us)')
    plt.ylabel('Diff-ratio')
    plt.text(0.02, .9, '(b)', transform=ax.transAxes)
    plt.xscale('log')
        
    # Some text
    ax = plt.subplot(222) # 2 rows, 2 columns, 2nd plot
    str_info = ('Inference: '+
                '\n$\Gamma_+$ = %f +- %f kHz'%(gp*1e-3, egp*1e-3) + 
                '\n$\Gamma_-$ = %f +- %f kHz'%(gm*1e-3, egm*1e-3) + 
                '\n$\chi^2_{reduced}$ = %f +- %f (%d dof)'%(chi2, (2/dof)**0.5, dof)) 
    
    plt.text(0.02, .4, str_info , transform=ax.transAxes,
             fontsize=12, color='black')
    plt.axis('off')
    
    # Put the residuals
    
    # For the data plus
    ax_res_p = plt.subplot(426)
    ax_res_p.plot(t_probe_plus_s*1e6, 0*t_probe_plus_s, '--r')
    ax_res_p.errorbar(t_probe_plus_s*1e6, res_p, yerr=uncertainty_plus_s, 
                 fmt='.')
    ax_res_p.set_ylabel('Residual +')
    # For the data minus
    ax_res_m = plt.subplot(428)
    ax_res_m.plot(t_probe_plus_s*1e6, 0*t_probe_plus_s, '--r')
    ax_res_m.errorbar(t_probe_minus_s*1e6, res_m, yerr=uncertainty_minus_s, 
                 fmt='.', label='Fit -')
    ax_res_m.set_ylabel('Residual -')
    ax_res_m.set_xlabel('Time probed (us)')
    ax_res_p.set_xscale('log')
    ax_res_m.set_xscale('log')


def restructure_trace(ds, N_split=10, want_print=False, 
                      use_funky_elapsed_time=False):
    """
    Restructure a data set of T1 measurements. 
    
    Idea:
        Eachd ata file contains many rows. Each row represent the counts from
        a pulse sequence. What we do each, is that we will take a certain 
        amount of row from each data file and create a list of data for each
        set of rows. This is for being able to know how the inference on time
        trace is evolving with time in the 1/sqrt(N) regime. 
        
    My apologize to the user. I didn't find the clearest way to explain this 
    yet. :/ 
        
    Inputs:
        ds:
            List of data file to process.
        N_split:
            Number cumulated data to generate. 
        want_print:
            (Boolean) If True, it will print the evolution of the processing. 
        use_funky_elapsed_time:
            (Bool) Keep it false please. Set True if the current time is not 
            available in the data file. 
    
    """
    
    N_datafile = len(ds)
    
    # Will be a list of tuple. 
    # Eacht tuple is (list_yp, list_eyp, list_ym, list_eym) for a particular amount of data
    list_batch_measure = []
    for i in range(N_split):    
        # Take data from zero to i*step (ie, cumulative data)
        list_y  = []
        list_ey = []
        list_t  = []
        list_type = []
        # The following will be to note the time elapsed for each cumulative row. 
        list_dt = []
        # We now gonnae take a certain ammount of step in each data file. 
        for kk, d in enumerate( ds ):       
            # The steps to take depends on how many row 
            N_row = len(d[0]) # Number of row in the data file. 
            step = int( (i+1)* N_row / N_split )            
            
            # It seems okay to overshot with numpy array. 
            # Therefore, it seems fine if i*step > N_data. Numpy will just take
            # the data from 0 to N_data if i*step >N_data
            C0_0 = d[str_PL1_t0][0:step]
            C0_t = d[str_PL1_tp][0:step]
            C1_0 = d[str_PL2_t0][0:step]
            C1_t = d[str_PL2_tp][0:step]
            
            if want_print:
                print('Split %d; Data %d; len(C0_0) / N_row = %d / %d'%(i, kk, len(C0_0), N_row) )
            
            rep = d.headers['repetition']
            y, ey = udiff_from_array_counts(C0_0, C0_t, C1_0, C1_t,
                                            rep, rep, rep, rep)
            # Add this points
            list_y .append( y  )
            list_ey.append( ey )
            # Note the time of measurement for this sequence
            t_probe = d.headers['t_probe']*1e-6 # In sec                         
            list_t .append( t_probe)
            # Note the corresponding type of measurement
            type_measurement = d.headers['Type_measure']  
            list_type.append(type_measurement)
            # Finally, get the total time elapsed
            if use_funky_elapsed_time:
                print('WARNING in restructure_trace. We are averaging the total time elapsed')
                t_tot = d.headers['Time_finish'] - d.headers['Time_initial']
                dt = t_tot * len(C0_0) / N_row # Time elapsed = fraction of total time
                list_dt.append( dt )
            else:
                # Way better elapsed time
                dt = d['curent_time'][step-1] - d['curent_time'][0]
                list_dt.append( dt )
        
        # Get the total time elapsed for this cumulative set
        t_elapse = np.sum(list_dt)
        
        # We now gonna create the data set well suited for the T1 finder. 
        list_tuple_meas = []
        for jj in range(N_datafile):
            tuple_meas = (list_t[jj], list_type[jj], list_y[jj], list_ey[jj])
            list_tuple_meas.append(tuple_meas )
        # Add this structur to our list of cumulative data
        list_batch_measure.append( (t_elapse, list_tuple_meas ) )
        
    # We now have what we wants
    return list_batch_measure    

def cum_rates_bayes_restructured_data(ds, model_1, model_2,
                                      N_split=10, want_print=False):
    """
    Get the inference VS time elapsed from restructured data set. 
    """
    out = restructure_trace(ds, N_split=N_split, want_print=want_print)
    N_cum = len(out)
    
    # For each accumulation, determine the inference
    list_gp, list_gm, list_egp, list_egm, list_t_elapsed = np.zeros((5,N_cum))
    for i in range(N_cum):
        t_ela = out[i][0]
        list_meas =   out[i][1] 
        # Infer
        outputs = rates_from_bayes_from_meas(list_meas, model_1, model_2)
        list_gp[i], list_egp[i], list_gm[i], list_egm[i], corr, my_bayes =  outputs
        list_t_elapsed[i] = t_ela 
        
    # We finally got it
    return list_t_elapsed, list_gp, list_egp, list_gm, list_egm

    
if __name__=="__main__":
    """
    For testing some code
    """    


    """
    Goal:
        From a batch of trace measurement, split the data into cumulative 
        measurement. 
        It basically mean to re-organize the file. 
        The structure will be adapted for processing with Bayesian inference. 
    """   
    
    
    # =============================================================================
    # Test the restructuration for the trace
    # =============================================================================
    def model_1(t, gp, gm):
        return model_00m0(+1, t, gp, gm)
    def model_2(t, gp, gm):
        return model_00m0(-1, t, gp, gm)    
    
    ds = sm.data.load_multiple(text='Select a batch of T1 measurement')
    out = cum_rates_bayes_restructured_data(ds, model_1, model_2, 
                                            N_split=30, want_print=True)
    list_ttotal, list_gp, list_egp, list_gm, list_egm = out


    # Plot the evolution of the inference
    plt.figure(tight_layout=True)
    
    # Check Gamma+
    ax = plt.subplot(221) 
    plt.errorbar(list_ttotal/3600, list_gp*1e-3, yerr=list_egp*1e-3, fmt='.')
    plt.ylabel('$\Gamma_+$ (kHz)', fontsize=18)
    plt.text(0.02, .9, '(a)', transform=ax.transAxes)
    s = ''
    for ss in ds[0].path.split(maxsplit=2):
        s += '\n' + ss
    plt.title(s, fontsize=10)    
    
    # Check Gamma-
    ax = plt.subplot(223)
    plt.errorbar(list_ttotal/3600, list_gm*1e-3, yerr=list_egm*1e-3, fmt='.')    
    plt.ylabel('$\Gamma_-$ (kHz)', fontsize=18)
    plt.text(0.02, .9, '(b)', transform=ax.transAxes)
    plt.xlabel('Time elapsed (hour) ')
    
    # Uncertainty Versus time
    ax = plt.subplot(222)
    plt.text(0.02, .9, '(c)', transform=ax.transAxes)
    plt.plot(list_ttotal, list_egp*1e-3, '.-', label='$e\Gamma_+$')
    plt.plot(list_ttotal, list_egm*1e-3, '.-', label='$e\Gamma_-$')
    plt.legend(loc='best')
    plt.xscale('log')
    plt.yscale('log')
    plt.xlabel('Time elapsed (hour) ')
    plt.ylabel('Uncertainty (kHz)')
          
            





    
    
    
    