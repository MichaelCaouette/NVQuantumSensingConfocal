# -*- coding: utf-8 -*-
"""
Created on Fri Oct  9 12:35:01 2020

Goal: Developper the adaptive Bayes finder

@author: Childresslab
"""


import numpy as np
from scipy import interpolate # for the Bayesian finder

import traceback
_p = traceback.print_last #Very usefull command to use for getting the last-not-printed error

# Debuger 
_debug_enabled     = False
def _debug(*a):
    if _debug_enabled: 
        s = []
        for x in a: s.append(str(x))
        print(', '.join(s))
        
        
def analytic_uncertainties(f1, f2, ef1, ef2, x0, y0, 
                         dx=0.001, dy=0.001,
                         want_variance=False):
    """
    Return an estimate of the uncertainties in the domain of a bi-dimensional
    pdf. 
    
    f1, f2:
        Two model function describing the measurement. 
        Their signature must best (x,y). ie f1 = f1(x,y) and f2 = f2(x,y)
    
    ef1, ef2:
        Absolute uncertainty in the measurement. 
    
    x0, y0:
        True or best estimate of x and y. 
        
    dx, dy:
        Infinitesimal step in x and y for taking the derivatives. 
        
    want_variance:
        (bool) If True, the function return the variances and the covariance of 
        x & y.  If False, the function return the uncertainty and the 
        correlation in x & y 
        (correlation = covariance / product of uncertainties)
    """
    
    # Compute the first derivatives, evaluated at x0, y0
    # I choose a two-point formula that should converge to h**2, according to 
    # Wikipedia: https://en.wikipedia.org/wiki/Numerical_differentiation
    df1dx = ( f1(x0 + dx, y0) - f1(x0 - dx, y0) ) / ( 2 * dx )
    df1dy = ( f1(x0, y0 + dy) - f1(x0, y0 - dy) ) / ( 2 * dy )
    df2dx = ( f2(x0 + dx, y0) - f2(x0 - dx, y0) ) / ( 2 * dx )
    df2dy = ( f2(x0, y0 + dy) - f2(x0, y0 - dy) ) / ( 2 * dy )
    
    # Compure the coefficients
    # Start with various gradients
    a1 = df1dx / ef1
    a2 = df2dx / ef2
    b1 = df1dy / ef1
    b2 = df2dy / ef2
    # Combine these gradients
    A = a1*a1 + a2*a2
    B = b1*b1 + b2*b2
    C = a1*b1 + a2*b2
    D = A*B - C*C
    
    # Compute the variances and covariances
    ex2 =  B / D # Variance in x
    ey2 =  A / D # Variance in y
    exy = -C / D # Covariance of x & y
    
    if want_variance:
        return ex2, ey2, exy 
    else:
        ex   = ex2**0.5
        ey   = ey2**0.5
        corr = exy / (ex * ey)
        
#        print('ex = ', ex)
        return ex, ey, corr
    

def EstimateBestSetting(list_t, best_gp, best_gm,
                        model_1, model_2, T_overhead=0, N_rep=1,
                        want_rel_sens=True):
    """
    Estimate the setting that should minimize the sensitivity on the rates.
    It uses an analytic estimation of the uncertainty in the rate from the 
    measurement.
    
    Input:
        list_t: EXPLAIN
        
        T_overhead:
            Extra time in the protocole that is not included in the time 
            probed. This can be many sources:
                - Time in the pulse sequence for applyied various pulse; 
                - Processing time between the iteration. 
                - If there is sporadic interruption (example, for refocusing 
                  the beam on the emitter), T_overhead can be the average extra
                  time in the protocole. 
        N_rep:
            Numberof repetition of the same pulse sequence. 

        want_rel_sens=True:
            (bool) If true, will take the times that miniminize the combined 
            relative sensitivity in the rate. Otherwise, it will be the 
            absolute sensitivity.
            
    """
    _debug('EstimateBestSetting')
      
    # Chop the time axis. This is in order to keep the analytic model well
    # behaved
    
    # Version 3, with different array of time to probe for each type.
    # We assume that model_1 is more sensitive on gp and model_2 more 
    # sensititive on gm. 
    iii_1 = ( 0.1/best_gp < list_t ) * (list_t < 10/best_gp )
    iii_2 = ( 0.1/best_gm < list_t ) * (list_t < 10/best_gm )
    list_t1 = list_t[iii_1]
    list_t2 = list_t[iii_2]
    mesh_t1, mesh_t2 = np.meshgrid(list_t1, list_t2)
    
#    # Version Not choppping
#    mesh_t1, mesh_t2 = np.meshgrid(list_t, list_t)
        
    def f1(gp, gm):
        return model_1(mesh_t1, gp, gm)
    def f2(gp, gm):
        return model_2(mesh_t2, gp, gm)  

    # Set the uncertainty in the measurement to be constant and the same for 
    # both type of measurement. This is reasonable because we are using this 
    # algorithm to find an extrema, which do not depend on the uncertainty if
    # both are the same. It is also reasonable to asusm that the uncertainty 
    # do not vary much over the time. This was argued my notebook (Michael) of 
    # 2021-04-14
    ef1 = 10
    ef2 = 10
    out = analytic_uncertainties(f1, f2, ef1, ef2, best_gp, best_gm)  
    mesh_ex, mesh_ey, mesh_corr = out
        
    # Compute the cost (sensitivity) for each time to probe
    # We want to minimize the sqrt of this.
    # The total time consist of the probing times + the extra overhead time
    T_measure = 2*N_rep*(mesh_t1 + mesh_t2) # The normalization imply to measure twice at t_probe
    T_total = T_measure + T_overhead     
    if want_rel_sens:
        map_rel_x = mesh_ex / best_gp
        map_rel_y = mesh_ey / best_gm
        cost = np.sqrt( (map_rel_x**2 + map_rel_y**2) * T_total )
    else:
        cost = np.sqrt( (mesh_ex*mesh_ex + mesh_ey*mesh_ey) * T_total )
    
    # Find the time that minimize this
    ind = np.unravel_index(cost.argmin(), cost.shape)
    i = ind[0]
    j = ind[1]
    # numpy.mean() is for if there is many winners
    best_t1 = np.mean( mesh_t1[i][j] )
    best_t2 = np.mean( mesh_t2[i][j] )  
    
    return best_t1, best_t2
                           


class Bayes2DInference():
    """
    Class for making bayesian inference on model with 2 parameters and 
    2 input data. 
    
    It is actually made on purpose of the inference of the rates.
        
    """

    def __init__(self, 
                 mesh_gp, mesh_gm, prior, 
                 model_plus, model_minus):
        """
        
        Input:
            mesh_gp and mesh_gm:
                Meshgrid of the rates on which we will make the inference. 
            prior:
                Same shape and the meshgrid of the rates. 
                It is the prior probability distribution of the rates. 
                No need to be normalized, because the class normalized the 
                posterior probability density function. 
            model_plus, model_minus:
                Each a function with signature (t, gamma+, gamma-), where t is 
                the time to probe. These are the model function that describe the 
                differential ratio of the measurement. The first is for the type 
                plus and the second for the type minus pulse sequence. 
        """
        
        _debug('Bayes2DInference: __init__')
        _debug('Be a fruitloop in a world of Cheerios. – Unknown')
        
        # Initiate the parameters
        self.mesh_gp = mesh_gp
        self.mesh_gm = mesh_gm
        self.prior   = prior 
        self.model_p = model_plus
        self.model_m = model_minus
        
        # Initiathe the posterior with the prior         
        self._update_post(np.log(self.prior), want_init=True )
        
        # We gonna note the initiale bounds. Useful for the re-finement of the 
        # grid. 
        self.Gp_upperBound = np.max(self.mesh_gp)
        self.Gp_lowerBound = np.min(self.mesh_gp)
        self.Gm_upperBound = np.max(self.mesh_gm)
        self.Gm_lowerBound = np.min(self.mesh_gm)        
        
        # Also note the 1D array corresponfing to each axis of the domain
        self.axis_gp = self.mesh_gp[0]   # 1D axis for gamma+
        self.axis_gm = self.mesh_gm.T[0] # 1D axis for gamma-
        self.N_gp    = len(self.axis_gp) # Number of discrete point along the gamma+ axis for the probability distributions.
        self.N_gm    = len(self.axis_gm)   
        
    def _likelihood_log(self, model, data, edata):   
        """
        Compute the logarithm of the like-lihood, modulo a constant. 
        
        model:
            Model, or expected value, for the ratio Top/Bot. 
            For example, m is meant to be a 2D array for each possible rate. 
            In other word, m = model_function( mesh_gp, mesh_gm ), evaluated at
            the time at which the data Top and Bot were taken. 
            
        data, edata:
            Collected data and the coresponding uncertainty.
            
        """
        
        _debug('Bayes2DInference: _likelihood_log')
        
        # Very basic. It is actually the chi2 component that depends on the 
        # rate and the data 
        # Note: If the dependency on the rate is only in the model, the last
        # term can be dropt, because it will be renormalized anyway. 
        dx = (data - model)
        ln_L = - (dx*dx) / (2*edata*edata) - np.log(edata)
        
        return ln_L  

        
    def _update_post(self, ln_L, want_init=False):
        """
        Update the posterior. 
        
        ln_L:
            Logarith of the new incoming like-lihood. 
            Note that this can also be the prior for initiating the posterior.
        want_init:
            (bool) If true, the posterior will be initiated with ln_L
            
        """
        _debug('Bayes2DInference: _update_post' )
        
        # Update the logarithm of the posterior. 
        if want_init:
            self.ln_post = ln_L
        else:
            self.ln_post += ln_L
        # Rescale it for avoiding extremen numerical number
        self.ln_post -= np.max(self.ln_post) # Rescale the max to be zero
        
        # Update the posterior and normalize it
        self.post  = np.exp(self.ln_post)
        self.post /= self._integral2D(self.mesh_gp[0], 
                                      self.mesh_gm.T[0], 
                                      self.post) 
        if _debug_enabled:
            #Put this debug into an extra of, because the extra calculation of the volume might be expensive 
            vol = self._integral2D(self.mesh_gp[0], 
                                   self.mesh_gm.T[0], 
                                   self.post) 
            _debug('Volume of posterior (its not fun)  = ', vol )    
          
    def _integral2D(self, x, y, Z):
        """
        Integrate in 2 dimension Z. 
        Z is the 2D array to integrate. 
        x and y are both 1D array used to define the axis of Z
        """
        _debug('Bayes2DInference: _integral2D')
        
        firstInt = np.trapz(Z, x=x, axis=1) #First integrate along the first axis
        return     np.trapz(firstInt, x=y) #Integrate over the remaining axis           

    def _refine_grid(self, nb_std_from_mean=10):
        """
        Refinement of the gridm or rediscretization of the domain 
        (= gamma+ and gamma- axis'es) based on 
        the standard deviation of the distribution in both direction. 
        
        nb_std_from_mean:
            Number of standart deviation away from the mean for the boundary 
            of the domain. 
            
        """
        _debug('Bayes2DInference: _refine_grid' )  
        
        self.nbStdFromMean = nb_std_from_mean           
        
        # Define the interpolator function before redefining the axis
        f_inter_ln_post    = interpolate.interp2d(self.axis_gp, self.axis_gm, 
                                                  self.ln_post, kind='linear')
        
        # Define the new bounds
        gp, gm, egp, egm = self.get_parameters()
        delta_Gp = self.nbStdFromMean*egp
        delta_Gm = self.nbStdFromMean*egm
        # Also make sure that we don't have negative bounds !!
        # Or that the new bound are outside the prior !
        Gp_lowerBound = gp - delta_Gp
        if Gp_lowerBound < self.Gp_lowerBound:
            Gp_lowerBound = self.Gp_lowerBound
            
        Gp_upperBound = gp + delta_Gp
        if Gp_upperBound> self.Gp_upperBound:
            Gp_upperBound = self.Gp_upperBound
            
        Gm_lowerBound = gm - delta_Gm
        if Gm_lowerBound < self.Gm_lowerBound:
            Gm_lowerBound = self.Gm_lowerBound
            
        Gm_upperBound = gm + delta_Gm
        if Gm_upperBound> self.Gm_upperBound:
            Gm_upperBound = self.Gm_upperBound     
        
        # Re-define the axis over which we estimate the rates and the 
        # probability distribution
        self.axis_gp = np.linspace(Gp_lowerBound, Gp_upperBound, self.N_gp) 
        self.axis_gm = np.linspace(Gm_lowerBound, Gm_upperBound, self.N_gm) 
        #Meshgrid
        self.mesh_gp, self.mesh_gm = np.meshgrid(self.axis_gp, self.axis_gm)
        #Interpolate the quantities 
        self.ln_post = f_inter_ln_post(self.axis_gp, self.axis_gm)
        
    def give_measurement(self, list_measurement, want_refine_grid=False):
        """
        Feed the algorithm with measurements. 
        It updates the knowledge on the rates accordingly.
        
        list_measurement:
            List of tuple. Each tuple represent a single measurement. 
            The tuple must be of the form:
                (t_probe, type_measure, data, edata)
            Where:
                t_probe is the time at which the measurement was done (the decay time)
                type_measure is either +1 or -1, depending on the type of measurement. 
                data is the data described by the model
                edata is the uncertainty in the data
        
        want_refine_grid:
            (bool) If true, will refine the grid of the posterior around the 
            best estimate.
        
        """
        _debug('Bayes2DInference: give_measurement')
        
        for meas in list_measurement:
            if want_refine_grid:
                self._refine_grid()            
            # Get the settings and the data
            t_probe, type_measure, data, edata = meas
            # Compute the model for all possible rates on the grid
            if   type_measure == +1:
                mesh_model = self.model_p(t_probe, self.mesh_gp, self.mesh_gm)
            elif type_measure == -1:
                mesh_model = self.model_m(t_probe, self.mesh_gp, self.mesh_gm)
            else:
                print('WOWOWO WAIT !!! In Bayes2DInference: give_measurement. The type of measure is wrong ! Cannot be', type_measure)
            # Compute the logarithm of the like-lihood of this measurement
            ln_L = self._likelihood_log(mesh_model, data, edata)
            # Update the posterior pdf. 
            self._update_post(ln_L)

    def get_parameters(self, method='integral', want_corr=False):
        """
        Infer the parameter, by using Bayes Theorem on the data. 
        
        method:
            (string) Method to use for extracting the parameters on the 
            posterior pdf of the rates.
        want_corr:
            If true, will retunr the correlation
        
        """
        _debug('Bayes2DInference: get_parameters') 
        
        
        # Use Bayes        
        if method == 'integral':
            """
            Integrate the posterior with the corresponding weights for 
            extractiong quantities. 
            """
            _debug('integral')
            #Get the expected mean for both rates
            x = self.mesh_gp[0]
            y = self.mesh_gm.T[0]
            #Integrate in 2D. 
            self.best_gp  = self._integral2D(x, y, self.post*self.mesh_gp)
            self.best_gm  = self._integral2D(x, y, self.post*self.mesh_gm)
            #Get the covariant matrix element
            # Simplify the integral by first calculate the second orde moements
            mean_Gp2  = self._integral2D(x, y, self.post*self.mesh_gp*self.mesh_gp) 
            mean_Gm2  = self._integral2D(x, y, self.post*self.mesh_gm*self.mesh_gm) 
            mean_GpGm = self._integral2D(x, y, self.post*self.mesh_gp*self.mesh_gm)
            # From the moments, get the covariances
            self.cov_gp   = mean_Gp2  - self.best_gp*self.best_gp
            self.cov_gm   = mean_Gm2  - self.best_gm*self.best_gm
            self.cov_gpgm = mean_GpGm - self.best_gp*self.best_gm   
            # Get the error from the covariant diagonal
            self.best_egp  = np.sqrt(self.cov_gp)
            self.best_egm  = np.sqrt(self.cov_gm)   
            
            if want_corr:
                corr = self.cov_gpgm / (self.best_egp * self.best_egm)
                return (self.best_gp, self.best_gm, 
                        self.best_egp, self.best_egm,
                        corr )
            else:
                return self.best_gp, self.best_gm, self.best_egp, self.best_egm
            
        else:
            print('Hey wow minute !!! In Bayes2DInference: get_parameters. The method ',
                  method,' is wrong !')
            
    def get_post(self):
        """
        Return the posterior pdf of the rate, with the domain, why not. 
        """
        return self.post, self.mesh_gp, self.mesh_gm
    
    
class T1Finder():
    """
    T1 finder. This one uses the grid model for infering the rates and the pdf.
    
    This class will help you to find the two rates associated with the 
    T1 relaxation of ms=+-1. 
    It assumes that we have two types of measurement to make and a model for 
    describing the outcome of each type of measurement. 
    
    It uses Bayesian inference for estimating the parameters and the settings
    that are the most sensitive on the knowledge of the parameters. 

    This is how this class should be used:
        1. The user initiate the object with:
            - An initial set of allowed time to probe. 
            - The model for the two functions of the two decays. 
            - The prior knowledge on the parameters of the models. 
        2. The user ask to this object which time to probe and which type of 
           measurement to make. 
        3. The user perform its experiment and send the measurement to this 
           object. 
        4. Now this object have a better knowledge of the physics and can 
           better tell to the user which setting to probe next. Therefore, 
           he/she can repeat step 2-3 until satisfaction. 
           For example, the satisfaction criteria can be that a given 
           uncertainty is reached in the knowledge of the parameters. 
        
    """

    def __init__(self, list_allowed_probed_t,
                 model_1, model_2, tuple_prior_info):
        """
        list_allowed_probed_t:
            List of allowed time to probe. 
            
        model_1, model_2:
            Each a function with signature (t, parm1, parm2, etc.), where t is 
            the time to probe. These are the model function that describe the 
            outcome of our experiment. 
            
        tuple_prior_info:
            tuple = (gp_min, gp_max, gm_min, gm_max, N)
            TODO: Keep explaining
            Assum a flat prior for now. 
            
            
        Choice of unit:
            As long as it is consistent in the models. The time will be 
            directly plugued in the function.             
        
        """
        _debug('T1Finder: __init__')
        _debug('A champion is afraid of losing. Everyone else is afraid of winning. – Billie Jean King')
        
        self.list_allowed_probed_t = list_allowed_probed_t
        self.model_1 = model_1
        self.model_2 = model_2
        self.tuple_priors = tuple_prior_info
        
        (gp_min, gp_max, gm_min, gm_max, N) = tuple_prior_info
        mesh_gp, mesh_gm = np.meshgrid(np.linspace(gp_min, gp_max, N),
                                       np.linspace(gm_min, gm_max, N))
        prior = 1 + 0*mesh_gp
        
        # =============================================================================
        # Create the class that will infere the rate and provide the pdf
        # =============================================================================
        self.my_bayes = Bayes2DInference(mesh_gp, mesh_gm, prior, 
                                         self.model_1, self.model_2)  
   
        

    def get_best_setting(self, T_overhead=0, N_rep=1, want_rel_sens=True):
        """
        Obtain the best set of time to probe for each of the type of 
        measurement. The method is based on an analytice expression for the 
        uncertainty in the rates. 
        
        Input:
        T_overhead=0:
            Extra time in the protocole that is not included in the time 
            probed. This can be many sources:
                - Time in the pulse sequence for applyied various pulse; 
                - Processing time between the iteration. 
                - If there is sporadic interruption (example, for refocusing 
                  the beam on the emitter), T_overhead can be the average extra
                  time in the protocole. 
        N_rep=1:
            Numberof repetition of the same pulse sequence. 
            
        want_rel_sens=True:
            (bool) If true, will take the times that miniminize the combined 
            relative sensitivity in the rate. Otherwise, it will be the 
            absolute sensitivity.
            
            
            
        """
        _debug('T1Finder: get_best_setting_analytic')
        
        # Estimate the best knowledge on the rate so far.
        out = self.my_bayes.get_parameters()
        best_gp , best_gm,  _ , _ = out
        
        # Estimate the best set f time to probe for the two measurement.
        t1, t2 = EstimateBestSetting(self.list_allowed_probed_t,
                                     best_gp, best_gm,
                                     self.model_1, self.model_2,
                                     T_overhead=T_overhead, N_rep=N_rep,
                                     want_rel_sens=want_rel_sens)            
        return t1, t2    
    
        
        
    def give_measurement(self, measurement, uncertainty, 
                               time_probed, type_measure):
        """
        Feed the algorithm with a measurement.
        
        Input Parameters
        measurement:
            (float) Measurement which is modelized by the model function. 
        uncertainty:
            (float) Uncertainty in the measurement. 
        time_probed:
            (float) Time probed at which the measurement was made. 
        type_measure:
            (+1 or -1) Type of the measurement. +1 means the measurement + and
            -1 means the measurement -. 
            
        Return:
            Nothing. 
        """
        _debug('T1Finder: give_measurement')
        
        # It should be a list of tuple
        list_meas = [(time_probed, type_measure, measurement, uncertainty)]
        self.my_bayes.give_measurement(list_meas, 
                                        want_refine_grid=True)            
        return
    
    def get_parameters(self):
        """
        Infer the parameter, by using Bayes Theorem on the data. 
        
        Return a Tuple of size 3:
        First element:
            (array of float) Mean of each parameter. 
            Explicitly, it is [gamma+, gamma-].
        Second element:
            (array of float) Standard deviation of each parameter.
            Explicitly, it is [error in gamma+, error in gamma-].
        Third element:
            (Array of arrays, or numpy matrix) Covariance matrix of the 
            parameters.
            
        """
        _debug('T1Finder: get_parameters')
        # Make the inference of the parameters
        gp, gm, egp, egm, corr = self.my_bayes.get_parameters(want_corr=True)
        # Need to be a tuple of tuple
        parms = (gp, gm)
        eparms = (egp, egm)
        return (parms, eparms, (corr))

        
        
        
        
if __name__=="__main__":
    """
    The following code is executed only when this script is run alone. 
    It is only meant to test the code above. 
    """
    _debug_enabled = True
    
    import T1_sim_data as _sim
    import matplotlib.pyplot as plt
    import spinmob as sm
    import time
    
 
    # =========================================================================
    # Parameter for simulating the data
    # =========================================================================
    mode = 'Delta' # Delta or NIST (Which algo to use)
    N_readout = 7e5   # number of readout at the single time to probe
    C   = 0.24  # Optical Contrast between the states 
    PL0 = 0.014 # Mean count of ms=0
    BG  = 0 # Mean count of the background
    true_gp = 1*1e3  # (Hz) Experimental true rate 
    true_gm = 3*1e3  # (Hz) Experimental true rate
    T_overhead = 300 # (second) Extra time in the protocole
    
    n_adapt = 20 # Number of adaption to perform. 
        
    # Define the grid for the prior on the rate
    Gp_min = 0.01*1e3   #Minimum guess for gamma plus (Hz) 
    Gp_max = 100*1e3  #Maximun guess for gamma plus (Hz)        
    Gm_min = 0.01*1e3   #Minimum guess for gamma minus (Hz) 
    Gm_max = 100*1e3  #Maximun guess for gamma minus (Hz)  
    N_grid = 200 # Number of elementin the grid for the delta approach
    n_samples_params_NIST = int ( 1e5 ) # Number of sample to take for the parameter space
    
    pair_model = [('00', '+0'), ('00', '-0')]
    # Define the alloqwed time to probe
    # Logarithm spacing
    list_t_probe = sm.fun.erange(5, 3000, steps=1000)*1e-6 #Sec
        
    # Super rough approximation of the uncertainty in a measurement
    # It is no longer used. But I keep it here as a reference.
    unc_meas = np.sqrt(2/(N_readout*PL0))     
    # =========================================================================
    # Initiate the algorithm
    # =========================================================================
    def model_00m0(m, t, gp, gm):
        """
        
        Model for the behavior of the experimental measurement. 
        It of the type 00m0; where m is either +1 or -1. 
        
        m:
            +1 or -1 
            (Depending on the tuype of the pulse sequence to use)   
        t:
            Time    
        gp, gm:
            Rates
            
        Choice of unit: 
            As long as the time multiplied by the rate is unitless.
            
        """    
        g0 = ( gp*gp + gm*gm - gp*gm )**0.5
        beta_p = gp + gm + g0
        beta_m = gp + gm - g0   
        
        # This trick outputs gp is m=+1 and gm if m=-1
        gamma = 0.5*(1+m)*gp + 0.5*(1-m)*gm 
        
        term1 = (g0 + gamma) *np.exp(-beta_p * t)
        term2 = (g0 - gamma)*np.exp(-beta_m * t)
                
        return (term1 + term2 ) / (2*g0)     
    
    def model_1(t, gp, gm):
        return model_00m0(+1, t, gp, gm)
    def model_2(t, gp, gm):
        return model_00m0(-1, t, gp, gm)    
    
    if mode == 'NIST':
        tuple_prior_info = (Gp_min, Gp_max, Gm_min, Gm_max, n_samples_params_NIST)
        print('NIST is not implemented !')
    elif mode == 'Delta':
        tuple_prior_info = (Gp_min, Gp_max, Gm_min, Gm_max, N_grid)
        self = T1Finder(list_t_probe, model_1, model_2, tuple_prior_info)            
    
    # =========================================================================
    # Simulate running the experiment in the lab
    # =========================================================================    
    # Initiate some usefull array for the keeping track of thinks. 
    best_gp  = np.zeros(n_adapt) # Best gamma+ infered
    best_egp = np.zeros(n_adapt) # Error in the best gamma+ infered
    best_gm  = np.zeros(n_adapt) # Best gamma- infered
    best_egm = np.zeros(n_adapt) # Error in the best gamma- infered
    t_probed_p_s = []  # Time probed for the plus measurement at each iteration
    t_probed_m_s = []  # Time probed for the minus measurement at each iteration
    iterations = np.arange(n_adapt) # Number of iteration performed
    measurement_p_s    = [] # Measurement of the type "plus"
    emeasurement_p_s   = [] # uncertainty in the measurement of the type "plus"
    measurement_m_s    = [] # Measurement of the type "minus"
    emeasurement_m_s   = [] # uncertainty in the measurement of the type "minus"
    time_cpu           = np.zeros(n_adapt) # CPU processing time
    time_measurement   = np.zeros(n_adapt) # Experiement time
    sim_meas_1 = _sim.DiffRatioNoise(N_readout, BG, PL0, C, 
                                     type1=pair_model[0][0], type2=pair_model[0][1])
    sim_meas_2 = _sim.DiffRatioNoise(N_readout, BG, PL0, C, 
                                     type1=pair_model[1][0], type2=pair_model[1][1])
        
    # Now loop over each measurement
    for i in range(n_adapt):       
        # Print the update of the protocol each certain iteration
        if i%10 == 0:
            print('')
            print('Iteration %d / %d'%(i, n_adapt))
            
        if mode == 'Delta':
            # =============================================================================
            #             # Estimate the best measurement
            # =============================================================================                        
            t0 = time.time() # The following is considered CPU time        
            # Determine the best setting
            t_probed_1, t_probed_2 = self.get_best_setting(T_overhead=T_overhead, 
                                                           N_rep=N_readout, 
                                                           want_rel_sens=True)
            #Update CPU time
            time_cpu[i] += time.time() - t0  
            # =============================================================================
            #         # Measurement 1
            # =============================================================================
            type_measure = +1
            t_probed = t_probed_1
            print('t_probed*true_gp = ', t_probed*true_gp)
            # Fake the data, depending on the type of measurement       
            result, uncertainty = sim_meas_1.model(t_probed, true_gp, true_gm)
            
            t_probed_p_s    .append(t_probed)
            measurement_p_s .append(result)
            emeasurement_p_s.append(uncertainty)
            
            # feed the measurement
            t0 = time.time() # The following is considered CPU time
            # Feed the algorithm with the measurement
            self.give_measurement(result, uncertainty, 
                                   t_probed, type_measure)
            #Update CPU time
            t_cpu_v1 =  time.time() - t0         
            # =============================================================================
            #         # Measurement 2
            # =============================================================================
            type_measure = -1
            t_probed = t_probed_2 
            print('t_probed*true_gp = ', t_probed*true_gp)
            # Fake the data, depending on the type of measurement
            result, uncertainty = sim_meas_2.model(t_probed, true_gp, true_gm)
            
            t_probed_m_s    .append(t_probed)
            measurement_m_s .append(result)
            emeasurement_m_s.append(uncertainty)  
            
            # feed the measurement
            t0 = time.time() # The following is considered CPU time
            # Feed the algorithm with the measurement
            self.give_measurement(result, uncertainty, 
                                   t_probed, type_measure)
            #Update CPU time
            time_cpu[i] = t_cpu_v1 +  time.time() - t0   

            # Record the experimental time
            time_measurement[i] = N_readout*( t_probed_1 + t_probed_2 )  
            
            
        elif mode == 'NIST':
            
            print('NIST SHOULD NOT BE USED YET. THE CODE IS NT ADAPTED YET.')
            # =============================================================================
            #             # Estimate the best measurement
            # =============================================================================                        
            t0 = time.time() # The following is considered CPU time        
            # Determine the best setting
            t_probed, type_measure = self.get_best_setting_NIST()
            #Update CPU time
            time_cpu[i] += time.time() - t0       
            
            # =============================================================================
            #         # Measurement 
            # =============================================================================      
            if type_measure == +1:
                result, uncertainty = sim_meas_1.model(t_probed, true_gp, true_gm)
                t_probed_p_s    .append(t_probed)
                measurement_p_s .append(result)
                emeasurement_p_s.append(uncertainty)
            elif type_measure == -1:
                result, uncertainty = sim_meas_2.model(t_probed, true_gp, true_gm)
                t_probed_m_s    .append(t_probed)
                measurement_m_s .append(result)
                emeasurement_m_s.append(uncertainty)      
                
            print('t_probed*true_gp = ', t_probed*true_gp)
            
            # feed the measurement
            t0 = time.time() # The following is considered CPU time
            # Feed the algorithm with the measurement
            self.give_measurement(result, uncertainty, 
                                   t_probed, type_measure)
            #Update CPU time
            time_cpu[i] += time.time() - t0           

            # Record the experimental time
            time_measurement[i] = N_readout*( t_probed )         
                
            
        # =============================================================================
        #         # Record the infered parameters
        # =============================================================================
        means, stds, covs = self.get_parameters()
        best_gp[i]  = means[0]
        best_egp[i] = stds[0]
        best_gm[i]  = means[1]
        best_egm[i] = stds[1]


    # Transform the lists into numpy array
    t_probed_p_s = np.array(t_probed_p_s) 
    t_probed_m_s = np.array(t_probed_m_s)
    measurement_p_s    = np.array(measurement_p_s)
    emeasurement_p_s   = np.array(emeasurement_p_s)
    measurement_m_s    = np.array(measurement_m_s)
    emeasurement_m_s   = np.array(emeasurement_m_s)
    
    #Update the total time
    time_total = time_measurement + time_cpu
    time_cum   = np.cumsum(time_total)
    
    # Compute the sensitivity
    eta_p_s = best_egp*np.sqrt(time_cum)
    eta_m_s = best_egm*np.sqrt(time_cum)
        
    # =========================================================================
    ### Let's now plot nice results for gamma+
    # =========================================================================
    
    plt.figure(figsize=(17, 11), tight_layout=True)
    # (1) Plot the infered rates
    #
    # 2 rows, 2 columns, Select the first plot
    ax = plt.subplot(221)
    # measurement data
    plt.errorbar(iterations, best_gp*1e-3, yerr=best_egp*1e-3, color='C0',
                 marker='.', linestyle='', label='Gamma+')
    plt.errorbar(iterations, best_gm*1e-3, yerr=best_egm*1e-3, color='C1',
                 marker='.', linestyle='', label='Gamma-')
    plt.plot([iterations[0], iterations[-1]], [true_gp*1e-3, true_gp*1e-3],
             '--', label='True gamma+', color='C0')
    plt.plot([iterations[0], iterations[-1]], [true_gm*1e-3, true_gm*1e-3],
             '--', label='True gamma-', color='C1')
    plt.legend()
    plt.xlabel("No. of adaptation")
    plt.ylabel("Infered rates (kHz)")
    plt.text(0.02, .9, '(a)', transform=ax.transAxes)
    xlims = plt.xlim()
    
    # (2) plot the true curve and the "measured" data
    #
    # second plot (next to the first)
    ax = plt.subplot(222)
    # Compute the true curves
    t = list_t_probe
    yp = model_1(t, true_gp, true_gm)
    ym = model_2(t, true_gp, true_gm)
    plt.plot(t*1e6, yp, label='True model +', color='C0')
    plt.plot(t*1e6, ym, label='True model -', color='C1')
    # Show the measurements
    plt.errorbar(t_probed_p_s*1e6, measurement_p_s, yerr=emeasurement_p_s, 
                marker='.', linestyle='', label='Measurement +', color='C0')
    plt.errorbar(t_probed_m_s*1e6, measurement_m_s, yerr=emeasurement_m_s, 
                marker='.', linestyle='', label='Measurement -',color='C1')
    plt.legend()
    plt.xlabel("Time (us)")
    plt.ylabel("Mean counts")
    plt.text(0.02, .90, '(b)', transform=ax.transAxes)
    plt.xscale('log')
    # This is useful for having another plot with the same limits
    xlims = plt.xlim() 
    
    # (3) plot the evolution of the std in the infered parameters
    #
    # Third plot (below the first)
    ax = plt.subplot(223)
    plt.loglog(iterations + 1, best_egp*1e-3, '.', label='Gamma+')
    plt.loglog(iterations + 1, best_egm*1e-3, '.', label='Gamma-')
    plt.legend()
    plt.ylabel("Uncertainty in rate (kHz)")
    plt.xlabel("No. of adaptation")
    plt.text(0.02, .1, '(c)', transform=ax.transAxes)
    
    # (4) plot a histogram of the adapted parameter
    #
    # Third plot (below the first)
    ax = plt.subplot(224)
    plt.hist(t_probed_p_s*1e6, bins=10, label='Measurement +', alpha=0.5)
    plt.hist(t_probed_m_s*1e6, bins=10, label='Measurement -', alpha=0.5)
    plt.legend()
    plt.ylabel("Time density")
    plt.xlabel("Time (us)")
    plt.text(0.02, .90, '(d)', transform=ax.transAxes)
    plt.xlim(xlims) # Have the same limit in the x-axis such that it is easy to compare        
            
    # =========================================================================
    ### Verify what best time was choosen 
    # =========================================================================         
    plt.figure(figsize=(17, 11), tight_layout=True)
    
    # First plot show the histogram after choppinf the outlier
    ax = plt.subplot(211)
    # Chop the outliers
    Nstd = 2 # Number of standard deviation away from the mean of the distribution
    meanp = np.mean(t_probed_p_s)
    meanm = np.mean(t_probed_m_s)
    stdp = np.std(t_probed_p_s)
    stdm = np.std(t_probed_m_s)
    binp = np.linspace(0, 2/true_gp, 50)
    binm = np.linspace(0, 2/true_gm, 50)
    true_g0 = np.sqrt(true_gp**2 + true_gm**2)
    plt.hist(t_probed_p_s*true_g0, bins=binp*true_g0, label='Measurement +', 
             alpha=0.5)
    plt.hist(t_probed_m_s*true_g0, bins=binm*true_g0, label='Measurement -', 
             alpha=0.5)
    plt.legend()
    plt.ylabel("Density of occurence")
    plt.xlabel("T_probe * sqrt(sum square rates)")
    plt.text(0.02, .90, '(d)', transform=ax.transAxes)
    
    # Second plot shows the time probed in scale
    ax = plt.subplot(212)
    plt.plot(t_probed_p_s*1e6, '.-', label='Measure +')
    plt.plot(t_probed_m_s*1e6, '.-', label='Measure -')
    plt.legend()
    plt.xlabel('Iterations')
    plt.ylabel('Time probed (us)')            
            
    # =========================================================================
    ### Verify the time elapsed and the sensitivity
    # =========================================================================         
    plt.figure(figsize=(17, 11), tight_layout=True)        
    
    # First plot the histograms of the times
    ax = plt.subplot(211)        
#    plt.hist(time_total*1e6, label='Total',alpha=0.5)
    plt.hist(time_cpu*1e3, label='CPU', alpha=0.5)
    plt.legend()
    plt.xlabel('Time at each adapation (ms)')
    plt.ylabel('Occurence')
    
    # Second, plot the sensitivity
    ax = plt.subplot(212)   
    plt.plot(time_cum/60, eta_p_s*1e-3, label='Rate+')
    plt.plot(time_cum/60, eta_m_s*1e-3, label='Rate-')
    plt.legend()
    plt.xlabel('Accumulated time (min)')
    plt.ylabel('Sensitivity (kHz/sqrt(Hz))')
    
    # =========================================================================
    ### Plot the cloud of parameters
    # =========================================================================  
    
    if mode == 'NIST':
        parms = self.my_obe.parameters # This contains the arrays of each parameter
        plt.figure(figsize=(8, 5), tight_layout=True)  
        plt.scatter(parms[0]*1e-3, parms[1]*1e-3, color='k', alpha=0.1)
        # Show the true value 
        plt.plot(true_gp*1e-3, true_gm*1e-3, 'Xr', 
                markersize=20, label='True value')  
        # Show the best estimate from Bayes
        plt.errorbar(best_gp[-1]*1e-3, best_gm[-1]*1e-3, 
                     xerr=best_egp[-1]*1e-3, yerr=best_egm[-1]*1e-3,
                     label='Best Estimate')
        plt.legend()
        plt.xlabel('Rate+ (kHz)')
        plt.ylabel('Rate- (kHz)')    
        plt.title('Cloud of parameter')
        
    elif mode == 'Delta':    
        Z, mesh_gp, mesh_gm = self.my_bayes.get_post()
        plt.figure(tight_layout=True)
        plt.pcolor(mesh_gp*1e-3, mesh_gm*1e-3, Z, cmap=plt.cm.jet)
        plt.colorbar(label="Probability density")
        plt.errorbar(best_gp[-1]*1e-3, best_gm[-1]*1e-3,
                     xerr=best_egp[-1]*1e-3,yerr=best_egm[-1]*1e-3,
                     linestyle='', marker='.', color='k', label='Best $\Gamma$', 
                     markersize=20)
        plt.axis("equal")#Equate the axis for a better estimate of the relative error
        plt.xlabel('$\Gamma_+$ (kHz)')
        plt.ylabel('$\Gamma_-$ (kHz)')
        plt.title('Posterior of the rates')
        plt.legend()              
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        


