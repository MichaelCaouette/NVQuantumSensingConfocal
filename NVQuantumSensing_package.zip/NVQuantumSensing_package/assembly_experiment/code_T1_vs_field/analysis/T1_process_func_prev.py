# -*- coding: utf-8 -*-
"""
Created on Wed Apr 14 10:51:01 2021

Goal:
    Useful function for analysing the T1 measurements

@author: Childresslab
"""
from T1_finder import T1Finder
import numpy as np
import spinmob as sm

def uinverse(A0, eA0, method = 1):
    """
    Propagate the uncertainty in f(A) = 1/A. 
    The formula is more precise than typical error propagtion with 
    linearization. 
    
    Linearization (ie, propagating the uncertainty by assuming
    linear perturbation. Therfore using derivatives of the function) works when
    A is a "gaussian variable": its noise is well defined by a gaussian 
    distribution and not chopped. 
    
    Here, we extended this to the case where:
        - A is expected to be positive
        - The noise in A can be large compared to A. Such that A can be zero or 
          negative, despite the fact that it is expected to be positive (this 
          situation happens when the noise in A is large compared to A).
    
    In order to get the propagation of the error in such a situation, we used 
    Bayesian analysis and considered the mean and standard deviation of the 
    probability density function of f(A), when A is expected to be positive, 
    but can be measured negative or zero because of noise fluctuation. 
    
    For more info on the derivation of the formula, see the notebook of 
    Michael Caouette-Mansour on 2020-11-30,
    in the subsection "Careful error propagation of inverse". 
    
    Input parameters:
        A0:
            Measured mean value of A. Can be begative or zero. 
        eA0:
            Measured uncertainty in A. If zero, the function will return 1/A0
            
        method:
            1 or 2. Which way around and in which order the algebra is made. 
            This influences some numerical round-off .
            
    return:
        z0:
            Best estimate of 1/A.
        ez0:
            Best uncertainty in z0.
    """
    if method == 1:
        """
        This method avoids division by zero if A0 = 0, 
        """
        # A ratio used many time
        ratio = A0/(eA0*eA0)
        # A product used many time
        eA02 = eA0*eA0
        # Expectation for f(A). Formula comes from careful Bayes analysis.
        z0 = 0.25*( (ratio*ratio + 8/(eA02))**0.5 - ratio)
        # Second derivative of the logarithm of the pdf of f(A)
        z02 = z0*z0 # A quantity used many time
        dL2dz2 = 2*ratio/(z02*z0) + 2/z02 - 3/(eA02*z02*z02) 
        
        #Uncertainty in f(A). Formula comes from careful Bayes analysis.
        ez0 = 1/ (-dL2dz2)**0.5
        # Here we go.
        return z0, ez0
    
    elif method == 2:
        """
        This method is more compact and may be better the deal with numerical
        round-off error. However, if A0=0, there is a division by zero. 
        """
        # A ratio used many time
        ratio = A0/(eA0*eA0) 
        relative = eA0 / A0
        
        z0 = 0.25*ratio*( ( 1 + 8*relative*relative )**0.5 - 1 )
        
        # Second derivative of the logarithm of the pdf of f(A)
        z02 = z0*z0 # A quantity used many time
        # A product used many time
        eA02 = eA0*eA0        
        dL2dz2 = 2*ratio/(z02*z0) + 2/z02 - 3/(eA02*z02*z02) 
        
        #Uncertainty in f(A). Formula comes from careful Bayes analysis.
        ez0 = 1/ (-dL2dz2)**0.5
        # Here we go.
        return z0, ez0        

    elif method == 3:
        """
        This another way to wrtie down the equation. 
        This as no 1/A0 and therefore I hope it will not have issues with 
        division by zero. 
        """
        # A ratio used many time
        ratio = A0/(eA0*eA0) 
        relative = eA0 / A0
        
        z0 = 0.25*(1/eA0)*( ( (A0/eA0)**2 + 8 )**0.5 - A0/eA0)
        
        # Second derivative of the logarithm of the pdf of f(A)
        z02 = z0*z0 # A quantity used many time
        # A product used many time
        eA02 = eA0*eA0        
        dL2dz2 = 2*ratio/(z02*z0) + 2/z02 - 3/(eA02*z02*z02) 
        
        #Uncertainty in f(A). Formula comes from careful Bayes analysis.
        ez0 = 1/ (-dL2dz2)**0.5
        # Here we go.
        return z0, ez0              
        
    

def uDiffRatio(x1, ex1, x2, ex2,
               x3, ex3, x4, ex4):
    """
    Return the differentio-Ratio measurement of 4 quantity, with the propagated
    uncertainty. 
    
    We want to evaluate z = ( x1 - x2 ) / ( x3 - x4)
    
    We linearly propagate the error in the numnerator and the denominator. 
    But we are more careful for when taking the ratio. We use a non-linear 
    error propagation for the inverse. 
    
    
    """
    # Combine the results
    Top = x1 -x2
    Bot = x3 - x4
    # Linearly propagate the error in the numerator and dominator
    eTop = ( ex1*ex1 + ex2*ex2 )**0.5   # Uncertainty in the numerator
    eBot = ( ex3*ex3 + ex4*ex4 )**0.5 # Uncertainty in the bottom
    # Non-linearly propagate the error in the inverse of the bottom
    inv_bot, einv_bot = uinverse(Bot, eBot, method=2)
    # Finnaly, the resulting best estimate and uncertainty
    z = Top*inv_bot
    
    # I comment this, because is either Top or inv_bot is zero, it leads to 
    # division by zero.
#    ez = z * ( (eTop/Top)**2 + (einv_bot/inv_bot)**2 )**0.5
    ez = ( (Top*einv_bot)**2 + (inv_bot*eTop)**2 )**0.5
    
    return z, ez

        
# Defines the models function        
def model_00m0(m, t, gp, gm):
    """
    
    Model for the behavior of the experimental measurement. 
    It of the type 00m0; where m is either +1 or -1. 
    
    m:
        +1 or -1 
        (Depending on the tuype of the pulse sequence to use)   
    t:
        Time    
    gp, gm:
        Rates
        
    Choice of unit: 
        As long as the time multiplied by the rate is unitless.
        
    """    
    g0 = ( gp*gp + gm*gm - gp*gm )**0.5
    beta_p = gp + gm + g0
    beta_m = gp + gm - g0   
    
    # This trick outputs gp is m=+1 and gm if m=-1
    gamma = 0.5*(1+m)*gp + 0.5*(1-m)*gm 
    
    term1 = (g0 + gamma) *np.exp(-beta_p * t)
    term2 = (g0 - gamma)*np.exp(-beta_m * t)
    
    return (term1 + term2 ) / (2*g0)  

def model_m0mm(m, t, gp, gm):
    """
    
    Model for the behavior of the experimental measurement. 
    It of the type m0mm; where m is either +1 or -1. 
    
    m:
        +1 or -1 
        (Depending on the tuype of the pulse sequence to use)   
    t:
        Time    
    gp, gm:
        Rates
        
    Choice of unit: 
        As long as the time multiplied by the rate is unitless.
        
    """    
    g0 = ( gp*gp + gm*gm - gp*gm )**0.5
    beta_p = gp + gm + g0
    beta_m = gp + gm - g0   
    
    term1 = (g0 + m*(gp-gm))*np.exp(-beta_p * t)
    term2 = (g0 + m*(gm-gp))*np.exp(-beta_m * t)
    
    return (term1 + term2 ) / (2*g0)  

def get_drift_indep_measurement(data_file, want_tuple_PL=False):
    """
    Compute the drift independent measurement from the 4 data points. 
    
    data_file:
        (databox from spinmob) File of a single drift independent measurement
        
    want_tuple_PL:
        (bool) if True, will also return a tuple of the 4 PLs and the 
        uncertainties
    """

    ## String for the headers of the data taken before 2021-05-17
    #str_PL1_t0 = 'ms0_t0'
    #str_PL1_tp = 'ms0_tprobed'
    #str_PL2_t0 = 'ms-+1_t0'
    #str_PL2_tp = 'ms-+1_tprobed'
    ## String for the headers of the data taken 2021-05-17 and after
    str_PL1_t0 = 'PL1_t0'
    str_PL1_tp = 'PL1_tprobed'
    str_PL2_t0 = 'PL2_t0'
    str_PL2_tp = 'PL2_tprobed'

    # =========================================================================
    # Get the number of readout
    # =========================================================================
    rep = data_file.headers['repetition']
    iteration  = data_file.headers['iteration']
    N_readout = rep*iteration

    # =========================================================================
    # Get the mean count and uncertainty of each data
    # =========================================================================    
    # ms=0 at t=0
    counts = np.sum(data_file[str_PL1_t0])
    PL0_0  = counts/N_readout
    ePL0_0 = np.sqrt(PL0_0/N_readout)

    # ms=0 at t=t_probed
    counts = np.sum(data_file[str_PL1_tp])
    PL0_t   = counts/N_readout
    ePL0_t  = np.sqrt(PL0_t /N_readout)  
    
    # ms=+-1 at t=0
    counts = np.sum(data_file[str_PL2_t0])
    PL1_0  = counts/N_readout
    ePL1_0 = np.sqrt(PL1_0/N_readout) 
    
    # ms=+-1 at t=t_probed
    counts = np.sum(data_file[str_PL2_tp])
    PL1_t  = counts/N_readout
    ePL1_t = np.sqrt(PL1_t/N_readout) 

    # =========================================================================
    # Compute the drift_independant measurement
    # =========================================================================  
    tuple_PL = (PL0_t, ePL0_t, PL1_t, ePL1_t, PL0_0, ePL0_0, PL1_0, ePL1_0)
    result, uncertainty = uDiffRatio(*tuple_PL)   
    
    if want_tuple_PL:        
        return result, uncertainty, tuple_PL 
    else:
        return result, uncertainty

def extract_measurement(ds):
    """
    ds:
        List of T1 datafile
        
    We will convert into second !!
    
    """
    
    N_data_file = len(ds)
    # Store the drift independent measurement for each type of experiment
    result_plus_s  = []
    result_minus_s = []
    uncertainty_plus_s  = []
    uncertainty_minus_s = []
    t_probe_plus_s  = []
    t_probe_minus_s = []
    
    # Extract each the measurement from each data file
    for i in range(N_data_file):
        # Get the data file
        d = ds[i]
        # Extract the time probed 
        t_probe = d.headers['t_probe'] * 1e-6 # CONVERT INTO SECOND
        # Extract the drift_independent measurement from the file. 
        result, uncertainty = get_drift_indep_measurement(d)
        # Append the result depending on the type of measurement
        type_measurement = d.headers['Type_measure']    
        if type_measurement == +1:
            result_plus_s.append(result)
            uncertainty_plus_s.append(uncertainty)
            t_probe_plus_s.append(t_probe)
        elif type_measurement == -1:
            result_minus_s.append(result)
            uncertainty_minus_s.append(uncertainty)     
            t_probe_minus_s.append(t_probe)

    # Get into numpy array
    result_plus_s       = np.array(result_plus_s)
    uncertainty_plus_s  = np.array(uncertainty_plus_s)
    result_minus_s      = np.array(result_minus_s)
    uncertainty_minus_s = np.array(uncertainty_minus_s) 
    t_probe_plus_s = np.array(t_probe_plus_s)   
    t_probe_minus_s = np.array(t_probe_minus_s)
    
    # Make the output to matche the input of other processinf function
    return (t_probe_plus_s , result_plus_s , uncertainty_plus_s, 
            t_probe_minus_s, result_minus_s, uncertainty_minus_s)


def rates_from_bayes(tp, yp, eyp, tm, ym, eym, 
                     model_1, model_2, N_sample_parms=1e5):
    """
    Fit the model on the data with stochastic bayesian fitting. 
    Get the rates from this
    
    time in SECOND please
    """
    
    # Initiate the object
    # THESE PRIOR SHOULD BE THE SAME AS TAKEN IN THE PROTOCOL !!
    print('WARNING')
    print('In func_T1_data.rates_from_brayes' )
    print('The prior is preset. SHould take what was taken in the GUI. Or guess in the input')
    print()
    Gp_min = 0.01e3  # Hz
    Gp_max = 100e3 # Hz
    Gm_min = 0.01e3  # Hz
    Gm_max = 100e3 # Hz
    n_samples_params = int ( N_sample_parms ) # Number of sample to take for the parameter space
    gp_sample = np.random.uniform(Gp_min, Gp_max, n_samples_params )   
    gm_sample = np.random.uniform(Gm_min, Gm_max, n_samples_params ) 
    # Gatther the samples of each parameter in a tuple
    tuple_priors = (gp_sample, gm_sample)    
    my_bayes = T1Finder( [] , model_1, model_2, tuple_priors)
    # Feed the measurements plus
    for i in range(len(yp)):
        measurement = yp[i]
        uncertainty = eyp[i]
        time_probed = tp[i]
        my_bayes.give_measurement( measurement, uncertainty, 
                                       time_probed, type_measure=+1)
    # Feed the measurements minus
    for i in range(len(ym)):
        measurement = ym[i]
        uncertainty = eym[i]
        time_probed = tm[i]
        my_bayes.give_measurement( measurement, uncertainty, 
                                       time_probed, type_measure=-1)
    # Estimate the rate
    means, stds, covs = my_bayes.get_parameters()
    gp_bayes  = means[0] # Hz
    egp_bayes = stds[0]  # Hz
    gm_bayes  = means[1] # Hz
    egm_bayes = stds[1]  # Hz 
    
    return gp_bayes, egp_bayes, gm_bayes, egm_bayes, my_bayes


def rate_from_chi2(tp, yp, eyp, tm, ym, eym, model_1, model_2):
    """
    Fit the model on the data with chi2 fitting. 
    Get the rates from this
    
    Unit: 
        time in SECOND please
    """
    # Create the fitter object
    fitter = sm.data.fitter(autoplot = False)
    # Set the two function that we simultaneuously fit
    fitter.set_functions(['fp(x, gp, gm)', 'fm(x, gp, gm)'], 
                          p='gp,gm', fp=model_1, fm=model_2)
    # Set the data
    fitter.set_data([tp, tm], 
                    [yp, ym], [eyp, eym])
    #Set the guess
    guess_gp = 1e3 # (Hz)
    guess_gm = 1e3 # (Hz)
    fitter.set(gp=guess_gp, gm=guess_gm)
    # Fit !
    fitter.fit()
    # Extract the rates
    gp_fit  = fitter.results.params['gp'].value
    egp_fit = fitter.results.params['gp'].stderr
    gm_fit  = fitter.results.params['gm'].value
    egm_fit = fitter.results.params['gm'].stderr   
    
    # Get extrac info
    chi2 = fitter.get_reduced_chi_squared()
    dof  = fitter.get_degrees_of_freedom()
    
    return gp_fit, egp_fit, gm_fit, egm_fit, chi2, dof
    


















    
    
    
    