# -*- coding: utf-8 -*-
"""
Created on Tue Jun  8 07:41:29 2021

Goal:
    Load the various files from a simulations

@author: Childresslab
"""

import spinmob as sm
import os

# Name of the folder containing various stuff
foler_name_mag = 'mag_pos'
folder_name_minus = 'pipulse_minus'  # Folder Containing pipulse plus
folder_name_plus  = 'pipulse_plus'   # Folder Containing pipulse minus
folder_name_T1    = 'T1_sequence'    # Folder Containing T1 data 
file_mag_pos = 'magnet_position.dat' # File for the mgnaet position
key_file_ESR       = 'ESR'  # String key in the name of the ESR  data file
key_file_RabiPower = 'Rabi' # String key in the name of the Rabi datafile
key_file_T1 = 'T1' # String key in the name of the T1 datafile


def sub_sample(x, i_min, i_max):
    """
    Sub select the element of an array. 
    Return the reduced size array
    """
    if i_min > 0:
        true_imin = i_min
    else:
        true_imin = 0   
        
    if i_max >= 1:
        x_true = x[true_imin : (i_max+1)]
    else:
        x_true = x[true_imin :]    
    
    return x_true


def get_list_folder_mag():
    """
    Get the list of the folder of each magnet position
    """
    
    # We will load the data in the folder for which the name contains the key 
    # str_key. The user will select the directory that contains these folders. 
    str_key = foler_name_mag
    txt = 'Select a directory containing the folder with key word %s in the name.'%str_key
    directory_main = sm.dialogs.select_directory(text=txt)
    # List all the files that has the key word. 
    list_folder_mag = []
    for file in os.listdir(directory_main ):
        if str_key in file:
            path = directory_main  + '/' + file
            list_folder_mag.append(path)
    print('len(list_folder_mag) = ', len(list_folder_mag))
    
    return directory_main, list_folder_mag
            

def get_list_data_file(i_min=0, i_max=-1):
    """
    
    i_min, i_max:
        Minimum and maximum index of folder to study
    
    Return the list of various data file for each magnet position. 
    """
    
    directory_main, list_folder_mag = get_list_folder_mag()
    # Keep only the relevant folder
    list_folder_mag_true = sub_sample(list_folder_mag,
                                      i_min, 
                                      i_max)
    print('len(list_folder_mag_true) = ', len(list_folder_mag_true)) 
    
    # Prepare the lists
    list_d_magpos = []
    list_d_ESR_p    = []
    list_d_Rabi_p   = []
    list_d_ESR_m    = []
    list_d_Rabi_m   = []
    
    # Ready to loop
    for i, folder_mag in enumerate( list_folder_mag_true ):
        
        # =============================================================================
        # Get the magnet position
        # =============================================================================   
        file_dir = folder_mag + '/' + file_mag_pos
        databox = sm.data.load(file_dir)        
        list_d_magpos.append(databox)        
    
        # =============================================================================
        #     # Get the pi-pulse plus data file
        # =============================================================================
        # List all the files
        list_path = []
        directory = folder_mag + '/' + folder_name_plus
        for file in os.listdir(directory):
            # Note the data file. Useful for debugging
            if file.endswith(".dat"):
                path_file = os.path.join(directory, file)
                list_path.append(path_file)
            # Keep the ESR file
            if key_file_ESR in file:
                path_file = os.path.join(directory, file)
                databox_ESR = sm.data.load(path_file)
            # Keep the Rabi file
            if key_file_RabiPower in file:
                path_file = os.path.join(directory, file)
                databox_RP = sm.data.load(path_file) 
            
        list_d_ESR_p .append(databox_ESR)
        list_d_Rabi_p.append(databox_RP)

        # =============================================================================
        #     # Get the pi-pulse minus data file
        # =============================================================================
        # List all the files
        list_path = []
        directory = folder_mag + '/' + folder_name_minus
        for file in os.listdir(directory):
            # Note the data file. Useful for debugging
            if file.endswith(".dat"):
                path_file = os.path.join(directory, file)
                list_path.append(path_file)
            # Keep the ESR file
            if key_file_ESR in file:
                path_file = os.path.join(directory, file)
                databox_ESR = sm.data.load(path_file)
            # Keep the Rabi file
            if key_file_RabiPower in file:
                path_file = os.path.join(directory, file)
                databox_RP = sm.data.load(path_file)    
                
        list_d_ESR_m .append(databox_ESR)
        list_d_Rabi_m.append(databox_RP)            
        
    # Be careful with the indentation
    return list_folder_mag_true, directory_main, (list_d_magpos, 
                                                  list_d_ESR_p, list_d_Rabi_p, 
                                                  list_d_ESR_m, list_d_Rabi_m)
                

def get_list_data_in_one_folder(directory, str_key):
    """
    Get the list of data file containt the key string str_key
    
    """
    
    list_d = []
    for file in os.listdir(directory):
        if str_key in file:
            path_file = os.path.join(directory, file)  
            list_d.append( sm.data.load(path_file) )
            
    return list_d
            
            
            
            
            
            
            
            
            
