# -*- coding: utf-8 -*-
"""
Created on Sat Feb 20 10:47:14 2021

@author: Childresslab
"""

import spinmob as sm
import numpy as np
import matplotlib.pyplot as plt 

import os
import tkinter as tk
import tkinter.filedialog as fd

# Get the list of the directory of each magnet positon
str_key_mag = 'mag_pos' # comment string in the name of the magnet position

# Get the path of the folders of each magnet position 
path_folder_mags = fd.askdirectory(title='Select the folder containing the %s files'%str_key_mag)
list_folder_mag = []

for file in os.listdir(path_folder_mags):
    # List the folders that contains the key for the magnet position 
    if str_key_mag in file:
        path_file = os.path.join(path_folder_mags, file)
        list_folder_mag.append(path_file)
    

# Name of the folder containing pipulse minus and plus data
folder_name_minus = 'pipulse_minus'
folder_name_plus  = 'pipulse_plus'
key_file_ESR = 'ESR' # Key in the name of the file for the ESR data
key_file_RabiPower = 'Rabi_Power' # Key in the name of the file for the Rabi Power data
file_mag_pos = 'magnet_position.dat'
# Set the name of the coolumns. In case this get changed 
str_setfreq = 'Frequency_(GHz)'
str_setpow  = 'Power_(dBm)'
str_c0   = 'Total_counts_0'
str_c1   = 'Total_counts_1'
str_rep  = 'repetition'
str_iter = 'iteration'
str_Nr_seq   = 'Nb_readout_per_sequence'
str_dtpulse = '/sig_gen_pulsed_ESR/dt_rf_pulse'
str_f0 = 'mean_f0'
str_ef0 = 'std_f0'
str_P0 = 'mean_P0'
str_eP0 = 'std_P0'
str_start_time = 'starting_time_sec'
str_time_ela = 'absolute_time_sec'


# For each magnet position, extract the pi-pulse
list_mag_x = []
list_mag_y = []
list_mag_z = []
list_minus_f0  = []
list_minus_ef0 = []
list_minus_P0  = []
list_minus_eP0 = []
list_plus_f0  = []
list_plus_ef0 = []
list_plus_P0  = []
list_plus_eP0 = []
# The following is for plotting the signal
# Minus
list_z_ESR_minus = []
list_z_RP_minus  = []
list_f_ESR_minus = []
list_p_RP_minus  = []
list_signal_ESR_minus = []
list_signal_RP_minus  = []
# Plus
list_z_ESR_plus= []
list_z_RP_plus  = []
list_f_ESR_plus = []
list_p_RP_plus  = []
list_signal_ESR_plus = []
list_signal_RP_plus  = []


for folder_mag in list_folder_mag:
    # =============================================================================
    # Get the magnet position
    # =============================================================================    
    file_dir = folder_mag + '/' + file_mag_pos
    databox = sm.data.load(file_dir)
    list_mag_x.append( databox.headers['x_magnet'] )
    list_mag_y.append( databox.headers['y_magnet'] )
    list_mag_z.append( databox.headers['z_magnet'] )
    
    # =============================================================================
    #     # Get the pi-pulse minus data
    # =============================================================================
    # Take the ESR and RabiPower file
    directory = folder_mag + '/' + folder_name_minus
    for file in os.listdir(directory):
        if key_file_ESR in file:
            path_file = os.path.join(directory, file)
            databox_ESR = sm.data.load(path_file)
        if key_file_RabiPower in file:
            path_file = os.path.join(directory, file)
            databox_RP = sm.data.load(path_file)        
    
    # Extract what we want
    # Note the pi-pulse
    list_minus_f0.append ( databox_ESR.headers[str_f0]  )
    list_minus_ef0.append( databox_ESR.headers[str_ef0] )
    list_minus_P0.append ( databox_RP.headers[str_P0]  )
    list_minus_eP0.append( databox_RP.headers[str_eP0] )
    # Note the signal for the ESR
    signal_ESR =  databox_ESR[str_c0] - databox_ESR[str_c1]
    list_signal_ESR_minus = np.concatenate(( list_signal_ESR_minus, signal_ESR) )
    list_z_ESR_minus = np.concatenate( ( list_z_ESR_minus, list_mag_z[-1] + np.zeros(len(signal_ESR)) ) ) 
    list_f_ESR_minus = np.concatenate((list_f_ESR_minus, databox_ESR[str_setfreq]))
    # Note the signal for the Rabi Power
    signal_RP =  databox_RP[str_c1] - databox_RP[str_c0]
    list_signal_RP_minus = np.concatenate(( list_signal_RP_minus, signal_RP) )
    list_z_RP_minus = np.concatenate( ( list_z_RP_minus, list_mag_z[-1] + np.zeros(len(signal_RP)) ) )  
    list_p_RP_minus = np.concatenate((list_p_RP_minus, databox_RP[str_setpow]))
    
    # =============================================================================
    #     # Get the pi-pulse plus data
    # =============================================================================
    # Take the ESR and RabiPower file
    directory = folder_mag + '/' + folder_name_plus
    for file in os.listdir(directory):
        if key_file_ESR in file:
            path_file = os.path.join(directory, file)
            databox_ESR = sm.data.load(path_file)
        if key_file_RabiPower in file:
            path_file = os.path.join(directory, file)
            databox_RP = sm.data.load(path_file)        
    
    # Extract what we want
    list_plus_f0.append ( databox_ESR.headers[str_f0]  )
    list_plus_ef0.append( databox_ESR.headers[str_ef0] )
    list_plus_P0.append ( databox_RP.headers[str_P0]  )
    list_plus_eP0.append( databox_RP.headers[str_eP0] )  
    # Note the signal for the ESR
    signal_ESR =  databox_ESR[str_c0] - databox_ESR[str_c1]
    list_signal_ESR_plus = np.concatenate(( list_signal_ESR_plus, signal_ESR) )
    list_z_ESR_plus = np.concatenate( ( list_z_ESR_plus, list_mag_z[-1] + np.zeros(len(signal_ESR)) ) ) 
    list_f_ESR_plus = np.concatenate((list_f_ESR_plus, databox_ESR[str_setfreq]))
    # Note the signal for the Rabi Power
    signal_RP =  databox_RP[str_c1] - databox_RP[str_c0]
    list_signal_RP_plus = np.concatenate(( list_signal_RP_plus, signal_RP) )
    list_z_RP_plus = np.concatenate( ( list_z_RP_plus, list_mag_z[-1] + np.zeros(len(signal_RP)) ) )  
    list_p_RP_plus = np.concatenate((list_p_RP_plus, databox_RP[str_setpow]))
    
# =============================================================================
### Awesome plotting
# =============================================================================
plt.figure(tight_layout=True)
# Frequency
ax = plt.subplot(211)
plt.errorbar(list_mag_z, list_minus_f0, yerr=list_minus_ef0, 
             fmt='.', label='Minus')
plt.errorbar(list_mag_z, list_plus_f0, yerr=list_plus_ef0, 
             fmt='.', label='Plus')
plt.legend(title='Pi pulse type', 
           bbox_to_anchor=(1.00, 1),loc='upper left')
plt.xlabel('Magnet z (mm)')
plt.ylabel('Frequency (GHz)')
dt_pulse = float(databox_RP.headers[str_dtpulse])*1e3
title = databox_RP.path + '\n Duration of pi-pulse: %d ns'%dt_pulse
plt.title(title, fontsize=10)
# Power
ax = plt.subplot(212)
plt.errorbar(list_mag_z, list_minus_P0, yerr=list_minus_eP0, fmt='.')
plt.errorbar(list_mag_z, list_plus_P0, yerr=list_plus_eP0, fmt='.')
plt.xlabel('Magnet z (mm)')
plt.ylabel('Power (dBm)')

# =============================================================================
# Try an awesome plotting by showing the signal and the found pi-pulse
# =============================================================================

plt.figure(tight_layout=False)
color_bg = 'black'
cmap_plot = 'twilight_shifted'
color_point = 'lime'
marker_size = 20 

# Frequency PLUS
ax = plt.subplot(221)
ax.set_facecolor(color_bg)
plt.tripcolor( list_z_ESR_plus, list_f_ESR_plus, list_signal_ESR_plus,
              cmap=cmap_plot)
plt.errorbar(list_mag_z, list_plus_f0, yerr=list_plus_ef0, 
             fmt='.', color=color_point, markersize=marker_size)
plt.xlabel('Magnet z (mm)')
plt.ylabel('Plus\nFrequency (GHz)')
title = databox_ESR.path
if len(title)>20:
    t1 = title[:int(len(title)/2)]
    t2 = title[int(len(title)/2):]
    title = t1+'\n'+t2   
plt.title(title, fontsize=10)

# Frequency MINUS
ax = plt.subplot(223)
ax.set_facecolor(color_bg)
plt.tripcolor( list_z_ESR_minus, list_f_ESR_minus, list_signal_ESR_minus, 
              cmap=cmap_plot)
plt.errorbar(list_mag_z, list_minus_f0, yerr=list_minus_ef0, 
             fmt='.', color=color_point, markersize=marker_size)
plt.ylabel('Minus\nFrequency (GHz)')

# Power MINUS
ax = plt.subplot(224)
ax.set_facecolor(color_bg)
plt.tripcolor( list_z_RP_minus, list_p_RP_minus, list_signal_RP_minus, 
              cmap=cmap_plot)
plt.errorbar(list_mag_z, list_minus_P0, yerr=list_minus_eP0, 
             fmt='.', color=color_point, markersize=marker_size)
plt.ylabel('Minus\nPower (dBm)')

# Power PLUS
ax = plt.subplot(222)
plt.tripcolor( list_z_RP_plus, list_p_RP_plus, list_signal_RP_plus, 
              cmap=cmap_plot)

ax.set_facecolor(color_bg)
plt.errorbar(list_mag_z, list_plus_P0, yerr=list_plus_eP0, 
             fmt='.', color=color_point, markersize=marker_size)
plt.xlabel('Magnet z (mm)')
plt.ylabel('Plus\nPower (dBm)')
dt_pulse = float(databox_RP.headers[str_dtpulse])*1e3
title1 = databox_RP.path
if len(title)>20:
    t1 = title1[:int(len(title)/2)]
    t2 = title1[int(len(title)/2):]
    title1 = t1+'\n'+t2  
title = title1 + '\n Duration of pi-pulse: %d ns'%dt_pulse
plt.title(title, fontsize=10)









