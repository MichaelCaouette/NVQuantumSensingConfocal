# -*- coding: utf-8 -*-
"""
Created on Wed Jul  8 07:57:17 2020

Example of how to load the saturation curve

@author: Childresslab
"""

import T1_process_func as _T1
import func_load_data as _load

import numpy as np
import matplotlib.pyplot as plt


# Define the fitting function
def model_1(t, gp, gm):
    return _T1.model_00m0(+1, t, gp, gm)
def model_2(t, gp, gm):
    return _T1.model_00m0(-1, t, gp, gm)

# Specifics for loading the files
folder_name_T1    = 'T1'    # Folder Containing T1 data 
key_file_T1 = 'T1' # String key in the name of the T1 datafile
i_min = 0 # Minimum folder to check
i_max = 1 # Maximum folder to check



# Get the list of the directory of each magnet positon
directory_main, list_folder_mag_all = _load.get_list_folder_mag()
list_folder_mag = _load.sub_sample(list_folder_mag_all, i_min, i_max)
# Number of magnet position    
#N_field = len(list_folder_mag)
N_data_set = len(list_folder_mag)    
    





# =============================================================================
# Prepare the plot
# =============================================================================
plt.figure(figsize=(15, 8), tight_layout=True)  
# The first is the cloud of points. 
ax = plt.subplot(211)
# Process each set of data
list_gp = []
list_gm = []
list_egp = []
list_egm = []
for i, folder_mag in enumerate( list_folder_mag ):
        
    # =============================================================================
    # Get the data
    # =============================================================================
    # Get the list of datafile
    
    directory = folder_mag + '/' + folder_name_T1
    list_d = _load.get_list_data_in_one_folder(directory, key_file_T1)
    
              
    print('Taking care of data set %d'%i)
    
    # =============================================================================
    # Extract the drift-independant measurement
    # =============================================================================
    out_etract = _T1.extract_measurement(list_d)
    out = _T1.rates_from_bayes(*out_etract, model_1, model_2)
    gp_bayes, egp_bayes, gm_bayes, egm_bayes, my_bayes = out
    # List them
    list_gp .append( gp_bayes )
    list_gm .append( gm_bayes )
    list_egp.append( egp_bayes)
    list_egm.append( egm_bayes)

    # =============================================================================
    # Plot the Bayes inference 
    # =============================================================================
    parms = my_bayes.my_obe.parameters # This contains the arrays of each parameter
#        txt_label = list_d[-1].path.split('/')[-3] # Have a meaningfull label
    txt_label = list_d[-1].path.split('/')[-2].split('\\')[-1]
    plt.scatter(parms[0]*1e-3, parms[1]*1e-3, color='C%d'%i, 
                alpha=0.1)
    # Plot a single point with alpha=1 for having the label clearer
    plt.scatter(parms[0][0]*1e-3, parms[1][0]*1e-3, color='C%d'%i, 
                alpha=1, label=txt_label)    
    
    # # Shown the inference
    plt.errorbar(gp_bayes*1e-3, gm_bayes*1e-3, 
                 xerr=egp_bayes*1e-3,yerr=egm_bayes*1e-3, color='k')
    
# Enhance the plot
plt.legend()
plt.xlabel('Rate+ (kHz)')
plt.ylabel('Rate- (kHz)')    
plt.title(list_d[-1].path, fontsize=8)

print('Done')



list_gp  = np.array(list_gp)
list_gm  = np.array(list_gm)
list_egp = np.array(list_egp)
list_egm = np.array(list_egm)
    
# The second is the value of the rates for each magnetpositon
ax = plt.subplot(212)
x_axis = np.arange(0, N_data_set)
plt.errorbar(x_axis, list_gp*1e-3, yerr=list_egp*1e-3, fmt='.-', label='$\Gamma_+$')
plt.errorbar(x_axis, list_gm*1e-3, yerr=list_egm*1e-3, fmt='.-', label='$\Gamma_-$')
plt.legend()
plt.ylabel('Rates (kHz)') 










