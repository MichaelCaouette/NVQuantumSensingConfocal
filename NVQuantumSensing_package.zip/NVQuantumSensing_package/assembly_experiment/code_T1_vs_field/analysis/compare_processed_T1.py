# -*- coding: utf-8 -*-
"""
Created on Wed Apr 14 12:59:19 2021

Goal:
    Compare the data from various runs of T1

@author: Childresslab
"""

import spinmob as sm
import numpy as np
import matplotlib.pyplot as plt 


ds = sm.data.load_multiple(text='Select many processed T1 runs')

# =============================================================================
# # Plot the infered rates Versus the field
# =============================================================================
plt.figure(tight_layout=True, figsize=(15,8))

ax_p = plt.subplot(211)
ax_m = plt.subplot(212)

for i, d in enumerate(ds):
    # Extract what we want
    list_Bz  = d['Bz_(T)'] * 1e3
    list_eBz = d['eBz_(T)']* 1e3
    list_gp  = d['gp_Hz']  * 1e-3
    list_egp = d['egp_Hz'] * 1e-3
    list_gm  = d['gm_Hz']  * 1e-3
    list_egm = d['egm_Hz'] * 1e-3
    directory = d.headers['directory']  
    
    ax_p.errorbar(list_Bz, list_gp, xerr=list_eBz, yerr=list_egp, 
                 fmt='.-', label=directory.split('/')[-3])
    ax_m.errorbar(list_Bz, list_gm, xerr=list_eBz, yerr=list_egm, 
                 fmt='.-')
ax_p.legend(bbox_to_anchor=(1.00, 1),loc='upper left')  
plt.xlabel('Bz (mT)')
ax_p.set_ylabel('Rate + (kHz)')
ax_m.set_ylabel('Rate - (kHz)')

title = ''
for d in ds:
    title += '\n'+ d.headers['directory']  
plt.title(title, fontsize=9)



