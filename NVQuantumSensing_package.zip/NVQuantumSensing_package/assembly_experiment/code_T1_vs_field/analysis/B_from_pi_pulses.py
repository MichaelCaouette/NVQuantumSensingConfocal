# -*- coding: utf-8 -*-
"""
Created on Mon Mar 15 07:37:02 2021

Goal:
    Load many pi-pulse data and interpret the field

@author: Childresslab
"""

# Load the function for computing the field. 
from B_from_frequencies import uBperp, uBz
import func_load_data as _load

import numpy as np
import matplotlib.pyplot as plt 




# =============================================================================
# Load the relevant list of data files for each magnet position
# =============================================================================
out = _load.get_list_data_file(i_min=0, i_max=2)  
_, directory_main, (list_d_magpos, 
                    list_d_ESR_p, list_d_Rabi_p, 
                    list_d_ESR_m, list_d_Rabi_m) = out

N_mag = len(list_d_magpos)
       
# =============================================================================
# Now, for each datafile, extract the info
# =============================================================================
        
# Set the name of the coolumns. In case this get changed 
str_setfreq = 'Frequency_(GHz)'
str_setpow  = 'Power_(dBm)'
str_c0   = 'Total_counts_0'
str_c1   = 'Total_counts_1'
str_rep  = 'repetition'
str_iter = 'iteration'
str_Nr_seq   = 'Nb_readout_per_sequence'
str_dtpulse = '/sig_gen_pulsed_ESR/dt_rf_pulse'
str_f0 = 'mean_f0'
str_ef0 = 'std_f0'
str_P0 = 'mean_P0'
str_eP0 = 'std_P0'
str_start_time = 'starting_time_sec'
str_time_ela = 'absolute_time_sec'

# For each magnet position, extract the pi-pulse
list_mag_x = []
list_mag_y = []
list_mag_z = []
list_minus_f0  = []
list_minus_ef0 = []
list_minus_P0  = []
list_minus_eP0 = []
list_plus_f0  = []
list_plus_ef0 = []
list_plus_P0  = []
list_plus_eP0 = []
list_Bz     = np.zeros( N_mag )
list_eBz    = np.zeros( N_mag )
list_Bperp  = np.zeros( N_mag )
list_eBperp = np.zeros( N_mag )

# Ready to loop
for i in range( N_mag ):
    # =============================================================================
    # Get the magnet position
    # =============================================================================    
    databox = list_d_magpos[i]
    list_mag_x.append( databox.headers['x_magnet'] )
    list_mag_y.append( databox.headers['y_magnet'] )
    list_mag_z.append( databox.headers['z_magnet'] )

    # =============================================================================
    #     # Get the pi-pulse plus data
    # =============================================================================
    databox_ESR = list_d_ESR_p[i]
    databox_RP  = list_d_Rabi_p[i]
    # Extract what we want
    list_plus_f0.append ( databox_ESR.headers[str_f0]  )
    list_plus_ef0.append( databox_ESR.headers[str_ef0] )
    list_plus_P0.append ( databox_RP.headers[str_P0]  )
    list_plus_eP0.append( databox_RP.headers[str_eP0] )   

    # =============================================================================
    #     # Get the pi-pulse minus data
    # =============================================================================
    databox_ESR = list_d_ESR_m[i]
    databox_RP  = list_d_Rabi_m[i]
    # Extract what we want
    list_minus_f0.append ( databox_ESR.headers[str_f0]  )
    list_minus_ef0.append( databox_ESR.headers[str_ef0] )
    list_minus_P0.append ( databox_RP.headers[str_P0]  )
    list_minus_eP0.append( databox_RP.headers[str_eP0] )
    
    # =============================================================================
    # Compute the magnetic field
    # =============================================================================
    fp  = list_plus_f0  [-1]
    efp = list_plus_ef0 [-1]
    fm  = list_minus_f0 [-1]
    efm = list_minus_ef0[-1]    
    Bz, eBz = uBz(fp, efp, fm, efm)
    Bperp, eBperp = uBperp(fp, efp, fm, efm)
    list_Bz[i]     = Bz
    list_eBz[i]    = eBz
    list_Bperp[i]  = Bperp
    list_eBperp[i] = eBperp
    
    
# =============================================================================
# Plot all that
# =============================================================================

plt.figure(tight_layout=True)
# Frequency
ax = plt.subplot(211)

want_compare = False
if want_compare:
    # Compare with some other data that we have
    prev_z = [1.3, 2.1, 3.02]
    prev_fp = [4.109, 3.8595, 3.57889]
    prev_fm = [1.6315, 1.8849, 2.1605]
    plt.plot(prev_z, prev_fm, 'or-',label='From ESRs')
    plt.plot(prev_z, prev_fp,'or-' )

plt.errorbar(list_mag_z, list_minus_f0, yerr=list_minus_ef0, 
             fmt='.', label='Minus')
plt.errorbar(list_mag_z, list_plus_f0, yerr=list_plus_ef0, 
             fmt='.', label='Plus')

plt.legend(title='Pi pulse type', 
           bbox_to_anchor=(1.00, 1),loc='upper left')
plt.xlabel('Magnet z (mm)')
plt.ylabel('Frequency (GHz)')
plt.title(databox.path, fontsize=10)
# Power
ax = plt.subplot(212)
plt.errorbar(list_mag_z, list_minus_P0, yerr=list_minus_eP0, fmt='.')
plt.errorbar(list_mag_z, list_plus_P0, yerr=list_plus_eP0, fmt='.')
plt.xlabel('Magnet z (mm)')
plt.ylabel('Power (dBm)')

    
    
# =============================================================================
### Awesome plotting
# =============================================================================
fig, axs = plt.subplots(nrows=4, ncols=1, 
                        sharex=True,tight_layout=True)
# Split the title in 2
ss = directory_main
str_t = ss[:len(ss)//2] + '\n' + ss[len(ss)//2:]
axs[0].set_title(str_t, fontsize=10)
# Power
axs[0].errorbar(list_mag_z, list_minus_P0, yerr=list_minus_eP0, 
                 fmt='.', label='Minus')

axs[0].errorbar(list_mag_z, list_plus_P0, yerr=list_plus_eP0, 
                 fmt='.', label='Plus')
axs[0].legend(title='Pi pulse type', 
            bbox_to_anchor=(1.00, 1),loc='upper left')
axs[0].set_ylabel('Power\n(dBm)')

# Frequency
axs[1].errorbar(list_mag_z, list_minus_f0, yerr=list_minus_ef0, 
             fmt='.', label='Minus')
axs[1].errorbar(list_mag_z, list_plus_f0, yerr=list_plus_ef0, 
             fmt='.', label='Plus')
axs[1].set_ylabel('Frequency\n(GHz)')

# Magnetic field parallele
axs[2].errorbar(list_mag_z, list_Bz*1e3, yerr=list_eBz*1e3, fmt='.')
axs[2].set_ylabel('Parallel\nB field (mT)')
# Field perpendicular
axs[3].errorbar(list_mag_z, list_Bperp*1e3, yerr=list_eBperp*1e3, fmt='.')
axs[3].set_ylabel('Perpendicular\nB field (mT)')
# Domain
axs[-1].set_xlabel('Magnet z (mm)')










