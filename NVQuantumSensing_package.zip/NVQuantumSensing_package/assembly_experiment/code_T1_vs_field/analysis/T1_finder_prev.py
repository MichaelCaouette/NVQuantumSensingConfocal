# -*- coding: utf-8 -*-
"""
Created on Fri Oct  9 12:35:01 2020

Goal: Developper the adaptive Bayes finder

@author: Childresslab
"""


import numpy as np
from optbayesexpt import OptBayesExpt

import traceback
_p = traceback.print_last #Very usefull command to use for getting the last-not-printed error

# Debuger 
_debug_enabled     = False
def _debug(*a):
    if _debug_enabled: 
        s = []
        for x in a: s.append(str(x))
        print(', '.join(s))
        
def analytic_uncertainties(f1, f2, ef1, ef2, x0, y0, 
                         dx=0.001, dy=0.001,
                         want_variance=False):
    """
    Return an estimate of the uncertainties in the domain of a bi-dimensional
    pdf. 
    
    f1, f2:
        Two model function describing the measurement. 
        Their signature must best (x,y). ie f1 = f1(x,y) and f2 = f2(x,y)
    
    ef1, ef2:
        Absolute uncertainty in the measurement. 
    
    x0, y0:
        True or best estimate of x and y. 
        
    dx, dy:
        Infinitesimal step in x and y for taking the derivatives. 
        
    want_variance:
        (bool) If True, the function return the variances and the covariance of 
        x & y.  If False, the function return the uncertainty and the 
        correlation in x & y 
        (correlation = covariance / product of uncertainties)
    """
    
    # Compute the first derivatives, evaluated at x0, y0
    # I choose a two-point formula that should converge to h**2, according to 
    # Wikipedia: https://en.wikipedia.org/wiki/Numerical_differentiation
    df1dx = ( f1(x0 + dx, y0) - f1(x0 - dx, y0) ) / ( 2 * dx )
    df1dy = ( f1(x0, y0 + dy) - f1(x0, y0 - dy) ) / ( 2 * dy )
    df2dx = ( f2(x0 + dx, y0) - f2(x0 - dx, y0) ) / ( 2 * dx )
    df2dy = ( f2(x0, y0 + dy) - f2(x0, y0 - dy) ) / ( 2 * dy )
    
    # Compure the coefficients
    # Start with various gradients
    a1 = df1dx / ef1
    a2 = df2dx / ef2
    b1 = df1dy / ef1
    b2 = df2dy / ef2
    # Combine these gradients
    A = a1*a1 + a2*a2
    B = b1*b1 + b2*b2
    C = a1*b1 + a2*b2
    D = A*B - C*C
    
    # Compute the variances and covariances
    ex2 =  B / D # Variance in x
    ey2 =  A / D # Variance in y
    exy = -C / D # Covariance of x & y
    
    if want_variance:
        return ex2, ey2, exy 
    else:
        ex   = ex2**0.5
        ey   = ey2**0.5
        corr = exy / (ex * ey)
        
#        print('ex = ', ex)
        return ex, ey, corr
    

def EstimateBestSetting(list_t, best_gp, best_gm, best_egp, best_egm,
                        model_1, model_2):
    """
    Estimate the setting that should minimize the sensitivity on the rates.
    It uses an analytic estimation of the uncertainty in the rate from the 
    measurement.
    
    Input:
        list_t: EXPLAIN
    """
    _debug('EstimateBestSetting')
      
    # Chop the time axis. This is in order to keep the analytic model well
    # behaved
    
    # Version 1
#    gg = ( best_gp**2 + best_gm**2 ) **0.5
#    iii = ( 0.02/gg < list_t ) * (list_t < 10/gg) 
#    list_new = list_t[iii]
#    mesh_t1, mesh_t2 = np.meshgrid(list_new, list_new)
    
    # Version 2
#    tmin = min(0.1/(best_gp+best_egp), 0.1/(best_gm+best_egm) )
#    tmax = max(  10/(best_gp-best_egp),   10/(best_gm-best_egm))
#    iii = ( tmin < list_t ) * (list_t < tmax) 
#    list_new = list_t[iii]
#    mesh_t1, mesh_t2 = np.meshgrid(list_new, list_new)
    
    # Version 3, with different array of time to probe for each type.
    # We assume that model_1 is more sensitive on gp and model_2 more 
    # sensititive on gm. 
    iii_1 = ( 0.1/best_gp < list_t ) * (list_t < 10/best_gp )
    iii_2 = ( 0.1/best_gm < list_t ) * (list_t < 10/best_gm )
    list_t1 = list_t[iii_1]
    list_t2 = list_t[iii_2]
    mesh_t1, mesh_t2 = np.meshgrid(list_t1, list_t2)
    
#    # Version Not choppping
#    mesh_t1, mesh_t2 = np.meshgrid(list_t, list_t)
        
    def f1(gp, gm):
        return model_1(mesh_t1, gp, gm)
    def f2(gp, gm):
        return model_2(mesh_t2, gp, gm)  

    # Set the uncertainty in the measurement to be constant and the same for 
    # both type of measurement. This is reasonable because we are using this 
    # algorithm to find an extrema, which do not depend on the uncertainty if
    # both are the same. It is also reasonable to asusm that the uncertainty 
    # do not vary much over the time. This was argued my notebook (Michael) of 
    # 2021-04-14
    ef1 = 10
    ef2 = 10
    out = analytic_uncertainties(f1, f2, ef1, ef2, best_gp, best_gm)  
    mesh_ex, mesh_ey, mesh_corr = out
    
    # For debugging
    
    # Compute the cost (sensitivity) for each time to probe
    # We want to minimize the sqrt of this. But this is equivalent to minimize
    # the square.
    cost = np.sqrt( (mesh_ex*mesh_ex + mesh_ey*mesh_ey) * (mesh_t1 + mesh_t2) )
    
    # Find the time that minimize this
    ind = np.unravel_index(cost.argmin(), cost.shape)
    i = ind[0]
    j = ind[1]
    # numpy.mean() is for if there is many winners
    best_t1 = np.mean( mesh_t1[i][j] )
    best_t2 = np.mean( mesh_t2[i][j] )  
    
    return best_t1, best_t2
       
    
class OptBayesExptTwoRate(OptBayesExpt):
    """ An OptBayesExpt object designed for probing the decay rate. 
    
    This object is meant to overid the cost function of the base OptBayesExpt
    object (in the script "obe_base.py") 
    The cost function will be related to the time probed; Such that the best 
    time to probe is taken considering the cost that it takes to measure for a 
    a long time. 
    
    """

    def __init__(self, model_function, setting_values, parameter_samples,
                 constants):

        # Initiate the parent object with the corresponding parameter
        # It is the same input that the base object. 
        OptBayesExpt.__init__(self, model_function, setting_values,
                                  parameter_samples, constants)
        
        # (in second)  Extra time cosummed when changing the setting
        self.T_overhead = 0 
        
    def cost_estimate(self):
        """
        This overids the corresponding method of the parent object. 
        
        
        Estimate the cost of measurements, depending on settings

        The denominator of the *utility* function allows measurement
        resources (e.g. setup time + data collection time) to be entered
        into the utility calculation.

        Returns:
            :obj:`float`, otherwise an :obj:`ndarray` describing how
                measurement variance depends on settings.
        """
        
        # 'self.allsettings' is from the parent object
        # It is a tuple of two arrays. The first one contains all the time 
        # to explore with the algorithm. The second contains all the type of
        # experiment to explore with the algorithm. 
        t_probed = self.allsettings[0] # Extract all the possible time to probe. 

        # Determine the cost of selecting the setting. 
        cost = t_probed + self.T_overhead

        return cost

    def enforce_parameter_constraints(self):
        """
        This overids the corresponding method of the parent object. 
        
        All parameters and noise values must be > 0.  Assign
        zero probability to any violators.
        """
        changes = False
        for param in self.parameters:
            # find the violators
            bad_ones = np.argwhere(param < 0).flatten()
            if len(bad_ones) > 0:
                changes = True
                for violator in bad_ones:
                    # effective death penalty.  Next resample will remove
                    self.particle_weights[violator] = 0

        if changes is True:
            # rescale the particle weights
            self.particle_weights = self.particle_weights \
                                    / np.sum(self.particle_weights)
                                    

class T1Finder():
    """
    T1 finder. 
    
    This class will help you to find the two rates associated with the 
    T1 relaxation of ms=+-1. 
    It assumes that we have two types of measurement to make and a model for 
    describing the outcome of each type of measurement. 
    
    It uses Bayesian inference for estimating the parameters and the settings
    that are the most sensitive on the knowledge of the parameters. 

    This is how this class should be used:
        1. The user initiate the object with:
            - An initial set of allowed time to probe. 
            - The model for the two functions of the two decays. 
            - The prior knowledge on the parameters of the models. 
        2. The user ask to this object which time to probe and which type of 
           measurement to make. 
        3. The user perform its experiment and send the measurement to this 
           object. 
        4. Now this object have a better knowledge of the physics and can 
           better tell to the user which setting to probe next. Therefore, 
           he/she can repeat step 2-3 until satisfaction. 
           For example, the satisfaction criteria can be that a given 
           uncertainty is reached in the knowledge of the parameters. 
        
    """

    def __init__(self, list_allowed_probed_t,
                 model_1, model_2, tuple_priors):
        """
        list_allowed_probed_t:
            List of allowed time to probe. 
            
        model_1, model_2:
            Each a function with signature (t, parm1, parm2, etc.), where t is 
            the time to probe. These are the model function that describe the 
            outcome of our experiment. 
        tuple_priors:
            Must ba a list of equally sized sample for each 
            parameter. Each sample consists of a randomly distributed value
            that the parameter can be. The order of the samples must match the 
            order of the free parameters in the model function 
            To know more, see an example of how it is used in the code below 
            "if __name__=="__main__":"      
            
        Choice of unit:
            As long as it is consistent in the models. The time will be 
            directly plugued in the function.             
        
        """
        _debug('T1Finder: __init__')
        _debug('A champion is afraid of losing. Everyone else is afraid of winning. – Billie Jean King')
        
        self.list_allowed_probed_t = list_allowed_probed_t
        self.model_1 = model_1
        self.model_2 = model_2
        self.tuple_priors = tuple_priors

        # The type of measurement to make will also be a setting
        # +1 means the measurement type1, -1 means the measurement type2
        self.type_measure_sample = (1, -1)
        self.setting_values = (self.list_allowed_probed_t, 
                               self.type_measure_sample)                
        
        # =====================================================================
        # Create an instance of the OptBayesExpt class
        # =====================================================================   
        # We are using our own class
        self.my_obe = OptBayesExptTwoRate(self._my_model_function, 
                                          self.setting_values,
                                          self.tuple_priors,
                                          () ) # No constant assumed for now    
        
    def _my_model_function(self, settings, parameters, constants):
        """
        Model function that needs to be passed to the OptBayesExpt class. 
        It is basically an other way to evaluate the model, with a specific 
        scheme for the input. 
        This is useful for OptBayesExpt, because it allows to distinguish the 
        settings from the other parameters that we want to infer. 
        
        Therefore, the signature must be as it is. 
        
        """
        # This function is called so often that it is maybe better to disable
        # the debugger
        #_debug('T1Finder: _my_model_function')
        
        # We assume the following order for the settings
        time_probed, type_experiment = settings 
   
        # Here is a trick to use the setting "type_experiment" has an array 
        # without using the if-else condition. 
        # If type_experiment=+1, it returns model_1. 
        # If type_experiment=-1, it returns model_2
        m1 = self.model_1 (time_probed, *parameters)
        m2 = self.model_2 (time_probed, *parameters)
        model_result = 0.5*(type_experiment+1)*m1 +0.5*(1-type_experiment)*m2    
       
        return model_result        
        
    def get_best_setting_NIST(self, pickiness=-1):
        """
        Get the best setting for the next experiment. It considers the model 
        and the given data so far. Based on that, it determines the settings
        that will maximize the information gain, divided by the cost. 
        
        To know more about how the best settings are choosen, see the 
        documentation here:
        https://pages.nist.gov/optbayesexpt/manual.html
        
        Optionnal input parameter:
            pickiness:
                (float) If above 0, the setting will be choosen less than
                optimal. The value should range between 0 and 10. A value of 0 
                indicates random setting. A value of 10 and above will be 
                optimal settings. A value in between determines the degree 
                of slopiness.
        
        Return:
            (Tuple of size 2)
            time_probed, type_measure
            Float and int, corresponding to the best time to probe and the best
            type of measurement to make.
        
        """
        _debug('T1Finder: get_best_setting_NIST')
        
        if pickiness > 0:
            # An alternative method, which allows some sloppyness.
            time_probed, type_measure =  self.my_obe.good_setting(pickiness=pickiness)
        else:
            # Choose optimal setting
            time_probed, type_measure = self.my_obe.opt_setting()
            
        return (time_probed, type_measure)

    def get_best_setting_analytic(self):
        """
        Obtain the best set of time to probe for each of the type of 
        measurement. The method is based on an analytice expression for the 
        uncertainty in the rates. 
        """
        _debug('T1Finder: get_best_setting_analytic')
        
        # Estimate the best knowledge on the rate so far.
        best_gp , best_gm  = self.my_obe.mean()
        best_egp, best_egm = self.my_obe.std()
        
        # Estimate the best set f time to probe for the two measurement.
        t1, t2 = EstimateBestSetting(self.list_allowed_probed_t,
                                     best_gp, best_gm,  best_egp, best_egm,
                                     self.model_1, self.model_2)
            
        return t1, t2    
    
        
        
    def give_measurement(self, measurement, uncertainty, 
                               time_probed, type_measure):
        """
        Feed the algorithm with a measurement.
        
        Input Parameters
        measurement:
            (float) Measurement which is modelized by the model function. 
        uncertainty:
            (float) Uncertainty in the measurement. 
        time_probed:
            (float) Time probed at which the measurement was made. 
        type_measure:
            (+1 or -1) Type of the measurement. +1 means the measurement + and
            -1 means the measurement -. 
            
        Return:
            Nothing. 
        """
        _debug('T1Finder: give_measurement')
        
        # Gather the settings in a tuple
        settings = (time_probed, type_measure)
        # Hather the information about the measurement as a tuple
        information = (settings, measurement, uncertainty)
        # Report the information
        self.my_obe.pdf_update(information)      
        
        return
    
    def get_parameters(self):
        """
        Infer the parameter, by using Bayes Theorem on the data. 
        
        Return a Tuple of size 3:
        First element:
            (array of float) Mean of each parameter. 
            Explicitly, it is [gamma+, gamma-].
        Second element:
            (array of float) Standard deviation of each parameter.
            Explicitly, it is [error in gamma+, error in gamma-].
        Third element:
            (Array of arrays, or numpy matrix) Covariance matrix of the 
            parameters.
            
        """
        _debug('T1Finder: get_parameters')
        
        return (self.my_obe.mean(), self.my_obe.std(), self.my_obe.covariance())

        
        
        
        
if __name__=="__main__":
    """
    The following code is executed only when this script is run alone. 
    It is only meant to test the code above. 
    """
    _debug_enabled = True
    
    import T1_finder_functions as _sim
    import matplotlib.pyplot as plt
    import spinmob as sm
    import time
    
 
    # =========================================================================
    # Parameter for simulating the data
    # =========================================================================
    mode = 'Delta' # Delta or NIST (Which algo to use)
    N_readout = 7e5   # number of readout at the single time to probe
    C   = 0.24  # Optical Contrast between the states 
    PL0 = 0.014 # Mean count of ms=0
    BG  = 0 # Mean count of the background
    true_gp = 4.7*1e3  # (Hz) Experimental true rate 
    true_gm = 23*1e3  # (Hz) Experimental true rate
    
    n_adapt = 50 # Number of adaption to perform. 
        
    # Define the grid for the prior on the rate
    Gp_min = 0.01*1e3   #Minimum guess for gamma plus (Hz) 
    Gp_max = 100*1e3  #Maximun guess for gamma plus (Hz)        
    Gm_min = 0.01*1e3   #Minimum guess for gamma minus (Hz) 
    Gm_max = 100*1e3  #Maximun guess for gamma minus (Hz)  
    n_samples_params = int ( 1e5 ) # Number of sample to take for the parameter space
    # Define the alloqwed time to probe
    # Logarithm spacing
    list_t_probe = sm.fun.erange(5, 3000, steps=1000)*1e-6 #Sec
    # =============================================================================
    # Plot the grid of time to probe. 
    # =============================================================================
    plt.figure()
    plt.plot(list_t_probe*1e6, '.')
    plt.xlabel('Index')
    plt.ylabel('t_probe (us)')

    # Flat prior
    gp_sample = np.random.uniform(Gp_min, Gp_max, n_samples_params )   
    gm_sample = np.random.uniform(Gm_min, Gm_max, n_samples_params ) 
    # Gatther the samples of each parameter in a tuple
    tuple_priors = (gp_sample, gm_sample)    
        
    # Super rough approximation of the uncertainty in a measurement
    # It is no longer used. But I keep it here as a reference.
    unc_meas = np.sqrt(2/(N_readout*PL0))     
    # =========================================================================
    # Initiate the algorithm
    # =========================================================================
    from T1_finder_functions import model_m0mm 
    def model_1(t, gp, gm):
        return model_m0mm(+1, t, gp, gm)
    def model_2(t, gp, gm):
        return model_m0mm(-1, t, gp, gm)    
    self = T1Finder(list_t_probe, model_1, model_2, tuple_priors)


    # =============================================================================
    # Plot the prior 
    # =============================================================================
    parms = self.my_obe.parameters # This contains the arrays of each parameter
    plt.figure(figsize=(8, 5), tight_layout=True)  
    plt.scatter(parms[0]*1e-3, parms[1]*1e-3, color='k', alpha=0.1)
    # Show the true value 
    plt.plot(true_gp*1e-3, true_gm*1e-3, 'Xr', 
            markersize=20, label='True value')   
    plt.legend()
    plt.xlabel('Rate+ (kHz)')
    plt.ylabel('Rate- (kHz)')    
    plt.title('Cloud of parameter')
        
    
    
    # =========================================================================
    # Simulate running the experiment in the lab
    # =========================================================================    
    # Initiate some usefull array for the keeping track of thinks. 
    best_gp  = np.zeros(n_adapt) # Best gamma+ infered
    best_egp = np.zeros(n_adapt) # Error in the best gamma+ infered
    best_gm  = np.zeros(n_adapt) # Best gamma- infered
    best_egm = np.zeros(n_adapt) # Error in the best gamma- infered
    t_probed_p_s = []  # Time probed for the plus measurement at each iteration
    t_probed_m_s = []  # Time probed for the minus measurement at each iteration
    iterations = np.arange(n_adapt) # Number of iteration performed
    measurement_p_s    = [] # Measurement of the type "plus"
    emeasurement_p_s   = [] # uncertainty in the measurement of the type "plus"
    measurement_m_s    = [] # Measurement of the type "minus"
    emeasurement_m_s   = [] # uncertainty in the measurement of the type "minus"
    time_cpu           = np.zeros(n_adapt) # CPU processing time
    time_measurement   = np.zeros(n_adapt) # Experiement time
    sim_meas_1 = _sim.DiffRatioNoise(N_readout, BG, PL0, C, type1='+0', type2='++')
    sim_meas_2 = _sim.DiffRatioNoise(N_readout, BG, PL0, C, type1='-0', type2='--')
    
    
    
    # Now loop over each measurement
    for i in range(n_adapt):
        
        # Print the update of the protocol each certain iteration
        if i%10 == 0:
            print('')
            print('Iteration %d / %d'%(i, n_adapt))
            
    
        
        if mode == 'Delta':
            # =============================================================================
            #             # Estimate the best measurement
            # =============================================================================                        
            t0 = time.time() # The following is considered CPU time        
            # Determine the best setting
            t_probed_1, t_probed_2 = self.get_best_setting_analytic()
            #Update CPU time
            time_cpu[i] += time.time() - t0  
            # =============================================================================
            #         # Measurement 1
            # =============================================================================
            type_measure = +1
            t_probed = t_probed_1
            print('t_probed*true_gp = ', t_probed*true_gp)
            # Fake the data, depending on the type of measurement       
            result, uncertainty = sim_meas_1.model(t_probed, true_gp, true_gm)
            
            t_probed_p_s    .append(t_probed)
            measurement_p_s .append(result)
            emeasurement_p_s.append(uncertainty)
            
            # feed the measurement
            t0 = time.time() # The following is considered CPU time
            # Feed the algorithm with the measurement
            self.give_measurement(result, uncertainty, 
                                   t_probed, type_measure)
            #Update CPU time
            t_cpu_v1 =  time.time() - t0         
            # =============================================================================
            #         # Measurement 2
            # =============================================================================
            type_measure = -1
            t_probed = t_probed_2 
            print('t_probed*true_gp = ', t_probed*true_gp)
            # Fake the data, depending on the type of measurement
            result, uncertainty = sim_meas_2.model(t_probed, true_gp, true_gm)
            
            t_probed_m_s    .append(t_probed)
            measurement_m_s .append(result)
            emeasurement_m_s.append(uncertainty)  
            
            # feed the measurement
            t0 = time.time() # The following is considered CPU time
            # Feed the algorithm with the measurement
            self.give_measurement(result, uncertainty, 
                                   t_probed, type_measure)
            #Update CPU time
            time_cpu[i] = t_cpu_v1 +  time.time() - t0   

            # Record the experimental time
            time_measurement[i] = N_readout*( t_probed_1 + t_probed_2 )        
        elif mode == 'NIST':
            # =============================================================================
            #             # Estimate the best measurement
            # =============================================================================                        
            t0 = time.time() # The following is considered CPU time        
            # Determine the best setting
            t_probed, type_measure = self.get_best_setting_NIST()
            #Update CPU time
            time_cpu[i] += time.time() - t0       
            
            # =============================================================================
            #         # Measurement 
            # =============================================================================      
            if type_measure == +1:
                result, uncertainty = sim_meas_1.model(t_probed, true_gp, true_gm)
                t_probed_p_s    .append(t_probed)
                measurement_p_s .append(result)
                emeasurement_p_s.append(uncertainty)
            elif type_measure == -1:
                result, uncertainty = sim_meas_2.model(t_probed, true_gp, true_gm)
                t_probed_m_s    .append(t_probed)
                measurement_m_s .append(result)
                emeasurement_m_s.append(uncertainty)      
                
            print('t_probed*true_gp = ', t_probed*true_gp)
            
            # feed the measurement
            t0 = time.time() # The following is considered CPU time
            # Feed the algorithm with the measurement
            self.give_measurement(result, uncertainty, 
                                   t_probed, type_measure)
            #Update CPU time
            time_cpu[i] += time.time() - t0           

            # Record the experimental time
            time_measurement[i] = N_readout*( t_probed )         
                
            
        # =============================================================================
        #         # Record the infered parameters
        # =============================================================================
        means, stds, covs = self.get_parameters()
        best_gp[i]  = means[0]
        best_egp[i] = stds[0]
        best_gm[i]  = means[1]
        best_egm[i] = stds[1]


    # Transform the lists into numpy array
    t_probed_p_s = np.array(t_probed_p_s) 
    t_probed_m_s = np.array(t_probed_m_s)
    measurement_p_s    = np.array(measurement_p_s)
    emeasurement_p_s   = np.array(emeasurement_p_s)
    measurement_m_s    = np.array(measurement_m_s)
    emeasurement_m_s   = np.array(emeasurement_m_s)
    
    #Update the total time
    time_total = time_measurement + time_cpu
    time_cum   = np.cumsum(time_total)
    
    # Compute the sensitivity
    eta_p_s = best_egp*np.sqrt(time_cum)
    eta_m_s = best_egm*np.sqrt(time_cum)
        
    # =========================================================================
    ### Let's now plot nice results for gamma+
    # =========================================================================
    
    plt.figure(figsize=(17, 11), tight_layout=True)
    # (1) Plot the infered rates
    #
    # 2 rows, 2 columns, Select the first plot
    ax = plt.subplot(221)
    # measurement data
    plt.errorbar(iterations, best_gp*1e-3, yerr=best_egp*1e-3, color='C0',
                 marker='.', linestyle='', label='Gamma+')
    plt.errorbar(iterations, best_gm*1e-3, yerr=best_egm*1e-3, color='C1',
                 marker='.', linestyle='', label='Gamma-')
    plt.plot([iterations[0], iterations[-1]], [true_gp*1e-3, true_gp*1e-3],
             '--', label='True gamma+', color='C0')
    plt.plot([iterations[0], iterations[-1]], [true_gm*1e-3, true_gm*1e-3],
             '--', label='True gamma-', color='C1')
    plt.legend()
    plt.xlabel("No. of adaptation")
    plt.ylabel("Infered rates (kHz)")
    plt.text(0.02, .9, '(a)', transform=ax.transAxes)
    xlims = plt.xlim()
    
    # (2) plot the true curve and the "measured" data
    #
    # second plot (next to the first)
    ax = plt.subplot(222)
    # Compute the true curves
    t = list_t_probe
    yp = model_1(t, true_gp, true_gm)
    ym = model_2(t, true_gp, true_gm)
    plt.plot(t*1e6, yp, label='True model +', color='C0')
    plt.plot(t*1e6, ym, label='True model -', color='C1')
    # Show the measurements
    plt.errorbar(t_probed_p_s*1e6, measurement_p_s, yerr=emeasurement_p_s, 
                marker='.', linestyle='', label='Measurement +', color='C0')
    plt.errorbar(t_probed_m_s*1e6, measurement_m_s, yerr=emeasurement_m_s, 
                marker='.', linestyle='', label='Measurement -',color='C1')
    plt.legend()
    plt.xlabel("Time (us)")
    plt.ylabel("Mean counts")
    plt.text(0.02, .90, '(b)', transform=ax.transAxes)
    # This is useful for having another plot with the same limits
    xlims = plt.xlim() 
    
    # (3) plot the evolution of the std in the infered parameters
    #
    # Third plot (below the first)
    ax = plt.subplot(223)
    plt.loglog(iterations + 1, best_egp*1e-3, '.', label='Gamma+')
    plt.loglog(iterations + 1, best_egm*1e-3, '.', label='Gamma-')
    plt.legend()
    plt.ylabel("Uncertainty in rate (kHz)")
    plt.xlabel("No. of adaptation")
    plt.text(0.02, .1, '(c)', transform=ax.transAxes)
    
    # (4) plot a histogram of the adapted parameter
    #
    # Third plot (below the first)
    ax = plt.subplot(224)
    plt.hist(t_probed_p_s*1e6, bins=10, label='Measurement +', alpha=0.5)
    plt.hist(t_probed_m_s*1e6, bins=10, label='Measurement -', alpha=0.5)
    plt.legend()
    plt.ylabel("Time density")
    plt.xlabel("Time (us)")
    plt.text(0.02, .90, '(d)', transform=ax.transAxes)
    plt.xlim(xlims) # Have the same limit in the x-axis such that it is easy to compare        
            
    # =========================================================================
    ### Verify what best time was choosen 
    # =========================================================================         
    plt.figure(figsize=(17, 11), tight_layout=True)
    
    # First plot show the histogram after choppinf the outlier
    ax = plt.subplot(211)
    # Chop the outliers
    Nstd = 2 # Number of standard deviation away from the mean of the distribution
    meanp = np.mean(t_probed_p_s)
    meanm = np.mean(t_probed_m_s)
    stdp = np.std(t_probed_p_s)
    stdm = np.std(t_probed_m_s)
    binp = np.linspace(0, 2/true_gp, 50)
    binm = np.linspace(0, 2/true_gm, 50)
    true_g0 = np.sqrt(true_gp**2 + true_gm**2)
    plt.hist(t_probed_p_s*true_g0, bins=binp*true_g0, label='Measurement +', 
             alpha=0.5)
    plt.hist(t_probed_m_s*true_g0, bins=binm*true_g0, label='Measurement -', 
             alpha=0.5)
    plt.legend()
    plt.ylabel("Density of occurence")
    plt.xlabel("T_probe * sqrt(sum square rates)")
    plt.text(0.02, .90, '(d)', transform=ax.transAxes)
    
    # Second plot shows the time probed in scale
    ax = plt.subplot(212)
    plt.plot(t_probed_p_s*1e6, '.-', label='Measure +')
    plt.plot(t_probed_m_s*1e6, '.-', label='Measure -')
    plt.legend()
    plt.xlabel('Iterations')
    plt.ylabel('Time probed (us)')            
            
    # =========================================================================
    ### Verify the time elapsed and the sensitivity
    # =========================================================================         
    plt.figure(figsize=(17, 11), tight_layout=True)        
    
    # First plot the histograms of the times
    ax = plt.subplot(211)        
#    plt.hist(time_total*1e6, label='Total',alpha=0.5)
    plt.hist(time_cpu*1e3, label='CPU', alpha=0.5)
    plt.legend()
    plt.xlabel('Time at each adapation (ms)')
    plt.ylabel('Occurence')
    
    # Second, plot the sensitivity
    ax = plt.subplot(212)   
    plt.plot(time_cum/60, eta_p_s*1e-3, label='Rate+')
    plt.plot(time_cum/60, eta_m_s*1e-3, label='Rate-')
    plt.legend()
    plt.xlabel('Accumulated time (min)')
    plt.ylabel('Sensitivity (kHz/sqrt(Hz))')
    
    # =========================================================================
    ### Plot the cloud of parameters
    # =========================================================================  
    parms = self.my_obe.parameters # This contains the arrays of each parameter
    plt.figure(figsize=(8, 5), tight_layout=True)  
    plt.scatter(parms[0]*1e-3, parms[1]*1e-3, color='k', alpha=0.1)
    # Show the true value 
    plt.plot(true_gp*1e-3, true_gm*1e-3, 'Xr', 
            markersize=20, label='True value')  
    # Show the best estimate from Bayes
    plt.errorbar(best_gp[-1]*1e-3, best_gm[-1]*1e-3, 
                 xerr=best_egp[-1]*1e-3, yerr=best_egm[-1]*1e-3,
                 label='Best Estimate')
    plt.legend()
    plt.xlabel('Rate+ (kHz)')
    plt.ylabel('Rate- (kHz)')    
    plt.title('Cloud of parameter')
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        


