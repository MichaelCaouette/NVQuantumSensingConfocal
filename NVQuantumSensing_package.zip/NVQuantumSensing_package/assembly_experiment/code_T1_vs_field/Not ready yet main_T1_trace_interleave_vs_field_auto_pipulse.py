# -*- coding: utf-8 -*-
"""
Created on Thu Feb  4 11:16:29 2021

Goal:
    Take measurements at various magnet position

@author: Childresslab
"""


# Also import nice stuff
import time
import os # For creating new folders
import traceback
_p = traceback.print_last #Very usefull command to use for getting the last-not-printed error


# =============================================================================
# Import the modules that we will use and the FPGA
# =============================================================================
# Add the folder of the software package that we are using. 
import sys
path_softwares = 'X:\\DiamondCloud\\Magnetometry\\Acquisition\\NVQuantumSensing_package\\software_packages'
# 'X:\\DiamondCloud\\Magnetometry\\Data\\2021\\07\\07\\NVQuantumSensing_package\\software_packages'
#sys.path.insert(0, pa)
sys.path.append(path_softwares)
path_base_modules = path_softwares + '\\base_modules'
sys.path.append(path_base_modules)
# Import the relevant module for the experiment
from confocal import GUIMainConfocal
from magnet_positions import GUIMagnetPositions
from pulse_sequences import GUIPulseSequences
from pipulse_find_auto import GUIPiPulseFinderAuto
# For an unknown reason I can import this only if I copy the script with an other name... 
from T1_time_trace_caprice  import GUIT1TimeTrace

# =============================================================================
# Open the fpga
# =============================================================================
# Get the ressource and bitfile
import spinmob as sm
dir_specifics = path_base_modules + '\\cpu_specifics.dat'
cpu_specific_infos = sm.data.load(dir_specifics)
# cpu_specific_infos is defined in the import of the base modules
bitfile_path = cpu_specific_infos.headers['FPGA_bitfile_path']
resource_num = cpu_specific_infos.headers['FPGA_resource_number']
# Open the fpga
import base_modules.api_fpga as _fc
fpga = _fc.FPGA_api(bitfile_path, resource_num) 
fpga.open_session()



# =============================================================================
# HARD WAY TO CODE THE BEST GUESS FOR THE PIPULSE
# =============================================================================
#list_f_minus_min = [1.4, 1.70, 2.05]
#list_f_minus_max = [1.7, 2.00, 2.30]
#list_f_plus_min  = [3.9, 3.75, 3.45]
#list_f_plus_max  = [4.2, 4.10, 3.75]

#import numpy as np
## For the pi-pulse minus
#list_f_minus_min = 1.5 + np.zeros(12)
#list_f_minus_max = 2.3 + np.zeros(12)
#list_p_minus_min = 15  + np.zeros(12)
#list_p_minus_max = 25  + np.zeros(12)
#
## For the pi-pulse plus
#list_f_plus_min = 3.4 + np.zeros(12)
#list_f_plus_max = 4.2 + np.zeros(12)
#list_p_plus_min = 15  + np.zeros(12)
#list_p_plus_max = 25  + np.zeros(12)

## For the pi-pulse minus
#fm_center = np.linspace(1.61,  1.88, 3)
#list_f_minus_min = fm_center - 0.20
#list_f_minus_max = fm_center + 0.20
#list_p_minus_min = 0  + 0*fm_center
#list_p_minus_max = 25  + 0*fm_center
#
## For the pi-pulse plus
#fp_center = np.linspace(4.13,  3.86, 3)
#list_f_plus_min = fp_center - 0.20
#list_f_plus_max = fp_center + 0.20
#list_p_plus_min = 0  + 0*fm_center
#list_p_plus_max = 25  + 0*fm_center

## For the pi-pulse minus
#fm_center = np.linspace(1.61,  1.98, 7)
#list_f_minus_min = fm_center - 0.20
#list_f_minus_max = fm_center + 0.20
#list_p_minus_min = 0  + 0*fm_center
#list_p_minus_max = 25  + 0*fm_center
#
## For the pi-pulse plus
#fp_center = np.linspace(4.13,  3.77, 7)
#list_f_plus_min = fp_center - 0.20
#list_f_plus_max = fp_center + 0.20
#list_p_plus_min = 0  + 0*fm_center
#list_p_plus_max = 25  + 0*fm_center

## For the pi-pulse minus
#fm_center = np.linspace(1.51, 1.941, 12)
#list_f_minus_min = fm_center - 0.10
#list_f_minus_max = fm_center + 0.10
#list_p_minus_min = 0  + 0*fm_center
#list_p_minus_max = 25  + 0*fm_center
#duration_RF_minus = 0.080 # (us) Duration of the pi-pulse -
#
## For the pi-pulse plus
#fp_center = np.linspace(4.23, 3.808, 12)
#list_f_plus_min = fp_center - 0.10
#list_f_plus_max = fp_center + 0.10
#list_p_plus_min = 2  + 0*fm_center
#list_p_plus_max = 25  + 0*fm_center
#duration_RF_plus = 0.08 # (us)Duration of the pi-pulse +

## For the pi-pulse minus
#fm_center = np.linspace(2.171, 1.515, 5)
#list_f_minus_min = fm_center - 0.15
#list_f_minus_max = fm_center + 0.15
#list_p_minus_min = 0  + 0*fm_center
#list_p_minus_max = 25  + 0*fm_center
#duration_RF_minus = 0.080 # (us) Duration of the pi-pulse -
#
## For the pi-pulse plus
#fp_center = np.linspace(3.566, 4.22, 5)
#list_f_plus_min = fp_center - 0.15
#list_f_plus_max = fp_center + 0.15
#list_p_plus_min = 0  + 0*fm_center
#list_p_plus_max = 25  + 0*fm_center
#duration_RF_plus = 0.08 # (us)Duration of the pi-pulse +

# =============================================================================
# Non-linearly interpolate the frequencies
# =============================================================================
from eigenfreq_interpolate import get_fs_from_r
import numpy as np
list_z = np.array( [1.25, 1.6666666666666667, 2.0833333333333335,2.5, 
                    2.916666666666667, 3.3333333333333335, 3.75, 
                    4.166666666666667,4.583333333333334, 5.0] )
tuple_parms = [34.12474791148252, 7.647660230661493, 3.141574704851089]
list_interp_fp, list_interp_fm = get_fs_from_r(list_z, *tuple_parms)
print()
print('List of frequencies: ')
print(list_interp_fp)
print(list_interp_fm)
print()    


#fm_center = np.linspace(1.5, 2.3995, 10)
fm_center = list_interp_fm
list_f_minus_min = fm_center - 0.15
list_f_minus_max = fm_center + 0.15
list_p_minus_min = 0  + 0*fm_center
list_p_minus_max = 25  + 0*fm_center
duration_RF_minus = 0.080 # (us) Duration of the pi-pulse -

# For the pi-pulse plus
#fp_center = np.linspace(4.25, 3.344, 10)
fp_center = list_interp_fp
list_f_plus_min = fp_center - 0.15
list_f_plus_max = fp_center + 0.15
list_p_plus_min = 0  + 0*fm_center
list_p_plus_max = 25  + 0*fm_center
duration_RF_plus = 0.120 # (us)Duration of the pi-pulse +


# =============================================================================
# Define a class that will connect all the modules together
# =============================================================================

class APIMagnetT1():
    """
    Class for taking T1 at various magnet positions.
    It should pop up the relevant guis.
    
    The experiment is the following:
        - Set the magnet position
        - Calibrate the one pipulse
        - Run a T1 measurement for this pi-pulse
        - 
    """
    
    def __init__(self):
        """
        Init... INIT !!! I said.... INIT !!
        """
        # =====================================================================
        # Open each application that we need
        # =====================================================================
        # The confocal microscope
        self.confo = GUIMainConfocal(fpga)
        self.confo.show()
        
        # The pulse sequence, that we add to the confocal for avoiding too many 
        # openned window
        self.pulser = GUIPulseSequences(fpga)
        tab_pulse = self.confo.tabs1.add_tab('Pulse Sequence')
        tab_pulse.place_object(self.pulser )  
        # The pi pulse finder
        self.pipulse = GUIPiPulseFinderAuto(fpga)
        self.pipulse.show()
        
        # The T1 finder
        self.T1tracer  = GUIT1TimeTrace(fpga)
        self.T1tracer.show()
                
        # The magnet positionner, for performing a task at each position
        self.magnet = GUIMagnetPositions()
        self.magnet.show()     
        
        # =====================================================================
        # Connect the signal for optimizing
        # =====================================================================
        # We have to connect the optimization to each gui that uses pulse sequences
        # First get the optimizer and its optimization function
        self.optimizer = self.confo.gui_optimizer
        self.f_optimize = self.optimizer.button_optimize.click
        # Now connect it to the various GUI that uses it.
        self.pulser.set_optimization_function(self.f_optimize)   
        self.pipulse.connect_optimization(self.f_optimize)
        self.T1tracer.dummy_please_optimize = self.f_optimize        
        self.T1tracer.gui_measurer.gui_pulse_runner.connect_opt_method(self.confo.gui_optimizer)   
        
        # =====================================================================
        # Connect the task to perform
        # =====================================================================
        self.magnet.dummy_before_starting = self.task_before
        self.magnet.dummy_task = self.task_to_perform
        
    def task_before(self):
        """
        Define the task to perform just before we start to loop over the magnet 
        positions
        """
        # We assum that, already:
        # - The signal generator is connected and the RF are ON
        # - The confocal microscope is focused on the NV. And the offset of the 
        #   optimzer is set. 
        # - The settings of PiPulse finder are set, BUT the window for findind f0 and P0
        # - The setting of the T1 finder are set
        
        self.magnet.label_info_update('Initiating all the settings')

        # =====================================================================
        # Set the saving path
        # =====================================================================   
        
        # Ask the user the repository for saving the files
        txt = 'Select a directory for saving the data at each field.'
        self.path_main_dir_save = sm.dialogs.select_directory(txt)
    

    def task_to_perform(self):
        """
        Define the task that we want to perform at each magnet position. 
        """
        # We assum that, already:
        # - 

        # =========================================================================
        # Create a new folder, because we are gonna save many things.
        # And save the magnet position
        # =========================================================================         
        self.mag_iter = self.magnet.get_iter()
        self.path_save = self.path_main_dir_save + '/' + 'mag_pos_%.3d'%self.mag_iter
        # This creates the directory if it doesn't exist
        if not os.path.exists(self.path_save):
            os.makedirs(self.path_save)
        # Now the magnet position
        self.databox_magnet = sm.data.databox()
        x, y, z = self.magnet.gui_magnet3.get_positions()
        self.databox_magnet.insert_header('date' , time.ctime(time.time()))  
        self.databox_magnet.insert_header('time_sec' , time.time())  
        self.databox_magnet.insert_header('x_magnet' , x)  
        self.databox_magnet.insert_header('y_magnet' , y)  
        self.databox_magnet.insert_header('z_magnet' , z)    
        # Save it 
        save_name = self.path_save + '/magnet_position.dat'
        self.databox_magnet.save_file(save_name)
        
        # =========================================================================
        # Step 1 Optimize the confocal spot on the NV
        # =========================================================================  
        self.magnet.label_info_update('Optimizing before finding the pipulse')
        self.optimizer.button_optimize.click()
        
        # =========================================================================
        # Step 2 Find the pipulse MINUS
        # =========================================================================
        
        # Disconnect the signal generator from the T1 and connect it to the 
        # pi-pulse, becuase it is shared between the two. 
        # Disconnect the T1 if it is connected
        if self.T1tracer.gui_measurer.sig_gen.button_connect.is_checked():
            self.T1tracer.gui_measurer.sig_gen.button_connect.click()           
        
        # Start with the minus pipulse
        self.magnet.label_info_update('Finding the first (minus) pipulse ...')
        # Set the best guess 
        self.pipulse.treeDic_settings['f_min'] = list_f_minus_min[self.mag_iter]
        self.pipulse.treeDic_settings['f_max'] = list_f_minus_max[self.mag_iter]
        self.pipulse.treeDic_settings['P_min'] = list_p_minus_min[self.mag_iter]
        self.pipulse.treeDic_settings['P_max'] = list_p_minus_max[self.mag_iter]
        self.pipulse.treeDic_settings['dt_pipulse'] = duration_RF_minus
        # Create a folder for saving the data
        self.path_save_pi_minus = self.path_save + '/' + 'pipulse_minus'
        if not os.path.exists(self.path_save_pi_minus):
            os.makedirs(self.path_save_pi_minus)
        # Run the pipulse
        self.pipulse.button_reset.click()
        self.pipulse._button_run_clicked(dir_save=self.path_save_pi_minus)
        # Note the pi-pulse parameter
        output = self.pipulse.get_pipulse()
        self.pi_minus_T  = output[0] # Should be in us
        self.pi_minus_f0 = output[1]
        self.pi_minus_P0 = output[2]

        # =========================================================================
        # Step 3 Find the pipulse PLUS
        # =========================================================================    
        
        # Then the plus pipulse
        self.magnet.label_info_update('Finding the second (plus) pipulse ...')
        # Set the best guess 
        self.pipulse.treeDic_settings['f_min'] = list_f_plus_min[self.mag_iter]
        self.pipulse.treeDic_settings['f_max'] = list_f_plus_max[self.mag_iter]
        self.pipulse.treeDic_settings['P_min'] = list_p_plus_min[self.mag_iter]
        self.pipulse.treeDic_settings['P_max'] = list_p_plus_max[self.mag_iter]
        self.pipulse.treeDic_settings['dt_pipulse'] = duration_RF_plus
        # Create a folder for saving the data
        self.path_save_pi_plus = self.path_save + '/' + 'pipulse_plus'
        if not os.path.exists(self.path_save_pi_plus):
            os.makedirs(self.path_save_pi_plus)
        # Run the pipulse
        self.pipulse.button_reset.click()
        self.pipulse._button_run_clicked(dir_save=self.path_save_pi_plus)
        # Note the pi-pulse parameter
        output = self.pipulse.get_pipulse()
        self.pi_plus_T  = output[0] # Should be in us
        self.pi_plus_f0 = output[1]
        self.pi_plus_P0 = output[2]

        # =========================================================================
        # Step 4 Measure T1 trace with the two type of measurement interleaved
        # =========================================================================

        # Disconnect the signal generator from the pipulse and connect it to 
        # the T1, becuase it is shared between the two. 
        # Disconnect the pipulse if it is connected
        self.pipulse.disconnect_sig_gen() 
        # Connect the T1 if it is not connected
        if not( self.T1tracer.gui_measurer.sig_gen.button_connect.is_checked() ):
            self.T1tracer.gui_measurer.sig_gen.button_connect.click()
            self.T1tracer.gui_measurer.sig_gen.button_reset.click()
            
        self.magnet.label_info_update('Measuring the time trace for each type of measurement ...')
        # Set the parameter of the pi-pulse MINUS
        print('Pi pulse minus:')
        print(self.pi_minus_T)
        print(self.pi_minus_f0)
        print(self.pi_minus_P0)
        self.T1tracer.treeDic_settings['Pipulse-/dt'] = self.pi_minus_T
        self.T1tracer.treeDic_settings['Pipulse-/frequency'] = self.pi_minus_f0
        self.T1tracer.treeDic_settings['Pipulse-/power'] = self.pi_minus_P0
        
        # Set the parameter of the pi-pulse PLUS
        print('Pi pulse plus:')
        print(self.pi_plus_T)
        print(self.pi_plus_f0)
        print(self.pi_plus_P0)
        self.T1tracer.treeDic_settings['Pipulse+/dt'] = self.pi_plus_T
        self.T1tracer.treeDic_settings['Pipulse+/frequency'] = self.pi_plus_f0
        self.T1tracer.treeDic_settings['Pipulse+/power'] = self.pi_plus_P0
        
        # Set a Bad-Ass name
        self.T1tracer.treeDic_settings['Name_save'] = 'T1_Orion'        
        
        # Create a folder for saving the data
        self.path_save_T1 = self.path_save + '/' + 'T1'
        if not os.path.exists(self.path_save_T1):
            os.makedirs(self.path_save_T1)
            
        # Run the T1
        self.T1tracer.button_reset.click()
        self.T1tracer._button_run_clicked(dir_save=self.path_save_T1)              
        

        return 
    
 
# Launch the experiment
self  =  APIMagnetT1()


#
## Bonus, aslo import the sweeper
#from sweep_pulsedESR import GUISweepPulsedESR
#sweepy = GUISweepPulsedESR(fpga)
#sweepy.gui_pulsed_ESR.gui_pulse_runner.dummy_please_optimize = self.f_optimize
#sweepy.show()
#








