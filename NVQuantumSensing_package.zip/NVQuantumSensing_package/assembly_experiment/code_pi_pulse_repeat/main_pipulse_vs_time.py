# -*- coding: utf-8 -*-
"""
Created on Thu Feb  4 11:16:29 2021

Goal:
    Take continueously-pi-pulse

@author: Childresslab
"""


# Also import nice stuff
import time
import os # For creating new folders
import traceback
_p = traceback.print_last #Very usefull command to use for getting the last-not-printed error


# =============================================================================
# Import the modules that we will use and the FPGA
# =============================================================================
# Add the folder of the software package that we are using. 
import sys
path_softwares = 'X:\\DiamondCloud\\Magnetometry\\Data\\2021\\04\\15\\NVQuantumSensing_package\\software_packages'
#sys.path.insert(0, pa)
sys.path.append(path_softwares)
path_base_modules = path_softwares + '\\base_modules'
sys.path.append(path_base_modules)
# Import
from confocal import GUIMainConfocal
from magnet_positions import GUIMagnetPositions
from pulse_sequences import GUIPulseSequences
from pipulse_find_auto import GUIPiPulseFinderAuto

# Debug stuff.
_debug_enabled     = True
def _debug(*a):
    if _debug_enabled: 
        s = []
        for x in a: s.append(str(x))
        print(', '.join(s))
# =============================================================================
# Open the fpga
# =============================================================================
# Get the ressource and bitfile
from spinmob import egg
import spinmob as sm
dir_specifics = path_base_modules + '\\cpu_specifics.dat'
cpu_specific_infos = sm.data.load(dir_specifics)
# cpu_specific_infos is defined in the import of the base modules
bitfile_path = cpu_specific_infos.headers['FPGA_bitfile_path']
resource_num = cpu_specific_infos.headers['FPGA_resource_number']
# Open the fpga
import base_modules.api_fpga as _fc
fpga = _fc.FPGA_api(bitfile_path, resource_num) 
fpga.open_session()


# =============================================================================
# Define the simple gui that wil control the experiment
# =============================================================================
class GUIRepeatPipulse(egg.gui.Window):
    """
    GUI meant for repeating measurement of the pi-pulse search
    
    """
    
    def __init__(self, name="Pi-Pulse finder auto", size=[1700, 900]): 
        """
        fpga:
            "FPGA_api" object from api_fpga.py. 
            This is the object shared amoung the GUIs for controlling the fpga. 
            The session of the fpga must already be open. 
            
        """    
        _debug('GUIRepeatPipulse:__init__')
        
        # Run the basic stuff for the initialization
        egg.gui.Window.__init__(self, title=name, size=size)
        
        self._open_application()
        
        self._init_GUI()
        
    def _open_application(self):
        """
        Open each application that we need
        """
        # The confocal microscope
        self.confo = GUIMainConfocal(fpga)
        self.confo.show()
        
        # The pulse sequence, that we add to the confocal for avoiding too many 
        # openned window
        self.pulser = GUIPulseSequences(fpga)
        tab_pulse = self.confo.tabs1.add_tab('Pulse Sequence')
        tab_pulse.place_object(self.pulser )  
        # The pi pulse finder
        self.pipulse = GUIPiPulseFinderAuto(fpga)
        self.pipulse.show()
                
        # The magnet positionner, for performing a task at each position
        self.magnet = GUIMagnetPositions()
        self.magnet.show()     
        
        # =====================================================================
        # Connect the signal for optimizing
        # =====================================================================
        self.optimizer = self.confo.gui_optimizer
        self.f_optimize = self.optimizer.button_optimize.click
        self.pulser.set_optimization_function(self.f_optimize)   
        self.pipulse.connect_optimization(self.f_optimize)        

    def _init_GUI(self):
        """
        Put some widget in the GUI
        """

        self.button_run = egg.gui.Button('Start', tip='Launch the experiment')
        self.button_run.set_style('background-color: rgb(0, 200, 0);')
        self.place_object(self.button_run, row=0, column=0)
        self.connect(self.button_run.signal_clicked, 
                     self._button_run_clicked)

        # Important: a button for resetting the iteration
        self.button_reset = egg.gui.Button('Reset/Set experiment', tip='Reset the loop and prepare the experiment')
        self.button_reset.set_style('background-color: rgb(0, 200, 0);')
        self.tab_control_main.place_object(self.button_reset, row=0, column=1)
        self.connect(self.button_reset.signal_clicked, 
                     self._button_reset_clicked)
        
        # tree dictionnarry for the settings
        self.treeDic_settings = egg.gui.TreeDictionary(autosettings_path='setting_pipulse_vs_time')
        self.tab_control_main.place_object(self.treeDic_settings, 
                                           row=1, column=0, column_span=2)        
        # Specific things for the pulse sequence for ms=+1
        self.treeDic_settings.add_parameter('frequency_+', 2.7, 
                                            type='float', step=0.1, decimals=10,
                                            bounds=[0,None], suffix=' GHz',
                                            tip='Central frequency_+')
        self.treeDic_settings.add_parameter('frequency_range_+', 0.2, 
                                            type='float', step=0.01, decimals=10,
                                            bounds=[0,None], suffix=' GHz',
                                            tip='Width of frequency_+')        
        self.treeDic_settings.add_parameter('frequency_-', 3.1, 
                                            type='float', step=0.1, decimals=10,
                                            bounds=[0,None], suffix=' GHz',
                                            tip='Central frequency_-')
        self.treeDic_settings.add_parameter('frequency_range_-', 0.2, 
                                            type='float', step=0.01, decimals=10,
                                            bounds=[0,None], suffix=' GHz',
                                            tip='Width of frequency_+')   

    def _initiate_acquisition(self):
        """
        Initiate the attributes
        """
        self.f_plus_0      = self.treeDic_settings['frequency_+']
        self.f_plus_range  = self.treeDic_settings['frequency_range_+']
        
        self.f_minus_0      = self.treeDic_settings['frequency_-']
        self.f_minus_range  = self.treeDic_settings['frequency_range_-']
        
    def _button_reset_clicked(self):
        """
        Stop and reset the iterations
        """
        _debug('GUIPiPulseFinderAuto: _button_reset_clicked')
        
        # Stop to run 
        if self.is_running:
            self.button_run.click()
        
        # Reinitiate the loop, which reset the iterators and everything
        self._initiate_acquisition()
        
    def _button_run_clicked(self, dir_save=False):
        """
        Launch the automatic measurement
        """

        if self.is_running == False:
            
            # Initiate
            self._initiate_acquisition()
            
            # Set the saving directory
            if dir_save == False:
                # Ask the user the repository for saving the files
                txt = 'Select a directory for saving the data'
                self.path_folder_save = sm.dialogs.select_directory(txt)  
            else:
                self.path_folder_save = dir_save
                                   
            # Update the run button
            self.is_running = True
            self.button_run.set_text('Pause')
            self.button_run.set_colors(background='blue')
            # Run the loop
            self._run_acquisition()
            
        else:
            # Stop to run if it is running (Pause)
            self.is_running = False
            self.button_run.set_text('Continue')
            self.button_run.set_style('background-color: rgb(0, 200, 0);')
            self.statut += '\n\nPaused !'
            self._label_info_update()
            
            
        self.iter = 0
        
        while ()
        # =============================================================================
        # Pi-pulse -        
        # =============================================================================

        # Then the plus pipulse
        self.magnet.label_info_update('Finding the second (plus) pipulse ...')
        # Set the best guess 
        self.pipulse.treeDic_settings['f_min'] = list_f_plus_min[self.mag_iter]
        self.pipulse.treeDic_settings['f_max'] = list_f_plus_max[self.mag_iter]
        self.pipulse.treeDic_settings['P_min'] = list_p_plus_min[self.mag_iter]
        self.pipulse.treeDic_settings['P_max'] = list_p_plus_max[self.mag_iter]
        self.pipulse.treeDic_settings['dt_pipulse'] = duration_RF_plus
        # Create a folder for saving the data
        self.path_save_pi_plus = self.path_save + '/' + 'pipulse_plus'
        if not os.path.exists(self.path_save_pi_plus):
            os.makedirs(self.path_save_pi_plus)
        # Run the pipulse
        self.pipulse.button_reset.click()
        self.pipulse._button_run_clicked(dir_save=self.path_save_pi_plus)
        # Note the pi-pulse parameter
        output = self.pipulse.get_pipulse()
        self.pi_plus_T  = output[0] # Should be in us
        self.pi_plus_f0 = output[1]        
        
        
        

# =============================================================================
# Define a class that will connect all the modules together
# =============================================================================

class APIMagnetT1():
    """
    Class for taking T1 at various magnet positions.
    It should pop up the relevant guis.
    
    The experiment is the following:
        - Set the magnet position
        - Calibrate the one pipulse
        - Run a T1 measurement for this pi-pulse
        - 
    """
    
    def __init__(self):
        """
        Init... INIT !!! I said.... INIT !!
        """
        # =====================================================================
        # Open each application that we need
        # =====================================================================
        # The confocal microscope
        self.confo = GUIMainConfocal(fpga)
        self.confo.show()
        
        # The pulse sequence, that we add to the confocal for avoiding too many 
        # openned window
        self.pulser = GUIPulseSequences(fpga)
        tab_pulse = self.confo.tabs1.add_tab('Pulse Sequence')
        tab_pulse.place_object(self.pulser )  
        # The pi pulse finder
        self.pipulse = GUIPiPulseFinderAuto(fpga)
        self.pipulse.show()
        
        # The T1 finder
        self.T1tracer  = GUIT1TimeTrace(fpga)
        self.T1tracer.show()
                
        # The magnet positionner, for performing a task at each position
        self.magnet = GUIMagnetPositions()
        self.magnet.show()     
        
        # =====================================================================
        # Connect the signal for optimizing
        # =====================================================================
        self.optimizer = self.confo.gui_optimizer
        self.f_optimize = self.optimizer.button_optimize.click
        self.pulser.set_optimization_function(self.f_optimize)   
        self.pipulse.connect_optimization(self.f_optimize)
        self.T1tracer.dummy_please_optimize = self.f_optimize
        self.T1tracer.gui_measurer.gui_pulse_runner.dummy_please_optimize = self.f_optimize         
        # =====================================================================
        # Connect the task to perform
        # =====================================================================
        self.magnet.dummy_before_starting = self.task_before
        self.magnet.dummy_task = self.task_to_perform
        
    def task_before(self):
        """
        Define the task to perform just before we start to loop over the magnet 
        positions
        """
        # We assum that, already:
        # - The signal generator is connected and the RF are ON
        # - The confocal microscope is focused on the NV. And the offset of the 
        #   optimzer is set. 
        # - The settings of PiPulse finder are set, BUT the window for findind f0 and P0
        # - The setting of the T1 finder are set
        
        self.magnet.label_info_update('Initiating all the settings')

        # =====================================================================
        # Set the saving path
        # =====================================================================   
        
        # Ask the user the repository for saving the files
        txt = 'Select a directory for saving the data at each field.'
        self.path_main_dir_save = sm.dialogs.select_directory(txt)
    

    def task_to_perform(self):
        """
        Define the task that we want to perform at each magnet position. 
        """
        # We assum that, already:
        # - 

        # =========================================================================
        # Create a new folder, because we are gonna save many things.
        # And save the magnet position
        # =========================================================================         
        self.mag_iter = self.magnet.get_iter()
        self.path_save = self.path_main_dir_save + '/' + 'mag_pos_%.3d'%self.mag_iter
        # This creates the directory if it doesn't exist
        if not os.path.exists(self.path_save):
            os.makedirs(self.path_save)
        # Now the magnet position
        self.databox_magnet = sm.data.databox()
        x, y, z = self.magnet.gui_magnet3.get_positions()
        self.databox_magnet.insert_header('date' , time.ctime(time.time()))  
        self.databox_magnet.insert_header('time_sec' , time.time())  
        self.databox_magnet.insert_header('x_magnet' , x)  
        self.databox_magnet.insert_header('y_magnet' , y)  
        self.databox_magnet.insert_header('z_magnet' , z)    
        # Save it 
        save_name = self.path_save + '/magnet_position.dat'
        self.databox_magnet.save_file(save_name)
        
        # =========================================================================
        # Step 1 Optimize the confocal spot on the NV
        # =========================================================================  
        self.magnet.label_info_update('Optimizing before finding the pipulse')
        self.optimizer.button_optimize.click()
        
        # =========================================================================
        # Step 2 Find the pipulse MINUS
        # =========================================================================
        
        # Disconnect the signal generator from the T1 and connect it to the 
        # pi-pulse, becuase it is shared between the two. 
        # Disconnect the T1 if it is connected
        if self.T1tracer.gui_measurer.sig_gen.button_connect.is_checked():
            self.T1tracer.gui_measurer.sig_gen.button_connect.click()           
        
        # Start with the minus pipulse
        self.magnet.label_info_update('Finding the first (minus) pipulse ...')
        # Set the best guess 
        self.pipulse.treeDic_settings['f_min'] = list_f_minus_min[self.mag_iter]
        self.pipulse.treeDic_settings['f_max'] = list_f_minus_max[self.mag_iter]
        self.pipulse.treeDic_settings['P_min'] = list_p_minus_min[self.mag_iter]
        self.pipulse.treeDic_settings['P_max'] = list_p_minus_max[self.mag_iter]
        self.pipulse.treeDic_settings['dt_pipulse'] = duration_RF_minus
        # Create a folder for saving the data
        self.path_save_pi_minus = self.path_save + '/' + 'pipulse_minus'
        if not os.path.exists(self.path_save_pi_minus):
            os.makedirs(self.path_save_pi_minus)
        # Run the pipulse
        self.pipulse.button_reset.click()
        self.pipulse._button_run_clicked(dir_save=self.path_save_pi_minus)
        # Note the pi-pulse parameter
        output = self.pipulse.get_pipulse()
        self.pi_minus_T  = output[0] # Should be in us
        self.pi_minus_f0 = output[1]
        self.pi_minus_P0 = output[2]

        # =========================================================================
        # Step 3 Measure T1 trace with the MINUS measurement
        # =========================================================================

        # Disconnect the signal generator from the pipulse and connect it to 
        # the T1, becuase it is shared between the two. 
        # Disconnect the pipulse if it is connected
        self.pipulse.disconnect_sig_gen() 
        # Connect the T1 if it is not connected
        if not( self.T1tracer.gui_measurer.sig_gen.button_connect.is_checked() ):
            self.T1tracer.gui_measurer.sig_gen.button_connect.click()
            self.T1tracer.gui_measurer.sig_gen.button_reset.click()
            
        self.magnet.label_info_update('Measuring the first T1 time trace (minus) ...')
        # Set the parameter of the pi-pulse MINUS
        print('Pi pulse minus:')
        print(self.pi_minus_T)
        print(self.pi_minus_f0)
        print(self.pi_minus_P0)
        self.T1tracer.treeDic_settings['Type_measurement'] = -1
        self.T1tracer.treeDic_settings['Pipulse-/dt'] = self.pi_minus_T
        self.T1tracer.treeDic_settings['Pipulse-/frequency'] = self.pi_minus_f0
        self.T1tracer.treeDic_settings['Pipulse-/power'] = self.pi_minus_P0
        self.T1tracer.treeDic_settings['Name_save'] = 'T1_minus'

        # Create a folder for saving the data
        self.path_save_T1 = self.path_save + '/' + 'T1'
        if not os.path.exists(self.path_save_T1):
            os.makedirs(self.path_save_T1)
            
        # Run the T1
        self.T1tracer.button_reset.click()
        self.T1tracer._button_run_clicked(dir_save=self.path_save_T1)              
        
        
        # =========================================================================
        # Step 4 Find the pipulse MINUS
        # =========================================================================    
        
        # Then the plus pipulse
        self.magnet.label_info_update('Finding the second (plus) pipulse ...')
        # Set the best guess 
        self.pipulse.treeDic_settings['f_min'] = list_f_plus_min[self.mag_iter]
        self.pipulse.treeDic_settings['f_max'] = list_f_plus_max[self.mag_iter]
        self.pipulse.treeDic_settings['P_min'] = list_p_plus_min[self.mag_iter]
        self.pipulse.treeDic_settings['P_max'] = list_p_plus_max[self.mag_iter]
        self.pipulse.treeDic_settings['dt_pipulse'] = duration_RF_plus
        # Create a folder for saving the data
        self.path_save_pi_plus = self.path_save + '/' + 'pipulse_plus'
        if not os.path.exists(self.path_save_pi_plus):
            os.makedirs(self.path_save_pi_plus)
        # Run the pipulse
        self.pipulse.button_reset.click()
        self.pipulse._button_run_clicked(dir_save=self.path_save_pi_plus)
        # Note the pi-pulse parameter
        output = self.pipulse.get_pipulse()
        self.pi_plus_T  = output[0] # Should be in us
        self.pi_plus_f0 = output[1]
        self.pi_plus_P0 = output[2]

        # =========================================================================
        # Step 5 Measure T1 trace with the PLUS measurement
        # =========================================================================

        # Disconnect the signal generator from the pipulse and connect it to 
        # the T1, becuase it is shared between the two. 
        # Disconnect the pipulse if it is connected
        self.pipulse.disconnect_sig_gen() 
        # Connect the T1 if it is not connected
        if not( self.T1tracer.gui_measurer.sig_gen.button_connect.is_checked() ):
            self.T1tracer.gui_measurer.sig_gen.button_connect.click()
            self.T1tracer.gui_measurer.sig_gen.button_reset.click()
            
        self.magnet.label_info_update('Measuring the second T1 time trace (plus) ...')
        # Set the parameter of the pi-pulse PLUS
        print('Pi pulse plus:')
        print(self.pi_plus_T)
        print(self.pi_plus_f0)
        print(self.pi_plus_P0)
        self.T1tracer.treeDic_settings['Type_measurement'] = +1
        self.T1tracer.treeDic_settings['Pipulse+/dt'] = self.pi_plus_T
        self.T1tracer.treeDic_settings['Pipulse+/frequency'] = self.pi_plus_f0
        self.T1tracer.treeDic_settings['Pipulse+/power'] = self.pi_plus_P0
        self.T1tracer.treeDic_settings['Name_save'] = 'T1_plus'
            
        # Run the T1
        self.T1tracer.button_reset.click()
        self.T1tracer._button_run_clicked(dir_save=self.path_save_T1)             
                
        return 
    
 
# Launch the experiment
self  =  APIMagnetT1()



# Bonus, aslo import the sweeper
from sweep_pulsedESR import GUISweepPulsedESR
sweepy = GUISweepPulsedESR(fpga)
sweepy.gui_pulsed_ESR.gui_pulse_runner.dummy_please_optimize = self.f_optimize
sweepy.show()









