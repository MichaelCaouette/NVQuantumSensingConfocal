# -*- coding: utf-8 -*-
"""
Created on Wed Jul  8 07:57:17 2020

Example of how to load the saturation curve

@author: Childresslab
"""

import Bayes_optimal_rates

import spinmob as sm
import numpy as np
import matplotlib.pyplot as plt

import os
import tkinter.filedialog as fd

# Get the list of the directory of each magnet positon
str_key_mag = 'mag_pos' # comment string in the name of the magnet position
folder_name_T1    = 'T1_sequence'
key_file_T1 = 'T1'
i_min = 0 # Minimum folder to check
i_max = 9 # Maximum folder to check

# Get the path of the folders of each magnet position 
path_folder_mags = fd.askdirectory(title='Select the folder containing the %s files'%str_key_mag)
list_folder_mag = []

for file in os.listdir(path_folder_mags):
    # List the folders that contains the key for the magnet position 
    if str_key_mag in file:
        path_file = os.path.join(path_folder_mags, file)
        list_folder_mag.append(path_file)
# Number of magnet position    
#N_field = len(list_folder_mag)
N_data_set = 1 + i_max - i_min     
    


def inverse_uncertainty(A0, eA0):
    """
    Propagate the uncertainty in f(A) = 1/A. 
    The formula is more precise than typical error propagtion with 
    linearization. 
    
    Linearization (ie, propagating the uncertainty by assuming
    linear perturbation. Therfore using derivatives of the function) works when
    A is a "gaussian variable": its noise is well defined by a gaussian 
    distribution and not chopped. 
    
    Here, we extended this to the case where:
        - A is expected to be positive
        - The noise in A can be large compared to A. Such that A can be zero or 
          negative, despite the fact that it is expected to be positive (this 
          situation happens when the noise in A is large compared to A).
    
    In order to get the propagation of the error in such a situation, we used 
    Bayesian analysis and considered the mean and standard deviation of the 
    probability density function of f(A), when A is expected to be positive, 
    but can be measured negative or zero because of noise fluctuation. 
    
    For more info on the derivation of the formula, see the notebook of 
    Michael Caouette-Mansour on 2020-11-30,
    in the subsection "Careful error propagation of inverse". 
    
    Input parameters:
        A0:
            Measured mean value of A. Can be begative or zero. 
        eA0:
            Measured uncertainty in A. If zero, the function will return 1/A0
            
    return:
        z0:
            Expected value for f(A) = 1/A.
        ez0:
            Uncertainty in z0.
    """
    # If there is no uncertainty in A0, no need to propagate the uncertainty
    if eA0 == 0:
        # The uncertainty in f(A) is null.
        return 1/A0, 0 
    
    # A ratio used many time
    ratio = A0/(eA0*eA0)
    # A product used many time
    eA02 = eA0*eA0
    # Expectation for f(A). Formula comes from careful Bayes analysis.
    z0 = 0.25*( np.sqrt(ratio*ratio + 8/(eA02)) - ratio)
    # Second derivative of the logarithm of the pdf of f(A)
    z02 = z0*z0 # A quantity used many time
    dL2dz2 = 2*ratio/(z02*z0) + 2/z02 - 3/(eA02*z02*z02) 
    
    #Uncertainty in f(A). Formula comes from careful Bayes analysis.
    ez0 = 1/np.sqrt(-dL2dz2)
    # Here we go.
    return z0, ez0

def get_drift_indep_measurement(data_file):
    """
    Compute the drift independent measurement from the 4 data points. 
    
    data_file:
        (databox from spinmob) File of a single drift independent measurement
    """

    # =========================================================================
    # Get the number of readout
    # =========================================================================
    rep = data_file.headers['repetition']
    iteration  = data_file.headers['iteration']
    N_readout = rep*iteration

    # =========================================================================
    # Get the mean count and uncertainty of each data
    # =========================================================================    
    # ms=0 at t=0
    counts = np.sum(data_file['ms0_t0'])
    PL0_0  = counts/N_readout
    ePL0_0 = np.sqrt(PL0_0/N_readout)

    # ms=0 at t=t_probed
    counts = np.sum(data_file['ms0_tprobed'])
    PL0_t   = counts/N_readout
    ePL0_t  = np.sqrt(PL0_t /N_readout)  
    
    # ms=+-1 at t=0
    counts = np.sum(data_file['ms-+1_t0'])
    PL1_0  = counts/N_readout
    ePL1_0 = np.sqrt(PL1_0/N_readout) 
    
    # ms=+-1 at t=t_probed
    counts = np.sum(data_file['ms-+1_tprobed'])
    PL1_t  = counts/N_readout
    ePL1_t = np.sqrt(PL1_t/N_readout) 

    # =========================================================================
    # Compute the drift_independant measurement
    # =========================================================================        
    # Numerator and denominator
    Top = PL0_t - PL1_t
    Bot = PL0_0 - PL1_0
    eTop = np.sqrt(ePL0_t**2 + ePL1_t**2)
    eBot = np.sqrt(ePL0_0**2 + ePL1_0**2)
    # Compute carfefully the inverse of the bottom
    inv_bot, einv_bot = inverse_uncertainty(Bot, eBot)        
    # Finnaly, the resulting data that we use for Bayesian inference
    result = Top*inv_bot
    uncertainty = np.sqrt( (eTop*inv_bot)**2 + (einv_bot*Top)**2 )    
    
    return result, uncertainty
    
    
# Defines the models function        
def model_plus(t, gp, gm):
    """
    Expected result for the measurement involving initiating in ms=+1
    """
    g0 = np.sqrt(gm**2 + gp**2 - gp*gm )
    betap = gp + gm + g0
    betam = gp + gm - g0    
    
    term1 = (g0 + gp)*np.exp(-betap*t)
    term2 = (g0 - gp)*np.exp(-betam*t)
    
    return (term1 + term2)/(2*g0)

def model_minus(t, gp, gm):
    """
    Expected result for the measurement involving initiating in ms=-1
    """
    g0 = np.sqrt(gm**2 + gp**2 - gp*gm )
    betap = gp + gm + g0
    betam = gp + gm - g0    
    
    term1 = (g0 + gm)*np.exp(-betap*t)
    term2 = (g0 - gm)*np.exp(-betam*t)
    
    return (term1 + term2)/(2*g0) 


# =============================================================================
# Prepare the plot
# =============================================================================
plt.figure(figsize=(15, 8), tight_layout=True)  

# The first is the cloud of points. 
ax = plt.subplot(211)

# Process each set of data
list_gp = []
list_gm = []
list_egp = []
list_egm = []

ds = []

for kkk, folder_mag in enumerate( list_folder_mag ):
    
    if ( kkk >= i_min ) and ( kkk <= i_max ):
        
        # =============================================================================
        # Get the data
        # =============================================================================
        # Get the last infered rates 
        directory = folder_mag + '/' + folder_name_T1
        for file in os.listdir(directory):
            if key_file_T1 in file:
                path_file = os.path.join(directory, file)  
                ds.append( sm.data.load(path_file) )
              
    print('Taking care of data set %d'%kkk)
    
    # =============================================================================
    # Extract the drift-independant measurement
    # =============================================================================
    N_data_file = len(ds)
    
    # Store the drift independent measurement for each type of experiment
    result_plus_s  = []
    result_minus_s = []
    uncertainty_plus_s  = []
    uncertainty_minus_s = []
    t_probe_plus_s  = []
    t_probe_minus_s = []
    # For studying the sensitivity
    t_elapsed = np.zeros(N_data_file) # Total time elapsed
    egp_protocole = np.zeros(N_data_file) # Uncertainty in the rate form the protocole
    egm_protocole = np.zeros(N_data_file) # Uncertainty in the rate form the protocole
    
    # Extract each the measurement from each data file
    for i in range(N_data_file):
        # Get the data file
        d = ds[i]
        # Extract the time probed 
        t_probe = d.headers['t_probe']
        # Extract the drift_independent measurement from the file. 
        result, uncertainty = get_drift_indep_measurement(d)
        # Append the result depending on the type of measurement
        type_measurement = d.headers['Type_measure']    
        if type_measurement == +1:
            result_plus_s.append(result)
            uncertainty_plus_s.append(uncertainty)
            t_probe_plus_s.append(t_probe)
        elif type_measurement == -1:
            result_minus_s.append(result)
            uncertainty_minus_s.append(uncertainty)     
            t_probe_minus_s.append(t_probe)
        # For the sensitivity
        try:
            t_elapsed[i] = d.headers['Time'] - d.headers['Time_initial']
            egp_protocole[i] = d.headers['egamma_plus']
            egm_protocole[i] = d.headers['egamma_minus']
        except:
            pass
        
    # Get into numpy array
    result_plus_s       = np.array(result_plus_s)
    uncertainty_plus_s  = np.array(uncertainty_plus_s)
    result_minus_s      = np.array(result_minus_s)
    uncertainty_minus_s = np.array(uncertainty_minus_s) 
    t_probe_plus_s = np.array(t_probe_plus_s)   
    t_probe_minus_s = np.array(t_probe_minus_s)
    
    # =============================================================================
    # Estimate the rate with Bayes
    # =============================================================================
    # Initiate the object
    Gp_min = 10  # Hz
    Gp_max = 5e4 # Hz
    Gm_min = 10  # Hz
    Gm_max = 5e4 # Hz
    my_bayes = Bayes_optimal_rates.Bayes(Gp_min, Gp_max, Gm_min, Gm_max)
    # Feed the measurements plus
    for i in range(len(result_plus_s)):
        measurement = result_plus_s[i]
        uncertainty = uncertainty_plus_s[i]
        time_probed = t_probe_plus_s[i]*1e-6 # second
        my_bayes.give_measurement( measurement, uncertainty, 
                                       time_probed, type_measure=+1)
    # Feed the measurements minus
    for i in range(len(result_minus_s)):
        measurement = result_minus_s[i]
        uncertainty = uncertainty_minus_s[i]
        time_probed = t_probe_minus_s[i]*1e-6 # second
        my_bayes.give_measurement( measurement, uncertainty, 
                                       time_probed, type_measure=-1)
    # Estimate the rate
    means, stds, covs = my_bayes.get_parameters()
    gp_bayes  = means[0]*1e-3 # kHz
    egp_bayes = stds[0] *1e-3 # kHz
    gm_bayes  = means[1]*1e-3 # kHz
    egm_bayes = stds[1] *1e-3 # kHz 
    
    # List them
    list_gp[kkk] = gp_bayes
    list_gm[kkk] = gm_bayes
    list_egp[kkk] = egp_bayes
    list_egm[kkk] = egm_bayes

    # =============================================================================
    # Plot the Bayes inference 
    # =============================================================================
    parms = my_bayes.my_obe.parameters # This contains the arrays of each parameter
    txt_label = d.path.split('/')[-3] # Have a meaningfull label
    plt.scatter(parms[0]*1e-3, parms[1]*1e-3, color='C%d'%kkk, 
                alpha=0.1)
    # Plot a single point with alpha=1 for having the label clearer
    plt.scatter(parms[0][0]*1e-3, parms[1][0]*1e-3, color='C%d'%kkk, 
                alpha=1, label=txt_label)    
    
# Show the time trace estimate
if show_time_trace_rates:
    plt.errorbar(gp_time_trace, gm_time_trace, 
                         xerr=egp_time_trace, yerr=egm_time_trace,
                         fmt='.', color='k', label='Time trace data') 
# Enhance the plot
plt.legend()
plt.xlabel('Rate+ (kHz)')
plt.ylabel('Rate- (kHz)')    
plt.title(d.path, fontsize=8)

print('Done')
    
# The second is the value of the rates for each magnetpositon
ax = plt.subplot(212)
x_axis = np.arange(0, N_data_set)
plt.errorbar(x_axis, list_gp, yerr=list_egp, fmt='.-', label='$\Gamma_+$')
plt.errorbar(x_axis, list_gm, yerr=list_egm, fmt='.-', label='$\Gamma_-$')
plt.legend()
plt.ylabel('Rates (kHz)') 



## =============================================================================
## Fit the measurement for determining the rates
## =============================================================================
## Create the fitter object
#fitter = sm.data.fitter()
## Set the two function that we simultaneuously fit
#fitter.set_functions(['fp(x, gp, gm)', 'fm(x, gp, gm)'], 
#                      p='gp,gm', fp=model_plus, fm=model_minus)
## Set the data
#fitter.set_data([t_probe_plus_s*1e-3, t_probe_minus_s*1e-3], 
#                [result_plus_s, result_minus_s], 
#                [uncertainty_plus_s,uncertainty_minus_s])
##Set the guess
#guess_gp = 1 # (kHz)
#guess_gm = 1 # (kHz)
#fitter.set(gp=guess_gp, gm=guess_gm)
## Fit !
#fitter.fit()
## Extract the rates
#gp_fit  = fitter.results.params['gp'].value
#egp_fit = fitter.results.params['gp'].stderr
#gm_fit  = fitter.results.params['gm'].value
#egm_fit = fitter.results.params['gm'].stderr

## =============================================================================
## Plot the drift independant measurements with the fit 
## =============================================================================
#plt.figure(figsize=(8, 5), tight_layout=True)
## Plot the plus type of measurement
#ax = plt.subplot(211)
#t_fit = np.linspace(t_probe_plus_s.min(), t_probe_plus_s.max(), 300) # us
#y_fit = model_plus(t_fit*1e-3, gp_fit, gm_fit)
#plt.errorbar(t_probe_plus_s, result_plus_s, yerr=uncertainty_plus_s, 
#             fmt='.', label='Plus')
#plt.plot(t_fit, y_fit, label='Chi2 Fit')
#plt.legend()
#plt.xlabel('Time probed (us)')
#plt.ylabel('Drif indep')
#plt.title(d.path, fontsize=8)
## Plot the minus type of measurement
#ax = plt.subplot(212)
#t_fit = np.linspace(t_probe_minus_s.min(), t_probe_minus_s.max(), 300) # us
#y_fit = model_plus(t_fit*1e-3, gp_fit, gm_fit)
#plt.errorbar(t_probe_minus_s, result_minus_s, yerr=uncertainty_minus_s, 
#             fmt='.', label='Minus')
#plt.plot(t_fit, y_fit, label='Chi2 Fit')
#plt.legend()
#plt.xlabel('Time probed (us)')
#plt.ylabel('Drif indep')


        
## =============================================================================
## Plot the sensitivity
## =============================================================================
#try:
#    plt.figure(figsize=(8, 5), tight_layout=True)  
#    plt.loglog(t_elapsed/60, egp_protocole*1e-3, '.', label='eGamma+')
#    plt.loglog(t_elapsed/60, egm_protocole*1e-3, '.', label='eGamma-')
#    plt.legend()
#    plt.xlabel('Elapsed time (min)')
#    plt.ylabel('Uncertainty in rates (kHz)')    
#    plt.title(d.path, fontsize=8)
#except:
#    pass







## =============================================================================
## Verify a very rough analysis
## =============================================================================
#M = (PL0_t - PLpm_t)/(PL0_0 - PLpm_0)
#plt.figure(tight_layout=True)
#plt.errorbar(t_probe, M, yerr=0, fmt='.', markersize=10)
#plt.xlabel('Time probed (us)')
#plt.ylabel('f(4 measurements) (uniteless)')
#plt.title('Drift independent measurement')
#
#
## =============================================================================
## Verify Just the diference at t_probed
## =============================================================================
#diff  = PL0_t - PLpm_t
#ediff = np.sqrt((PL0_t + PLpm_t)/N_readout)
#plt.figure(tight_layout=True)
#plt.errorbar(t_probe, diff, yerr=ediff, fmt='.', markersize=10)
#plt.xlabel('Time probed (us)')
#plt.ylabel('Difference at t_probed')
#plt.title(d.path, fontsize=8)
#
#
## =============================================================================
## Plot each category of data and the drift independent measurement
## =============================================================================
#plt.figure(figsize=(8, 5), tight_layout=True)
#
## First plot the raw data
#ax = plt.subplot(211)
#plt.errorbar(t_probe, ms0_t0, yerr=ems0_t0, fmt='o', markersize=10,label='ms0_t0')
#plt.errorbar(t_probe, ms0_tp, yerr=ems0_tp, fmt='*', markersize=10,label='ms0_tprobe')
#plt.errorbar(t_probe, mspm_t0, yerr=emspm_t0, fmt='.', markersize=10,label='ms+-1_t0')
#plt.errorbar(t_probe, mspm_tp, yerr=emspm_tp, fmt='v', markersize=10,label='ms+-1_tprobe')
#plt.errorbar(t_probe, ref, yerr=eref, fmt='x', markersize=10,label='Reference')
#plt.legend()
#plt.xlabel('Time probed (us)')
#plt.ylabel('Count per readout')
#plt.title('Time trace of each measurement')
#
## Plot the famous drif-independant measurement. 
#ax = plt.subplot(212)
#plt.errorbar(t_probe, result, yerr=uncertainty, fmt='.', markersize=10)
#plt.xlabel('Time probed (us)')
#plt.ylabel('f(4 measurements) (uniteless)')
#plt.title(d.path+'\nDrift independent measurement', fontsize=8)
#


# Fit the distribution
#TODO fit them !






