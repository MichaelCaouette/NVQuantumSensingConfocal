# -*- coding: utf-8 -*-
"""
Created on Fri Oct  9 12:35:01 2020

Goal: Developper the Bayes inferencer
        For further information about the software OptBayesExp, go to 
        https://pages.nist.gov/optbayesexpt/quickstart.html

@author: Childresslab
"""


import numpy as np
from optbayesexpt import OptBayesExpt

import traceback
_p = traceback.print_last #Very usefull command to use for getting the last-not-printed error

# Debuger 
_debug_enabled     = False
def _debug(*a):
    if _debug_enabled: 
        s = []
        for x in a: s.append(str(x))
        print(', '.join(s))
        
        
# Defines the models function        
def model_plus(t, gp, gm):
    """
    Expected result for the measurement involving initiating in ms=+1
    """
    g0 = np.sqrt(gm**2 + gp**2 - gp*gm )
    betap = gp + gm + g0
    betam = gp + gm - g0    
    
    term1 = (g0 + gp)*np.exp(-betap*t)
    term2 = (g0 - gp)*np.exp(-betam*t)
    
    return (term1 + term2)/(2*g0)

def model_minus(t, gp, gm):
    """
    Expected result for the measurement involving initiating in ms=-1
    """
    g0 = np.sqrt(gm**2 + gp**2 - gp*gm )
    betap = gp + gm + g0
    betam = gp + gm - g0    
    
    term1 = (g0 + gm)*np.exp(-betap*t)
    term2 = (g0 - gm)*np.exp(-betam*t)
    
    return (term1 + term2)/(2*g0) 

def my_model_function(settings, parameters, constants):
   """Model function for using with the class OptBayesExp


   The ``(settings, parameters, constants)`` argument structure is required
   Args:
       settings (tuple or tuple of array(s)): knob settings
       parameters (tuple of arrays, or tuple): parameter distribution sample(s)
       constants (tuple): infrequently changed values
       
   settings:
       A tuple (tp, bool_plus_minus). With...
       tp:
           (float) Time probed. 
       plus_minus:
           (int) Either +1 or -1. If +1, the measurement will be with the ms=+1
           pi-pulse. Vice-versa for if -1. 
   parameters:
       A tuple (gp, gm). With...
       gp:
           (float) The rate gamma+. 
       gm:
           (float) The rate gamma-
   constant:
       Nothing. This is not used, because we are using a measurement independant
       of other parameter (Because the contrast and the fluorescence is drifting)
       
   CHOICE OF UNIT:
       As long as the rate times the time is uniteless. 

   Returns: a noise-free model value
   """
   # Unpack the arguments.  See the "Specify ..." sections in the text.
   time_probed, type_experiment = settings 
   (gp, gm) = parameters # Gamma + and gamma-
   _ = constants # There is no constant to unpack with this experiment. 
   
   # Here is a trick to use the setting "type_experiment" has an array without
   # Using the if-else condition. 
   # If type_experiment=+1, it returns model_plus. 
   # If type_experiment=-1, it returns model_minus
   # Note that if we really want to minimize the amount of computation, we 
   # could even simplify the expression by writting explicitally each model +-
   # and making algebraic simplifications. After making it on the back of an 
   # enveloppe, I noticed that we can reduce by almost half the amount of 
   # operation. Anyway. For now it is probably way more clear like this lol. 
   mp = model_plus (time_probed, gp, gm)
   mm = model_minus(time_probed, gp, gm)
   model_result = 0.5*(type_experiment+1)*mp +0.5*(1-type_experiment)*mm    
       
   return model_result
    
class OptBayesExptTwoRate(OptBayesExpt):
    """ An OptBayesExpt object designed for probing the decay rate. 
    
    This object is meant to overid the cost function of the base OptBayesExpt
    object (in the script "obe_base.py") 
    The cost function will be related to the time probed; Such that the best 
    time to probe is taken considering the cost that it takes to measure for a 
    a long time. 
    
    """

    def __init__(self, model_function, setting_values, parameter_samples,
                 constants):

        # Initiate the parent object with the corresponding parameter
        # It is the same input that the base object. 
        OptBayesExpt.__init__(self, model_function, setting_values,
                                  parameter_samples, constants)
        
        # (in second)  Extra time cosummed when changing the setting
        self.T_overhead = 0 
        
    def cost_estimate(self):
        """
        This overids the corresponding method of the parent object. 
        
        
        Estimate the cost of measurements, depending on settings

        The denominator of the *utility* function allows measurement
        resources (e.g. setup time + data collection time) to be entered
        into the utility calculation.

        Returns:
            :obj:`float`, otherwise an :obj:`ndarray` describing how
                measurement variance depends on settings.
        """
        
        # 'self.allsettings' is from the parent object
        # It is a tuple of two arrays. The first one contains all the time 
        # to explore with the algorithm. The second contains all the type of
        # experiment to explore with the algorithm. 
        t_probed = self.allsettings[0] # Extract all the possible time to probe. 

        # Determine the cost of selecting the setting. 
        cost = t_probed + self.T_overhead

        return cost

class Bayes():
    """
    Bayes inference for infering the rates, based on measurements that doesn't
    dependon drifting parameters, like the contrast and counts at t=0. 
    
#TODO Complete this section of comment. 
    The measurements consists of 4 data points... KEEP EXPLAINING THE 
    MEASUREMENT PLEASE. 
    
    This class is used for:
        - Give a measurement + or -
        - Determine the best settings (time to probe and type of measurement)
        - Infer the rates with uncertainty from Bayes theorem.
        
    """

    def __init__(self, Gp_min, Gp_max, Gm_min, Gm_max,
                 gaussian_prior=False):
        """
        The user initiates the class by telling:
            - The bounds of the rates
            - That's pretty much it. 

        Input parameters:
            Gp_min:
                (float) Minimum value that the rate+ can take. 
            Gp_max:
                (float) Maximum value that the rate+ can take. 
            Gm_min:
                (float) Minimum value that the rate- can take. 
            Gm_max:
                (float) Maximum value that the rate- can take.  
            gaussian_prior:
                (Boolean) If True, the prior distribution in the parameters 
                will be taken to be Gaussian, with mean and width from the 
                boundary. If False, the prior distribution will be flat (no
                particular value within the range is prefered)
        """
        
        # =====================================================================
        # Prepare the parameters to infer      
        # =====================================================================
        # How many sample to generate for each parameter
        self.n_samples_parameters = 5000 
        
        if gaussian_prior:
            # Here we think that the rate is most probably in one value, but 
            # With the widt sets by the minimum and maximum
            # Determine the mean and width
            m_gp = 0.5*(Gp_max + Gp_min)
            w_gp = 0.5*(Gp_max - Gp_min)
            m_gm = 0.5*(Gm_max + Gm_min)
            w_gm = 0.5*(Gm_max - Gm_min)
            # Let's keep just the positive values from the sample, because we 
            # know, a priori, that the rates are positive. 
            sample = np.random.normal(m_gp, w_gp, self.n_samples_parameters) 
            self.gp_sample = sample[np.where(sample>=0)]
            sample = np.random.normal(m_gm, w_gm, self.n_samples_parameters)  
            self.gm_sample = sample[np.where(sample>=0)]
            # Gatther the samples of each parameter in a tuple
            self.parameter_samples = (self.gp_sample, self.gm_sample)           
            
        else:
            # Here we think that the rate is between a minimum and maximum value, 
            # without preference for any value between. 
            self.gp_sample = np.random.uniform(Gp_min, Gp_max, 
                                          self.n_samples_parameters)   
            self.gm_sample = np.random.uniform(Gm_min, Gm_max, 
                                          self.n_samples_parameters) 
            # Gatther the samples of each parameter in a tuple
            self.parameter_samples = (self.gp_sample, self.gm_sample)
        
        # =====================================================================
        # Prepare the settings to adapt   
        # =====================================================================
        # We have a continuous parameter. Therefore it has to be discretized
        self.n_sample_setting = 4000 # How many sample to explore.
        self.time_probed_sample = np.linspace(0.1/Gm_max, 1/Gm_min, 
                                           self.n_sample_setting)
        # The type of measurement to make will also be a setting
        # +1 means the measurement +, and vice versa for -1
        self.type_measure_sample = (1, -1)
        self.setting_values = (self.time_probed_sample, 
                               self.type_measure_sample)                

        # =====================================================================
        # Prepare the constant of the experiment
        # =====================================================================                
        # In this case we do not have constant
        self.constants = ( )        
        
        # =====================================================================
        # Create an instance of the OptBayesExpt class
        # =====================================================================   
        # We are using our own class
        self.my_obe = OptBayesExptTwoRate(my_model_function, 
                                          self.setting_values,
                                          self.parameter_samples,
                                          self.constants)    
        # =====================================================================
        # Refine the grid of time probed. Hopefully it will avoid outliers
        # =====================================================================   
        self._refine_setting()
        
    def _refine_setting(self):
        """
        Refine the grid of the time_probed to explore. 
        The new grid of t_probed will be considering the best estimates of the 
        rates with there uncertainties.
        """
        _debug('Bayes: _refine_setting')
        
        # Get the best estimate and uncertainty on the rate so far
        rates, erates = (self.my_obe.mean(), self.my_obe.std())
        gp , gm  =  rates
        egp, egm = erates
        _debug('Bayes: get_best_setting: refining grid with:')
        _debug('gp = %f +- %f kHz'%(gp, egp))
        _debug('gm = %f +- %f kHz'%(gm, egm))
        # Determine a metric for gauging the time to probe
        g0_min = np.sqrt((gp-egp)**2 + (gm-egm)**2)
        g0_max = np.sqrt((gp+egp)**2 + (gm+egm)**2)
        # Rebuild the settings value
        self.time_probed_sample = np.linspace(0.1/g0_max, 2/g0_min, 
                                           self.n_sample_setting)
        self.setting_values = (self.time_probed_sample, 
                               self.type_measure_sample)     
        # Modifify the obe_base class
        self.my_obe.setting_values = self.setting_values
        self.my_obe.allsettings = [s.flatten() for s in
                            np.meshgrid(*self.setting_values, 
                                        indexing='ij')]
        lenght = len(self.my_obe.allsettings[0])
        self.my_obe.setting_indices = np.arange(lenght)  
        
    def get_best_setting(self, pickiness=-1, refine_grid=False):
        """
        Get the best setting for the next experiment. It considers the model 
        and the given data so far. Based on that, it determines the settings
        that will maximize the information gain, divided by the cost. 
        
        To know more about how the best settings are choosen, see the 
        documentation here:
        https://pages.nist.gov/optbayesexpt/manual.html
        
        Optionnal input parameter:
            pickiness:
                (float) If above 0, the setting will be choosen less than
                optimal. The value should range between 0 and 10. A value of 0 
                indicates random setting. A value of 10 and above will be 
                optimal settings. A value in between determines the degree 
                of slopiness.
            refine_grid:
                (Boolean) If True, the possible settings and parameters to 
                expore will be refine according to the actual knowledge of the 
                rate.
        
        Return:
            (Tuple of size 2)
            time_probed, type_measure
            Float and int, corresponding to the best time to probe and the best
            type of measurement to make.
        
        """
        _debug('Bayes: get_best_setting')
        
        # Refine the boudary of the parameters and setting to explore. 
        if refine_grid:
            self._refine_setting()
        
        # We unpack and pack the settings. Just for clarity.  
        if pickiness > 0:
            # An alternative method, which allows some sloppyness.
            time_probed, type_measure =  self.my_obe.good_setting(pickiness=pickiness)
        else:
            # Choose optimal setting
            time_probed, type_measure = self.my_obe.opt_setting()
            
        return (time_probed, type_measure)
        
        
    def give_measurement(self, measurement, uncertainty, 
                               time_probed, type_measure):
        """
        Feed the algorithm with a measurement.
        
        Input Parameters
        measurement:
            (float) Measurement which is modelized by the model function. 
        uncertainty:
            (float) Uncertainty in the measurement. 
        time_probed:
            (float) Time probed at which the measurement was made. 
        type_measure:
            (+1 or -1) Type of the measurement. +1 means the measurement + and
            -1 means the measurement -. 
            
        Return:
            Nothing. 
        """
        _debug('Bayes: give_measurement')
        
        # Gather the settings in a tuple
        settings = (time_probed, type_measure)
        # Hather the information about the measurement as a tuple
        information = (settings, measurement, uncertainty)
        # Report the information
        self.my_obe.pdf_update(information)      
        
        return
    
    def get_parameters(self):
        """
        Infer the parameter, by using Bayes Theorem on the data. 
        
        Return a Tuple of size 3:
        First element:
            (array of float) Mean of each parameter. 
            Explicitly, it is [gamma+, gamma-].
        Second element:
            (array of float) Standard deviation of each parameter.
            Explicitly, it is [error in gamma+, error in gamma-].
        Third element:
            (Array of arrays, or numpy matrix) Covariance matrix of the 
            parameters.
            
        """
        _debug('Bayes: get_parameters')
        
        return (self.my_obe.mean(), self.my_obe.std(), self.my_obe.covariance())

        
        
        
        
if __name__=="__main__":
    """
    The following code is executed only when this script is run alone. 
    It is only meant to test the code above. 
    """
    _debug_enabled = True
 
    # Define the expected individual photoluminescence because we want to 
    # simulate measurements
    # Otherwise the three following functions are not necessary to implement in 
    # the in-lab experiment. 
    def expected_ms0(PL0, C, t, gamma_p, gamma_m):
        """
        Return the expected count per readout when initializing ms=0 and
        reading ms=0. 
        
        PL0:
            (float) Count per readout of the state ms=0 at time equal0
        C:
            (float) Contrast in photoluminescence from the ms=+-1 state. 
            This is defined such that the photoluminescence coming from ms=+-1 
            is PL0*(1-C)
        t:
            (float) Time elapsed after the initialization of the states. 
        gamma_p:
            (float or grid of float): Rate gamma +
        gamma_m:
            (float or grid of float): Rate gamma -
            
        """
        A = PL0*(1-C*2/3)
        
        gamma_0 = np.sqrt(gamma_p*gamma_p + gamma_m*gamma_m - gamma_p*gamma_m)
        beta_p = gamma_p + gamma_m + gamma_0
        beta_m = gamma_p + gamma_m - gamma_0        
        
        term1 = (2*gamma_0 + gamma_p + gamma_m)*np.exp(-beta_p*t)
        term2 = (2*gamma_0 - gamma_p - gamma_m)*np.exp(-beta_m*t)
        
        return A + (term1 + term2)*C*PL0/(6*gamma_0)
    
    def expected_msp(PL0, C, t, gamma_p, gamma_m):
        """
        Return the expected count per readout when initializing ms=+1 and
        reading ms=0. 
        
        PL0:
            (float) Count per readout of the state ms=0 at time equal0
        C:
            (float) Contrast in photoluminescence from the ms=+-1 state. 
            This is defined such that the photoluminescence coming from ms=+-1 
            is PL0*(1-C)
        t:
            (float) Time elapsed after the initialization of the states. 
        gamma_p:
            (float or grid of float): Rate gamma +
        gamma_m:
            (float or grid of float): Rate gamma -
            
        """
        
        A = PL0*(1-C*2/3)
        
        gamma_0 = np.sqrt(gamma_p*gamma_p + gamma_m*gamma_m - gamma_p*gamma_m)
        beta_p = gamma_p + gamma_m + gamma_0
        beta_m = gamma_p + gamma_m - gamma_0        
        
        term1 = (gamma_0 + 2*gamma_p - gamma_m)*np.exp(-beta_p*t)
        term2 = (gamma_0 - 2*gamma_p + gamma_m)*np.exp(-beta_m*t)
        
        return A - (term1 + term2)*C*PL0/(6*gamma_0)    
    
    def expected_msm(PL0, C, t, gamma_p, gamma_m):
        """
        Return the expected count per readout when initializing ms=-1 and
        reading ms=0. 
        
        PL0:
            (float) Count per readout of the state ms=0 at time equal0
        C:
            (float) Contrast in photoluminescence from the ms=+-1 state. 
            This is defined such that the photoluminescence coming from ms=+-1 
            is PL0*(1-C)
        t:
            (float) Time elapsed after the initialization of the states. 
        gamma_p:
            (float or grid of float): Rate gamma +
        gamma_m:
            (float or grid of float): Rate gamma -
            
        """
        A = PL0*(1-C*2/3)
        
        gamma_0 = np.sqrt(gamma_p*gamma_p + gamma_m*gamma_m - gamma_p*gamma_m)
        beta_p = gamma_p + gamma_m + gamma_0
        beta_m = gamma_p + gamma_m - gamma_0        
        
        term1 = (gamma_0 + 2*gamma_m - gamma_p)*np.exp(-beta_p*t)
        term2 = (gamma_0 - 2*gamma_m + gamma_p)*np.exp(-beta_m*t)
        
        return A - (term1 + term2)*C*PL0/(6*gamma_0)          

    def inverse_uncertainty(A0, eA0):
        """
        Propagate the uncertainty in f(A) = 1/A. 
        The formula is more precise than typical error propagtion with 
        linearization. 
        
        Linearization (ie, propagating the uncertainty by assuming
        linear perturbation. Therfore using derivatives of the function) works when
        A is a "gaussian variable": its noise is well defined by a gaussian 
        distribution and not chopped. 
        
        Here, we extended this to the case where:
            - A is expected to be positive
            - The noise in A can be large compared to A. Such that A can be zero or 
              negative, despite the fact that it is expected to be positive (this 
              situation happens when the noise in A is large compared to A).
        
        In order to get the propagation of the error in such a situation, we used 
        Bayesian analysis and considered the mean and standard deviation of the 
        probability density function of f(A), when A is expected to be positive, 
        but can be measured negative or zero because of noise fluctuation. 
        
        For more info on the derivation of the formula, see the notebook of 
        Michael Caouette-Mansour on 2020-11-30,
        in the subsection "Careful error propagation of inverse". 
        
        Input parameters:
            A0:
                Measured mean value of A. Can be begative or zero. 
            eA0:
                Measured uncertainty in A. If zero, the function will return 1/A0
                
        return:
            z0:
                Expected value for f(A) = 1/A.
            ez0:
                Uncertainty in z0.
        """
        # If there is no uncertainty in A0, no need to propagate the uncertainty
        if eA0 == 0:
            # The uncertainty in f(A) is null.
            return 1/A0, 0 
        
        # A ratio used many time
        ratio = A0/(eA0*eA0)
        # A product used many time
        eA02 = eA0*eA0
        # Expectation for f(A). Formula comes from careful Bayes analysis.
        z0 = 0.25*( np.sqrt(ratio*ratio + 8/(eA02)) - ratio)
        # Second derivative of the logarithm of the pdf of f(A)
        z02 = z0*z0 # A quantity used many time
        dL2dz2 = 2*ratio/(z02*z0) + 2/z02 - 3/(eA02*z02*z02) 
        
        #Uncertainty in f(A). Formula comes from careful Bayes analysis.
        ez0 = 1/np.sqrt(-dL2dz2)
        # Here we go.
        return z0, ez0
    
    # =========================================================================
    # Parameter for simulating the data
    # =========================================================================
    N_hit = 8e5   # number of readout at the single time to probe
    C   = 0.15  # Optical Contrast between the states 
    PL0 = 0.05 # Mean count of ms=0
    true_gp = 0.1*1e3 # Experimental true rate
    true_gm = 0.05*1e3  # Experimental true rate
    
    # Test the Bayes class with a measurement of thetwo type of difference 
    # Define the grid for th rates
    Gp_min = 0.01*1e3   #Minimum guess for gamma plus (Hz) 
    Gp_max = 10*1e3  #Maximun guess for gamma plus (Hz)        
    Gm_min = 0.01*1e3   #Minimum guess for gamma minus (Hz) 
    Gm_max = 10*1e3  #Maximun guess for gamma minus (Hz)  
    n_adapt = 50 # Number of adaption to perform. 
    
    # =========================================================================
    # Initiate the algorithm
    # =========================================================================
    self = Bayes(Gp_min, Gp_max, Gm_min, Gm_max)

    # =========================================================================
    # Simulate running the experiment in the lab
    # =========================================================================    
    # Initiate some usefull array for the keeping track of thinks. 
    best_gp  = np.zeros(n_adapt) # Best gamma+ infered
    best_egp = np.zeros(n_adapt) # Error in the best gamma+ infered
    best_gm  = np.zeros(n_adapt) # Best gamma- infered
    best_egm = np.zeros(n_adapt) # Error in the best gamma- infered
    t_probed_p_s = []  # Time probed for the plus measurement at each iteration
    t_probed_m_s = []  # Time probed for the minus measurement at each iteration
    iterations = np.arange(n_adapt) # Number of iteration performed
    measurement_p_s    = [] # Measurement of the type "plus"
    emeasurement_p_s   = [] # uncertainty in the measurement of the type "plus"
    measurement_m_s    = [] # Measurement of the type "minus"
    emeasurement_m_s   = [] # uncertainty in the measurement of the type "minus"
    type_measurement_s = np.zeros(n_adapt) # Will containt +1 or -1 for the type of experiment
    time_cpu           = np.zeros(n_adapt) # CPU processing time
    time_measurement   = np.zeros(n_adapt) # Experiement time
    import time
    
    # Now loop over each measurement
    for i in range(n_adapt):
        
        # Print the update of the protocol each certain iteration
        if i%10 == 0:
            print('')
            print('Iteration %d / %d'%(i, n_adapt))
                
        t0 = time.time() # The following is considered CPU time
        # Determine the best setting
        if i%20 == 19:
            # Also refine the grid
            t_probed, type_measure = self.get_best_setting(refine_grid=True)
        else:
            t_probed, type_measure = self.get_best_setting()
        #Update CPU time
        time_cpu[i] += time.time() - t0         
        
        # Fake the data, depending on the type of measurement
        if type_measure == +1:
            # Note the type of measurement
            type_measurement_s[i] = +1
            
            # Measurement with ms=+1
            # Get the mean value
            mean0_t =  expected_ms0(PL0, C, t_probed, true_gp, true_gm)
            mean0_0 =  expected_ms0(PL0, C, 0       , true_gp, true_gm)
            meanp_t =  expected_msp(PL0, C, t_probed, true_gp, true_gm)
            meanp_0 =  expected_msp(PL0, C, 0       , true_gp, true_gm)
            # Add poissonian noise
            PL0_t =  np.random.poisson(N_hit*mean0_t)/N_hit
            PL0_0 =  np.random.poisson(N_hit*mean0_0)/N_hit
            PLp_t =  np.random.poisson(N_hit*meanp_t)/N_hit
            PLp_0 =  np.random.poisson(N_hit*meanp_0)/N_hit  
            
            # Combine the results for a measurement independent of PL0 and C
            Top = PL0_t - PLp_t
            Bot = PL0_0 - PLp_0
            # Get the uncertainty in the measurement
            eTop2 = (PL0_t + PLp_t)/N_hit # Square of the uncertainty
            eBot = np.sqrt( (PL0_0 + PLp_0)/N_hit )
            # Compute carfefully the inverse of the bottom
            inv_bot, einv_bot = inverse_uncertainty(Bot, eBot)
            # Finnaly, the resulting data that we use for Bayesian inference
            result = Top*inv_bot
            uncertainty = np.sqrt( eTop2*inv_bot**2 + einv_bot**2*Top**2 ) 
            
            # Record some information specific to this type of measurement
            t_probed_p_s    .append(t_probed)
            measurement_p_s .append(result)
            emeasurement_p_s.append(uncertainty)
            
        elif type_measure == -1:
            # Note the type of measurement
            type_measurement_s[i] = -1
            # Measurement with ms=+1
            # Get the mean value
            mean0_t =  expected_ms0(PL0, C, t_probed, true_gp, true_gm)
            mean0_0 =  expected_ms0(PL0, C, 0       , true_gp, true_gm)
            meanm_t =  expected_msm(PL0, C, t_probed, true_gp, true_gm)
            meanm_0 =  expected_msm(PL0, C, 0       , true_gp, true_gm)
            # Add poissonian noise
            PL0_t =  np.random.poisson(N_hit*mean0_t)/N_hit
            PL0_0 =  np.random.poisson(N_hit*mean0_0)/N_hit
            PLm_t =  np.random.poisson(N_hit*meanm_t)/N_hit
            PLm_0 =  np.random.poisson(N_hit*meanm_0)/N_hit  
            
            # Combine the result for a measurement independent of PL0 and C
            Top = PL0_t - PLm_t
            Bot = PL0_0 - PLm_0
            # Get the uncertainty in the measurement
            eTop2 = (PL0_t + PLm_t)/N_hit  # Square of the uncertainty
            eBot = np.sqrt( (PL0_0 + PLm_0)/N_hit  )
            # Compute carfefully the inverse of the bottom
            inv_bot, einv_bot = inverse_uncertainty(Bot, eBot)
            # Finnaly, the resulting data that we use for Bayesian inference
            result = Top*inv_bot
            uncertainty = np.sqrt( eTop2*inv_bot**2 + einv_bot**2*Top**2 ) 
    
            # Record some information specific to this type of measurement
            t_probed_m_s    .append(t_probed)
            measurement_m_s .append(result)
            emeasurement_m_s.append(uncertainty)
            
        print('t_probed*true_gp = ', t_probed*true_gp)
            
        t0 = time.time() # The following is considered CPU time
        # Feed the algorithm with the measurement
        self.give_measurement(result, uncertainty, 
                               t_probed, type_measure)
        #Update CPU time
        time_cpu[i] += time.time() - t0 
        
        # Record the infered parameters
        means, stds, covs = self.get_parameters()
        best_gp[i]  = means[0]
        best_egp[i] = stds[0]
        best_gm[i]  = means[1]
        best_egm[i] = stds[1]
        # Record the experimental time
        time_measurement[i] = N_hit*t_probed

    # Transform the lists into numpy array
    t_probed_p_s = np.array(t_probed_p_s) 
    t_probed_m_s = np.array(t_probed_m_s)
    measurement_p_s    = np.array(measurement_p_s)
    emeasurement_p_s   = np.array(emeasurement_p_s)
    measurement_m_s    = np.array(measurement_m_s)
    emeasurement_m_s   = np.array(emeasurement_m_s)
    
    #Update the total time
    time_total = time_measurement + time_cpu
    time_cum   = np.cumsum(time_total)
    
    # Compute the sensitivity
    eta_p_s = best_egp*np.sqrt(time_cum)
    eta_m_s = best_egm*np.sqrt(time_cum)
        
    # =========================================================================
    ### Let's now plot nice results for gamma+
    # =========================================================================
    import matplotlib.pyplot as plt
    plt.figure(figsize=(8, 5), tight_layout=True)
    # (1) Plot the infered rates
    #
    # 2 rows, 2 columns, Select the first plot
    ax = plt.subplot(221)
    # measurement data
    plt.errorbar(iterations, best_gp*1e-3, yerr=best_egp*1e-3, color='C0',
                 marker='.', linestyle='', label='Gamma+')
    plt.errorbar(iterations, best_gm*1e-3, yerr=best_egm*1e-3, color='C1',
                 marker='.', linestyle='', label='Gamma-')
    plt.plot([iterations[0], iterations[-1]], [true_gp*1e-3, true_gp*1e-3],
             '--', label='True gamma+', color='C0')
    plt.plot([iterations[0], iterations[-1]], [true_gm*1e-3, true_gm*1e-3],
             '--', label='True gamma-', color='C1')
    plt.legend()
    plt.xlabel("No. of adaptation")
    plt.ylabel("Infered rates (kHz)")
    plt.text(0.02, .9, '(a)', transform=ax.transAxes)
    xlims = plt.xlim()
    
    # (2) plot the true curve and the "measured" data
    #
    # second plot (next to the first)
    ax = plt.subplot(222)
    # Compute the true curves
    t = np.linspace(0, 2/true_gp, 200)
    yp = model_plus (t, true_gp, true_gm)
    ym = model_minus(t, true_gp, true_gm)
    plt.plot(t*1e6, yp, label='True model +', color='C0')
    plt.plot(t*1e6, ym, label='True model -', color='C1')
    # Show the measurements
    plt.errorbar(t_probed_p_s*1e6, measurement_p_s, yerr=emeasurement_p_s, 
                marker='.', linestyle='', label='Measurement +', color='C0')
    plt.errorbar(t_probed_m_s*1e6, measurement_m_s, yerr=emeasurement_m_s, 
                marker='.', linestyle='', label='Measurement -',color='C1')
    plt.legend()
    plt.xlabel("Time (us)")
    plt.ylabel("Mean counts")
    plt.text(0.02, .90, '(b)', transform=ax.transAxes)
    # This is useful for having another plot with the same limits
    xlims = plt.xlim() 
    
    # (3) plot the evolution of the std in the infered parameters
    #
    # Third plot (below the first)
    ax = plt.subplot(223)
    plt.loglog(iterations + 1, best_egp*1e-3, '.', label='Gamma+')
    plt.loglog(iterations + 1, best_egm*1e-3, '.', label='Gamma-')
    plt.legend()
    plt.ylabel("Uncertainty in rate (kHz)")
    plt.xlabel("No. of adaptation")
    plt.text(0.02, .1, '(c)', transform=ax.transAxes)
    
    # (4) plot a histogram of the adapted parameter
    #
    # Third plot (below the first)
    ax = plt.subplot(224)
    plt.hist(t_probed_p_s*1e6, bins=10, label='Measurement +', alpha=0.5)
    plt.hist(t_probed_m_s*1e6, bins=10, label='Measurement -', alpha=0.5)
    plt.legend()
    plt.ylabel("Time density")
    plt.xlabel("Time (us)")
    plt.text(0.02, .90, '(d)', transform=ax.transAxes)
    plt.xlim(xlims) # Have the same limit in the x-axis such that it is easy to compare        
            
    # =========================================================================
    ### Verify what best time was choosen 
    # =========================================================================         
    plt.figure(figsize=(8, 5), tight_layout=True)
    
    # First plot show the histogram after choppinf the outlier
    ax = plt.subplot(211)
    # Chop the outliers
    Nstd = 2 # Number of standard deviation away from the mean of the distribution
    meanp = np.mean(t_probed_p_s)
    meanm = np.mean(t_probed_m_s)
    stdp = np.std(t_probed_p_s)
    stdm = np.std(t_probed_m_s)
    binp = np.linspace(0, 2/true_gp, 50)
    binm = np.linspace(0, 2/true_gm, 50)
    true_g0 = np.sqrt(true_gp**2 + true_gm**2)
    plt.hist(t_probed_p_s*true_g0, bins=binp*true_g0, label='Measurement +', 
             alpha=0.5)
    plt.hist(t_probed_m_s*true_g0, bins=binm*true_g0, label='Measurement -', 
             alpha=0.5)
    plt.legend()
    plt.ylabel("Density of occurence")
    plt.xlabel("T_probe * sqrt(sum square rates)")
    plt.text(0.02, .90, '(d)', transform=ax.transAxes)
    
    # Second plot shows the time probed in scale
    ax = plt.subplot(212)
    plt.plot(t_probed_p_s*1e6, '.-', label='Measure +')
    plt.plot(t_probed_m_s*1e6, '.-', label='Measure -')
    plt.legend()
    plt.xlabel('Iterations')
    plt.ylabel('Time probed (us)')            
            
    # =========================================================================
    ### Verify the time elapsed and the sensitivity
    # =========================================================================         
    plt.figure(figsize=(8, 5), tight_layout=True)        
    
    # First plot the histograms of the times
    ax = plt.subplot(211)        
#    plt.hist(time_total*1e6, label='Total',alpha=0.5)
    plt.hist(time_cpu*1e3, label='CPU', alpha=0.5)
    plt.legend()
    plt.xlabel('Time at each adapation (ms)')
    plt.ylabel('Occurence')
    
    # Second, plot the sensitivity
    ax = plt.subplot(212)   
    plt.plot(time_cum/60, eta_p_s*1e-3, label='Rate+')
    plt.plot(time_cum/60, eta_m_s*1e-3, label='Rate-')
    plt.legend()
    plt.xlabel('Accumulated time (min)')
    plt.ylabel('Sensitivity (kHz/sqrt(Hz))')
    
    # =========================================================================
    ### Plot the cloud of parameters
    # =========================================================================  
    parms = self.my_obe.parameters # This contains the arrays of each parameter
    plt.figure(figsize=(8, 5), tight_layout=True)  
    plt.scatter(parms[0]*1e-3, parms[1]*1e-3, color='k', alpha=0.1)
    # Show the true value 
    plt.plot(true_gp*1e-3, true_gm*1e-3, 'Xr', 
            markersize=20, label='True value')   
    plt.legend()
    plt.xlabel('Rate+ (kHz)')
    plt.ylabel('Rate- (kHz)')    
    plt.title('Cloud of parameter')
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        


